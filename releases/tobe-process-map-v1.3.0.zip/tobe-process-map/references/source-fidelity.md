# As-Is 원본 보존 (v1.2.0)

입력 HTML은 **원본 화면의 기준**, Excel은 업무 행과 속성의 기준이다. 원본 HTML을 To-be 엔진의 좌표·레인·연결선 규칙으로 다시 그려서 '원본 그대로'라고 표시하지 않는다.

## 생성 방법

1. Excel을 빠짐없이 파싱한다. HTML이 같이 제공되면 `parse_excel.py ... --source-html 원본.html`의 엄격한 행 대응을 사용한다. 빈 ID를 이유로 업무 행을 버리지 않는다.
2. `python scripts/source_asis.py capture 원본.html work/asis.json`을 실행한다. `asis.json.source_html`에 입력 파일의 바이트(base64), SHA-256, DATA 및 저장 편집을 반영한 스냅샷, HTML ID↔Excel ID 대응, 범위 차이를 기록한다.
3. `structure.py`는 `const/let/var DATA = JSON`과 선택적 `s04SavedEdits`를 읽는다. ID가 다르면 sourceRows와 업무명 원문이 함께 일치하는 경우만 연결한다. 다의적인 대응이나 미지원 구조를 순차선으로 대체하지 않는다.
4. 원본은 최종 PMD의 `sourceAsis`로 전달한다. As-Is 탭은 원본 HTML 자체를 `sandbox="allow-scripts allow-downloads"` iframe에서 실행한다. 원본의 Lv.4·5·6 배치, 레인, 분기·병행·조건·환류선, 명칭과 라벨을 원래 렌더러가 표시한다. To-be의 레인·정렬·필터는 원본에 적용되지 않는다.
5. 원본 화면의 레벨·단계 선택 및 내보내기는 원본 내부 조작부를 사용한다. 부모 탭의 As-Is↔To-be 전환 및 전체 HTML 저장은 유지한다. 원본 내부에서 한 편집은 그 원본의 저장 기능으로 내보낸 뒤 새 입력으로 다시 적용한다. 부모 HTML 저장이 내부 편집을 자동 환류한다고 주장하지 않는다.
6. `source_asis.py verify work/asis.json` 및 최종 HTML의 내장 sourceAsis 검증을 수행한다. 바이트 또는 스냅샷이 달라지면 배포를 중단한다. 브라우저 QA는 iframe의 실제 가시 화면을 검사하고 숨겨진 재구성 As-Is를 검증 대상으로 쓰지 않는다.

## 다른 입력 간 차이

HTML과 Excel의 범위가 다르면 `scope_difference`와 입력 감사에 남긴다. 같은 개수라고 가정하지 않으며, 해석을 위해 원본 노드를 임의 제거하지 않는다. 제공된 CRM 예시는 빈 Excel ID 56개가 파서에서 누락된 문제였으므로 원본 HTML의 행번호·업무명·계층을 근거로 복원한다. 각 복원의 근거를 남긴다.

원본과 다른 ID를 사용하는 분석용 그래프에는 타입을 명시적으로 대응한다: std→s, conditional/cond→b, rework→r, parallel/fork→p, join→s(다중 유입으로 합류). **이는 분석용 대응이며 화면 재생 규칙이 아니다.** 원본 화면과 원본 엣지 내보내기는 snapshot의 원래 타입·라벨·확장 필드를 그대로 쓴다. 알 수 없는 타입은 오류로 보고한다.

사용자 답변이 없으면 `structure.confirmed=false`, `answer=""`로 기록한다. 원천 확인(`source_verified`)과 사용자 승인(`confirmed`)을 구분한다. 답변이 없다는 이유로 원천의 특수 화살표를 순차선으로 바꾸지 않는다.

## 검증 범위

실제 CRM 예시는 std/fork/join을 포함한다. conditional·rework·빈 edge 목록·저장 편집 우선·변조·Excel 변경은 별도 회귀 테스트로 검증한다. 바이트 보존만으로 원본 화면의 기존 가독성 문제까지 해결됐다고 주장하지 않는다. 원본 HTML이 오프라인에서 실행되는지도 실제 브라우저에서 확인한다.
