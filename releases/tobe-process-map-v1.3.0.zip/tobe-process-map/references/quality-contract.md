# v1.2.0 품질 계약

## 구조 변경 근거

```json
{
  "mode": "restructure",
  "design_contract": {
    "version": 1,
    "redesign": [{
      "scope": "실제 As-Is Lv.4 ID 또는 g4 키",
      "kind": "merge",
      "source_ids": ["A1", "A2"],
      "tobe_ids": ["T1"],
      "reason": "같은 자료를 조직별로 다시 수집하는 중복 해소",
      "evidence": "A1/A2가 요구하는 공통 원천을 T1에서 한번 수집해 다음 판단에 전달"
    }]
  }
}
```

모든 원본 Lv.4를 변경 또는 유지 검토에 포함한다. 실제 사용 가능한 키는 A5의 g4id → g4 → l4id 순이다. kind는 merge, regroup, reorder, parallelize, relocate, remove, retain이다.
각 주장에 연결된 실제 ref·Lv.5 소속·전후 연결을 검증한다. retain은 constraint(유지해야 하는 실제 제약)를 추가한다. 모든 범위를 retain으로 처리한 결과는 재설계 산출물로 통과하지 않는다. 이는 강제로 구조를 망가뜨리라는 의미가 아니며, 타당한 구조 변화가 불가능하면 분석 결과와 제약을 설명한다.
명칭/담당/ID만 바꾼 전면 1:1 그래프, 근거 없이 붙인 merge 문구, 인간 승인 박스 추가만으로 혁신이라고 주장하는 설계는 실패한다. 자동 검사는 필요한 최소 기준이며 변화의 충분성·업무적 유효성은 근거를 읽고 별도로 QA한다.

## 사람 개입 계약

각 A 노드에 아래처럼 human_review를 둔다. 사람이 필요 없는 경우도 required=false와 해당 업무별 reason이 필수다.

```json
{
  "T1": {
    "t": "A", "sub": "S1", "l5": "T5-1", "lb": "비교 자료 작성",
    "ref": ["A1", "A2"], "role": "A-작성", "role_why": "정해진 기준의 자료 취합",
    "io": {"out": "비교 자료", "to": "T2"},
    "human_review": {
      "required": true, "reason": "대상 선정에는 책임자의 판단이 필요",
      "decision_node": "T2", "continue_to": ["T3"], "rework_to": ["T1"]
    }
  },
  "T2": {
    "t": "N", "lane": "crm", "l5": "T5-1", "lb": "대상 확정",
    "role": "H-최종", "role_why": "최종 대상의 책임있는 결정",
    "io": {"inp": "비교 자료", "out": "승인 결과"}
  }
}
```

```json
"tobe_flow": [["T1","T2","s","검토 요청"], ["T2","T3","b","승인"], ["T2","T1","r","보완 필요"]]
```

- T2는 실제 사람 레인에 있어야 하고 sub를 지정하지 않는다. 사람 역할이 섞인 Agent 업무명/설명을 분리한다.
- Agent 산출물→사람 판단 연결, 승인 후행, 반려·보완 경로를 검사한다. 업무가 승인으로 끝나면 terminal=true를 적고 continue_to는 비울 수 있다.
- 승인 대상 후행으로 이어지는 사람 노드 우회 경로를 허용하지 않는다. 병렬 분기는 서로 무관한 작업인 경우에만 설계한다.
- 원본 최종 결정 업무가 required=false 선언만으로 사라지지 않도록 원본 참조도 검사한다.
- 무조건 확인 박스를 늘리지 않는다. 미리 승인된 규칙 아래의 자동 처리와 책임자의 의사결정을 업무 맥락으로 구분한다. 코드의 어휘 검사는 휴리스틱이며 검토 보조다.

## 원본 보존·출력 계약

원본 HTML은 source_asis.py capture로 exact bytes, SHA256, DATA/저장 편집, 원천 행 대응을 묶어 보존한다. HTML 내 As-Is 탭은 sandbox iframe의 원본 렌더러를 사용한다. 기존 To-be 디자인과 서로 CSS/JS 영향을 주지 않는다. 원본 전체는 원본 내부 필터로 탐색하며 부모 화면의 To-be 필터를 적용하지 않는다. 원본은 기존 화면 형식을 유지하므로 To-be와 모양이 다를 수 있다.

원본 HTML과 Excel 범위가 다르면 누락된 원본 노드를 검토하고 차이를 보고한다. capture는 진단용 부분 대응을 기록할 수 있으나 release는 범위 차이가 남아 있으면 최종 생성을 차단한다. 'HTML 미지원→조용한 Excel fallback'은 허용하지 않는다. capture 후 Excel 업무를 바꾸면 다시 capture해야 한다.

XLSX는 고정 템플릿 복제가 아닌 검토용 정규화 표이다. Edges/Traceability/Redesign와 JSON payload로 정보를 보존한다. verify는 표시 표·payload·HTML의 일치를 검사하고, restore는 원본 JSON 세트를 꺼낸다. Excel의 직접 수정분을 자동으로 병합하지 않는다.

## 검증 단계

release build는 구조·사람·설명·문구·경고 검토·Excel/HTML 일치를 확인해 후보를 생성한다. final 브라우저 QC와 certify까지 완료해야 배포 통과다. 종료 코드 0만 보지 말고 실제 화면/패널 검사 수와 manifest 상태를 확인한다. 후보 파일이 존재한다고 배포 가능 상태로 보고하지 않는다.

과거 문서의 오류 무시·추측 연결·순차화·원문 Lv.5 유지 지침과 충돌하면 이 계약 및 SKILL.md가 우선한다.
