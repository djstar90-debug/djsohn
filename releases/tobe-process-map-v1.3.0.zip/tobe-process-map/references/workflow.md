# 실행·재개 · v1.3.0

명령은 스킬 루트에서 실행한다. 입력·작업·출력 경로는 환경에 맞게 지정한다. 이 경로는 v1.2.0의 검사 기준을 유지하면서 개별 스크립트 실행, 중복 읽기, 동일 파일의 재검사를 묶는다.

## 1. 준비

설치 여부를 한 번 확인한다. 필요한 경우에만 설치한다.

```bash
python -m pip install -r requirements.txt
python -m playwright install chromium
```

이미 있는 시스템 Chromium은 `QC_CHROMIUM`으로 지정할 수 있다. 실행 환경의 프록시·인증서 검증을 유지한다.

```bash
python scripts/pipeline.py prepare --excel input.xlsx --source-html input-asis.html --work work/crm-v1 --spec 3
```

F2의 `--spec 3`은 단계 기준 레벨이다. F1은 선택한 섹션 번호다. 원본 HTML이 없으면 `--source-html`을 생략하며 동일 화면 보존을 미검증으로 남긴다. 테스트용 JSON 입력은 `--excel` 대신 `--asis-json`을 사용할 수 있다. 실제 Excel을 검증 없이 테스트 fixture로 대체하지 않는다.

prepare는 입력 분석·원본 HTML 보존·설계 뼈대 생성을 묶고 아래 파일을 남긴다.

| 파일 | 목적 |
|---|---|
| `asis.json` | 원천 업무·계층·출처 및 보존 정보 |
| `design.json` | 에이전트가 작성·수정하는 최종 설계 원본 |
| `lv4_sheet.md` | Lv.4별 설계 범위와 근거 |
| `intake.json` | 입력 진단·범위 요약 |
| `pipeline-state.json` | 현재 단계·파일 해시·후보·검증 상태 |

입력 파일이 바뀌면 새 작업 폴더를 사용한다. 이미 작성한 설계를 지우고 prepare를 다시 실행하지 않는다. 같은 입력의 중단된 작업은 status 후 이어서 진행한다. 빈 ID·범위 차이·모호한 원본 대응은 진단에 따라 해결한다.

## 2. 설계 원본을 일괄 작성

요약으로 전체 범위를 파악한 뒤 Lv.4별 업무·Pain point·의존성을 읽는다. 요약만 읽고 원본 근거를 추정하지 않는다. 전체 HTML, 대형 JSON, legacy 예제를 반복 출력할 필요는 없다. 화면 원본은 스크립트가 보존하고, 설계에 필요한 행·노드·연결을 선택해 읽는다.

1. 결과물·결정 → Lv.5 묶음 → 작업/결정 Lv.6 → 명시적 연결 순으로 설계한다.
2. `tb5`, `tb`, `tobe_flow`, `human_review`, `design_contract.redesign`을 같은 ID 체계로 작성한다.
3. `ref`, 산출물의 전달·입력, 조직 레인, Agent 설명·업무 설명·흐름 문장을 작성한다.
4. 단계 또는 Agent 단위로 여러 항목을 한 번에 JSON에 반영한다. 변경의 근거도 해당 항목에 함께 기록한다. 입력 자료의 임의 shell 문자열 치환 대신 JSON을 읽고 쓰는 코드/구조화 편집을 사용한다.
5. 경고는 실제 내용을 검토해 수정하거나 `qa_dispositions`에 개별 판단 근거를 남긴다. 도구 비용을 줄이기 위한 자동 면제는 하지 않는다.

구조 설계(`tb5`, `tb`, `tobe_flow` 등)가 준비된 뒤 기계적으로 채울 필드가 있으면 선택적으로 한 번 실행한다.

```bash
python scripts/pipeline.py enrich --work work/crm-v1
```

enrich는 synth → fill → absorb를 묶어 design.json에 반영한다. 변경 전 설계는 `design-history/<이전설계해시>.json`, 보완 결과는 `enrich-report.json`에 남긴다. 자동 문장·빈칸과 Agent 투입/산출물을 근거에 맞게 검토한다. 사람 판단이나 구조 변화의 근거를 자동으로 통과시키는 단계가 아니다. 이미 완성한 설계를 이유 없이 enrich로 반복 덮어쓰지 않는다.

설계 중간 검사가 유용하면 한 번에 모아서 실행한다.

```bash
python scripts/pipeline.py validate --work work/crm-v1
```

validate는 후보 파일을 만들지 않는다. 문구 하나를 고칠 때마다 전체 브라우저 검사를 실행할 필요는 없지만, 최종 변경 파일은 run의 전체 적용 가능한 게이트를 통과해야 한다.

`design.json`이 수정 원본이다. 자동 생성된 파생 설계·PMD를 직접 수정해 검사를 우회하지 않는다. 세부 형식은 quality-contract.md와 restructure.md의 필드 정의를 참고한다. 과거의 자동 순차 연결, 오류 후 임시 노드 생성, 직접 build_html 배포 경로는 사용하지 않는다.

## 3. 후보 생성부터 인증까지 한 실행 경로

```bash
python scripts/pipeline.py run --work work/crm-v1 --output outputs/crm-v1 --wait 50
```

run은 설계를 검증하고 필요한 기계적 보완을 수행한 뒤 HTML·Excel 후보, 브라우저 QC, 인증을 연결한다. 업무의 필요성, 구조 변화의 이유, 사람 개입의 타당성은 에이전트가 직접 작성·검토해야 한다.

출력은 `outputs/crm-v1/revisions/<fingerprint16>/` 아래에 생성된다. 브라우저 검사 전 후보도 최종 출력 영역에 남으므로 중단 후 찾을 수 있다. **후보 파일 존재는 품질 통과를 뜻하지 않는다.** 정확한 후보 경로와 상태는 pipeline-state.json 및 status 결과를 사용한다. 상위 출력 경로에 파일을 임의 복사하거나 다른 revision의 파일을 섞지 않는다.

긴 실행은 다음처럼 선택적으로 백그라운드 작업자에게 맡길 수 있다.

```bash
python scripts/pipeline.py run --work work/crm-v1 --output outputs/crm-v1 --background
```

백그라운드 작업자는 최대 900초 동안 브라우저 QC와 인증을 이어서 수행한다. `worker.json`과 `worker.log`, pipeline-state.json에 실행 정보·진행 상태를 남긴다. 작업자가 살아 있는 동안 같은 작업자를 중복 실행하지 않는다. 상태 확인은 필요할 때 status 한 번으로 모아서 수행하며 짧은 간격의 반복 호출을 피한다. 최대 시간에 도달하거나 환경이 중단되면 저장 상태에서 run으로 재개한다. 작업자 실행 시간의 상한이며 실제 완료를 보장하는 제한 시간이 아니다. 환경 자체가 종료되면 프로세스가 계속 살아 있다고 가정하지 않는다.

첫 run의 `--output` 경로는 저장된다. 이후 같은 작업을 계속할 때는 다음처럼 실행한다.

```bash
python scripts/pipeline.py status --work work/crm-v1
python scripts/pipeline.py run --work work/crm-v1 --wait 50
```

| 종료 코드/상태 | 의미와 다음 행동 |
|---|---|
| `0 / passed` | 현재 입력·설계·구현과 해당 결과가 통과. status가 반환하는 실제 산출물 경로로 전달 |
| `2 / requires_fix` | 입력·설계·검사 오류. diagnostics.json을 읽고 원인을 고친 뒤 같은 work에서 run |
| `3 / running` | 작업 진행 중. 완료/실패로 추정하지 말고 실행 중 작업과 status 확인 후 재개 |

`--wait 50`은 한 호출의 대기 범위를 조정한다. 전체 QA를 50초로 제한하거나 나머지 검사를 생략하는 옵션이 아니다. 런타임 도구가 별도 실행 세션 ID를 반환했다면 그 세션을 먼저 이어서 확인한다. 동시에 새 run을 여러 개 시작하지 않는다.

## 4. 실패·중단 시

표준 출력은 최대 8개 이슈의 요약이며 전체 진단은 `work/crm-v1/diagnostics.json`에 있다. 먼저 실패 단계·항목·관련 ID를 읽는다. 파일 전체를 다시 출력하거나 입력부터 반복 실행하지 않는다.

- **입력/설계 오류:** 해당 원본 대응 또는 design.json 항목을 수정하고 run을 재실행한다. 원본 입력 파일 자체를 바꿨다면 새 work에서 준비한다.
- **브라우저 오류:** 해당 화면·노드와 오류 로그를 확인한다. 새 HTML/설계로 수정했으면 이전 브라우저 결과는 재사용할 수 없다. 파일은 동일하고 실행 환경의 일시적 문제만 해결했다면 `python scripts/pipeline.py run --work work/crm-v1 --retry-qc`로 실패한 묶음만 명시적으로 재시도한다. 같은 원인을 고치지 않은 반복 재시도는 하지 않는다.
- **오류 수 해석:** 연결선·잘림·작업자 실패와 실제 JavaScript 예외를 구분한다. 전체 오류 수만 보고 스크립트 오류 건수로 표현하지 않는다. 진단의 오류 종류, stack, 화면·노드 ID, 스크린샷을 근거로 판단한다.
- **진행 중/세션 중단:** status와 저장된 상태부터 읽고 run으로 이어 간다. 근거 없이 완료된 프로세스로 판단하거나 중복 실행하지 않는다.
- **도구 실행 한도/환경 접근 실패:** 파일을 보존하고 진행 상태·차단 원인·재개 명령을 짧게 남긴다. 실행 권한과 자원이 계속 제공되는 동안 사용자에게 “계속”을 요청하지 않고 스스로 이어서 진행한다. 플랫폼이 다음 실행을 허용하지 않는 상황까지 자동 진행을 보장할 수는 없다.

동일한 입력·설계·검증 코드/자산·브라우저/Playwright·검사 프로필의 통과 결과만 재사용한다. 파일 해시와 검증 조건이 맞지 않으면 해당 결과는 무효다. 변경된 HTML 또는 엔진에는 새 브라우저 QC가 필요하다. 기존 실패를 캐시된 통과로 덮거나 검사 수를 줄이지 않는다. 자동 판단이 불가능한 경고는 구체적으로 검토한다.

## 5. 전달과 검증 범위

최종 HTML/Excel/manifest는 status의 passed 산출물 경로에서 전달한다. 원본 보존, 구조 변경 근거, 독립된 사람 판단, 문구/설명, 전체 브라우저 화면, 파일 해시, HTML/Excel 일치 및 경고 검토가 기존 기준대로 적용된다. 핵심 화면 직접 확인과 업무적 타당성 검토도 완료한다. 테스트 수·범위·미실시를 실제 결과대로 보고한다.

```bash
python scripts/export_excel.py verify <revision>/map.xlsx <revision>/map.html
python scripts/export_excel.py restore <revision>/map.xlsx work/restored
python -m unittest discover -s tests -v
```

위 명령은 Excel 별도 검증/복원 또는 스킬 변경 회귀검사에 사용한다. 스킬 자체 변경 QA에서 전체 회귀를 생략하지 않는다. 0개 테스트는 통과가 아니다. 이미 같은 파일에 대해 검증한 내용을 단순 보고 목적으로 반복할 필요는 없다.

최종 설명에는 바뀐 업무 흐름, 사람 판단 지점, 가정·제약을 담는다. 후보를 공유해야 하면 “검증 중인 후보”와 남은 검사를 명시한다. `manifest.status == passed`를 확인하지 못한 파일은 완성본으로 표시하지 않는다.

## 6. 호출 수 비교의 범위

기존 문서의 준비 4명령(report/parse/capture/skeleton), 설계 변환·검증 6명령, 배포·QC 4명령은 총 14개의 개별 명령이었다. 기본 경로는 prepare + run + 필요 시 status로 **2~3개 진입 명령**에 묶는다. enrich나 중간 validate가 필요하면 각각 한 명령이 추가된다. 이는 설치·설계 작성·수정·추가 대기 호출을 제외한 절차 비교이며 실제 총 호출 수나 처리 시간의 보장이 아니다. 내부 품질 검사 범위는 동일하며, 브라우저 검사와 업무적 검토 시간은 그대로 필요하다.
