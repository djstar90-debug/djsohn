/* ---------- To-be 흐름 설명 v2 — 번호(묶음) 안을 '누가 → 무엇을' 순서로 나눔 · 가설 · 업무 ID는 To-be Lv.6 기준
   색은 박스 종류에서 자동으로 정함: Agent(빨강) · 담당자 확인·판단(갈색) · 사람 직접(회색) · Orchestrator 신호·호출(검정) ---------- */
const STORY = (window.__PMD__ && window.__PMD__.tour) || {};

/* 엔진 v3 — Lv.4·5·6 × As-Is·To-be, 7단계 필터, 큰 기능 Agent(밴드) ▸ 세부 Agent(행), 데이터·시스템 보유/추가 표시 */
(function(){
'use strict';
const SHELL = "<!DOCTYPE html>\n<html lang=\"ko\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">\n<title>/*__TITLE__*/<\/title>\n<style>\n\n/* ── Bain design system token block (verbatim) ── */\n:root {\n  /* === Spacing — base-2 scale === */\n  --ds-space-01: 2px;\n  --ds-space-02: 4px;\n  --ds-space-03: 8px;\n  --ds-space-04: 16px;\n  --ds-space-05: 24px;\n  --ds-space-06: 32px;\n  --ds-space-07: 40px;\n  --ds-space-08: 48px;\n  --ds-space-09: 64px;\n  --ds-space-10: 80px;\n  --ds-space-11: 96px;\n  --ds-space-12: 160px;\n\n  /* === Type === */\n  --ds-font-sans: Arial, Helvetica, sans-serif;\n\n  /* === Primary colors === */\n  --ds-color-company-red:       #CC0000;\n  --ds-color-company-red-hover: #9D1B22;\n  --ds-color-black:             #121212;\n  --ds-color-white:             #FFFFFF;\n\n  /* === Text colors === */\n  --ds-text-black:    #000000;\n  --ds-text-dark:     #333333;\n  --ds-text-regular:  #717171;\n  --ds-text-body:     #616568;   /* color-card hex labels, secondary body */\n  --ds-text-helper:   #767676;   /* small-label helper text */\n  --ds-text-on-color: #FFFFFF;\n\n  /* === Neutral greys === */\n  --ds-gray-x-light:  #F9F9F9;   /* default input fill, subtle layer */\n  --ds-gray-light:    #ECECEC;   /* pill button border, dividers on tinted surfaces */\n  --ds-gray-medium:   #CCCCCC;\n  --ds-gray-dark:     #A3A3A3;\n  --ds-stroke:        #D8D8D8;   /* canonical card/divider stroke */\n\n  /* === Status / notification === */\n  --ds-success:       #07C29F;\n  --ds-success-light: #DAF2ED;\n  --ds-warning:       #F1C21B;\n  --ds-warning-light: #FEF7E8;\n  --ds-error:         #CC0000;   /* same hue as company red — pair with icon/label, never color alone */\n  --ds-error-light:   #F2DFD8;\n\n  /* === Surfaces & layers === */\n  --ds-background:        var(--ds-color-white);\n  --ds-background-hover:  rgba(0, 0, 0, 0.04);\n  --ds-layer-tinted:      var(--ds-gray-x-light);\n\n  /* === Card shadow (signature) === */\n  --ds-shadow-card: 0 14px 42px 0 rgba(8, 15, 52, 0.06);\n\n  /* === Layout offsets ===\n     Overridden locally when the artifact includes a top navigation bar\n     (e.g. set --ds-nav-height: 64px on :root). Used by the progress-bar\n     recipe to sit directly below the nav. */\n  --ds-nav-height: 0;\n\n  /* === Data-viz palette ===\n     For palette decisions, see references/charts.md. */\n\n  /* Company red — monochrome ramp (4 shades, light → dark) */\n  --ds-red-100: #FF6666;     /* ⚠️ Ramp-only — never standalone. See Color exception rules. */\n  --ds-red-200: #CC0000;   /* Company red — the HIGHLIGHT shade */\n  --ds-red-300: #990000;\n  --ds-red-400: #660000;\n\n  /* Beacon Violet — used in multi-series + diverging */\n  --ds-violet-100: #D5D6FF;   /* lightest lilac — common context/neutral series fill */\n  --ds-violet-200: #988FEC;\n  --ds-violet-300: #5E4ADC;   /* Beacon brand violet */\n\n  /* Expert Purple — anchors the dark end of diverging scales */\n  --ds-purple-100: #B4A2CB;\n  --ds-purple-200: #926F98;\n  --ds-purple-300: #4F0731;   /* Expert purple */\n\n  /* \"Something to highlight\" grey ramp (5 steps, light → dark) */\n  --ds-chart-gray-100: #D2D2D1;   /* lightest — default context fill on highlight charts */\n  --ds-chart-gray-200: #A5A5A4;\n  --ds-chart-gray-300: #777776;\n  --ds-chart-gray-400: #343432;\n  --ds-chart-gray-500: #000000;\n\n  /* Soft warm greys — RESERVED for \"Other\" segments and accent backgrounds */\n  --ds-other-100: #F2EEE9;\n  --ds-other-200: #DCD1C9;\n  --ds-other-300: #C6B3A8;\n\n  /* Diverging scale (Negative → Neutral → Positive), 7 steps.\n     ⚠️ Spectrum visualizations only — never as general series colors.\n     See Color exception rules. */\n  --ds-diverging-1: #4F0731;   /* Negative 1 — most negative (Expert purple) */\n  --ds-diverging-2: #7C4C76;\n  --ds-diverging-3: #A891BA;\n  --ds-diverging-4: #D5D6FF;   /* Neutral (lilac) */\n  --ds-diverging-5: #DDABD3;\n  --ds-diverging-6: #DD476D;\n  --ds-diverging-7: #FF0024;   /* Positive 1 — most positive */\n\n  /* === Exception color (opt-in only — see references/charts.md) === */\n  --ds-nps-red:        #CC0000;\n  --ds-nps-gray:       #979797;\n  --ds-nps-yellow:     #FFCC00;\n\n  /* === Surface modes === (see references/advanced-color.md for Expert Purple) */\n\n  /* Light mode (default) */\n  --ds-surface:           var(--ds-color-white);\n  --ds-surface-text:      var(--ds-text-dark);\n  --ds-surface-heading:   var(--ds-text-black);\n  --ds-surface-divider:   var(--ds-stroke);\n  --ds-surface-eyebrow:   var(--ds-color-company-red);\n}\n\n/* Expert Purple surface mode — opt in by setting data-surface=\"purple\" on <body>. */\n[data-surface=\"purple\"] {\n  --ds-surface:         #4F0731;\n  --ds-surface-text:    var(--ds-color-white);\n  --ds-surface-heading: var(--ds-color-white);\n  --ds-surface-divider: rgba(255, 255, 255, 0.15);\n  --ds-surface-eyebrow: var(--ds-color-white);\n  /* Consume the surface tokens here too — not only on html, body — so a region\n     works when data-surface=\"purple\" is scoped to an inner element (e.g. a single\n     hero section on an otherwise white page), not just when it's on <body>. */\n  color: var(--ds-surface-text);\n  background: var(--ds-surface);\n}\n\n/* Apply base typography and surface tokens to the page. */\nhtml, body {\n  font-family: var(--ds-font-sans);\n  color: var(--ds-surface-text);\n  background: var(--ds-surface);\n  margin: 0;\n  font-size: 18px;\n  line-height: 28px;\n}\n\n/* ── 이 프로세스맵 전용 의미 토큰: 전부 --ds-* 토큰에서 가져옴. 회사 레드는 포인트로만, 바탕은 흰색·웜그레이 ── */\n:root{--lbw:300px;\n--bg:var(--ds-gray-x-light);--surface:var(--ds-color-white);--cream:var(--ds-other-100);--cream2:var(--ds-other-200);--cream3:var(--ds-other-300);\n--ink:var(--ds-text-dark);--ink-strong:var(--ds-text-black);--ink2:var(--ds-text-regular);--ink3:var(--ds-text-helper);\n--line:var(--ds-gray-light);--line-strong:var(--ds-stroke);--line2:var(--ds-gray-light);--lbl:var(--ds-color-white);\n--red:var(--ds-color-company-red);--red-dk:var(--ds-color-company-red-hover);\n--sh-sm:0 1px 2px rgba(8,15,52,.06);--sh-xl:0 30px 70px rgba(8,15,52,.18),0 2px 8px rgba(8,15,52,.06);--cv-inset:inset 0 -2px 0 rgba(0,0,0,.18);--sh-md:0 6px 18px rgba(8,15,52,.07);--sh-lg:var(--ds-shadow-card);--shadow:rgba(8,15,52,.07);\n--lane-alt:var(--ds-gray-x-light);--stage-alt:rgba(8,15,52,.012);\n--t-ai:var(--ds-color-company-red);\n--h-bg:var(--ds-color-white);--h-bd:var(--ds-stroke);--h-ac:var(--ds-gray-dark);\n--nh-bg:var(--ds-other-100);--nh-bd:var(--ds-other-200);--nh-ac:var(--ds-other-300);\n--a-bg:var(--ds-color-white);--a-bd:var(--ds-stroke);--a-ac:var(--ds-color-company-red);--na-bg:var(--ds-color-white);--na-bd:var(--ds-color-company-red);\n--adv-bg:var(--ds-color-white);--adv-bd:var(--ds-stroke);--adv-ac:var(--ds-color-company-red);--gone-bd:var(--ds-gray-medium);--gone-ink:var(--ds-gray-dark);\n--mk-bg:var(--ds-text-dark);--mk-ink:var(--ds-text-on-color);--mk-ac:var(--ds-color-company-red);\n--e-def:var(--ds-gray-dark);--e-ai:var(--ds-color-company-red);--e-hitl:var(--ds-other-300);--e-rej:var(--ds-text-dark);--e-adv:var(--ds-color-company-red);--e-loop:var(--ds-gray-medium);\n--have-bg:var(--ds-gray-x-light);--have-bd:var(--ds-gray-medium);--have-ink:var(--ds-text-dark);--need-bg:var(--ds-color-white);--need-bd:var(--ds-color-company-red);--need-ink:var(--ds-color-company-red);\n--band-bd:var(--ds-gray-light);--band-bg:var(--ds-color-white);--band-hd:var(--ds-other-100);--sub-bd:var(--ds-gray-medium);--sub-bg:transparent;\n--cv1:var(--ds-text-dark);--cv1-ink:var(--ds-text-on-color);--cv2:var(--ds-other-100);--cv2-ink:var(--ds-text-dark);--cv3:var(--ds-color-white);--cv3-ink:var(--ds-color-company-red);\n--pain-bg:var(--ds-other-100);--pain-bd:var(--ds-color-company-red);--vf:var(--ds-text-dark);--chg:var(--ds-color-company-red);--focus:var(--ds-color-company-red);--btn-on:var(--ds-text-dark);color-scheme:light}\n:root{box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}\nhtml{scroll-padding-top:env(safe-area-inset-top,0px)}\n*,*::before,*::after{box-sizing:border-box}\n[hidden]{display:none!important}\nbody{margin:0;background:var(--bg);color:var(--ink);font-family:var(--ds-font-sans);font-size:13px;line-height:1.5;-webkit-font-smoothing:antialiased;letter-spacing:-.1px}\nbutton{font:inherit;color:inherit;background:var(--surface);border:1px solid var(--line-strong);border-radius:999px;padding:4px 11px;cursor:pointer;transition:background .18s,border-color .18s,color .18s,box-shadow .18s,transform .18s}\nbutton:hover{border-color:var(--ds-gray-dark);box-shadow:var(--sh-sm)}button:active{transform:translateY(1px)}\nbutton:focus-visible,.nd:focus-visible{outline:2px solid var(--focus);outline-offset:2px}button:disabled{opacity:.35;cursor:default;box-shadow:none}\nbutton[aria-pressed=\"true\"]{background:var(--btn-on);color:var(--ds-text-on-color);border-color:var(--btn-on)}\n.ic{display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto}\n.ic svg{width:100%;height:100%;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}\n.ic.fill svg{fill:currentColor;stroke:none}\n/* 머리글 */\n#top{padding:18px 22px 8px;max-width:100%}\n.hero{display:flex;gap:16px;align-items:flex-end;justify-content:space-between;flex-wrap:wrap;background:var(--surface);border-radius:20px;padding:16px 20px;box-shadow:var(--sh-lg);position:relative;overflow:hidden}\n.hero::before{content:\"\";position:absolute;left:0;top:0;bottom:0;width:5px;background:var(--red)}\n.hero .eyebrow{display:flex;align-items:center;gap:7px;font-size:11px;font-weight:700;letter-spacing:.8px;color:var(--red);text-transform:uppercase;margin-bottom:3px}\n.hero .eyebrow .dot{width:8px;height:8px;border-radius:50%;background:var(--red);box-shadow:0 0 0 4px var(--cream)}\nh1{font-size:23px;margin:0;line-height:1.3;color:var(--ink-strong);letter-spacing:-.4px}\n.crumb{font-size:12px;color:var(--ink2);margin-top:4px}\n.ver{font-size:11px;color:var(--ink2);white-space:nowrap;background:var(--cream);border-radius:999px;padding:4px 12px}\n#controls{display:flex;flex-wrap:wrap;gap:6px 8px;align-items:center;margin:12px 0 8px;padding:7px 10px;background:var(--surface);border-radius:16px;box-shadow:var(--sh-md)}\n.grp{display:inline-flex;align-items:center;gap:6px}.grp>span{font-size:10.5px;color:var(--ink3);font-weight:700;letter-spacing:.3px}\n.seg{display:inline-flex;background:var(--cream);border-radius:999px;padding:3px;gap:2px}\n.seg button{border:0;border-radius:999px;padding:3px 9px;background:transparent;box-shadow:none}\n.seg button:hover{background:rgba(255,255,255,.7);box-shadow:none}\n.seg button[aria-pressed=\"true\"]{background:var(--surface);color:var(--ink-strong);font-weight:700;box-shadow:var(--sh-sm)}\n#scrSeg button[data-scr=\"ns\"][aria-pressed=\"true\"]{background:var(--red);color:var(--ds-text-on-color)}\n.sp{flex:1}\n#summary{display:flex;flex-direction:column;gap:4px;margin:4px 4px 6px}\n.sm{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--ink2)}\n.sm::before{content:\"\";width:7px;height:7px;border-radius:50%;background:var(--ds-gray-medium);flex:0 0 auto}\n.sm.on{color:var(--ink-strong);font-weight:700}.sm.on::before{background:var(--red);box-shadow:0 0 0 3px var(--cream)}\n#legend{display:flex;flex-wrap:wrap;gap:6px 10px;margin:6px 0 2px;font-size:11px;color:var(--ink2)}\n.lgg{display:flex;flex-wrap:wrap;align-items:center;gap:4px 10px;background:var(--surface);border-radius:12px;padding:5px 10px;box-shadow:var(--sh-sm)}\n.lgg>b{font-size:10px;color:var(--ink3);font-weight:700;letter-spacing:.4px;margin-right:2px}\n.lg{display:inline-flex;align-items:center;gap:5px}.lgg.hint{background:transparent;box-shadow:none;color:var(--ink3);font-size:10.5px}\n.sw{display:inline-block;width:20px;height:13px;border-radius:4px;vertical-align:middle}\n.sw.nd{position:static;padding:0;border:1px solid;transition:none}\n.sw.fr.big{border:1.5px solid var(--band-bd);background:var(--cream);border-radius:5px}.sw.fr.small{border:1px dashed var(--sub-bd);border-radius:4px}\n.sw.ln{height:0;border-radius:0;border-top:2px solid var(--e-def)}.sw.ln.l{border-top:2px dotted var(--e-loop)}.sw.ln.v{border-top:2px dashed var(--e-rej)}.sw.ln.r{border-top:2px solid var(--e-ai)}.sw.ln.o{border-top:2px dashed var(--e-hitl)}.sw.ln.p{border-top:2px solid var(--e-adv)}\n/* 지도 카드 */\n#stageWrap{position:relative;margin:4px 22px 0;background:var(--surface);border-radius:20px;box-shadow:var(--sh-lg);overflow:hidden}\n#slbar{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 18px;background:var(--surface);border-bottom:1px solid var(--line);font-size:12px}\n#sllab{display:flex;align-items:center;gap:8px}#sllab b{font-size:13.5px;color:var(--ink-strong)}#sllab.ns b{color:var(--red)}\n#sldots{display:inline-flex;align-items:center;gap:8px;background:var(--cream);border-radius:999px;padding:3px}\n#sldots button{border:0;border-radius:999px;padding:3px 14px;font-size:11.5px;background:transparent;box-shadow:none}\n#sldots button[aria-pressed=\"true\"]{background:var(--surface);color:var(--ink-strong);font-weight:700;box-shadow:var(--sh-sm)}\n#sldots button[data-scr=\"ns\"][aria-pressed=\"true\"]{background:var(--red);color:var(--ds-text-on-color)}\n#sldots i{display:inline-block;width:26px;height:2px;background:var(--ds-gray-medium);border-radius:2px;position:relative}\n#sldots i::after{content:\"\";position:absolute;right:-2px;top:-4px;border-left:6px solid var(--ds-gray-dark);border-top:5px solid transparent;border-bottom:5px solid transparent}\n.slhint{color:var(--ink3);font-size:11px}\n#btnExitPresent{display:none}\n.slnav{position:absolute;top:calc(50% + 20px);transform:translateY(-50%);z-index:50;width:44px;height:44px;border-radius:50%;padding:0;font-size:24px;line-height:40px;text-align:center;background:var(--surface);border:1px solid var(--line);box-shadow:var(--sh-md);opacity:.9}\n.slnav:hover{opacity:1;color:var(--red)}.slnav.prev{left:calc(var(--lbw) + 14px)}.slnav.next{right:14px}.slnav:disabled{opacity:0;pointer-events:none}\n#wrap{overflow:auto;height:74vh;min-height:460px;background:var(--surface)}\nbody.present #top,body.present #foot{display:none}\nbody.present #stageWrap{margin:0;border-radius:0}\nbody.present #wrap{height:calc(100vh - 46px)}\nbody.present #btnExitPresent{display:inline-block}\n#inner{display:grid;grid-template-columns:var(--lbw) max-content;grid-template-rows:84px auto;width:max-content}\n#corner{position:sticky;left:0;top:0;z-index:40;background:var(--surface);display:flex;flex-direction:column;justify-content:flex-end;padding:0 14px 6px;font-size:10px;color:var(--ink3);border-right:1px solid var(--line);border-bottom:1px solid var(--line)}\n#corner b{font-size:14px;color:var(--ink-strong);margin-bottom:3px}#corner span{height:23px;display:flex;align-items:center}\n#stagehead{position:sticky;top:0;z-index:30;background:var(--surface);height:84px;border-bottom:1px solid var(--line)}\n#labels{position:sticky;left:0;z-index:20;background:var(--surface);border-right:1px solid var(--line)}\n#boardwrap{position:relative}#board{position:relative}\n.cv{position:absolute;display:flex;align-items:center;justify-content:center;gap:6px;white-space:nowrap;overflow:hidden;padding:0 12px;border-radius:9px}\n.cv span{overflow:hidden;text-overflow:ellipsis}\n.cv .sn{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:50%;background:var(--red);color:var(--ds-text-on-color);font-size:10.5px;font-weight:700;flex:0 0 auto}\n.cv.r1{top:6px;height:26px;background:var(--cv1);color:var(--cv1-ink);font-size:12px;font-weight:700}\n.cv.r2{top:35px;height:20px;background:var(--cv2);color:var(--cv2-ink);font-size:10.5px;border-radius:999px}\n.cv.r3{top:58px;height:20px;background:var(--cv3);color:var(--cv3-ink);font-size:10.5px;font-weight:700;border:1px solid var(--red);border-radius:999px}\n/* 레인 카드 */\n.lc{position:absolute;left:0;width:var(--lbw);padding:8px 12px 6px 12px;border-top:1px solid var(--line);background:var(--surface);overflow:hidden;display:flex;gap:9px;align-items:flex-start}\n.lc .lic{width:28px;height:28px;border-radius:50%;background:var(--cream);color:var(--ink);padding:6px;flex:0 0 auto}\n.lc .lt{min-width:0;flex:1}\n.lc b{display:block;font-size:12.5px;line-height:1.3;color:var(--ink-strong)}.lc small{display:block;font-size:10.5px;color:var(--ink2);margin-top:1px}\n.lc.aih{background:var(--surface);border-top:2px solid var(--red);align-items:center;padding-top:5px}.lc.aih b{color:var(--red)}.lc.aih .lic{background:var(--red);color:var(--ds-text-on-color);width:22px;height:22px;padding:4px}\n.lc.band{background:transparent;border-top:0;padding:8px 14px;align-items:center}.lc.band b{color:var(--red);font-size:12.5px}.lc.band .lic{width:22px;height:22px;padding:4px;background:var(--cream);color:var(--red)}\n.lc.sub{left:14px;width:calc(var(--lbw) - 24px);background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:6px 10px;box-shadow:var(--sh-sm);display:block}.lc.sub b{font-size:11.3px;margin-bottom:3px}\n.lc.clk{cursor:pointer}.lc.clk:hover b{text-decoration:underline;text-underline-offset:3px}\n.lc.sub.clk:hover{box-shadow:var(--sh-md)}\n.lbandf{position:absolute;left:5px;width:calc(var(--lbw) - 10px);border:1.5px solid var(--band-bd);border-radius:16px;pointer-events:none}\n.mc{font-size:9.5px;font-weight:400;color:var(--ink3)}\n/* 칩 */\n.chips{display:block;line-height:0}\n.cp{display:inline-block;font-style:normal;font-size:9px;line-height:14px;padding:0 6px;margin:1px 3px 1px 0;border:1px solid;border-radius:4px;white-space:nowrap;max-width:100%;overflow:hidden;text-overflow:ellipsis;vertical-align:top}\n.cp.s{border-radius:999px}.cp.h{background:var(--have-bg);border-color:var(--have-bd);color:var(--have-ink)}.cp.n{background:var(--need-bg);border-color:var(--need-bd);color:var(--need-ink);border-style:dashed}\n.cp.more{border-color:var(--line);color:var(--ink3);background:transparent}.lc.sub .cp{max-width:118px}\n/* 보드 배경 */\n.bg{position:absolute;left:0;pointer-events:none}\n.stband{top:0}.stband.odd{background:var(--stage-alt)}\n.row-lane{border-top:1px solid var(--line)}.row-lane.alt{background:rgba(8,15,52,.014)}\n.row-aih{background:var(--surface);border-top:2px solid var(--red)}\n.sep{top:0;width:0;border-left:1px dashed var(--line-strong)}\n.bandf{left:4px;border:1.5px solid var(--band-bd);border-radius:18px;background:var(--surface);box-shadow:var(--sh-sm)}\n.bandh{left:6px;display:flex;align-items:center;gap:10px;padding:0 14px;white-space:nowrap;overflow:hidden;font-size:11px;pointer-events:auto;cursor:pointer;border-radius:16px 16px 0 0;background:var(--cream)}\n.bandh b{color:var(--red);font-size:12px}.bandh .bd{color:var(--ink2)}.bandh .chips{display:inline;line-height:normal}.bandh .cp{margin:0 3px 0 0}\n.subf{left:12px;border:1px dashed var(--sub-bd);border-radius:12px;background:transparent}\n/* 연결선 */\n#edges{position:absolute;left:0;top:0;z-index:3;pointer-events:none;overflow:visible}\n.e{fill:none;stroke:var(--e-def);stroke-width:1.25;stroke-linejoin:round;stroke-linecap:round}.e-loop{stroke:var(--e-loop);stroke-dasharray:2 3}.e-rej{stroke:var(--e-rej);stroke-dasharray:5 3}\n.e-ai{stroke:var(--e-ai);stroke-width:1.5}.e-hitl{stroke:var(--e-hitl);stroke-dasharray:5 3;stroke-width:1.5}.e-adv{stroke:var(--e-adv);stroke-width:1.5}.e-grp{stroke:var(--ds-gray-medium);stroke-dasharray:1 3;stroke-width:1.6}\n.elab{position:absolute;z-index:6;font-size:9.5px;line-height:1.35;padding:0 7px;border-radius:999px;background:var(--surface);border:1px solid currentColor;white-space:nowrap;pointer-events:none;box-shadow:var(--sh-sm)}\n.elab.r{color:var(--red)}.elab.o{color:var(--ink2)}.elab.v{color:var(--ink)}.elab.g{color:var(--ink2)}\n/* 박스 */\n.nd{position:absolute;z-index:5;background:var(--h-bg);border:1px solid var(--h-bd);border-radius:10px;padding:4px 7px 4px 9px;overflow:hidden;cursor:pointer;color:var(--ink);box-shadow:inset 3px 0 0 var(--h-ac),var(--sh-sm);transition:left .62s cubic-bezier(.4,0,.2,1),top .62s cubic-bezier(.4,0,.2,1),width .45s ease,height .45s ease,opacity .4s ease,box-shadow .18s ease,transform .18s ease}\n.nd:hover{box-shadow:inset 3px 0 0 var(--h-ac),var(--sh-md);transform:translateY(-1px)}\n.nd.hl{box-shadow:inset 3px 0 0 var(--red),0 0 0 2px var(--ds-color-white),0 0 0 4px var(--focus)}\n.nd.k-nh{background:var(--nh-bg);border-color:var(--nh-bd);box-shadow:inset 3px 0 0 var(--nh-ac),var(--sh-sm)}\n.nd.k-a{background:var(--a-bg);border-color:var(--a-bd);box-shadow:inset 3px 0 0 var(--a-ac),var(--sh-sm)}\n.nd.k-na{background:var(--na-bg);border-color:var(--na-bd);box-shadow:inset 3px 0 0 var(--a-ac),var(--sh-sm)}\n.nd.k-a:hover,.nd.k-na:hover{box-shadow:inset 3px 0 0 var(--a-ac),var(--sh-md)}.nd.k-nh:hover{box-shadow:inset 3px 0 0 var(--nh-ac),var(--sh-md)}\n.nd.k-adv{background:var(--adv-bg);border-color:var(--adv-bd);box-shadow:inset 3px 0 0 var(--adv-ac),var(--sh-sm)}\n.nd.k-gone{background:transparent;border:1px dashed var(--gone-bd);box-shadow:none}.nd.k-gone .lbl{text-decoration:line-through;color:var(--gone-ink)}\n.nd.k-mk{background:var(--mk-bg);color:var(--mk-ink);border-color:var(--mk-bg);box-shadow:inset 3px 0 0 var(--mk-ac),var(--sh-sm)}.nd.k-mk .nt{color:var(--mk-ink);opacity:.8}\n.sw.k-h{background:var(--h-bg);border-color:var(--h-bd);box-shadow:inset 3px 0 0 var(--h-ac)}.sw.k-nh{background:var(--nh-bg);border-color:var(--nh-bd);box-shadow:inset 3px 0 0 var(--nh-ac)}.sw.k-a{background:var(--a-bg);border-color:var(--a-bd);box-shadow:inset 3px 0 0 var(--a-ac)}.sw.k-na{background:var(--na-bg);border-color:var(--na-bd);box-shadow:inset 3px 0 0 var(--a-ac)}.sw.k-adv{background:var(--adv-bg);border-color:var(--adv-bd)}.sw.k-gone{background:transparent;border-color:var(--gone-bd);border-style:dashed}.sw.k-mk{background:var(--mk-bg);border-color:var(--mk-bg);box-shadow:inset 3px 0 0 var(--mk-ac)}\n.nd .nt{display:flex;gap:4px;align-items:center;height:13px;font-size:8.5px;color:var(--ink3);white-space:nowrap;overflow:hidden}\n.nd .nk{width:11px;height:11px;color:var(--ds-gray-dark)}.nd.k-a .nk,.nd.k-na .nk{color:var(--red)}.nd.k-nh .nk{color:var(--ink)}.nd.k-mk .nk{color:var(--mk-ac)}\n.nd .nid{flex:0 0 auto;letter-spacing:.2px}\n.nd .lbl{font-size:10px;line-height:1.3;margin-top:2px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;word-break:keep-all;overflow-wrap:anywhere}\n.nd.L5 .lbl{font-size:10.5px}.nd.L4 .lbl{font-size:12px;font-weight:700;-webkit-line-clamp:2}\n.nd .meta{font-size:9.6px;color:var(--ink2);line-height:1.4;margin-top:4px;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}\n.tg{padding:0 6px;border-radius:999px;font-size:8.5px;line-height:12px;border:1px solid transparent;overflow:hidden;text-overflow:ellipsis}\n.tg.gate{background:var(--cv1);color:var(--cv1-ink)}.tg.own{color:var(--ink);border-color:var(--nh-bd);background:var(--nh-bg)}.tg.tool{background:var(--ds-gray-dark);color:var(--ds-text-on-color)}.tg.hot{color:var(--red);border-color:var(--red);background:var(--surface)}.tg.cnt{color:var(--ink2);border-color:var(--line-strong)}\n.aib{font-style:normal;font-size:8.5px;line-height:12px;color:var(--red);border:1px solid var(--red);background:var(--surface);border-radius:999px;padding:0 5px}.aib.lead{background:var(--red);color:var(--ds-text-on-color)}\n.ty0{font-size:8.5px;color:var(--ink2);white-space:nowrap}\n.vf{font-size:8.5px;line-height:12px;color:var(--vf);border:1px dashed var(--vf);border-radius:999px;padding:0 5px;white-space:nowrap}\n.chg{position:absolute;right:5px;top:5px;width:7px;height:7px;border-radius:50%;background:var(--chg);box-shadow:0 0 0 2px var(--ds-color-white)}.chg0{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--chg)}\nbody.editing [contenteditable=\"true\"]{outline:1px dashed var(--red);outline-offset:1px;cursor:text}\n#foot{margin:14px 26px 26px;font-size:11px;color:var(--ink3);line-height:1.6}\n/* 상세 창 */\n#panel{position:fixed;right:18px;top:calc(18px + env(safe-area-inset-top,0px));width:min(460px,94vw);max-height:84vh;overflow:auto;z-index:60;background:var(--surface);border-radius:20px;padding:14px 18px 16px;box-shadow:0 24px 60px rgba(8,15,52,.16),0 2px 6px rgba(8,15,52,.06);font-size:12px}\n#panel .px,#amap .px{position:absolute;right:12px;top:10px;border:0;background:var(--cream);font-size:16px;line-height:1;padding:5px 9px;border-radius:999px;box-shadow:none}\n#panel .px:hover,#amap .px:hover{background:var(--cream2)}\n.ph{font-size:10.5px;color:var(--ink3);padding-right:36px;letter-spacing:.2px}#panel h3{font-size:15.5px;margin:5px 0 4px;line-height:1.38;color:var(--ink-strong)}#panel h4{font-size:11.5px;margin:14px 0 6px;color:var(--ink2)}\n.kd{display:inline-block;font-size:10.5px;padding:2px 10px;border-radius:999px;margin:2px 0 8px;border:1px solid var(--line-strong);background:var(--surface)}\n.kd.k-nh{background:var(--nh-bg);border-color:var(--nh-bd)}.kd.k-a,.kd.k-na{border-color:var(--red);color:var(--red)}.kd.k-mk{background:var(--mk-bg);color:var(--mk-ink)}.kd.k-gone{border-style:dashed}\n.painbox{position:relative;background:var(--pain-bg);border-radius:14px;padding:10px 13px 10px 16px;margin:4px 0 12px;overflow:hidden}\n.painbox::before{content:\"\";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--pain-bd)}\n.painbox>b{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--red);margin-bottom:4px}.painbox small{display:block;font-size:10px;color:var(--ink2);margin-top:6px}.painbox p{margin:1px 0;font-size:11.6px;line-height:1.6;color:var(--ink)}\ntable.kv{border-collapse:collapse;width:100%;font-size:11.2px}table.kv th{text-align:left;vertical-align:top;color:var(--ink3);font-weight:500;width:84px;padding:5px 8px 5px 0;border-top:1px solid var(--line)}table.kv td{padding:5px 0;border-top:1px solid var(--line)}\ntable.cb{border-collapse:separate;border-spacing:0;width:100%;font-size:11px;margin-top:2px;border:1px solid var(--line);border-radius:12px;overflow:hidden}table.cb th{font-weight:500;color:var(--ink3);text-align:left;padding:5px 7px;background:var(--cream);border-bottom:1px solid var(--line)}table.cb td{padding:5px 7px;border-bottom:1px solid var(--line);vertical-align:top}\ntable.cb .cp{white-space:normal;max-width:none}\nul.ls{margin:0;padding-left:16px}ul.ls li{margin:4px 0}ul.ls small{color:var(--ink2)}\n.ty{font-style:normal;font-size:10px;padding:0 7px;border-radius:999px;border:1px solid var(--line-strong)}.ty-A{color:var(--red);border-color:var(--red)}.ty-N{color:var(--ink);background:var(--nh-bg);border-color:var(--nh-bd)}.ty-X{color:var(--ink3);text-decoration:line-through}.ty-ADV{color:var(--red);border-color:var(--red)}\n.pain{background:var(--bg);border-radius:8px;padding:6px 8px;font-size:11px;margin:4px 0}.none{color:var(--ink3);font-size:11px}.src{font-size:11px;color:var(--ink2)}.hint{font-size:11px;color:var(--ink3)}\n.lk{border:0;background:transparent;padding:0;color:var(--red);text-decoration:underline;font-weight:700;box-shadow:none}\n.pgo{margin-top:12px;width:100%;background:var(--red);color:var(--ds-text-on-color);border-color:var(--red);font-weight:700}.pgo:hover{background:var(--red-dk);border-color:var(--red-dk)}\n/* Agent 구조도 */\n#amap{position:fixed;inset:0;z-index:55;background:var(--bg);overflow:auto;padding:20px 22px 30px}\n.amh{display:flex;gap:12px;align-items:baseline;flex-wrap:wrap;margin-bottom:14px;padding-right:40px}.amh b{font-size:18px;color:var(--ink-strong)}.amh span{font-size:11.5px;color:var(--ink2)}\n.amg{display:grid;grid-template-columns:repeat(auto-fill,minmax(430px,1fr));gap:16px}\n.amb{border-radius:18px;background:var(--surface);padding:12px 14px;box-shadow:var(--sh-lg);position:relative;overflow:hidden}\n.amb::before{content:\"\";position:absolute;left:0;top:0;right:0;height:4px;background:var(--red)}\n.amb header{cursor:pointer;margin:2px 0 10px;padding:8px 10px;border-radius:12px;background:var(--cream)}.amb header b{color:var(--red);font-size:13.5px;display:block}.amb header span{font-size:11px;color:var(--ink2);display:block;margin-bottom:4px}\n.amb header .pgo{width:auto;margin:6px 0 0;padding:3px 12px;font-size:11px}\n.ams{display:grid;grid-template-columns:repeat(auto-fill,minmax(195px,1fr));gap:9px}\n.ams article{border:1px dashed var(--sub-bd);border-radius:14px;padding:8px 9px;cursor:pointer;background:var(--surface);transition:box-shadow .18s,transform .18s}.ams article:hover{box-shadow:var(--sh-md);transform:translateY(-1px)}\n.ams article b{font-size:11.6px;display:block;color:var(--ink-strong)}.ams article small{font-size:10px;color:var(--ink3)}.ams article p{font-size:10.6px;margin:3px 0;color:var(--ink2)}\n/* Agent 상세 페이지 */\n#apage{position:fixed;inset:0;z-index:57;background:var(--bg);display:flex;flex-direction:column}\n.aph{display:flex;align-items:center;gap:8px;padding:11px 18px;background:var(--surface);box-shadow:var(--sh-sm);z-index:2}.aph b{font-size:14px;color:var(--ink-strong)}.aph .sp{flex:1}\n.aph .dot{width:8px;height:8px;border-radius:50%;background:var(--red);box-shadow:0 0 0 4px var(--cream)}\n.apb{flex:1;display:grid;grid-template-columns:270px minmax(0,1fr);min-height:0}\n.aps{overflow:auto;padding:14px 12px;background:var(--surface);border-right:1px solid var(--line)}\n.apn{display:block;width:100%;text-align:left;margin:0 0 7px;padding:9px 12px 9px 44px;position:relative;border-radius:14px;border:1px solid transparent;background:transparent;box-shadow:none}\n.apn:hover{background:var(--bg);box-shadow:none;border-color:var(--line)}\n.apn .apx{position:absolute;left:11px;top:10px;width:23px;height:23px;border-radius:50%;background:var(--cream);color:var(--ink);font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center}\n.apn b{display:block;font-size:12.6px;color:var(--ink-strong)}.apn small{color:var(--ink3);font-size:10.5px}\n.apn.on{background:var(--cream);border-color:var(--cream2)}.apn.on .apx{background:var(--red);color:var(--ds-text-on-color)}\n.apm{overflow:auto;padding:20px 28px 48px}\n.apt{display:flex;gap:22px;justify-content:space-between;align-items:center;flex-wrap:wrap;padding:18px 22px;border-radius:22px;background:var(--surface);box-shadow:var(--sh-lg);position:relative;overflow:hidden}\n.apt::before{content:\"\";position:absolute;left:0;top:0;bottom:0;width:5px;background:var(--red)}\n.apt .apl{display:flex;gap:14px;align-items:center}\n.apico{width:52px;height:52px;border-radius:16px;background:var(--cream);color:var(--red);padding:12px;flex:0 0 auto;box-shadow:inset 0 0 0 1px var(--cream2)}\n.apk{font-size:10.5px;color:var(--red);font-weight:700;letter-spacing:.5px}.apt h2{margin:3px 0 4px;font-size:22px;color:var(--ink-strong);letter-spacing:-.3px}.apt p{margin:0;color:var(--ink2);max-width:640px}\n.kpis{display:flex;gap:0;background:var(--bg);border-radius:16px;padding:4px}\n.kpi{min-width:108px;padding:8px 14px;border-radius:12px}.kpi+.kpi{border-left:1px solid var(--line)}\n.kpi b{display:block;font-size:21px;color:var(--ink-strong);line-height:1.25}.kpi span{font-size:11px;color:var(--ink2)}.kpi small{display:block;font-size:10px;color:var(--ink3)}\n.apm section{margin-top:24px}\n.apm h3{display:flex;align-items:center;gap:8px;font-size:15px;margin:0 0 12px;color:var(--ink-strong)}\n.apm h3 .h3i{width:26px;height:26px;border-radius:9px;background:var(--cream);color:var(--red);padding:5px}\n.aptabs{display:inline-flex;background:var(--cream);border-radius:999px;padding:3px;gap:2px;margin:0 0 12px}\n.aptabs button{border:0;border-radius:999px;padding:5px 14px;background:transparent;box-shadow:none}\n.aptabs button[aria-pressed=\"true\"]{background:var(--surface);color:var(--ink-strong);font-weight:700;box-shadow:var(--sh-sm)}\n.panelcard{background:var(--surface);border-radius:20px;box-shadow:var(--sh-lg);padding:14px 16px}\n.tl{display:grid;grid-template-columns:repeat(7,minmax(165px,1fr));gap:10px;overflow-x:auto;padding-bottom:4px}\n.tls{border-radius:16px;background:var(--surface);min-height:110px;opacity:.5;box-shadow:var(--sh-sm)}.tls.on{opacity:1;box-shadow:var(--sh-md)}\n.tlh{display:flex;gap:7px;align-items:center;padding:9px 11px;font-size:11.5px;font-weight:700;color:var(--ink2)}.tls.on .tlh{background:var(--cream);border-radius:16px 16px 0 0;color:var(--ink-strong)}\n.tln{display:inline-flex;align-items:center;justify-content:center;width:21px;height:21px;border-radius:50%;background:var(--ds-gray-dark);color:var(--ds-text-on-color);font-size:10.5px;font-weight:700;flex:0 0 auto}\n.tls.on .tln{background:var(--red)}.tln.sm{width:19px;height:19px;font-size:10px;margin-right:3px;background:var(--red)}\n.tlb{padding:8px}.tlc{border:1px dashed var(--sub-bd);border-radius:12px;padding:7px 8px;margin-bottom:7px;background:var(--surface)}.tlc b{font-size:11px;color:var(--red)}\n.tlc ul{margin:4px 0 0;padding:0;list-style:none}.tlc li{font-size:10.8px;line-height:1.45;margin:4px 0}\n.tid{font-size:9.5px;color:var(--ink3);margin-right:4px;white-space:nowrap;letter-spacing:.2px}\n.mxs{margin:0 0 10px;font-size:12px;color:var(--ink2)}.st-h,.st-n{font-weight:700;border-radius:999px;padding:1px 9px}.st-h{color:var(--have-ink);background:var(--have-bg);border:1px solid var(--have-bd)}.st-n{color:var(--need-ink);background:var(--need-bg);border:1px dashed var(--need-bd)}\n.tblw{overflow-x:auto;border-radius:16px;background:var(--surface);box-shadow:var(--sh-md)}\ntable.mx2,table.tk{border-collapse:collapse;width:100%;font-size:11.5px}\ntable.mx2 th,table.tk th{background:var(--cream);text-align:left;font-weight:700;color:var(--ink);padding:8px 10px;white-space:nowrap;font-size:11px}\ntable.mx2 td,table.tk td{padding:7px 10px;border-top:1px solid var(--line);vertical-align:top}table.mx2 .cp{white-space:normal;max-width:none}\ntable.mx2 tr:hover td,table.tk tr:hover td{background:var(--bg)}\n.stp{font-size:10.5px;padding:1px 9px;border-radius:999px;white-space:nowrap}.stp.h{background:var(--have-bg);color:var(--have-ink);border:1px solid var(--have-bd)}.stp.n{background:var(--need-bg);color:var(--need-ink);border:1px dashed var(--need-bd)}\n.sbt{display:inline-block;font-size:10.5px;padding:0 8px;margin:1px 3px 1px 0;border-radius:999px;background:var(--cream);color:var(--ink)}td.ev{font-size:10.5px;color:var(--ink3)}\n.sbs{border-radius:20px;background:var(--surface);padding:16px 18px;margin:0 0 16px;box-shadow:var(--sh-lg);position:relative;overflow:hidden}\n.sbs::before{content:\"\";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--red)}\n.sbs header{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:10px}.sbs h4{margin:0;font-size:15px;color:var(--ink-strong)}.sbs header p{margin:3px 0 0;color:var(--ink2);font-size:12px}\n.sbm{display:flex;align-items:center;gap:2px;white-space:nowrap}.sbg{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(0,1fr);gap:18px;margin-bottom:8px}\n.sbs h5{font-size:11.5px;color:var(--ink2);margin:8px 0 6px}.outs{display:flex;flex-wrap:wrap;gap:5px}.oc{font-size:10.5px;padding:2px 9px;border-radius:999px;background:var(--cream);color:var(--ink)}\ntable.tk td.c{text-align:center;color:var(--ink3)}table.tk td.tid{white-space:nowrap}table.tk td.pc{min-width:280px}table.tk td.pc p{margin:0 0 3px;font-size:11px;line-height:1.55}table.tk td.pc small{color:var(--ink3);font-size:10px}\n@media (max-width:900px){.sbg{grid-template-columns:1fr}.apb{grid-template-columns:1fr;grid-template-rows:auto minmax(0,1fr)}.aps{display:flex;overflow-x:auto;border-right:0;border-bottom:1px solid var(--line)}.apn{min-width:210px;margin:0 6px 0 0}}\n/* Agent 페이지 — Capability map */\n.cmctl{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center;margin:0 0 12px}\n.cmlg{display:inline-flex;align-items:center;gap:5px;font-size:11px;color:var(--ink2)}.cmlg i{display:inline-block;width:14px;height:8px;border-radius:4px}\n.cmlg i.A,.cmbar .A{background:var(--red)}.cmlg i.N,.cmbar .N{background:var(--cream3)}.cmlg i.H,.cmbar .H{background:var(--ds-gray-dark)}.cmlg i.X,.cmbar .X{background:var(--ds-gray-light)}\n.cmlg .sep2{display:inline-block;width:1px;height:12px;background:var(--line-strong);margin:0 4px}.cmlg .mebox{display:inline-block;width:12px;height:12px;border-radius:3px;box-shadow:inset 3px 0 0 var(--red);background:var(--cream)}\n.cm{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(240px,1fr);gap:12px;overflow-x:auto;padding-bottom:6px;align-items:start}\n.cm.cm6{grid-auto-columns:minmax(300px,1fr)}\n.cmc{background:var(--bg);border-radius:18px;padding:10px}\n.cmh{display:flex;align-items:center;gap:7px;font-weight:700;font-size:12px;color:var(--ink-strong);padding:2px 4px 9px;margin-bottom:9px;border-bottom:1px solid var(--line-strong)}\n.cmc.rel .cmh{border-bottom-color:var(--red)}.cmc.rel .tln{background:var(--red)}\n.cmt{background:var(--surface);border-radius:14px;padding:9px 10px;margin-bottom:9px;box-shadow:var(--sh-sm)}.cmt.rel{box-shadow:inset 0 3px 0 var(--red),var(--sh-md)}.cmt.dim{opacity:.55}\n.cmt h6{margin:0 0 6px;font-size:11.8px;line-height:1.38;color:var(--ink-strong)}.cmt h6 .tid{display:block}\n.cml{display:grid;grid-template-columns:40px 1fr;gap:2px 6px;font-size:10.8px;line-height:1.5}.cml b{font-size:9.5px;color:var(--ink3);padding-top:1px}.cml .tb{color:var(--ink)}\n.me{color:var(--red);font-weight:700}\n.cmbar{display:flex;height:7px;border-radius:999px;overflow:hidden;margin:7px 0 2px;background:var(--ds-gray-light);gap:1px}.cmbar i{display:block;height:100%}\n.cmsub{margin:6px 0 0;font-size:10.5px;color:var(--ink2)}\n.cmrs{margin-top:7px}\n.cmr{display:grid;grid-template-columns:62px minmax(0,1fr);gap:1px 6px;padding:6px 4px 6px 8px;border-top:1px solid var(--line);font-size:10.6px;line-height:1.42;border-radius:0}\n.cmr .tid{grid-row:span 2;padding-top:1px}.cmr .cn{color:var(--ink)}.cmr.me{box-shadow:inset 3px 0 0 var(--red);background:var(--cream);border-radius:8px}.cmr.me .cn{font-weight:700;color:var(--ink-strong)}\n.cmr.t-X .cn{text-decoration:line-through;color:var(--ink3)}\n.cmr .io{display:flex;flex-wrap:wrap;gap:3px 5px;align-items:center;font-size:10px;color:var(--ink2)}.cmr .lab{font-size:9px;color:var(--ink3);font-weight:700}.cmr .ar{color:var(--ink3)}.cmr .who{color:var(--ink)}\n.ty6{font-size:9.5px;line-height:14px;padding:0 6px;border-radius:999px;border:1px solid var(--line-strong);background:var(--surface)}.ty6.A{border-color:var(--red);color:var(--red)}.ty6.N{background:var(--nh-bg);border-color:var(--nh-bd)}.ty6.X{border-style:dashed;color:var(--ink3)}.ty6.new{background:var(--red);border-color:var(--red);color:var(--ds-text-on-color)}\n/* Agent 페이지 — 흐름도 (As-Is ↔ To-be 애니메이션) */\n.af{background:var(--surface);border-radius:20px;box-shadow:var(--sh-lg);overflow:hidden}\n.afctl{display:flex;flex-wrap:wrap;gap:8px 12px;align-items:center;padding:10px 14px;border-bottom:1px solid var(--line)}\n.afctl .afscr button[data-af=\"scr:ns\"][aria-pressed=\"true\"]{background:var(--red);color:var(--ds-text-on-color)}\n.afhint{font-size:11px;color:var(--ink3)}\n.afwrap{overflow:auto;max-height:72vh}\n.afin{display:grid;grid-template-columns:190px max-content;width:max-content}\n.aflab{position:sticky;left:0;z-index:4;background:var(--surface);border-right:1px solid var(--line)}\n.afl{position:absolute;left:0;width:190px;padding:8px 10px;border-top:1px solid var(--line);display:flex;gap:8px;align-items:flex-start;background:var(--surface)}\n.afl .lic{width:24px;height:24px;border-radius:50%;background:var(--cream);color:var(--ink);padding:5px;flex:0 0 auto}\n.afl b{display:block;font-size:11.5px;color:var(--ink-strong);line-height:1.3}.afl small{display:block;font-size:10px;color:var(--ink3)}\n.afl.sub .lic{background:var(--red);color:var(--ds-text-on-color)}.afl.sub b{color:var(--red)}.afl.oth .lic{background:var(--ds-gray-light)}\n.afl.head{border-top:0;align-items:center;font-size:10.5px;color:var(--ink3)}\n.afboard{position:relative}\n.afbg{position:absolute;left:0;pointer-events:none}\n.afrow{border-top:1px solid var(--line)}.afrow.alt{background:rgba(8,15,52,.014)}.afrow.sub{background:var(--cream)}.afrow.sub.first{border-top:2px solid var(--red)}.afrow.oth{background:var(--bg)}\n.afst{position:absolute;top:6px;height:22px;border-radius:999px;background:var(--cv1);color:var(--cv1-ink);font-size:11px;font-weight:700;display:flex;align-items:center;gap:6px;padding:0 10px;white-space:nowrap;overflow:hidden}\n.afst .sn{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;background:var(--red);color:var(--ds-text-on-color);font-size:9.5px}\n.afsep{position:absolute;top:0;width:0;border-left:1px dashed var(--line-strong)}\n.afedges{position:absolute;left:0;top:0;z-index:3;pointer-events:none;overflow:visible}\n.afn{cursor:pointer}.afn.mine{box-shadow:inset 3px 0 0 var(--red),0 0 0 2px var(--cream),var(--sh-md)}.afn.oth{opacity:.55}\n.cmr[data-id],.cmt[data-l5],.cmt[data-st],[data-tid]{cursor:pointer}.cmr[data-id]:hover{background:var(--bg);border-radius:8px}.cmr.me[data-id]:hover{background:var(--cream2)}\n.cmt[data-l5]:hover,.cmt[data-st]:hover{box-shadow:inset 0 0 0 1px var(--line-strong),var(--sh-md)}.cmt.rel[data-l5]:hover,.cmt.rel[data-st]:hover{box-shadow:inset 0 3px 0 var(--red),inset 0 0 0 1px var(--line-strong),var(--sh-md)}\n.tlc li[data-tid]:hover{color:var(--red)}table.tk tr[data-tid]:hover td{background:var(--cream)}ul.ls li[data-tid]:hover{color:var(--red)}\n.apov{flex:1 1 100%;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.25fr);gap:16px 28px;margin-top:4px;padding-top:16px;border-top:1px solid var(--line)}\n.apov h5{display:flex;align-items:center;gap:7px;font-size:12px;font-weight:700;color:var(--red);margin:0 0 9px;letter-spacing:.2px}\n.apov h5 .ic{width:22px;height:22px;border-radius:8px;background:var(--cream);color:var(--red);padding:4px}\n.ovp p{margin:0 0 10px;font-size:13.2px;line-height:1.75;color:var(--ink)}\n.ovp .ovh{font-size:12px;color:var(--ink2);background:var(--bg);border-radius:12px;padding:9px 13px;line-height:1.65}\n.ovi ul{margin:0;padding:0;list-style:none}.ovi li{display:flex;gap:10px;align-items:flex-start;font-size:12.3px;line-height:1.65;margin:0 0 8px;color:var(--ink)}\n.ovt{flex:0 0 auto;font-size:10px;font-weight:700;padding:1px 10px;border-radius:999px;background:var(--cream);color:var(--ink);margin-top:2px;white-space:nowrap}\n.ovsw{grid-column:1/-1}\n.ovs{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:12px;margin-bottom:8px}\n.ovs article{border:1px solid var(--line);border-radius:16px;padding:13px 15px 12px 17px;background:var(--surface);box-shadow:var(--sh-sm);position:relative;overflow:hidden}\n.ovs article::before{content:\"\";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--red)}\n.ovs article header{display:flex;justify-content:space-between;align-items:baseline;gap:8px;margin-bottom:2px}.ovs article header b{font-size:13.2px;color:var(--ink-strong)}\n.ovs h6{font-size:10.5px;color:var(--ink3);margin:10px 0 4px;font-weight:700;letter-spacing:.3px}\n.ovs ul{margin:0;padding-left:17px}.ovs li{font-size:11.9px;line-height:1.62;margin:3px 0;color:var(--ink)}\n.ovs ul.pn li::marker{color:var(--red)}\n.ove{margin:10px 0 0;font-size:11.9px;line-height:1.6;background:var(--cream);border-radius:11px;padding:8px 12px;color:var(--ink)}.ove b{color:var(--red);margin-right:6px}\n.idc{font-size:9.5px;line-height:15px;padding:0 7px;margin:0 2px 0 0;border-radius:999px;border:1px solid var(--line-strong);background:var(--surface);color:var(--ink2);box-shadow:none;vertical-align:1px}\n.idc:hover{border-color:var(--red);color:var(--red);box-shadow:none}\n@media (max-width:1100px){.apov{grid-template-columns:1fr}}\n/* ── 뷰티파이 2차: 따뜻한 바탕, 고정 컨트롤, 7단계 스텝, 정돈된 범례·카드·상세 창 ── */\nbody{background:linear-gradient(180deg,var(--ds-other-100) 0,var(--ds-gray-x-light) 460px) no-repeat,var(--ds-gray-x-light)}\n::selection{background:var(--cream2)}\n*{scrollbar-width:thin;scrollbar-color:var(--ds-gray-medium) transparent}\n*::-webkit-scrollbar{width:10px;height:10px}*::-webkit-scrollbar-track{background:transparent}\n*::-webkit-scrollbar-thumb{background:var(--ds-gray-medium);border-radius:999px;border:3px solid transparent;background-clip:padding-box}*::-webkit-scrollbar-thumb:hover{background:var(--ds-gray-dark);border:3px solid transparent;background-clip:padding-box}\n@keyframes rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}\n#top>*{animation:rise .5s ease both}#top>*:nth-child(2){animation-delay:.05s}#top>*:nth-child(3){animation-delay:.1s}#top>*:nth-child(4){animation-delay:.15s}#stageWrap{animation:rise .55s .18s ease both}\n.hero{flex-wrap:wrap;padding:22px 28px 18px;border-radius:26px;box-shadow:0 1px 0 var(--line),var(--sh-lg)}\n.hero::before{width:6px}\n.hero::after{content:\"\";position:absolute;right:-70px;top:-110px;width:300px;height:300px;border-radius:50%;background:var(--cream);pointer-events:none}\n.hero>*{position:relative;z-index:1}\nh1{font-size:27px;letter-spacing:-.7px}.hero .eyebrow{letter-spacing:1.3px}\n.ver{background:var(--surface);border:1px solid var(--cream2);box-shadow:var(--sh-sm)}\n.steps{flex:1 1 100%;display:flex;align-items:center;gap:0;margin-top:14px;overflow-x:auto;padding:2px 2px 4px}\n.stp2{display:flex;align-items:center;gap:8px;border:1px solid var(--line);border-radius:16px;background:var(--surface);padding:7px 11px 7px 8px;min-width:150px;text-align:left;box-shadow:var(--sh-sm);flex:1 1 0}\n.stp2:hover{border-color:var(--cream3);box-shadow:var(--sh-md);transform:translateY(-1px)}\n.stp2 .sn{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:50%;background:var(--cream);color:var(--ink-strong);font-size:11.5px;font-weight:700;flex:0 0 auto}\n.stp2 .stx{display:flex;flex-direction:column;min-width:0;flex:1}.stp2 b{font-size:11.8px;color:var(--ink-strong);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.stp2 small{font-size:10px;color:var(--ink3)}\n.stp2 .stbar{display:block;height:4px;border-radius:999px;background:var(--ds-gray-light);margin-top:4px;overflow:hidden}.stp2 .stbar i{display:block;height:100%;background:var(--red);border-radius:999px}\n.stp2[aria-pressed=\"true\"]{background:var(--surface);color:inherit;border-color:var(--red);box-shadow:0 0 0 3px var(--cream),var(--sh-md)}.stp2[aria-pressed=\"true\"] .sn{background:var(--red);color:var(--ds-text-on-color)}\n.stl{flex:0 0 14px;height:2px;background:var(--cream2);border-radius:2px}\n#controls{position:sticky;top:10px;z-index:45;border:1px solid var(--line);border-radius:18px;box-shadow:var(--sh-md);padding:8px 12px}\n.seg{box-shadow:inset 0 0 0 1px var(--cream2)}\n#summary{flex-direction:column;gap:6px;margin:10px 6px 8px}\n.sm{gap:10px}.smt{flex:0 1 auto}\n.smb{display:inline-flex;width:200px;height:8px;border-radius:999px;overflow:hidden;background:var(--ds-gray-light);gap:2px;flex:0 0 auto;box-shadow:inset 0 0 0 1px var(--surface)}\n.smb i{display:block;height:100%}.smb .A{background:var(--red)}.smb .N{background:var(--cream3)}.smb .H{background:var(--ds-gray-dark)}.smb .X{background:var(--ds-gray-medium)}.smb .new{background:repeating-linear-gradient(45deg,var(--red) 0 3px,var(--surface) 3px 5px)}\n#legend{background:var(--surface);border-radius:18px;box-shadow:var(--sh-sm);padding:9px 14px;gap:6px 0;margin:0 0 4px}\n.lgg{background:transparent;box-shadow:none;padding:2px 14px;border-radius:0}.lgg:first-child{padding-left:2px}.lgg+.lgg{border-left:1px solid var(--line)}.lgg.hint{border-left:0;flex:1 1 100%;padding:4px 2px 0}\n#stageWrap{margin-top:10px;border-radius:26px;box-shadow:0 1px 0 var(--line),var(--sh-lg)}\n#slbar{padding:11px 20px;background:linear-gradient(180deg,var(--surface),var(--ds-gray-x-light))}\n#sllab b{font-size:14px}\n.cv.r1{border-radius:11px;box-shadow:var(--cv-inset)}\n.lc .lic{box-shadow:inset 0 0 0 1px var(--cream2)}\n.lc.lane:hover .lic{background:var(--cream2)}\n.nd{border-radius:11px}\n.nd:hover{transform:translateY(-2px)}\n.nd.act{box-shadow:inset 3px 0 0 var(--red),0 0 0 2px var(--ds-color-white),0 0 0 4px var(--red),var(--sh-md)!important;z-index:7}\n.bandf{border-radius:20px}.bandh{border-radius:18px 18px 0 0}\n.elab{font-weight:700}\n#panel{border-radius:24px;padding:16px 20px 18px;box-shadow:var(--sh-xl);animation:rise .25s ease both}\n#panel h3{font-size:16.5px;letter-spacing:-.2px}\n#panel h4{display:flex;align-items:center;gap:6px}#panel h4::before{content:\"\";width:6px;height:6px;border-radius:50%;background:var(--red)}\ntable.kv tr:nth-child(even) th,table.kv tr:nth-child(even) td{background:var(--ds-gray-x-light)}table.kv th{padding-left:8px}table.kv td{padding-right:6px}\n#amap .amb,#amap .ams article{transition:box-shadow .2s,transform .2s}#amap .amb:hover{transform:translateY(-2px)}\n.aph{padding:12px 20px}\n.apn{transition:background .18s,border-color .18s}.apn.on{box-shadow:inset 3px 0 0 var(--red)}\n.apm>*{animation:rise .45s ease both}.apm>*:nth-child(2){animation-delay:.05s}.apm>*:nth-child(3){animation-delay:.1s}.apm>*:nth-child(4){animation-delay:.15s}.apm>*:nth-child(5){animation-delay:.2s}\n.apt{border-radius:26px;padding:22px 26px}\n.apt::after{content:\"\";position:absolute;right:-80px;top:-120px;width:300px;height:300px;border-radius:50%;background:var(--cream);pointer-events:none}\n.apt>*{position:relative;z-index:1}\n.kpis{background:var(--surface);box-shadow:inset 0 0 0 1px var(--line),var(--sh-sm)}\n.apov{border-top:1px dashed var(--cream3)}\n.ovs article{transition:box-shadow .2s,transform .2s}.ovs article:hover{box-shadow:var(--sh-md);transform:translateY(-2px)}\n.tls.on{box-shadow:inset 0 3px 0 var(--red),var(--sh-md)}\n.sbs{border-radius:24px}.af{border-radius:24px}.panelcard{border-radius:24px}.tblw{border-radius:18px}\ntable.cb{table-layout:fixed}table.cb tr>th:first-child{width:52px;white-space:nowrap}table.cb tr:first-child>th:nth-child(2){width:57%}table.cb td .cp{max-width:100%}\n/* 지도 위 데이터·시스템 띠 */\n.bandh{overflow:visible}\n.bhin{position:sticky;left:calc(var(--lbw) + 14px);display:inline-flex;align-items:center;gap:10px;white-space:nowrap}\n.rib{left:13px;height:44px;z-index:4;pointer-events:none}\n.afrib{position:absolute;left:7px;height:44px;z-index:4;pointer-events:none}\n.ribin{position:sticky;left:calc(var(--lbw) + 14px);display:inline-flex;flex-direction:column;align-items:flex-start;gap:3px;padding:4px 12px 4px 10px;white-space:nowrap;pointer-events:auto;cursor:pointer;background:var(--surface);border:1px solid var(--line);border-radius:14px;box-shadow:var(--sh-sm)}\n.ribin:hover{border-color:var(--cream3);box-shadow:var(--sh-md)}\n.af .ribin{left:204px;cursor:default}\n.rg{display:inline-flex;align-items:center;gap:3px;height:17px}\n.rl{font-size:9.5px;color:var(--ink-strong);font-weight:700;margin-right:3px;width:34px}\n.rk{font-size:8.5px;font-weight:700;padding:0 7px;border-radius:999px;margin:0 3px 0 4px;line-height:14px;white-space:nowrap;display:inline-block}\n.rk.h{color:var(--have-ink);background:var(--have-bg);border:1px solid var(--have-bd)}\n.rk.n{color:var(--red);background:var(--surface);border:1px dashed var(--red)}\n.rsep{display:inline-block;width:1px;height:12px;background:var(--line-strong);margin:0 7px}\n.ribin .cp{margin:0 2px 0 0;line-height:15px;max-width:150px}\n.cps{display:inline-flex;align-items:center;flex-wrap:wrap;gap:3px;font-style:normal}\n.cpl{font-size:9.5px;color:var(--ink2);margin:0 1px 0 5px}.cps .cpl:first-child{margin-left:0}\n.cps i{font-style:normal;font-size:9px;font-weight:700;padding:0 6px;border-radius:999px;line-height:14px}\n.cps .ch{color:var(--have-ink);background:var(--have-bg);border:1px solid var(--have-bd)}.cps .cn{color:var(--red);background:var(--surface);border:1px dashed var(--red)}\n.lc.sub .scd{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:10px;color:var(--ink2);line-height:1.4;margin:2px 0 5px}\n.nd .meta .mbar{display:flex;height:5px;border-radius:999px;overflow:hidden;background:var(--ds-gray-light);gap:1px;margin:4px 0 2px}.nd .meta .mbar i{display:block;height:100%}\n.mbar .A{background:var(--red)}.mbar .N{background:var(--cream3)}.mbar .H{background:var(--ds-gray-dark)}.mbar .X{background:var(--ds-gray-medium)}\n.nd .meta .mtx{display:block;font-size:9px;color:var(--ink3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.nd.L5 .lbl{-webkit-line-clamp:2}.nd.L5 .meta{margin-top:2px;display:block}\n.nd.k-pt{background:var(--surface);border:1px dashed var(--red);box-shadow:none;opacity:.92}.nd.k-pt .nk{color:var(--red)}.nd.k-pt .lbl{color:var(--ink2)}.nd.k-pt:hover{box-shadow:var(--sh-md)}\n.sw.k-pt{background:var(--surface);border:1px dashed var(--red)}\n/* 제목 고정 */\n.stitle{display:inline-flex;align-items:center;gap:7px;font-size:12.5px;font-weight:700;color:var(--ink-strong);padding:0 10px 0 4px;margin-right:4px;border-right:1px solid var(--line);white-space:nowrap;max-width:100%}\n.stitle .dot{width:7px;height:7px;border-radius:50%;background:var(--red);box-shadow:0 0 0 3px var(--cream);flex:0 0 auto}\n.ptitle{display:none;font-size:13px;font-weight:700;color:var(--ink-strong);margin-right:12px}body.present .ptitle{display:inline}\n.aphs{font-size:11.5px;color:var(--ink3);margin-left:8px}\n/* 소멸 이유 박스 */\n.nd.k-why{background:var(--cream);border:1px dashed var(--cream3);box-shadow:none;cursor:pointer;overflow:visible}\n.nd.k-why::before{content:\"\";position:absolute;left:18px;top:-7px;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:7px solid var(--cream3)}\n.nd.k-why .lbl{font-size:9.6px;line-height:1.38;color:var(--ink);-webkit-line-clamp:3}.nd.k-why .nk{color:var(--ink2)}.nd.k-why:hover{box-shadow:var(--sh-md);transform:none}\n.tg.why{background:var(--surface);color:var(--ink);border:1px solid var(--cream3)}\n.sw.k-why{background:var(--cream);border:1px dashed var(--cream3)}\n.nd .nt{padding-right:9px}\n/* 뒤로·앞으로 */\n.navb{display:inline-flex;gap:3px;margin-right:2px}.navb button{width:30px;height:28px;padding:0;border-radius:50%;font-size:15px;line-height:26px;text-align:center}\n.navb button:not(:disabled):hover{color:var(--red);border-color:var(--red)}\n.aph .navb{margin-right:8px}.amh .navb{margin-right:6px}\n/* Agent 한눈에 보기 (4열 정리표) */\n.apov{grid-template-columns:minmax(0,1.35fr) minmax(0,1fr)}\n.x4w{border:1px solid var(--line);border-radius:18px;overflow:hidden;background:var(--surface);box-shadow:var(--sh-sm)}\n.x4{display:grid;grid-template-columns:190px minmax(0,1.2fr) minmax(0,1.05fr) minmax(0,.95fr) minmax(0,1.25fr)}\n.x4h{background:var(--cream);font-size:11.8px;font-weight:700;color:var(--ink-strong)}\n.x4h>div{padding:10px 12px;display:flex;align-items:center;gap:6px;flex-wrap:wrap}.x4h small{font-weight:400;color:var(--ink3);font-size:10px}\n.x4n{display:inline-flex;align-items:center;justify-content:center;width:19px;height:19px;border-radius:50%;background:var(--red);color:var(--ds-text-on-color);font-size:10px;flex:0 0 auto}\n.x4r{border-top:1px solid var(--line)}.x4r>div{padding:12px 13px;border-left:1px solid var(--line2)}.x4r>div:first-child{border-left:0}\n.x4r.big{background:var(--ds-gray-x-light);border-top:0}\n.x4r:hover{background:var(--ds-gray-x-light)}\n.x4a{display:flex;flex-direction:column;gap:2px}.x4a b{font-size:13.2px;line-height:1.35;color:var(--ink-strong)}.x4r.big .x4a b{color:var(--red);font-size:14.5px}.x4a small{font-size:10.3px;color:var(--ink3)}\n.x4i{width:28px;height:28px;border-radius:10px;background:var(--cream);color:var(--red);padding:6px;margin-bottom:4px}.x4i.sm{width:24px;height:24px;padding:5px}\n.x4c p{margin:0;font-size:12.2px;line-height:1.65;color:var(--ink)}.x4c ul{margin:0;padding-left:16px}.x4c li{font-size:11.9px;line-height:1.58;margin:2px 0;color:var(--ink)}.x4c ul.pn li::marker{color:var(--red)}\n.x4g{margin:0 0 7px;line-height:1.95}.x4g .rk{margin:0 4px 0 0}\n.x4c .cp{white-space:normal;max-width:100%}.x4c .ove{margin-top:9px}\n@media (max-width:1150px){.x4{grid-template-columns:1fr}.x4h{display:none}.x4r>div{border-left:0}.x4r>.x4c{border-top:1px dashed var(--line2)}.x4c::before{content:attr(data-h);display:block;font-size:10.5px;font-weight:700;color:var(--red);margin-bottom:5px}}\n.cmr{grid-template-columns:minmax(0,1fr)}\n/* 데이터·시스템을 왼쪽 세부 Agent 카드로 */\n:root{--lbw:198px}\n.lc.sub{padding:8px 11px 8px}.lc.sub b{font-size:11.6px;margin-bottom:2px}\n.lc.sub .scd{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:10px;color:var(--ink2);line-height:1.4;margin:1px 0 5px}\n.scg{display:flex;gap:6px;align-items:flex-start;margin-top:4px}\n.sct{flex:0 0 36px;font-size:9.5px;font-weight:700;color:var(--ink-strong);padding-top:2px;white-space:nowrap}\n.scl{flex:1;min-width:0;line-height:0}\n.scl .rk{margin:1px 3px 1px 0;vertical-align:top;line-height:13px}\n.scl .cp{margin:1px 3px 1px 0}.lc.sub .scl .cp{max-width:160px}\n.afin{grid-template-columns:262px max-content}.afl{width:262px}.afl .aflt{min-width:0;flex:1}.afl .scg{margin-top:3px}.afl .sct{flex-basis:32px}.afl.sub .scl .cp{max-width:120px}\n/* 정리표: 불릿·큰 글씨 */\n.x4{grid-template-columns:200px minmax(0,1.3fr) minmax(0,1fr) minmax(0,1fr) minmax(0,1.3fr)}\n.x4h{font-size:13.5px}.x4h>div{padding:12px 14px}\n.x4n{width:21px;height:21px;font-size:11px}\n.x4r>div{padding:14px 16px}\n.x4a b{font-size:15px}.x4r.big .x4a b{font-size:17px}.x4a small{font-size:11px}\n.x4num{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;border-radius:50%;background:var(--cream);color:var(--red);font-size:12px;font-weight:700;margin-bottom:4px;box-shadow:inset 0 0 0 1px var(--cream2)}\nul.x4l{margin:0;padding-left:18px}ul.x4l li{font-size:13.2px;line-height:1.62;margin:0 0 6px;color:var(--ink)}ul.x4l li::marker{color:var(--ink3)}ul.x4l.pn li::marker{color:var(--red)}\n.dsg{margin:0 0 10px}\n.dst{display:inline-block;font-size:11px;font-weight:700;padding:1px 10px;border-radius:999px;margin-bottom:5px}\n.dst.h{color:var(--have-ink);background:var(--have-bg);border:1px solid var(--have-bd)}.dst.n{color:var(--red);background:var(--surface);border:1px dashed var(--red)}\nul.dsl{margin:0;padding-left:18px}ul.dsl li{font-size:13px;line-height:1.55;margin:0 0 3px;color:var(--ink)}\nul.dsl.h li::marker{color:var(--ds-gray-dark)}ul.dsl.n li::marker{color:var(--red)}ul.dsl.n li{font-weight:700;color:var(--ink-strong)}\nul.dsl li.more{list-style:none;margin-left:-18px;font-size:12px;color:var(--ink3);cursor:help}\n.dsk{font-size:11px;color:var(--ink3);margin-right:4px}\n.x4c .ove{font-size:12.8px;line-height:1.6;padding:9px 13px}\n.ovi li{font-size:13px}.ovp p{font-size:13.5px}.ovp .ovh{font-size:12.8px}\n/* 세부 Agent 프로필 표 */\ntable.prof{width:100%;border-collapse:separate;border-spacing:0;border:1px solid var(--line);border-radius:16px;overflow:hidden;margin:8px 0 18px;background:var(--surface)}\ntable.prof th{width:200px;text-align:left;vertical-align:top;background:var(--cream);color:var(--ink-strong);font-weight:700;font-size:12.8px;padding:12px 14px;border-bottom:1px solid var(--surface);white-space:nowrap}\ntable.prof th .ic{width:22px;height:22px;border-radius:7px;background:var(--surface);color:var(--red);padding:4px;margin-right:8px;vertical-align:-6px}\ntable.prof td{padding:12px 16px;border-bottom:1px solid var(--line);vertical-align:top;line-height:1.62;color:var(--ink);font-size:13px}\ntable.prof tr:last-child>*{border-bottom:0}\ntable.prof td.big{font-size:14.8px;font-weight:700;color:var(--ink-strong)}\ntable.prof td.eff{background:var(--ds-gray-x-light);font-weight:700;color:var(--ink-strong)}\ntable.prof ul{margin:0;padding-left:18px}table.prof li{margin:0 0 4px}table.prof ul.pn li::marker{color:var(--red)}table.prof p{margin:0}\n.pcol{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px 22px}.pcol .dsg{margin:0}\n.stpill{display:inline-block;padding:1px 11px;border-radius:999px;background:var(--bg);border:1px solid var(--line);font-size:12px;margin:0 5px 4px 0;color:var(--ink)}\n.sp2{display:inline-block;width:10px}\n.prof .who{color:var(--ink3);font-size:11.8px;margin-left:6px}\n.prof .nx{margin:9px 0 4px;font-size:12.5px;color:var(--ink2)}\n.tg.big{font-size:11.5px;line-height:19px;padding:0 11px;margin:0 5px 5px 0;display:inline-block}\n.sbs .apk{display:block;font-size:10.5px;color:var(--red);font-weight:700;letter-spacing:.4px;margin-bottom:2px}.sbs h4{font-size:17.5px}\n@media (max-width:900px){table.prof th{width:118px;white-space:normal}.pcol{grid-template-columns:1fr}}\n/* 말줄임 없이 전체 문장 */\n:root{--hl-glow:rgba(204,0,0,.22)}\n.nd .lbl,.nd.L5 .lbl,.nd.L4 .lbl{-webkit-line-clamp:unset;display:block;overflow:visible}\n.nd .meta{-webkit-line-clamp:unset;display:block;overflow:visible}\n.nd .nt{flex-wrap:wrap;height:auto;min-height:13px;white-space:normal;row-gap:2px}\n.tg{overflow:visible;text-overflow:clip}\n.nd .meta .mtx{white-space:normal;overflow:visible}\n.cp{white-space:normal;overflow:visible;text-overflow:clip;max-width:none!important}\n.elab{white-space:normal;max-width:190px;text-align:center}\n.stp2 b{white-space:normal;overflow:visible}\n/* 더블클릭으로 내려간 하위 박스 강조 */\n.nd.hl{box-shadow:inset 3px 0 0 var(--red),0 0 0 3px var(--surface),0 0 0 5px var(--red)!important;z-index:8;animation:hlp 1.2s ease-in-out 3}\n@keyframes hlp{50%{box-shadow:inset 3px 0 0 var(--red),0 0 0 3px var(--surface),0 0 0 10px var(--hl-glow)}}\n/* 흐름도 편집 */\n#edbar{flex:1 1 100%;display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px;margin-top:2px;padding:7px 10px;border-radius:12px;background:var(--cream);border:1px dashed var(--red)}\n#edbar b{color:var(--red);font-size:12px;margin-right:4px}#edbar .hint{flex:1;min-width:240px}\n#btnFlow[aria-pressed=\"true\"]{background:var(--red);border-color:var(--red);color:var(--ds-text-on-color)}\nbody.fediting #board .nd{cursor:grab;user-select:none}\nbody.fediting #board .nd:hover{transform:none}\n#board .nd.dragging{cursor:grabbing!important;transition:none!important;transform:none!important;z-index:20;opacity:.92;box-shadow:var(--sh-md)!important}\nbody.dragging-box,body.dragging-box *{cursor:grabbing!important;user-select:none!important}\n#board .nd{user-select:none;-webkit-user-select:none}\nbody.fediting #board .nd{touch-action:none}\nbody.fediting #board .nd.sel{outline:2px dashed var(--red);outline-offset:3px;z-index:9}\nbody.connecting #board .nd{cursor:crosshair}\n#edtb{position:absolute;z-index:30;display:flex;gap:4px;align-items:center;background:var(--surface);border:1px solid var(--line-strong);border-radius:12px;box-shadow:var(--sh-md);padding:4px 6px;white-space:nowrap}\n#edtb button,#edtb select,#edtb input{font:inherit;font-size:11px;padding:3px 9px;border-radius:8px;border:1px solid var(--line-strong);background:var(--surface);color:var(--ink)}\n#edtb input{width:130px;border-radius:8px}#edtb .danger{color:var(--red);border-color:var(--red)}#edtb .edl{font-size:11px;font-weight:700;color:var(--ink2);margin:0 4px}\n.ehit{stroke:transparent;stroke-width:12;fill:none;pointer-events:stroke;cursor:pointer}\n.e.esel{stroke:var(--red)!important;stroke-width:3!important;stroke-dasharray:none!important}\n/* 데이터 흐름 그림 */\n.dfw{margin:4px 0 18px}.dfw h5{display:flex;align-items:center;gap:7px;margin:0 0 10px;font-size:13px;color:var(--red)}.dfw h5 .ic{width:20px;height:20px;padding:3px;border-radius:7px;background:var(--cream);color:var(--red)}\n.dfw.sub{margin:6px 0 14px}.dfw.sub h5{color:var(--ink-strong);font-size:12.5px}\n.dfd{display:grid;grid-template-columns:minmax(0,1fr) 40px minmax(0,1.05fr) 40px minmax(0,1fr);grid-template-areas:\"in a1 ag a2 out\" \"sys sys sys sys sys\";align-items:stretch}\n.dfc{border:1px solid var(--line);border-radius:16px;padding:12px 14px;background:var(--surface);box-shadow:var(--sh-sm)}\n.dfc.in{grid-area:in}.dfc.ag{grid-area:ag;background:var(--cream);border-color:var(--cream3)}.dfc.out{grid-area:out}\n.dfa{position:relative}.dfa.a1{grid-area:a1}.dfa.a2{grid-area:a2}\n.dfa::before{content:\"\";position:absolute;left:5px;right:12px;top:50%;border-top:2px solid var(--red)}\n.dfa::after{content:\"\";position:absolute;right:3px;top:calc(50% - 6px);border-left:10px solid var(--red);border-top:6px solid transparent;border-bottom:6px solid transparent}\n.dfs{grid-area:sys;margin-top:26px;border:1px dashed var(--red);border-radius:16px;padding:12px 14px;position:relative;background:var(--surface)}\n.dfv{position:absolute;left:50%;top:-26px;height:26px;border-left:2px dashed var(--red)}\n.dfv span{position:absolute;left:8px;top:5px;font-size:10.5px;color:var(--red);font-weight:700;white-space:nowrap}\n.dfd h6{margin:0 0 9px;font-size:12.5px;color:var(--ink-strong);display:flex;align-items:center;gap:6px;flex-wrap:wrap}.dfd h6 small{font-weight:400;color:var(--ink3);font-size:10.5px}\n.dfn{width:20px;height:20px;border-radius:50%;background:var(--red);color:var(--ds-text-on-color);font-size:10.5px;display:inline-flex;align-items:center;justify-content:center;flex:0 0 auto}\n.fg{margin:0 0 9px}.fg:last-child{margin-bottom:0}\n.fmt{display:inline-block;font-size:10.5px;font-weight:700;padding:1px 10px;border-radius:999px;background:var(--bg);border:1px solid var(--line-strong);color:var(--ink2);margin-bottom:4px}.fmt.o{background:var(--cream);border-color:var(--cream3);color:var(--ink-strong)}\n.fg ul{margin:0;padding-left:17px}.fg li{font-size:12.2px;line-height:1.5;margin:0 0 2px;color:var(--ink)}.fg li.n{font-weight:700;color:var(--ink-strong)}.fg li::marker{color:var(--ds-gray-dark)}.fg li.n::marker{color:var(--red)}\n.fg li em{font-style:normal;font-size:9.5px;font-weight:700;color:var(--red);border:1px dashed var(--red);border-radius:999px;padding:0 6px;margin-left:6px}\n.fg li.more{list-style:none;margin-left:-17px;color:var(--ink3);font-size:11px;cursor:help}\n.agc .ic{width:32px;height:32px;padding:7px;border-radius:11px;background:var(--surface);color:var(--red);box-shadow:var(--sh-sm)}.agc b{display:block;font-size:14.5px;margin:8px 0 6px;color:var(--red)}\n.agc ul{margin:0;padding-left:17px}.agc li{font-size:12.2px;line-height:1.5;margin:0 0 5px;color:var(--ink)}.agc li b{display:inline;font-size:12.2px;color:var(--ink-strong);margin:0}.agc .lsd{display:block;font-size:11px;color:var(--ink2)}\n.syl{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:8px}\n.sy{border:1px solid var(--have-bd);background:var(--have-bg);border-radius:12px;padding:8px 11px}.sy.n{border:1px dashed var(--red);background:var(--surface)}\n.sy b{font-size:12.2px;color:var(--ink-strong);display:block}.sy .st{font-size:9.5px;font-weight:700;color:var(--ink3)}.sy.n .st{color:var(--red)}.sy small{display:block;font-size:11.2px;color:var(--ink2);margin-top:3px;line-height:1.45}\ntable.mx .fmt{margin:0}\n@media (max-width:1050px){.dfd{grid-template-columns:1fr;grid-template-areas:\"in\" \"a1\" \"ag\" \"a2\" \"out\" \"sys\"}.dfa{height:30px}.dfa::before{left:50%;right:auto;top:3px;bottom:10px;border-top:0;border-left:2px solid var(--red)}.dfa::after{left:calc(50% - 5px);right:auto;top:auto;bottom:1px;border-left:6px solid transparent;border-right:6px solid transparent;border-top:10px solid var(--red);border-bottom:0}}\n/* 머리글: 제목 줄 → 그 아래 데이터 흐름 그림 */\n.apt>.dfw{flex:1 1 100%;width:100%;min-width:0;margin:6px 0 0;padding-top:16px;border-top:1px dashed var(--cream3)}\n.apt>.apov{margin-top:2px}\n/* 관계별 '언제' */\n.fg li .wh,.sy .wh{display:block;font-size:10.8px;line-height:1.45;color:var(--ink2);font-weight:400;margin:1px 0 4px}\n.fg li .wh b,.sy .wh b,.sy .ex b{display:inline-block;font-size:9.5px;font-weight:700;color:var(--red);background:var(--cream);border-radius:6px;padding:0 5px;margin-right:5px}\n.sy .ex{display:block;font-size:11px;color:var(--ink2);line-height:1.45;margin-top:2px}.sy .ex b{color:var(--ink2);background:var(--bg)}\n/* 발표 모드 조작 막대 */\n#pctl{display:none;align-items:center;gap:6px 8px;flex-wrap:wrap}\nbody.present #pctl{display:flex}\nbody.present #slbar{flex-wrap:wrap;row-gap:6px;padding-top:8px;padding-bottom:8px}\nbody.present #slbar .slhint{display:none}\nbody.present #sllab{display:none}\n#pctl .pgl{font-size:11px;font-weight:700;color:var(--ink3);margin-left:4px}\n#pctl .seg button{font-size:11.5px;padding:3px 10px}\n#pctl .pbtn{font-size:11.5px;padding:4px 11px;border-radius:999px}\n#pctl #pzv{min-width:52px}\nbody.present #wrap{height:calc(100vh - var(--slbar-h, 54px))}\n/* 맨 위 데이터 흐름: 세부 Agent 연쇄 */\n.fx{border:1px solid var(--line);border-radius:18px;padding:14px 16px 16px;background:var(--surface);overflow-x:auto}\n.fx-cap,.fx-row,.fx-hand{display:grid;grid-template-columns:minmax(220px,1fr) 46px minmax(280px,1fr) 46px minmax(200px,.85fr);min-width:900px}\n.fx-cap{font-size:11.5px;font-weight:700;color:var(--ink3);margin-bottom:8px}\n.fx-cap span:nth-child(1){grid-column:1}.fx-cap span:nth-child(2){grid-column:3;text-align:center;color:var(--red)}.fx-cap span:nth-child(3){grid-column:5}\n.fx-row{align-items:stretch}\n.fx-in,.fx-out{display:flex;flex-direction:column;gap:8px;justify-content:center}.fx-in{grid-column:1}.fx-out{grid-column:5}\n.fbx{position:relative;border:1px solid var(--line-strong);border-radius:12px;background:var(--surface);padding:8px 11px;box-shadow:var(--sh-sm)}\n.fbx.none{opacity:.6}\n.fbx h6{display:flex;align-items:center;gap:6px;margin:0 0 5px;font-size:11px;font-weight:700;color:var(--ink-strong)}\n.fbx h6 small{font-size:9.5px;font-weight:700;color:var(--ink3);background:var(--bg);border-radius:999px;padding:0 6px}\n.fbx.in h6::before{content:\"\";width:7px;height:7px;border-radius:2px;background:var(--ds-gray-dark)}.fbx.out h6::before{content:\"\";width:7px;height:7px;border-radius:2px;background:var(--red)}\n.fbx ul{margin:0;padding-left:15px}.fbx li{font-size:11.6px;line-height:1.45;margin:0 0 3px;color:var(--ink)}.fbx li.n{font-weight:700;color:var(--ink-strong)}.fbx li.n::marker{color:var(--red)}\n.fbx li em{font-style:normal;font-size:9px;font-weight:700;color:var(--red);border:1px dashed var(--red);border-radius:999px;padding:0 5px;margin-left:5px}\n.fbx li .wh{display:block;font-size:10.2px;font-weight:400;color:var(--ink2);line-height:1.4;margin:1px 0 2px}.fbx li .wh b,.fx-api .wh b{font-size:9px;color:var(--red);background:var(--cream);border-radius:5px;padding:0 4px;margin-right:4px}\n.fbx li.more{list-style:none;margin-left:-15px;color:var(--ink3);font-size:10.5px;cursor:help}\n.fbx>p.wh{margin:5px 0 0;padding-top:5px;border-top:1px dashed var(--line);font-size:10.2px;color:var(--ink2);line-height:1.4}.fbx>p.wh b{font-size:9px;color:var(--red);background:var(--cream);border-radius:5px;padding:0 4px;margin-right:4px}\n.fbx.out{background:var(--cream);border-color:var(--cream3)}\n/* 연결선: 투입 박스 → Agent, Agent → 산출물 박스 */\n.fx-in .fbx::after{content:\"\";position:absolute;top:50%;right:-46px;width:40px;border-top:2px solid var(--ds-gray-dark)}\n.fx-in .fbx::before{content:\"\";position:absolute;top:calc(50% - 5px);right:-47px;border-left:8px solid var(--ds-gray-dark);border-top:5px solid transparent;border-bottom:5px solid transparent}\n.fx-out .fbx::after{content:\"\";position:absolute;top:50%;left:-46px;width:40px;border-top:2px solid var(--red)}\n.fx-out .fbx::before{content:\"\";position:absolute;top:calc(50% - 5px);left:-8px;border-left:8px solid var(--red);border-top:5px solid transparent;border-bottom:5px solid transparent}\n.fx-ag{grid-column:3;border:2px solid var(--red);border-radius:16px;background:var(--surface);padding:12px 14px;display:flex;flex-direction:column;justify-content:center;box-shadow:var(--sh-md);cursor:pointer}\n.fx-ag:hover{background:var(--ds-gray-x-light)}\n.fx-agh{display:flex;align-items:center;gap:9px;margin-bottom:6px}.fx-agh small{display:block;font-size:10px;color:var(--ink3)}.fx-agh b{font-size:14px;color:var(--red)}\nul.fx-fn{margin:0 0 6px;padding-left:16px}ul.fx-fn li{font-size:11.8px;line-height:1.5;margin:0 0 3px}\n.fx-api{border-top:1px dashed var(--cream3);padding-top:7px;margin-top:2px}.fx-api>b{display:inline-block;font-size:10px;color:var(--red);margin-bottom:4px}\n.fx-api ul{list-style:none;margin:0;padding:0}.fx-api li{font-size:11.2px;line-height:1.4;margin:0 0 5px}\n.fx-api li>b{font-weight:700;color:var(--ink-strong)}.fx-api li small{display:block;font-size:10.2px;color:var(--ink2);margin-left:34px}\n.sst{display:inline-block;min-width:28px;text-align:center;font-size:9px;font-weight:700;border-radius:999px;padding:0 5px;margin-right:6px}.sst.h{color:var(--have-ink);background:var(--have-bg);border:1px solid var(--have-bd)}.sst.n{color:var(--red);border:1px dashed var(--red)}\n/* 다음 세부 Agent로 산출물 전달 */\n.fx-hand>div{grid-column:3;position:relative;text-align:center;padding:14px 0 16px}\n.fx-hand>div::before{content:\"\";position:absolute;left:50%;top:0;bottom:6px;border-left:2px solid var(--red)}\n.fx-hand>div::after{content:\"\";position:absolute;left:calc(50% - 6px);bottom:0;border-top:9px solid var(--red);border-left:6px solid transparent;border-right:6px solid transparent}\n.fx-hand span{position:relative;display:inline-block;max-width:100%;background:var(--surface);border:1px solid var(--red);color:var(--red);border-radius:999px;padding:2px 11px;font-size:10.8px;line-height:1.45}\n/* Y축 세부 Agent 카드: 기존 / 신규 행 분리 */\n.scg .scl{display:flex;flex-direction:column;gap:3px;line-height:0}\n.scg .scr{line-height:0}\n.scg .scr.n{padding-top:3px;border-top:1px dashed var(--line)}\n.scg .scr .rk{min-width:30px;text-align:center}\n/* Agent 구조도: 간결하게 */\n.dfw h5 .dfs2{font-size:11px;font-weight:400;color:var(--ink3);margin-left:8px}\n.fx .fbx li{margin-bottom:2px}\n.fx-api li{margin-bottom:4px}.fx-api li small{margin-left:36px}\n/* Agent 소개 (큰 글씨) */\n.apt .apl{flex:1 1 560px;min-width:0}\n.apintro{margin:8px 0 0;max-width:820px;font-size:15.5px;line-height:1.68;color:var(--ink-strong);font-weight:400}\n.apintro b{display:inline-block;font-size:11.5px;font-weight:700;color:var(--ds-text-on-color);background:var(--red);border-radius:999px;padding:1px 10px;margin-right:9px;vertical-align:2px}\n/* 투입 형태 */\n.fbx .ifm{margin:-1px 0 5px;font-size:10.6px;color:var(--ink2);line-height:1.4}\n.fbx .ifm b{display:inline-block;font-size:9.2px;font-weight:700;color:var(--ink-strong);background:var(--bg);border:1px solid var(--line-strong);border-radius:6px;padding:0 5px;margin-right:5px}\n\n/* ================= 뷰티파이 (기능·콘텐츠 그대로, 보기만 다듬기) ================= */\n/* 기본 */\nhtml{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility}\n::selection{background:var(--cream2);color:var(--ink-strong)}\n*{scrollbar-width:thin;scrollbar-color:var(--ds-gray-medium) transparent}\n::-webkit-scrollbar{width:11px;height:11px}::-webkit-scrollbar-track{background:transparent}\n::-webkit-scrollbar-thumb{background:var(--ds-gray-medium);border-radius:999px;border:3px solid transparent;background-clip:content-box}\n::-webkit-scrollbar-thumb:hover{background:var(--ds-gray-dark);border:3px solid transparent;background-clip:content-box}\n.kpis b,.stp2 small,.x4num,.dfn,.sn,#zv,#pzv{font-variant-numeric:tabular-nums}\n/* 범례 '소멸 이유' 견본에 붙던 꼬리(삼각형) 제거 */\n.sw.nd::before,.sw.nd::after{content:none!important}\n/* 머리 카드 */\n.hero>.ver{position:absolute;top:20px;right:26px;z-index:2}\n.hero .eyebrow{letter-spacing:.9px}\n.hero h1{letter-spacing:-.5px}\n.hero .crumb{line-height:1.55;padding-right:250px}\n/* 위쪽 컨트롤 막대: 높이·간격·눌림 상태 통일 */\n#controls{gap:8px 10px;padding:9px 14px;align-items:center}\n#controls>button{height:32px;padding:0 14px;font-size:12px;border:1px solid var(--line-strong);background:var(--surface);border-radius:999px;color:var(--ink)}\n#controls>button:hover{border-color:var(--red);color:var(--red);box-shadow:var(--sh-sm)}\n#controls>button[aria-pressed=\"true\"]{background:var(--red);border-color:var(--red);color:var(--ds-text-on-color);box-shadow:0 2px 8px rgba(204,0,0,.22)}\n#controls .grp{gap:7px;padding-left:2px}\n#controls .grp>span{font-size:10.5px;letter-spacing:.4px}\n#controls .seg{height:32px;align-items:center;padding:3px;background:var(--bg);box-shadow:inset 0 0 0 1px var(--line)}\n#controls .seg button{height:26px;padding:0 11px;font-size:12px;color:var(--ink2)}\n#controls .seg button:hover{color:var(--ink-strong);background:var(--surface)}\n#controls .seg button[aria-pressed=\"true\"]{color:var(--ink-strong);background:var(--surface);box-shadow:0 1px 3px rgba(8,15,52,.12)}\n#controls .seg button[data-scr=\"ns\"][aria-pressed=\"true\"]{background:var(--red);color:var(--ds-text-on-color)}\n#controls .navb button{width:32px;height:32px;line-height:30px;border:1px solid var(--line-strong);background:var(--surface)}\n#controls .stitle{font-size:12.5px;padding-right:12px}\n/* 요약 막대 */\n#summary .sm{font-size:12px}#summary .sm.on{font-size:12.5px}\n.smb{height:9px}\n/* 범례 카드 */\n#legend{padding:10px 16px;row-gap:8px}\n#legend .lgg{align-items:center}\n#legend .lgg>b{font-size:10.5px;letter-spacing:.3px;color:var(--ink-strong)}\n/* 지도 카드 */\n#stageWrap{box-shadow:0 1px 0 var(--line),var(--sh-lg)}\n#slbar{padding:10px 18px}\n#stagehead{box-shadow:0 1px 0 var(--line)}\n/* 단계 머리: 글자가 늘 화면 안에 보이게 */\n.cv{overflow:visible}\n.cv .cvi{position:sticky;left:calc(var(--lbw) + 16px);right:16px;display:inline-flex;align-items:center;gap:7px;white-space:nowrap}\n.cv.wide{justify-content:flex-start;padding-left:16px}\n.cv span{overflow:visible;text-overflow:clip}\n.cv.r1{letter-spacing:.1px}\n/* 레인 이름 카드 */\n#labels .lc{transition:box-shadow .2s,border-color .2s}\n#labels .lc.sub{border-radius:14px}\n#labels .lc.sub:hover{box-shadow:var(--sh-md)}\n/* 박스 */\n.nd{border-radius:11px;transition:left .62s cubic-bezier(.2,.7,.2,1),top .62s cubic-bezier(.2,.7,.2,1),box-shadow .2s,transform .2s,opacity .4s}\n.nd:hover{box-shadow:0 8px 22px rgba(8,15,52,.10)}\n.elab{border-radius:999px;box-shadow:0 1px 2px rgba(8,15,52,.06)}\n/* 양옆 넘김 버튼 */\n.slnav{width:42px;height:42px;line-height:38px;opacity:.6;box-shadow:var(--sh-md);backdrop-filter:blur(4px)}\n.slnav:hover{opacity:1}\n/* 상세 창 */\n#panel{scrollbar-gutter:stable}\n#panel .ph{letter-spacing:.2px}\n#panel table.kv tr:nth-child(odd) td,#panel table.kv tr:nth-child(odd) th{background:var(--ds-gray-x-light)}\n#panel .painbox{border-radius:14px}\n#toast{box-shadow:var(--sh-xl);padding:9px 20px;letter-spacing:.1px}\n/* ===== Agent 상세 페이지 ===== */\n.kpis{border-radius:18px}\n#apm section>h3{letter-spacing:-.2px}\n/* Agent 구조도 */\n.fx{background:linear-gradient(180deg,var(--surface),var(--ds-gray-x-light))}\n.fx-ag{justify-content:flex-start;border-radius:18px}\n.fx-in,.fx-out{justify-content:flex-start}\n.fx-row+.fx-hand+.fx-row{margin-top:0}\n.fbx{border-radius:13px}\n.fbx h6{letter-spacing:.1px}\n/* 표 (필요한 데이터·활용 시스템·맡는 업무) 통일 */\n.tblw{border:1px solid var(--line);border-radius:16px;overflow:auto;background:var(--surface);box-shadow:var(--sh-sm);max-height:none}\ntable.mx,table.tk{width:100%;border-collapse:separate;border-spacing:0;font-size:12px;line-height:1.5}\ntable.mx thead th,table.tk thead th{position:sticky;top:0;z-index:1;background:var(--cream);color:var(--ink-strong);font-weight:700;font-size:11.5px;text-align:left;padding:10px 12px;border-bottom:1px solid var(--cream3);white-space:nowrap}\ntable.mx tbody td,table.tk tbody td{padding:9px 12px;border-bottom:1px solid var(--line);vertical-align:top;background:var(--surface)}\ntable.mx tbody tr:last-child td,table.tk tbody tr:last-child td{border-bottom:0}\ntable.mx tbody tr:hover td,table.tk tbody tr:hover td{background:var(--ds-gray-x-light)}\ntable.mx td:first-child{min-width:150px}\ntable.mx td .fmt{white-space:nowrap}\ntable.mx td.src{font-size:11px;color:var(--ink3);min-width:120px}\ntable.mx .rk{white-space:nowrap}\n/* 세부 Agent 섹션 */\n.sbs{border-radius:22px}\n.sbs>header{padding-bottom:6px;border-bottom:1px dashed var(--line);margin-bottom:10px}\ntable.prof td.eff{background:var(--cream)}\n.pcol ul.dsl:has(li:nth-child(7)){columns:2 170px;column-gap:22px}.pcol ul.dsl li{break-inside:avoid}\n/* 세부 Agent 흐름 그림: '언제'는 연하게 */\n.fg li .wh,.sy .wh{color:var(--ink3);font-size:10.4px}\n.fg li .wh b,.sy .wh b{background:transparent;padding:0;color:var(--red)}\n.dfc{border-radius:18px}\n/* 발표 모드 막대: 한 줄로 */\nbody.present #slbar{flex-wrap:nowrap;gap:12px;overflow-x:auto;padding:8px 14px}\nbody.present .ptitle{font-size:12.5px;white-space:nowrap;margin-right:4px}\nbody.present #pctl{flex-wrap:nowrap;gap:6px}\nbody.present #btnExitPresent{white-space:nowrap;height:30px;padding:0 13px;border-radius:999px}\nbody.present #sldots{flex:0 0 auto}\n/* 편집 모드 막대 */\n#edbar{border-radius:14px}\n/* 일반 모드에서도 박스를 누르면 수정 도구 */\nbody:not(.fediting) #board .nd.sel{outline:2px dashed var(--red);outline-offset:3px}\n#edtb{animation:rise .18s ease both}\n/* AI Agent: Y축은 'AI Agent' 하나, 지도 안에서 묶음 박스로 */\n#labels .lc.ai-all{display:block;padding:0;overflow:visible;border-top:2px solid var(--red);background:linear-gradient(90deg,var(--cream),var(--surface) 85%)}\n#labels .lc.ai-all .aiin{position:sticky;top:96px;display:flex;align-items:flex-start;gap:10px;padding:14px 14px 12px}\n#labels .lc.ai-all .lic{background:var(--red);color:var(--ds-text-on-color);width:30px;height:30px;padding:6px;border-radius:10px;flex:0 0 auto}\n#labels .lc.ai-all b{display:block;font-size:17px;color:var(--red);letter-spacing:-.2px}\n#labels .lc.ai-all small{display:block;font-size:11px;color:var(--ink2);margin-top:2px}\n#labels .lc.ai-all small.aih2{font-size:10.5px;color:var(--ink3);line-height:1.5;margin-top:6px}\n.bg.row-band,.bg.row-sub{background:transparent}\n.gbox{position:absolute;z-index:1;pointer-events:none;border-radius:18px}\n.gbox.gb{background:color-mix(in srgb,var(--red) 3.5%,var(--surface));border:1.5px solid color-mix(in srgb,var(--red) 30%,var(--surface));box-shadow:var(--sh-sm)}\n.gbox.gs{background:var(--surface);border:1.5px dashed color-mix(in srgb,var(--red) 42%,var(--surface));border-radius:14px}\n.gbox .gt{position:absolute;left:12px;top:6px;display:flex;align-items:center;gap:8px;white-space:nowrap;pointer-events:auto;cursor:pointer;line-height:1.3}\n.gbox.gs .gt{top:5px;left:10px}\n.gbox .gt:hover b{text-decoration:underline;text-underline-offset:3px}\n.gbox .gi{width:20px;height:20px;padding:3px;border-radius:7px;background:var(--surface);color:var(--red);box-shadow:var(--sh-sm)}\n.gbox.gb .gt b{font-size:13px;color:var(--red)}\n.gbox.gs .gt b{font-size:11.8px;color:var(--red)}\n.gbox .gd{font-size:11px;color:var(--ink2)}\n.gbox .gc{font-size:10px;color:var(--ink2);background:var(--surface);border:1px solid var(--line-strong);border-radius:999px;padding:0 8px;line-height:17px}\n/* 촘촘한 지도 */\n.nd{padding:5px 7px 6px}\n.nd .lbl{line-height:1.32}\n.e.xrow{opacity:.5}\n.gbox.gs .gt{top:4px}\n.gbox.gb .gt{top:5px}\n/* 더 촘촘하게 (참고: 자동차보상 HTML — 열 122 · 박스 112) */\n.nd{padding:4px 6px 5px 7px;border-radius:8px}\n.nd .nl{display:flex;gap:4px;align-items:flex-start}.nd .nl .nk{flex:0 0 auto;margin-top:2px}.nd .nl .lbl{margin-top:0;flex:1;min-width:0}\n.nd .nt{margin-bottom:1px}\n.gbox .gt{position:absolute;left:8px;right:8px;top:4px;white-space:normal;line-height:1.3}\n.gbox.gb{border-radius:12px}.gbox.gs{border-radius:10px}\n.gbox.gb .gt b{font-size:11.5px}.gbox.gs .gt b{font-size:10.5px}\n.gbox .gi{width:16px;height:16px;padding:2px;vertical-align:-3px;margin-right:4px}\n#labels .lc.lane .lt b{font-size:11.5px}\n/* As-Is ↔ To-be 전환: 천천히, 함께 미끄러지게 */\n:root{--mt:1.9s;--ez:cubic-bezier(.65,0,.35,1)}\n#board .bg.stband{z-index:0}#board .bg[class*=\"row-\"]{z-index:1}#board .bg.sep{z-index:2}#board .gbox{z-index:3}#edges{z-index:4}\n#edges{transition:opacity .6s ease}\nbody.morph #edges{opacity:0}\nbody.morph #board .nd,#afb.morph .nd{transition:left var(--mt) var(--ez),top var(--mt) var(--ez),width var(--mt) var(--ez),height var(--mt) var(--ez),background-color var(--mt) ease,border-color var(--mt) ease,box-shadow var(--mt) ease,opacity .7s ease}\nbody.morph #board .bg.stband,body.morph #board .bg.sep{transition:left var(--mt) var(--ez),width var(--mt) var(--ez),height var(--mt) var(--ez)}\nbody.morph #board .bg[class*=\"row-\"]{transition:top var(--mt) var(--ez),height var(--mt) var(--ez),width var(--mt) var(--ez)}\nbody.morph #labels .lc{transition:top var(--mt) var(--ez),height var(--mt) var(--ez)}\nbody.morph #stagehead .cv{transition:left var(--mt) var(--ez),width var(--mt) var(--ez)}\n.gin{animation:gin .8s ease both;animation-delay:calc(var(--mt) * .72)}\n@keyframes gin{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}\nbody.morph.to-ns #board .nd.k-a,body.morph.to-ns #board .nd.k-na{box-shadow:inset 3px 0 0 var(--red),0 0 0 3px var(--cream),var(--sh-md)}\n/* 박스에는 글자만 */\n#board .nd,#afb .nd{padding:5px 6px 5px 7px}\n#board .nd .lbl,#afb .nd .lbl{margin-top:0;font-size:10px;line-height:1.32}\n#board .nd.L4 .lbl{font-size:11px;font-weight:700}\n#panel .pmeta{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:-2px 0 10px;font-size:11.5px;color:var(--ink2)}\n#panel .pmeta b{font-size:11px;color:var(--ink-strong)}#panel .pmeta .mbar{display:inline-flex;width:120px;height:6px;border-radius:999px;overflow:hidden;gap:1px;background:var(--ds-gray-light)}#panel .pmeta .mbar i{display:block;height:100%}\n#panel .chgt{color:var(--red);font-weight:700}\n/* ===== 2차 뷰티파이 ===== */\n/* 박스: 글자만 있는 카드 */\n#board .nd{border-radius:7px;border-color:var(--line-strong);box-shadow:inset 3px 0 0 var(--h-ac),0 1px 2px rgba(8,15,52,.05)}\n#board .nd:hover{transform:translateY(-1px);box-shadow:inset 3px 0 0 var(--h-ac),0 6px 16px rgba(8,15,52,.10)}\n#board .nd .lbl{color:var(--ink-strong);letter-spacing:-.1px}\n#board .nd.k-a,#board .nd.k-na{border-color:color-mix(in srgb,var(--red) 36%,var(--surface));box-shadow:inset 3px 0 0 var(--red),0 1px 2px rgba(8,15,52,.05)}\n#board .nd.k-a:hover,#board .nd.k-na:hover{box-shadow:inset 3px 0 0 var(--red),0 6px 16px rgba(204,0,0,.13)}\n#board .nd.k-nh{border-color:var(--cream3);box-shadow:inset 3px 0 0 var(--cream3),0 1px 2px rgba(8,15,52,.05)}\n#board .nd.k-nh:hover{box-shadow:inset 3px 0 0 var(--cream3),0 6px 16px rgba(8,15,52,.10)}\n#board .nd.k-mk{border-radius:7px}#board .nd.k-mk .lbl{color:var(--mk-ink)}\n#board .nd.k-gone{background:var(--ds-gray-x-light);box-shadow:none}#board .nd.k-gone .lbl{color:var(--gone-ink)}\n#board .nd.k-pt{box-shadow:none}#board .nd.k-pt .lbl{color:var(--ink2)}\n#board .nd.k-why{box-shadow:none}#board .nd.k-why .lbl{color:var(--ink);font-size:9.6px}\n/* 묶음 박스 */\n.gbox.gb{background:color-mix(in srgb,var(--cream) 50%,var(--surface));border:1px solid color-mix(in srgb,var(--red) 20%,var(--surface));box-shadow:inset 3px 0 0 var(--red),0 1px 3px rgba(8,15,52,.05);border-radius:12px}\n.gbox.gs{background:var(--surface);border:1px dashed color-mix(in srgb,var(--red) 38%,var(--surface));border-radius:9px}\n.gbox .gt{display:flex;align-items:flex-start;gap:5px}\n.gbox.gb .gt b{font-size:11.2px;letter-spacing:-.1px;line-height:1.25;color:var(--red)}\n.gbox.gs .gt b{font-size:10.2px;line-height:1.25;color:color-mix(in srgb,var(--red) 82%,var(--ink-strong))}\n.gbox .gi{flex:0 0 auto;margin:0}\n/* 선: 줄을 넘는 선은 가는 회색, 박스에 마우스를 올리면 그 박스의 선만 또렷하게 */\n#edges .e.xrow{stroke:var(--ds-gray-dark);stroke-width:1;opacity:.42}\n#edges path.e{transition:opacity .2s ease,stroke-width .2s ease}\n#board.efocus #edges path.e{opacity:.1}\n#board.efocus #edges path.e.hot{opacity:1;stroke-width:2.2}\n#board.efocus #edges path.e.hot.xrow{stroke:var(--ink)}\n.elab{font-size:9.5px;padding:0 7px}\n/* 지도 카드: 내용이 짧으면 빈 칸 없이 */\n#wrap{transition:height .3s ease}\n/* ===== 3차 디자인: 빨강은 포인트로만, 차분하게, 한 덩어리로 ===== */\n/* 머리 카드 */\n.hero::after{display:none}\n.hero{padding:20px 26px 16px;border:1px solid var(--line);box-shadow:0 10px 30px rgba(8,15,52,.05)}\n.hero h1{font-size:26px;letter-spacing:-.6px}\n.hero .crumb{font-size:11.5px;color:var(--ink3)}\n.steps{margin-top:14px}\n.stp2{border-radius:12px;box-shadow:none;border-color:var(--line);background:var(--surface)}\n.stp2:hover{box-shadow:0 4px 12px rgba(8,15,52,.08)}\n.stp2 .sn{background:var(--bg);color:var(--ink-strong)}\n/* 툴바 */\n#controls{border-radius:16px;padding:8px 12px;box-shadow:0 6px 18px rgba(8,15,52,.06);gap:8px 10px}\n#controls .grp+.grp,#controls .grp+button,#controls button+.grp{margin-left:2px}\n#controls .grp>span{color:var(--ink3);font-weight:700}\n#controls>button{height:30px;font-size:11.8px;color:var(--ink2)}\n#controls .seg{height:30px}#controls .seg button{height:24px;font-size:11.5px}\n#controls .navb button{width:30px;height:30px;line-height:28px;color:var(--ink2)}\n/* 요약 + 범례를 한 카드로 */\n#summary{background:var(--surface);border:1px solid var(--line);border-bottom:0;border-radius:16px 16px 0 0;padding:11px 18px 7px;margin:10px 0 0;flex-direction:row;flex-wrap:wrap;gap:6px 30px}\n#summary .sm{font-size:11.5px;color:var(--ink3)}#summary .sm.on{font-size:11.8px;color:var(--ink-strong)}\n#legend{border:1px solid var(--line);border-top:1px dashed var(--line);border-radius:0 0 16px 16px;box-shadow:none;margin:0 0 4px;padding:8px 18px 10px;font-size:10.8px}\n#legend .lgg>b{font-size:10px;color:var(--ink3);letter-spacing:.4px}\n/* 지도 카드 */\n#stageWrap{border-radius:18px;border:1px solid var(--line);box-shadow:0 12px 32px rgba(8,15,52,.06)}\n#slbar{background:var(--surface);padding:9px 18px}\n#corner b{font-size:13px}\n/* 단계 머리: 덜 무겁게 (진한 단계명 한 줄 + 회색 구성 + 빨간 게이트 글자) */\n.cv.r1{top:7px;height:24px;border-radius:8px;font-size:11.5px;background:var(--ink);box-shadow:none}\n.cv.r2{top:35px;height:18px;background:transparent;color:var(--ink2);font-size:10.4px;border-radius:0}\n.cv.r3{top:56px;height:18px;background:transparent;border:0;color:var(--red);font-size:10.4px}\n.cv.r3 .cvi::before{content:\"◆\";font-size:7px;margin-right:1px;position:relative;top:-1px}\n.cv.r2:not(.wide),.cv.r3:not(.wide){justify-content:center}\n.cv.r2.wide,.cv.r3.wide{padding-left:18px}\n/* 레인 이름·배경 */\n#labels .lc.lane{padding:7px 10px;gap:8px}\n#labels .lc.lane .lic{width:20px;height:20px;padding:4px;background:var(--bg);color:var(--ink2)}\n#labels .lc.lane .lt b{font-size:11.5px;color:var(--ink-strong)}\n#labels .lc.lane .lt small{font-size:9.8px;color:var(--ink3)}\n.row-lane.alt,.alt{background:color-mix(in srgb,var(--bg) 55%,var(--surface))}\n.sep{border-left:1px solid var(--line)}\n.row-aih{background:linear-gradient(180deg,color-mix(in srgb,var(--cream) 40%,var(--surface)),var(--surface) 180px)!important;border-top:2px solid var(--red)}\n/* 묶음 제목: 큰 기능은 빨강, 세부는 진한 회색 */\n.gbox.gs .gt b{color:var(--ink-strong)}\n.gbox.gb .gt b{color:var(--red)}\n/* 상세 창 */\n#panel{border:1px solid var(--line)}\n.sw.ln.x{border-top:1px solid var(--ds-gray-dark);opacity:.6}\n.sw.fr.big{background:color-mix(in srgb,var(--cream) 50%,var(--surface));border:1px solid color-mix(in srgb,var(--red) 20%,var(--surface));box-shadow:inset 3px 0 0 var(--red)}\n.sw.fr.small{background:var(--surface);border:1px dashed color-mix(in srgb,var(--red) 38%,var(--surface))}\n/* Orchestrator 신호선 */\n.e-orc{stroke:var(--ink-strong);stroke-width:1.5;stroke-dasharray:5 3}\n.sw.ln.k{border-top:2px dashed var(--ink-strong)}\n.elab.orc,.elab:has(+.orc){font-weight:700}\n/* 흐름 보기: 선이 굵고 또렷하게 */\nbody.vflow #edges path.e{stroke-width:1.6}\nbody.vflow #edges path.e.e-ai{stroke-width:1.8}\nbody.vflow #board .nd .lbl{font-size:10.4px}\n/* 라벨 종류: 신호(진한), 다른 Agent와 주고받는 것(빨간 테두리) */\n.elab.k{border-color:var(--ink-strong);color:var(--ink-strong);font-weight:700;background:var(--surface)}\n.elab.x{border-color:var(--red);color:var(--red);font-weight:700;background:var(--surface)}\n.e.hand{stroke:var(--red);stroke-width:1.7;stroke-dasharray:6 3}\n/* Agent 흐름도: 다른 Agent 레인·바깥 박스 */\n.afn.ext{opacity:.78;border-style:dashed}\n.afl.oth .xch{display:flex;flex-direction:column;gap:2px;margin-top:4px;font-size:10.5px;color:var(--ink2);line-height:1.35}\n.afl.oth .xch i{font-style:normal;font-weight:700;margin-right:4px;padding:0 5px;border-radius:999px;font-size:9.5px}\n.afl.oth .xg i{background:var(--red);color:var(--ds-text-on-color)}.afl.oth .xt i{background:var(--ink);color:var(--ds-text-on-color)}\n.afrow.oth{background:color-mix(in srgb,var(--ds-gray-x-light) 70%,var(--surface))}\n/* 상세 창: 선행 업무 / 후행 업무 */\n#panel .pflow{display:grid;grid-template-columns:1fr;gap:8px;margin:2px 0 14px}\n#panel .pf{border:1px solid var(--line);border-radius:12px;padding:9px 12px 8px;background:var(--surface)}\n#panel .pf.in{border-left:3px solid var(--ds-gray-dark)}#panel .pf.out{border-left:3px solid var(--red)}\n#panel .pf h4{margin:0 0 6px;font-size:12.5px;display:flex;align-items:center;gap:6px}#panel .pf h4 small{color:var(--ink3);font-weight:400;font-size:11px}\n#panel .pf .ar{font-weight:900;color:var(--red)}#panel .pf.in .ar{color:var(--ds-gray-dark)}\n#panel .pf ul{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}\n#panel .pf li{display:flex;flex-wrap:wrap;align-items:baseline;gap:4px 8px;font-size:12px;line-height:1.45}\n#panel .pf .fgo{font-weight:700;color:var(--ink-strong);text-align:left;padding:0;background:none;border:0;cursor:pointer;text-decoration:underline;text-decoration-color:var(--line-strong);text-underline-offset:3px}\n#panel .pf .fgo:hover{color:var(--red);text-decoration-color:var(--red)}\n#panel .pf .fw{font-size:11px;color:var(--red);font-weight:700}#panel .pf.in .fw{color:var(--ink2)}\n#panel .pf .ft{font-size:10.5px;padding:0 7px;border-radius:999px;background:var(--bg);color:var(--ink2);border:1px solid var(--line)}\n#panel .pf .none{margin:0;font-size:11.5px;color:var(--ink3)}\n#panel .pflow.gone p{margin:0;font-size:12px;color:var(--ink3)}\n#panel .painbox{margin-top:16px}\n/* 흐름 (넓게): 굵은 선·큰 화살촉·여유 있는 박스 */\nbody.vflow #board .nd{padding:7px 9px}\nbody.vflow #board .nd .lbl{font-size:11px;line-height:1.38}\nbody.vflow #edges path.e{stroke-width:1.9}\nbody.vflow #edges path.e.e-ai{stroke-width:2.1}\nbody.vflow #edges path.e.e-orc{stroke-width:1.9}\nbody.vflow .elab{font-size:10.5px}\n/* 상세 창: 이 박스는 (맨 위) */\n#panel h3{margin-top:4px}\n#panel .pwhat{border-radius:12px;background:color-mix(in srgb,var(--cream) 55%,var(--surface));border:1px solid var(--cream3);padding:10px 13px 10px;margin:0 0 10px}\n#panel .pwhat b{display:block;font-size:11px;letter-spacing:.3px;color:var(--red);margin-bottom:3px}\n#panel .pwhat p{margin:0;font-size:13.2px;line-height:1.6;color:var(--ink-strong)}\n#panel .pwhat small{display:block;margin-top:5px;font-size:11.2px;color:var(--ink2)}\n/* 상세 창 맨 끝: 이 박스 수정 (지도 위 떠 있던 도구 스타일 덮어쓰기) */\n#panel #edtb{position:static;display:block;z-index:auto;white-space:normal;background:none;border:0;border-top:1px dashed var(--line-strong);border-radius:0;box-shadow:none;padding:12px 0 0;animation:none}\n#panel #edtb button,#panel #edtb select,#panel #edtb input{font-size:12px;border-radius:999px}\n#panel #edtb input,#panel #edtb select{width:auto;border-radius:8px}\n/* 상세 창 맨 끝: 이 박스 수정 */\n#panel .ped{margin-top:16px;border-top:1px dashed var(--line-strong);padding-top:12px}\n#panel .ped h4{margin:0 0 8px;font-size:12.5px}\n#panel .pedr{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px}\n#panel .pedr button{height:30px;padding:0 12px;border-radius:999px;border:1px solid var(--line-strong);background:var(--surface);font-size:12px;cursor:pointer}\n#panel .pedr button:hover{border-color:var(--ink2)}#panel .pedr button.danger{color:var(--red);border-color:var(--red)}\n#panel .pedf{display:flex;align-items:center;gap:8px;margin:0 0 6px;font-size:12px}\n#panel .pedf span{width:64px;color:var(--ink2);font-weight:700}\n#panel .pedf input,#panel .pedf select{flex:1;height:30px;border:1px solid var(--line-strong);border-radius:8px;padding:0 9px;font-size:12px;background:var(--surface);color:var(--ink-strong)}\n#panel .pedh{margin:6px 0 0;font-size:11px;color:var(--ink3);line-height:1.5}\n/* 상세 창은 위쪽 조작 막대를 가리지 않게 그 아래에서 열림 */\n#panel{top:calc(var(--ctlb, 18px) + 10px);max-height:calc(100vh - var(--ctlb, 18px) - 24px)}\nbody.present #panel{top:calc(18px + env(safe-area-inset-top,0px));max-height:84vh}\n/* 누른 박스의 앞·뒤 흐름 고정 표시 */\n#board.pinned .nd:not(.fsel):not(.fnb){opacity:.35}\n#board.pinned .gbox{opacity:.6}\n#board.pinned .elab{opacity:.12}#board.pinned .elab.hot{opacity:1}\n#board .nd.fsel{opacity:1;box-shadow:0 0 0 3px var(--red),0 8px 20px rgba(204,0,0,.18)!important}\n#board .nd.fin{opacity:1;box-shadow:0 0 0 2px var(--ink2),0 4px 10px rgba(8,15,52,.12)!important}\n#board .nd.fout{opacity:1;box-shadow:0 0 0 2px var(--red),0 4px 10px rgba(204,0,0,.12)!important}\n#board.pinned #edges path.e.hot{opacity:1;stroke-width:2.6}\n.elab{white-space:nowrap}\n/* ===== 한눈에 보기: 덜어내고 깔끔하게 — 박스 글자 최대 3줄, 그림자 없음, 선 라벨 없음, Orchestrator는 연한 회색 ===== */\nbody:not(.vflow) #board .nd{border-color:var(--line);box-shadow:inset 3px 0 0 var(--h-ac)}\nbody:not(.vflow) #board .nd:hover{box-shadow:inset 3px 0 0 var(--h-ac),0 4px 12px rgba(8,15,52,.10)}\nbody:not(.vflow) #board .nd .lbl{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;font-size:9.6px;line-height:1.3;color:var(--ink)}\nbody:not(.vflow) #board .nd.k-a,body:not(.vflow) #board .nd.k-na{border-color:color-mix(in srgb,var(--red) 26%,var(--surface));box-shadow:inset 3px 0 0 var(--red)}\nbody:not(.vflow) #board .nd.k-nh{box-shadow:inset 3px 0 0 var(--cream3)}\nbody:not(.vflow) #board .nd.k-mk{background:var(--ds-gray-light);border-color:var(--ds-gray-medium);box-shadow:inset 3px 0 0 var(--ink)}\nbody:not(.vflow) #board .nd.k-mk .lbl{color:var(--ink-strong)}\nbody:not(.vflow) #board .nd.k-why .lbl{-webkit-line-clamp:2}\nbody:not(.vflow) #edges .e.xrow{opacity:.28}\nbody:not(.vflow) #board.efocus #edges path.e.hot{opacity:1}\n/* ===== 흐름 (넓게): 박스 아래 '넘기는 것' 한 줄 ===== */\n#board .nd .nds{margin-top:4px;padding-top:3px;border-top:1px dashed var(--line);font-size:9.8px;line-height:1.35;color:var(--ink3)}\n#board .nd.k-a .nds,#board .nd.k-na .nds{color:color-mix(in srgb,var(--red) 70%,var(--ink2))}\n#board .nd.k-mk .nds{color:var(--mk-ink);opacity:.85;border-top-color:rgba(255,255,255,.25)}\n/* ===== 흐름 설명 v2 — 색은 박스 종류와 같게: Agent 빨강 · 담당자 확인·판단 갈색 · 사람 직접 회색 · Orchestrator 검정 ===== */\n:root{--k-ai:#D0021B;--k-hitl:#0E8A5F;--k-hu:#7B8290;--k-orc:#151A22;--k-ai-t:#FDECEE;--k-hitl-t:#E9F6F0;--k-hu-t:#F1F3F5;--k-orc-t:#E4E7EB;\n  --nh-ac:var(--k-hitl);--nh-bd:#A8D9C4;--nh-bg:#EEF8F3;--h-ac:var(--k-hu);--mk-ac:#8B95A1;--e-hitl:var(--k-hitl)}\n/* 박스 색 = 동그라미 색: Agent 빨강 · 담당자 확인·판단 초록 · 사람 직접 회색 · Orchestrator 검정 */\n#board .nd.k-nh{border-color:var(--nh-bd);box-shadow:inset 3px 0 0 var(--nh-ac),0 1px 2px rgba(8,15,52,.05)}\n#board .nd.k-nh:hover{box-shadow:inset 3px 0 0 var(--nh-ac),0 6px 16px rgba(8,15,52,.10)}\nbody:not(.vflow) #board .nd.k-nh{box-shadow:inset 3px 0 0 var(--nh-ac)}\nbody:not(.vflow) #board .nd.k-mk{box-shadow:inset 3px 0 0 var(--k-orc)}\n#edges path.agf-bh{stroke:var(--k-hitl)}.sw.ln.bbh{border-top-color:var(--k-hitl)!important}#labels .lc.agv .agk i.bh{border-top-color:var(--k-hitl)!important}\n.elab.bl.bh{color:var(--k-hitl);border-color:var(--k-hitl)}\n/* 번호 동그라미: 묶음 번호는 색 없는 테두리 원(주체 색과 헷갈리지 않게), 단계 번호는 주체 색 */\n#board .sc ol.sc-bt li i,.af .afstory li i,#tourcap .tno{background:var(--surface)!important;color:var(--ink-strong)!important;box-shadow:inset 0 0 0 1.6px var(--ink-strong)}\n.chn{display:inline;line-height:1.9}\n.chn s{text-decoration:none;color:var(--ink3);margin:0 3px;font-weight:700}\n.chn em{display:inline-block;font-style:normal;font-size:10.2px;line-height:16px;padding:0 6px;border-radius:6px;border:1px solid;white-space:nowrap;vertical-align:middle;cursor:pointer}\n.chn em u{text-decoration:none;font-weight:700;margin-right:4px}\n.chn em.ai{color:var(--k-ai);border-color:color-mix(in srgb,var(--k-ai) 40%,transparent);background:color-mix(in srgb,var(--k-ai) 7%,var(--surface))}\n.chn em.hitl{color:var(--k-hitl);border-color:color-mix(in srgb,var(--k-hitl) 45%,transparent);background:#F6EEE2}\n.chn em.hu{color:var(--k-hu);border-color:color-mix(in srgb,var(--k-hu) 40%,transparent);background:var(--ds-gray-x-light)}\n.chn em.orc{color:#fff;border-color:var(--k-orc);background:var(--k-orc)}\n.chn em.now{box-shadow:0 0 0 2px var(--surface),0 0 0 3.5px currentColor;font-weight:700}\n.chn em.orc.now{box-shadow:0 0 0 2px var(--surface),0 0 0 3.5px var(--k-orc)}\n.chn em.done{opacity:.45}\n.chn em.me{font-weight:700;box-shadow:inset 0 -2px 0 currentColor}\n.sc.narrow .chn em{width:12px;height:10px;padding:0;border-radius:3px}\n#board .sc ol.sc-bt li{line-height:1.5}\n#board .sc ol.sc-bt li i{background:var(--ink-strong)!important}\n#board .sc ol.sc-bt li b{display:inline;margin-right:6px}\n/* 번호 표시: 4-1처럼 같은 번호 안 순서 */\n.sbadge{min-width:20px;width:auto!important;padding:0 5px;border-radius:10px!important;box-sizing:border-box}\n.sbadge.hitl{background:var(--k-hitl)}.sbadge.hu{background:var(--k-hu)}.sbadge.orc{background:var(--k-orc)}.sbadge.ai{background:var(--k-ai)}\n.sbadge.nb{background:var(--surface);color:var(--ink-strong);box-shadow:0 0 0 1.5px var(--ink-strong),0 2px 5px rgba(8,15,52,.2)}\nbody.touring .sbadge:not(.mate){opacity:.25}\nbody.touring .sbadge.mate{opacity:1}\n/* 따라가기: 앞 단계 박스(옅은 테두리) → 지금 단계 박스(진한 테두리), 둘 사이 화살표가 흐름 */\n#board.tour .nd.hl2{opacity:1;box-shadow:0 0 0 2px var(--surface),0 0 0 4px color-mix(in srgb,var(--ink3) 55%,transparent)!important;z-index:7}\n#board.tour #edges path.e.tflow{stroke-width:3;stroke-dasharray:7 5;animation:tflow .8s linear infinite;opacity:1}\n@keyframes tflow{to{stroke-dashoffset:-24}}\n#tourcap .tchain{margin-top:8px;display:flex;flex-wrap:wrap;align-items:center;gap:3px 2px}\n#tourcap .tchain s{text-decoration:none;color:var(--ink3);margin:0 2px;font-weight:700}\n#tourcap .tsx{font-size:11px;line-height:20px;padding:0 8px;border-radius:7px;border:1px solid;background:var(--surface);cursor:pointer}\n#tourcap .tsx u{text-decoration:none;font-weight:700;margin-right:4px}\n#tourcap .tsx.ai{color:var(--k-ai);border-color:color-mix(in srgb,var(--k-ai) 40%,transparent)}\n#tourcap .tsx.hitl{color:var(--k-hitl);border-color:color-mix(in srgb,var(--k-hitl) 45%,transparent)}\n#tourcap .tsx.hu{color:var(--k-hu);border-color:color-mix(in srgb,var(--k-hu) 40%,transparent)}\n#tourcap .tsx.orc{color:var(--k-orc);border-color:var(--k-orc)}\n#tourcap .tsx.now{color:#fff;font-weight:700}\n#tourcap .tsx.now.ai{background:var(--k-ai)}#tourcap .tsx.now.hitl{background:var(--k-hitl)}#tourcap .tsx.now.hu{background:var(--k-hu)}#tourcap .tsx.now.orc{background:var(--k-orc)}\n#tourcap .tsx.done{opacity:.5}\n#tourcap .tnow{margin-top:9px;display:flex;flex-wrap:wrap;align-items:baseline;gap:4px 8px}\n#tourcap .twho{font-size:12px;font-weight:700;color:#fff;padding:1px 9px;border-radius:7px}\n#tourcap .twho.ai{background:var(--k-ai)}#tourcap .twho.hitl{background:var(--k-hitl)}#tourcap .twho.hu{background:var(--k-hu)}#tourcap .twho.orc{background:var(--k-orc)}\n#tourcap .tkd{font-size:10.5px;color:var(--ink3)}\n#tourcap .tnow p{flex-basis:100%;margin:2px 0 0;font-size:13px;line-height:1.55;color:var(--ink)}\n#tourcap .tno{background:var(--ink-strong)!important}\n#tourcap .tlv{display:inline-flex;border:1px solid var(--line-strong);border-radius:8px;overflow:hidden}\n#tourcap .tlv button{border:0!important;border-radius:0!important;padding:4px 9px!important}\n#tourcap .tlv button[aria-pressed=\"true\"]{background:var(--ink-strong);color:#fff}\n#tourcap .tbt button.on{background:var(--ink-strong);color:#fff;border-color:var(--ink-strong)}\n#tourcap .tkey{margin-left:auto;font-size:10px;color:var(--ink3);white-space:nowrap}\n#tourcap .tkey i{display:inline-block;width:9px;height:9px;border-radius:50%;margin:0 3px 0 7px;vertical-align:-1px}\n#tourcap .tkey i.ai,#labels .lc.story .stk i.ai{background:var(--k-ai)}#tourcap .tkey i.hitl,#labels .lc.story .stk i.hitl{background:var(--k-hitl)}#tourcap .tkey i.hu,#labels .lc.story .stk i.hu{background:var(--k-hu)}#tourcap .tkey i.orc,#labels .lc.story .stk i.orc{background:var(--k-orc)}\n#tourcap .thint{display:none}\n#tourfocus{position:absolute;pointer-events:none;visibility:hidden}\n.af .afstory li{white-space:normal;overflow:visible}\n.af .afstory li i{background:var(--ink-strong)!important}\n/* ===== 흐름 설명 줄 (지도 맨 위) ===== */\n#board .bg.story{z-index:3;background:var(--surface);border:1.5px solid var(--line-strong);border-radius:12px;padding:10px 12px 8px;box-shadow:0 2px 8px rgba(8,15,52,.05);overflow:hidden;pointer-events:auto}\n#board .bg.story.asis{background:var(--ds-gray-x-light)}\n#board .sc p{margin:0;font-size:11px;line-height:1.5;color:var(--ink2)}\n#board .sc p b{display:inline-block;margin-right:6px;padding:0 6px;border-radius:5px;font-size:10px;line-height:16px;font-weight:700;background:var(--bg);color:var(--ink-strong)}\n#board .sc .sc-chg{color:var(--ink-strong);font-weight:600}\n#board .sc .sc-chg b{background:var(--red);color:#fff}\n#board .sc.asis .sc-now b{background:var(--ds-gray-dark);color:#fff}\n#board .sc.asis .sc-chg{margin-top:6px}\n#board .sc ol.sc-bt{list-style:none;margin:7px 0 6px;padding:0;display:grid;grid-template-columns:1fr;gap:4px 14px}\n#board .sc.wide ol.sc-bt{grid-template-columns:1fr 1fr}\n#board .sc ol.sc-bt li{position:relative;padding:3px 6px 3px 26px;border-radius:7px;font-size:11px;line-height:1.45;color:var(--ink);cursor:pointer;transition:background .15s ease}\n#board .sc ol.sc-bt li:hover{background:var(--bg)}\n#board .sc ol.sc-bt li.on{background:color-mix(in srgb,var(--red) 10%,var(--surface));box-shadow:inset 0 0 0 1.5px var(--red)}\n#board .sc ol.sc-bt li i{position:absolute;left:4px;top:3px;width:17px;height:17px;border-radius:50%;font-style:normal;font-size:10px;font-weight:700;line-height:17px;text-align:center;color:#fff;background:var(--ds-gray-dark)}\n#board .sc ol.sc-bt li.ai i{background:var(--red)}#board .sc ol.sc-bt li.orc i{background:var(--ink-strong)}\n#board .sc ol.sc-bt li b{font-weight:700;color:var(--ink-strong);margin-right:5px}\n#board .sc ol.sc-bt li span{color:var(--ink2)}\n#board .sc.narrow ol.sc-bt li{padding-right:2px;font-size:10.4px}\n#board .sc.narrow .sc-chg{font-size:10px;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}\n#board .sc.narrow .sc-nx{display:none}\n#board .sc .sc-nx{font-size:10.5px;color:var(--ink3)}\n/* Agent 페이지 흐름도: 한 화면 맞춤 + 이 Agent의 흐름 */\n.af .afstory{margin:8px 0 10px;padding:10px 12px;border:1px solid var(--line);border-radius:12px;background:var(--surface)}\n.af .afstory:empty{display:none}\n.af .afsh{display:flex;align-items:baseline;gap:10px;margin-bottom:6px}.af .afsh b{font-size:12.5px;color:var(--red)}.af .afsh span{font-size:10.5px;color:var(--ink3)}\n.af .afstory ol{list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:4px 14px}\n.af .afstory li{position:relative;padding:2px 4px 2px 26px;font-size:11px;line-height:1.45;color:var(--ink2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.af .afstory li i{position:absolute;left:3px;top:2px;width:17px;height:17px;border-radius:50%;font-style:normal;font-size:10px;font-weight:700;line-height:17px;text-align:center;color:#fff;background:var(--ds-gray-dark)}\n.af .afstory li.ai i{background:var(--red)}.af .afstory li.orc i{background:var(--ink-strong)}\n.af .afstory li em{font-style:normal;font-size:10px;color:var(--ink3);margin-right:5px}.af .afstory li b{color:var(--ink-strong);margin-right:5px}\n.af .afwrap{overflow-x:auto;overflow-y:hidden}\n.af .afsz{position:relative;overflow:hidden}\n.af .afin{position:absolute;left:0;top:0}\n#afb .nd.afn .lbl{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;font-size:10.2px;line-height:1.3}\n#afb .nd.afn{padding:4px 7px}\n#aflab .afl .aflt small{font-size:10px}\n#afb .nd.afn .afo{display:block;font-size:9px;line-height:1.2;color:var(--ink3);font-weight:700;margin-bottom:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n#afb .nd.afn.oth .lbl{-webkit-line-clamp:2}\n.af .afctl .afstg button{min-width:46px}\n#afb .afbg.afsec{background:transparent;border-top:2px solid var(--ink-strong)}\n#afb .afbg.afsec.ns{border-top-color:var(--red)}\n#afb .afbg.afsec span{position:absolute;left:8px;top:4px;font-size:11px;font-weight:700;color:var(--ink-strong)}\n#afb .afbg.afsec.ns span{color:var(--red)}\n#aflab .afl.sech{display:flex;align-items:center;padding-left:10px;font-size:11.5px;font-weight:700;color:#fff;background:var(--ink-strong);border-radius:6px 0 0 6px}\n#aflab .afl.sech.ns{background:var(--red)}\n#afb .nd.afn.twin{box-shadow:0 0 0 2px var(--surface),0 0 0 4px var(--red)!important;z-index:7}\n/* 박스 번호 */\n.sbadge{position:absolute;z-index:9;width:20px;height:20px;border-radius:50%;font-size:10.5px;font-weight:700;line-height:20px;text-align:center;color:#fff;background:var(--ds-gray-dark);box-shadow:0 0 0 2px var(--surface),0 2px 5px rgba(8,15,52,.25);cursor:pointer;pointer-events:auto}\n.sbadge.ai{background:var(--red)}.sbadge.orc{background:var(--ink-strong)}\n.sbadge.on{transform:scale(1.25);box-shadow:0 0 0 3px var(--surface),0 0 0 5px var(--red)}\n/* 왼쪽 칸 안내 */\n#labels .lc.story{align-items:flex-start;padding:12px;background:var(--surface)}\n#labels .lc.story .lt b{font-size:12.5px;color:var(--red)}\n#labels .lc.story .lt small{display:block;margin-top:5px;font-size:10.5px;line-height:1.5;color:var(--ink2);white-space:normal}\n#labels .lc.story .tourgo{margin-top:8px;padding:4px 10px;border-radius:8px;border:0;background:var(--red);color:#fff;font-size:11px;font-weight:700;cursor:pointer}\n#labels .lc.story .stk{display:block;margin-top:8px;font-size:10px;color:var(--ink3)}\n#labels .lc.story .stk i{display:inline-block;width:10px;height:10px;border-radius:50%;margin:0 3px 0 6px;vertical-align:-1px;background:var(--ds-gray-dark)}\n#labels .lc.story .stk i.ai{background:var(--red)}#labels .lc.story .stk i.orc{background:var(--ink-strong)}\n/* 흐름 따라가기 */\n#board.tour .nd:not(.hl):not(.hl2){opacity:.45}\n/* 따라가기 중 박스 색이 그대로 보이게: 지금 단계 = 그 종류 색 굵은 테두리 + 옅은 바탕, 앞 단계 = 같은 색 점선 */\n#board.tour .nd.hl{animation:none!important}\n#board.tour .nd.hl.k-a,#board.tour .nd.hl.k-na{box-shadow:inset 4px 0 0 var(--k-ai),0 0 0 2px var(--surface),0 0 0 5px var(--k-ai)!important;background:var(--k-ai-t)}\n#board.tour .nd.hl.k-nh{box-shadow:inset 4px 0 0 var(--k-hitl),0 0 0 2px var(--surface),0 0 0 5px var(--k-hitl)!important;background:var(--k-hitl-t)}\n#board.tour .nd.hl.k-h{box-shadow:inset 4px 0 0 var(--k-hu),0 0 0 2px var(--surface),0 0 0 5px var(--k-hu)!important;background:var(--k-hu-t)}\n#board.tour .nd.hl.k-mk{box-shadow:inset 4px 0 0 var(--k-orc),0 0 0 2px var(--surface),0 0 0 5px var(--k-orc)!important}\n#board.tour .nd.hl2{outline:2px dashed var(--k-hu);outline-offset:3px;box-shadow:none!important}\n#board.tour .nd.hl2.k-a,#board.tour .nd.hl2.k-na{outline-color:var(--k-ai)}#board.tour .nd.hl2.k-nh{outline-color:var(--k-hitl)}#board.tour .nd.hl2.k-mk{outline-color:var(--k-orc)}\n/* Lv.5 점선 박스: 다른 Lv.5 박스 안에서 일하는 주체를 그 주체 자리에 잠깐 표시 */\n#board .nd.tghost{position:absolute;z-index:9;opacity:1!important;border:2px dashed var(--k-hu);border-radius:9px;background:rgba(255,255,255,.97);padding:3px 8px;box-sizing:border-box;overflow:hidden}\n#board .nd.tghost.k-a{border-color:var(--k-ai);background:var(--k-ai-t)}#board .nd.tghost.k-nh{border-color:var(--k-hitl);background:var(--k-hitl-t)}#board .nd.tghost.k-h{border-color:var(--k-hu);background:var(--k-hu-t)}#board .nd.tghost.k-mk{border-color:var(--k-orc)}\n#board .nd.tghost small{display:block;font-size:9px;line-height:1.25;color:var(--ink3);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n#board .nd.tghost .lbl{font-size:10.2px;line-height:1.3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}\n#board .nd.tghost.hl2{opacity:.8!important;outline:none}\n#edges path.tgl{fill:none;stroke:var(--k-hu);stroke-width:1.5;stroke-dasharray:2 4;opacity:.9}\n#edges path.tgl.k-a{stroke:var(--k-ai)}#edges path.tgl.k-nh{stroke:var(--k-hitl)}#edges path.tgl.k-mk{stroke:var(--k-orc)}\n#edges path.tarw{fill:none;stroke:var(--ink-strong);stroke-width:2.2;stroke-dasharray:7 5;animation:tflow .8s linear infinite;opacity:.85}\n#tourcap .tbx{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:5px;vertical-align:-2px;border:1.5px solid var(--k-hu);background:var(--k-hu-t);box-shadow:inset 3px 0 0 var(--k-hu)}\n#tourcap .tbx.ai{border-color:var(--k-ai);background:var(--k-ai-t);box-shadow:inset 3px 0 0 var(--k-ai)}#tourcap .tbx.hitl{border-color:var(--k-hitl);background:var(--k-hitl-t);box-shadow:inset 3px 0 0 var(--k-hitl)}#tourcap .tbx.orc{border-color:var(--k-orc);background:var(--k-orc-t);box-shadow:inset 3px 0 0 var(--k-orc)}\n#board.tour .gbox,#board.tour .bg.lgrp{opacity:.45}\n#board.tour #edges path.e:not(.hot){opacity:.08}\n#board.tour #edges path.e.hot{opacity:1;stroke-width:2.4}\n#board.tour .nd.hl{opacity:1;z-index:8}\n#tourcap{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:80;width:min(720px,calc(100vw - 40px));background:var(--surface);border:1.5px solid var(--red);border-radius:14px;box-shadow:0 14px 40px rgba(8,15,52,.25);padding:12px 16px 10px}\n#tourcap .tch{display:flex;align-items:center;gap:8px}\n#tourcap .tst{font-size:10.5px;font-weight:700;color:var(--ink3);padding:1px 8px;border-radius:6px;background:var(--bg)}\n#tourcap .tno{width:22px;height:22px;border-radius:50%;font-size:11px;font-weight:700;line-height:22px;text-align:center;color:#fff;background:var(--ds-gray-dark)}\n#tourcap .tno.ai{background:var(--red)}#tourcap .tno.orc{background:var(--ink-strong)}\n#tourcap .tch b{font-size:14px;color:var(--ink-strong);flex:1}\n#tourcap .tcnt{font-size:10.5px;color:var(--ink3)}\n#tourcap p{margin:6px 0 0;font-size:12.5px;line-height:1.55;color:var(--ink)}\n#tourcap .tnone{font-size:11px;color:var(--ink3)}\n#tourcap .tbt{display:flex;align-items:center;gap:6px;margin-top:9px}\n#tourcap .tbt button{padding:4px 12px;border-radius:8px;border:1px solid var(--line-strong);background:var(--surface);font-size:11.5px;cursor:pointer}\n#tourcap .tbt button.pri{background:var(--red);border-color:var(--red);color:#fff;font-weight:700}\n#tourcap .tbt button:disabled{opacity:.4;cursor:default}\n#tourcap .thint{margin-left:auto;font-size:10.5px;color:var(--ink3)}\nbody.touring #btnTour{background:var(--red);color:#fff}\n/* 경로 고르기: 촬영(빨강)·비촬영(보라) 버튼 색 */\n#controls .pathseg button.ps-sh[aria-pressed=\"true\"],#slbar .pathseg button.ps-sh[aria-pressed=\"true\"]{background:var(--ds-red-200);color:#fff;box-shadow:none}\n#controls .pathseg button.ps-ns[aria-pressed=\"true\"],#slbar .pathseg button.ps-ns[aria-pressed=\"true\"]{background:#6F5BB5;color:#fff;box-shadow:none}\nbody[data-path=\"촬영\"] #stageWrap{box-shadow:inset 0 3px 0 var(--ds-red-200)}\nbody[data-path=\"비촬영\"] #stageWrap{box-shadow:inset 0 3px 0 #6F5BB5}\n/* ===== Agent 흐름 보기: 단계마다 사람 역할·큰 기능 Agent 업무 묶음 + 묶음 사이 흐름 ===== */\n#board .bg.agh{z-index:2;height:18px;font-size:10.5px;font-weight:700;color:var(--ink2);letter-spacing:.2px;border-bottom:1.5px solid var(--line-strong);padding-left:2px}\n#board .bg.agh.ai{color:var(--red);border-bottom-color:color-mix(in srgb,var(--red) 40%,var(--surface))}\n#labels .lc.agv{align-items:flex-start;padding:14px 12px;background:var(--surface)}\n#labels .lc.agv .lt b{font-size:13px;color:var(--ink-strong)}\n#labels .lc.agv .lt small{display:block;margin-top:6px;font-size:10.5px;line-height:1.5;color:var(--ink2);white-space:normal}\n#labels .lc.agv .agk{margin-top:12px;line-height:2}\n#labels .lc.agv .agk i{display:inline-block;width:22px;height:0;margin-right:6px;vertical-align:middle;border-top:3px solid var(--ds-chart-gray-400)}\n#labels .lc.agv .agk i.bh{border-top:3px dashed #9A7650}#labels .lc.agv .agk i.bb{border-top-color:var(--ds-red-200)}#labels .lc.agv .agk i.hh{border-top-color:var(--ds-gray-dark)}#labels .lc.agv .agk i.o{border-top:2px dotted var(--ds-chart-gray-400)}\n#board .nd.k-blk{padding:0;border-radius:12px;background:var(--surface);border:1.5px solid var(--line-strong);box-shadow:inset 4px 0 0 var(--ds-gray-dark),0 2px 8px rgba(8,15,52,.06);cursor:pointer}\n#board .nd.k-blk.blk-ai{border-color:color-mix(in srgb,var(--red) 45%,var(--surface));box-shadow:inset 4px 0 0 var(--red),0 2px 8px rgba(8,15,52,.06);background:color-mix(in srgb,var(--cream) 30%,var(--surface))}\n#board .nd.k-blk.blk-orc{border-color:var(--ds-gray-medium);box-shadow:inset 4px 0 0 var(--ink),0 2px 8px rgba(8,15,52,.06);background:var(--ds-gray-x-light)}\n#board .nd.k-blk:hover{box-shadow:inset 4px 0 0 var(--red),0 8px 20px rgba(8,15,52,.12)}\n#board .nd.k-blk .bh{display:flex;align-items:center;gap:6px;padding:8px 10px 3px 13px}\n#board .nd.k-blk .bh b{font-size:12.4px;color:var(--ink-strong);flex:1;line-height:1.3}\n#board .nd.k-blk.blk-ai .bh b{color:var(--red)}#board .nd.k-blk.blk-orc .bh b{color:var(--ink-strong)}\n#board .nd.k-blk .bc{font-size:10.5px;font-weight:700;padding:0 7px;line-height:17px;border-radius:999px;background:var(--bg);color:var(--ink2)}\n#board .nd.k-blk .bs{padding:0 13px 4px;font-size:10px;color:var(--ink3);line-height:1.4}\n#board .nd.k-blk ul.bt{margin:0;padding:2px 12px 9px 26px;font-size:10.4px;line-height:1.5;color:var(--ink)}\n#board .nd.k-blk ul.bt li.more{list-style:none;margin-left:-13px;color:var(--ink3);font-size:10px}\n#edges path.agf{fill:none;stroke-linecap:round;stroke-linejoin:round;opacity:.82}\n#edges path.agf-hb{stroke:var(--ds-chart-gray-400)}\n#edges path.agf-bh{stroke:#9A7650;stroke-dasharray:9 4}\n#edges path.agf-bb{stroke:var(--ds-red-200)}\n#edges path.agf-hh{stroke:var(--ds-gray-dark)}\n#edges path.agf.e-orc{stroke:var(--ds-chart-gray-400);stroke-dasharray:3 4;opacity:.65}\n.elab.bl.hh{color:var(--ink2);border-color:var(--ds-gray-dark)}\n.elab.bl.o{color:var(--ds-chart-gray-300);border-color:var(--ds-chart-gray-200);border-style:dashed;font-weight:400}\nbody.vagent #board .elab{display:none}\nbody.vagent #board.efocus .elab.hot{display:block;z-index:9}\nbody.vagent #edges path.agf.agx{stroke:var(--ds-chart-gray-200);stroke-dasharray:none;opacity:.55}\nbody.vagent #board.efocus #edges path.agf{opacity:.1}\nbody.vagent #board.efocus #edges path.agf.hot{opacity:.95}\nbody.vagent #board.efocus #edges path.agf.agx.hot{stroke:var(--ds-chart-gray-400)}\nbody.vagent #board.efocus .nd.k-blk:not(.fsel):not(.fnb):not(:hover){opacity:.55}\n#panel .blkls li{font-size:12px;line-height:1.5}#panel .blkls li small{color:var(--red);margin-left:4px}\n/* 흐름 묶음 (한눈에 · To-be): Agent·사람 묶음 사이 흐름을 굵은 선 하나로 */\n#edges path.e.xg{opacity:0}\n#board.efocus #edges path.e.xg.hot{opacity:1;stroke-width:2.2}\n#edges path.bnd{fill:none;stroke-width:3.2;stroke-linecap:round;stroke-linejoin:round;opacity:.82;transition:opacity .2s ease,stroke-width .2s ease}\n#edges path.bnd-hb{stroke:var(--ds-chart-gray-400)}\n#edges path.bnd-bh{stroke:#9A7650;stroke-dasharray:9 4}\n#edges path.bnd-bb{stroke:var(--ds-red-200)}\n#edges path.bnd-sig{stroke:var(--ds-chart-gray-400);stroke-width:1.8;stroke-dasharray:3 4;opacity:.7}\n#board.efocus #edges path.bnd{opacity:.12}\n#board.efocus #edges path.bnd.hot{opacity:.95;stroke-width:4}\n.elab.bl{font-weight:700;background:var(--surface);border-width:1.5px;font-size:10px;padding:0 8px}\n.elab.bl.hb{color:var(--ds-chart-gray-400);border-color:var(--ds-chart-gray-400)}\n.elab.bl.bh{color:#7A5A38;border-color:#9A7650}\n.elab.bl.bb{color:var(--ds-red-200);border-color:var(--ds-red-200)}\n.elab.bl.sig{color:var(--ds-chart-gray-300);border-color:var(--ds-chart-gray-200);border-style:dashed;font-weight:400}\n#board.efocus .elab.bl{opacity:.15}\n.sw.ln.bhb{border-top:3px solid var(--ds-chart-gray-400)}.sw.ln.bbh{border-top:3px dashed #9A7650}.sw.ln.bbb{border-top:3px solid var(--ds-red-200)}.sw.ln.bsig{border-top:2px dotted var(--ds-chart-gray-400)}\n/* Agent별 업무 영역: 큰 기능 Agent 묶음 테두리를 또렷하게 */\n.gbox.gb{border:1.5px solid color-mix(in srgb,var(--red) 34%,var(--surface))}\n/* 촬영·비촬영: 줄 전체가 아니라 해당 박스만 묶어서 색 상자 */\n#board .gbox.lgrp{z-index:3;background:var(--tkb);border:1.5px solid color-mix(in srgb,var(--tkc) 42%,transparent);border-radius:10px;pointer-events:none}\n#board .gbox.lgrp .lgl{position:absolute;left:7px;top:1px;font-size:9.6px;font-weight:700;line-height:13px;color:var(--tkc);letter-spacing:-.1px;white-space:nowrap}\n.swg{display:inline-block;font-style:normal;font-size:10px;font-weight:700;padding:0 8px;line-height:16px;border-radius:6px;color:var(--tkc);background:var(--tkb);border:1.5px solid color-mix(in srgb,var(--tkc) 42%,transparent)}\n/* 병렬 줄 (촬영·비촬영 × 영상·이미지) */\n#board .bg[class*=\"row-\"]{z-index:1}#board .bg.trk{z-index:2}#board .bg.sep{z-index:2}#board .gbox{z-index:3}#board .gbox.gtk{z-index:3}\n.tk{--tkc:var(--ds-gray-dark);--tkb:transparent}\n.tk-sh{--tkc:var(--ds-red-200);--tkb:color-mix(in srgb,var(--ds-red-100) 9%,transparent)}\n.tk-sh.tk-i{--tkb:color-mix(in srgb,var(--ds-red-100) 5%,transparent)}\n.tk-ns{--tkc:var(--ds-violet-300);--tkb:color-mix(in srgb,var(--ds-violet-200) 13%,transparent)}\n.tk-ns.tk-i{--tkb:color-mix(in srgb,var(--ds-violet-200) 7%,transparent)}\n.tk-md{--tkc:var(--ds-chart-gray-300);--tkb:color-mix(in srgb,var(--ds-other-200) 26%,transparent)}\n.tk-md.tk-i{--tkb:color-mix(in srgb,var(--ds-other-200) 14%,transparent)}\n.tk-cm{--tkc:var(--ds-chart-gray-300);--tkb:transparent}\n#board .bg.trk{background:var(--tkb);border-top:1px dashed color-mix(in srgb,var(--tkc) 35%,transparent);box-shadow:inset 4px 0 0 color-mix(in srgb,var(--tkc) 70%,transparent)}\n#board .bg.trk.tk-cm{box-shadow:none}\n#labels .lc.lane .trc{position:absolute;right:8px;font-size:10px;font-weight:700;line-height:16px;height:18px;padding:0 8px;border-radius:999px;color:var(--tkc);background:color-mix(in srgb,var(--tkc) 10%,var(--surface));border:1px solid color-mix(in srgb,var(--tkc) 40%,var(--surface));white-space:nowrap}\n#labels .lc.lane .trc.tk-cm{color:var(--ink3);background:var(--surface);border-color:var(--line)}\n#labels .lc.lane.has-trk .lt{max-width:calc(100% - 92px)}\n.gbox.gtk{background:var(--tkb);border:0;border-top:1px dashed color-mix(in srgb,var(--tkc) 40%,transparent);border-radius:6px}\n.gbox.gtk.tk-cm{background:transparent}\n.gbox.gtk .gtl{position:absolute;left:5px;top:1px;font-size:9.6px;font-weight:700;color:var(--tkc);letter-spacing:-.1px;white-space:nowrap}\n.sbl{display:inline-flex;align-items:center;justify-content:center;width:22px;height:16px;font-size:12px;color:var(--ink2)}\n.swt{display:inline-block;font-style:normal;font-size:10px;font-weight:700;padding:0 8px;line-height:16px;border-radius:999px;color:var(--tkc);background:color-mix(in srgb,var(--tkc) 10%,var(--surface));border:1px solid color-mix(in srgb,var(--tkc) 40%,var(--surface))}\n/* Orchestrator 신호 표 */\n.orcs .orcn{font-size:13px;color:var(--ink2);line-height:1.6;margin:0 0 10px}\n.orct td{vertical-align:top;font-size:12px}.orct td.c{width:44px;text-align:center}.orct .sn{display:inline-flex;width:22px;height:22px;border-radius:50%;background:var(--ink);color:var(--ds-text-on-color);align-items:center;justify-content:center;font-size:11px;font-weight:700}\n.orct td.orc{background:color-mix(in srgb,var(--cream) 45%,var(--surface));font-weight:700;color:var(--ink-strong)}.orct td.orc .ic{width:14px;height:14px;color:var(--red);vertical-align:-2px;margin-right:4px}\n.orct .og{margin:0 0 6px}.orct .og b{color:var(--ink-strong)}.orct .og .ow{color:var(--red);font-weight:700}.orct .og small{display:block;color:var(--ink3);font-size:11px;margin-top:1px}\n.orct tr.sto td{background:var(--ds-gray-x-light)}.orct .muted{color:var(--ink3)}\n@media (prefers-reduced-motion:reduce){:root{--mt:.01s}.gin{animation:none}}\n@media (prefers-reduced-motion:reduce){#top>*,#stageWrap,.apm>*,#panel,.nd.hl{animation:none}}\n#toast{position:fixed;left:50%;bottom:calc(18px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);background:var(--ink);color:var(--ds-text-on-color);padding:8px 18px;border-radius:999px;font-size:12px;opacity:0;pointer-events:none;transition:opacity .25s;z-index:70;box-shadow:var(--sh-md)}\n#toast.on{opacity:1}\n@media (prefers-reduced-motion:reduce){.nd{transition:none}}\n\n\n/* 번호 동그라미 최종: 묶음 번호 = 흰 바탕 테두리 원 (주체 색과 헷갈리지 않게) */\n#board .bg.story .sc ol.sc-bt li > i,.af .afstory ol li > i,#tourcap .tch span.tno{background:var(--surface)!important;color:var(--ink-strong)!important;box-shadow:inset 0 0 0 1.6px var(--ink-strong)!important;font-weight:800}\n#board .sbadge.on,.sbadge.on{transform:scale(1.22);box-shadow:0 0 0 2.5px var(--surface),0 0 0 4.5px var(--ink-strong),0 3px 8px rgba(8,15,52,.3)!important}\n\n/* 따라가기 창: 그 단계의 바뀌는 점 · 다음 단계 */\n#tourcap .tchg{margin:7px 0 0;font-size:11.5px;line-height:1.5;color:var(--ink2)}\n#tourcap .tchg b{display:inline-block;margin-right:6px;padding:0 6px;border-radius:5px;font-size:10px;line-height:16px;background:var(--red);color:#fff}\n#tourcap .tchg i{font-style:normal;display:inline-block;margin-right:6px;padding:0 6px;border-radius:5px;font-size:10px;line-height:16px;background:var(--ds-gray-dark);color:#fff}\n#tourcap .tnx{margin:6px 0 0;font-size:11.5px;color:var(--ink3)}\n/* 범례 번호 견본 */\n.sbadge.lgb{position:static;display:inline-block;font-style:normal;transform:none;cursor:default;vertical-align:middle;line-height:18px;height:18px;font-size:9.5px}\n\nbody.touring .sbadge.lgb{opacity:1!important}\n\n/* ===== 흐름 따라가기 v3 ===== */\n/* 그 시점 주체 색으로 박스 색 맞춤 (Lv.5 박스 종류와 달라도) */\n#board.tour .nd.hl.tk-ai{box-shadow:inset 4px 0 0 var(--k-ai),0 0 0 2px var(--surface),0 0 0 5px var(--k-ai)!important;background:var(--k-ai-t)!important;border-color:var(--k-ai)!important}\n#board.tour .nd.hl.tk-hitl{box-shadow:inset 4px 0 0 var(--k-hitl),0 0 0 2px var(--surface),0 0 0 5px var(--k-hitl)!important;background:var(--k-hitl-t)!important;border-color:var(--k-hitl)!important}\n#board.tour .nd.hl.tk-hu{box-shadow:inset 4px 0 0 var(--k-hu),0 0 0 2px var(--surface),0 0 0 5px var(--k-hu)!important;background:var(--k-hu-t)!important;border-color:var(--k-hu)!important}\n#board.tour .nd.hl.tk-orc{box-shadow:inset 4px 0 0 var(--k-orc),0 0 0 2px var(--surface),0 0 0 5px var(--k-orc)!important;border-color:var(--k-orc)!important}\n#board.tour .nd.hl2.tk2-ai{outline-color:var(--k-ai)}#board.tour .nd.hl2.tk2-hitl{outline-color:var(--k-hitl)}#board.tour .nd.hl2.tk2-hu{outline-color:var(--k-hu)}#board.tour .nd.hl2.tk2-orc{outline-color:var(--k-orc)}\n#board.tour .nd.tcov{opacity:0!important}\n/* 잠깐 늘린 박스: 어느 Agent에서 · 그 자리의 순서 2-1, 2-2 … */\n#board .tcard{position:absolute;z-index:10;box-sizing:border-box;padding:7px 9px 7px 11px;border-radius:11px;border:2px solid var(--k-hu);background:var(--surface);box-shadow:inset 5px 0 0 var(--k-hu),0 10px 26px rgba(8,15,52,.22)}\n#board .tcard.k-a{border-color:var(--k-ai);box-shadow:inset 5px 0 0 var(--k-ai),0 10px 26px rgba(8,15,52,.22)}\n#board .tcard.k-nh{border-color:var(--k-hitl);box-shadow:inset 5px 0 0 var(--k-hitl),0 10px 26px rgba(8,15,52,.22)}\n#board .tcard.k-mk{border-color:var(--k-orc);box-shadow:inset 5px 0 0 var(--k-orc),0 10px 26px rgba(8,15,52,.22)}\n#board .tcard.tghostc{border-style:dashed}\n#board .tcard.tghostc.k-a{background:var(--k-ai-t)}#board .tcard.tghostc.k-nh{background:var(--k-hitl-t)}#board .tcard.tghostc.k-h{background:var(--k-hu-t)}\n#board .tcard .tch2 b{display:block;font-size:12.5px;line-height:1.3;color:var(--ink-strong)}\n#board .tcard.k-a .tch2 b{color:var(--k-ai)}#board .tcard.k-nh .tch2 b{color:var(--k-hitl)}#board .tcard.k-mk .tch2 b{color:var(--k-orc)}\n#board .tcard .tch2 small{display:block;font-size:10px;color:var(--ink3);margin-top:1px}\n#board .tcard .tcs{font-size:9.8px;color:var(--ink3);margin:3px 0 4px;line-height:1.35}\n#board .tcard ol{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:3px}\n#board .tcard li{display:flex;align-items:flex-start;gap:6px;font-size:10.8px;line-height:1.35;color:var(--ink2);padding:3px 5px;border-radius:6px}\n#board .tcard li i{flex:none;font-style:normal;font-size:9.5px;font-weight:700;line-height:16px;height:16px;min-width:26px;text-align:center;border-radius:8px;color:#fff;background:var(--k-hu)}\n#board .tcard li i.ai{background:var(--k-ai)}#board .tcard li i.hitl{background:var(--k-hitl)}#board .tcard li i.orc{background:var(--k-orc)}\n#board .tcard li b{color:var(--ink-strong)}\n#board .tcard li.now{background:color-mix(in srgb,var(--ink-strong) 7%,var(--surface));box-shadow:inset 0 0 0 1.5px var(--ink-strong);color:var(--ink-strong);font-weight:600}\n#board .tcard li.done{opacity:.5}\n/* 어느 Agent에서 일어나는지: 그 큰 기능·세부 Agent 묶음은 흐리지 않고 테두리 강조 */\n#board.tour .gbox.tsel{opacity:1!important}\n#board.tour .gbox.gb.tsel-ai{box-shadow:0 0 0 2.5px var(--k-ai)!important;border-color:var(--k-ai)!important}\n#board.tour .gbox.gs.tsel-ai{box-shadow:0 0 0 1.5px var(--k-ai)!important}\n#board.tour .gbox.gb.tsel-orc{box-shadow:0 0 0 2.5px var(--k-orc)!important;border-color:var(--k-orc)!important}\n#board.tour .gbox.gs.tsel-orc{box-shadow:0 0 0 1.5px var(--k-orc)!important}\n#board.tour .gbox.tsel > .gt{opacity:1;font-weight:800}\n/* 단계·번호가 넘어갈 때 */\n#tourcap .ttrans{margin:-4px -6px 8px;padding:6px 10px;border-radius:9px;background:var(--ink-strong);color:#fff;font-size:11.5px;line-height:1.5}\n#tourcap .ttrans b{display:block;font-size:12px}\n#tourcap .ttrans.sm{background:var(--bg);color:var(--ink2);font-size:11px}\n#tourcap .ttrans.sm b{display:inline;color:var(--ink-strong)}\n#tourcap .tnow p b{color:var(--ink-strong);font-weight:800;background:linear-gradient(transparent 60%,color-mix(in srgb,var(--k-hitl) 18%,transparent) 60%)}\n\n/* ================= 흐름 따라가기 디자인 v4 ================= */\n#tourcap.tc{--kc:var(--k-hu);position:fixed;left:50%;bottom:20px;transform:translateX(-50%);z-index:80;width:min(780px,calc(100vw - 40px));box-sizing:border-box;padding:16px 22px 20px 24px;border-radius:18px;border:1px solid rgba(15,23,42,.08);background:#fff;box-shadow:0 28px 64px -24px rgba(15,23,42,.42),0 4px 14px rgba(15,23,42,.08);overflow:hidden;font-feature-settings:'tnum'}\n#tourcap.tc.ai{--kc:var(--k-ai)}#tourcap.tc.hitl{--kc:var(--k-hitl)}#tourcap.tc.orc{--kc:var(--k-orc)}\n#tourcap.tc::before{content:'';position:absolute;left:0;top:0;bottom:0;width:5px;background:var(--kc);transition:background .3s}\n#tourcap.tc.tc-in > *:not(.tc-prog):not(.tc-x){animation:tcIn .32s cubic-bezier(.2,.8,.2,1) both}\n@keyframes tcIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}\n#tourcap .tc-x{position:absolute;top:10px;right:12px;width:28px;height:28px;border-radius:50%;border:0;background:transparent;color:var(--ink3);font-size:18px;line-height:28px;cursor:pointer}\n#tourcap .tc-x:hover{background:#F3F4F6;color:var(--ink-strong)}\n#tourcap .tc-trans{display:flex;flex-wrap:wrap;align-items:center;gap:6px 10px;margin:0 34px 12px 0;padding:9px 14px;border-radius:12px;background:linear-gradient(100deg,#111827,#273244);color:#fff;font-size:12px}\n#tourcap .tc-trans .tc-tr{display:inline-flex;align-items:center;gap:6px;opacity:.7}\n#tourcap .tc-trans .tc-tr.on{opacity:1;font-weight:700}\n#tourcap .tc-trans .tc-tr i{font-style:normal;width:20px;height:20px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:10.5px;font-weight:800;background:rgba(255,255,255,.16)}\n#tourcap .tc-trans .tc-tr.on i{background:var(--red)}\n#tourcap .tc-trans .tc-arr{opacity:.6}\n#tourcap .tc-trans small{flex-basis:100%;font-size:11px;opacity:.78;line-height:1.5}\n#tourcap .tc-trans.sm{background:#F3F4F6;color:var(--ink2);padding:7px 12px;font-size:11.5px}\n#tourcap .tc-trans.sm b{color:var(--ink-strong)}\n#tourcap .tc-trans.sm small{flex-basis:auto;opacity:1;color:var(--ink3)}\n#tourcap .tc-top{display:flex;align-items:center;justify-content:space-between;margin-right:30px}\n#tourcap .tc-stage{display:inline-flex;align-items:center;gap:7px;font-size:11px;font-weight:700;color:var(--ink3);letter-spacing:.02em}\n#tourcap .tc-stage i{font-style:normal;width:20px;height:20px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font-size:10.5px;color:#fff;background:var(--red)}\n#tourcap .tc-count{font-size:10.5px;color:var(--ink3)}\n#tourcap .tc-title{display:flex;align-items:center;gap:10px;margin:6px 0 14px;font-size:17px;font-weight:800;color:var(--ink-strong);letter-spacing:-.01em}\n#tourcap .tc-no{width:26px;height:26px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:12.5px;font-weight:800;color:var(--ink-strong);box-shadow:inset 0 0 0 1.8px var(--ink-strong)}\n/* 가로 단계표 */\n#tourcap .tc-steps{list-style:none;margin:0 0 14px;padding:0;display:grid;grid-template-columns:repeat(var(--n),minmax(0,1fr));align-items:start}\n#tourcap .tc-steps li{--c:var(--k-hu);position:relative;padding-top:30px;text-align:center;cursor:pointer;min-width:0}\n#tourcap .tc-steps li.ai{--c:var(--k-ai)}#tourcap .tc-steps li.hitl{--c:var(--k-hitl)}#tourcap .tc-steps li.orc{--c:var(--k-orc)}\n#tourcap .tc-steps li + li::before{content:'';position:absolute;top:12px;right:50%;width:100%;height:2px;background:#E5E7EB;z-index:0}\n#tourcap .tc-steps li.done::before,#tourcap .tc-steps li.now::before{background:linear-gradient(90deg,#CBD5E1,var(--c))}\n#tourcap .tc-steps li i{position:absolute;top:0;left:50%;transform:translateX(-50%);z-index:1;min-width:26px;height:26px;padding:0 6px;box-sizing:border-box;border-radius:13px;display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:10.5px;font-weight:800;color:var(--c);background:#fff;box-shadow:inset 0 0 0 1.6px var(--c);transition:all .25s}\n#tourcap .tc-steps li.done i{background:var(--c);color:#fff;box-shadow:none;opacity:.5}\n#tourcap .tc-steps li.now i{background:var(--c);color:#fff;box-shadow:0 0 0 5px color-mix(in srgb,var(--c) 18%,transparent);transform:translateX(-50%) scale(1.1)}\n#tourcap .tc-steps li span{display:block;padding:0 4px;font-size:10.5px;line-height:1.35;color:var(--ink3);overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}\n#tourcap .tc-steps li span b{display:block;font-size:10px;font-weight:800;color:var(--c);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n#tourcap .tc-steps li.now span{color:var(--ink-strong);font-weight:600}\n#tourcap .tc-steps li.todo span{opacity:.75}\n#tourcap .tc-steps li:hover i{box-shadow:0 0 0 5px color-mix(in srgb,var(--c) 14%,transparent)}\n/* 지금 주체 · 설명 */\n#tourcap .tc-now{border-radius:12px;padding:11px 14px 12px;background:color-mix(in srgb,var(--kc) 6%,#fff);box-shadow:inset 3px 0 0 var(--kc)}\n#tourcap .tc-who{display:flex;align-items:center;gap:8px}\n#tourcap .tc-who i{width:9px;height:9px;border-radius:50%;background:var(--kc);box-shadow:0 0 0 3px color-mix(in srgb,var(--kc) 20%,transparent)}\n#tourcap .tc-who b{font-size:13px;font-weight:800;color:var(--kc)}\n#tourcap .tc-who span{font-size:10.5px;color:var(--ink3)}\n#tourcap .tc-now p{margin:6px 0 0;font-size:14px;line-height:1.65;color:#111827}\n#tourcap .tc-now p b{font-weight:800;color:#0B1220;background:linear-gradient(transparent 62%,color-mix(in srgb,var(--kc) 22%,transparent) 62%)}\n#tourcap .tc-note{position:relative;margin:8px 2px 0;padding-left:18px;font-size:11px;line-height:1.5;color:var(--ink3)}\n#tourcap .tc-note::before{content:'i';position:absolute;left:0;top:2px;width:13px;height:13px;border-radius:50%;font-size:9px;font-weight:800;line-height:13px;text-align:center;color:#fff;background:#94A3B8;font-style:italic}\n#tourcap .tc-ctx{margin-top:10px;padding:8px 12px;border-radius:10px;background:#F7F8FA;font-size:11px;line-height:1.65;color:var(--ink2)}\n#tourcap .tc-ctx span{display:inline-block;margin-right:7px;padding:0 6px;border-radius:4px;font-size:9.5px;font-weight:800;line-height:16px;color:#fff;background:var(--red);vertical-align:1px}\n#tourcap .tc-ctx span.g{background:#64748B}\n/* 조작 */\n#tourcap .tc-ctrl{display:flex;align-items:center;gap:8px;margin-top:14px}\n#tourcap .tc-ic{width:36px;height:36px;border-radius:50%;border:1px solid #E5E7EB;background:#fff;color:var(--ink-strong);font-size:20px;line-height:1;cursor:pointer;transition:all .15s}\n#tourcap .tc-ic:hover:not(:disabled){border-color:var(--ink-strong)}\n#tourcap .tc-ic:disabled{opacity:.35;cursor:default}\n#tourcap .tc-ic.pri{background:var(--ink-strong);border-color:var(--ink-strong);color:#fff;box-shadow:0 6px 14px -6px rgba(15,23,42,.6)}\n#tourcap .tc-ic.pri:hover{background:#000}\n#tourcap .tc-play{height:32px;padding:0 13px;border-radius:16px;border:1px solid #E5E7EB;background:#fff;font-size:11.5px;font-weight:700;color:var(--ink2);cursor:pointer}\n#tourcap .tc-play.on{background:#111827;color:#fff;border-color:#111827}\n#tourcap .tc-lv{display:inline-flex;padding:3px;border-radius:16px;background:#F3F4F6}\n#tourcap .tc-lv button{height:26px;padding:0 11px;border:0;border-radius:13px;background:transparent;font-size:11px;font-weight:700;color:var(--ink3);cursor:pointer}\n#tourcap .tc-lv button[aria-pressed=\"true\"]{background:#fff;color:var(--ink-strong);box-shadow:0 1px 3px rgba(15,23,42,.15)}\n#tourcap .tc-key{margin-left:auto;display:inline-flex;align-items:center;gap:4px;font-size:10px;color:var(--ink3);white-space:nowrap}\n#tourcap .tc-key i{width:8px;height:8px;border-radius:50%;margin-left:8px}\n#tourcap .tc-key i.ai{background:var(--k-ai)}#tourcap .tc-key i.hitl{background:var(--k-hitl)}#tourcap .tc-key i.hu{background:var(--k-hu)}#tourcap .tc-key i.orc{background:var(--k-orc)}\n#tourcap .tc-prog{position:absolute;left:0;right:0;bottom:0;height:4px;background:#EEF0F3}\n#tourcap .tc-prog span{display:block;height:100%;background:linear-gradient(90deg,#94A3B8,var(--kc));transition:width .45s cubic-bezier(.2,.8,.2,1)}\n#tourcap .tc-prog b{position:absolute;top:-1px;width:6px;height:6px;margin-left:-3px;border-radius:50%;background:#CBD5E1;font-size:0}\n#tourcap .tc-prog b.on{background:var(--kc)}\n/* 지도 위: 부드러운 스포트라이트 */\n#board.tour .nd{transition:opacity .35s ease,box-shadow .35s ease,background-color .35s ease}\n#board.tour .nd:not(.hl):not(.hl2){opacity:.38}\n#board.tour .nd.hl.tk-ai{box-shadow:0 0 0 2px var(--k-ai),0 0 0 8px color-mix(in srgb,var(--k-ai) 13%,transparent),0 18px 30px -14px color-mix(in srgb,var(--k-ai) 60%,transparent)!important;background:var(--k-ai-t)!important;border-color:var(--k-ai)!important}\n#board.tour .nd.hl.tk-hitl{box-shadow:0 0 0 2px var(--k-hitl),0 0 0 8px color-mix(in srgb,var(--k-hitl) 13%,transparent),0 18px 30px -14px color-mix(in srgb,var(--k-hitl) 60%,transparent)!important;background:var(--k-hitl-t)!important;border-color:var(--k-hitl)!important}\n#board.tour .nd.hl.tk-hu{box-shadow:0 0 0 2px var(--k-hu),0 0 0 8px color-mix(in srgb,var(--k-hu) 14%,transparent),0 18px 30px -14px color-mix(in srgb,var(--k-hu) 60%,transparent)!important;background:var(--k-hu-t)!important;border-color:var(--k-hu)!important}\n#board.tour .nd.hl.tk-orc{box-shadow:0 0 0 2px var(--k-orc),0 0 0 8px color-mix(in srgb,var(--k-orc) 12%,transparent),0 18px 30px -14px color-mix(in srgb,var(--k-orc) 55%,transparent)!important;border-color:var(--k-orc)!important}\n#board.tour .nd.hl2{outline:none!important;opacity:.95;box-shadow:0 0 0 2px color-mix(in srgb,var(--k-hu) 40%,transparent)!important}\n#board.tour .nd.hl2.tk2-ai{box-shadow:0 0 0 2px color-mix(in srgb,var(--k-ai) 40%,transparent)!important}\n#board.tour .nd.hl2.tk2-hitl{box-shadow:0 0 0 2px color-mix(in srgb,var(--k-hitl) 40%,transparent)!important}\n#board.tour .nd.hl2.tk2-orc{box-shadow:0 0 0 2px color-mix(in srgb,var(--k-orc) 40%,transparent)!important}\n#board.tour #edges path.e:not(.hot){opacity:.06}\n#board.tour #edges path.e.tflow{stroke-dasharray:none!important;animation:none!important;stroke-width:2.4;opacity:.9}\n#edges path.tarw{fill:none;stroke-width:2.6;stroke-linecap:round;stroke-dasharray:none!important;animation:none!important;opacity:.9}\n#edges circle.tdot{stroke:#fff;stroke-width:1.6;filter:drop-shadow(0 1px 2px rgba(15,23,42,.35))}\n#edges path.tgl{stroke-dasharray:1 6!important;stroke-linecap:round;stroke-width:2.2!important;opacity:.85}\n/* 그 Agent 묶음: 은은한 빛 */\n#board.tour .gbox.gb.tsel-ai{box-shadow:0 0 0 2px color-mix(in srgb,var(--k-ai) 50%,transparent),0 22px 40px -24px color-mix(in srgb,var(--k-ai) 70%,transparent)!important;border-color:transparent!important;background:color-mix(in srgb,var(--k-ai) 3%,var(--surface))!important}\n#board.tour .gbox.gs.tsel-ai{box-shadow:0 0 0 1.5px color-mix(in srgb,var(--k-ai) 45%,transparent)!important}\n#board.tour .gbox.gb.tsel-orc{box-shadow:0 0 0 2px color-mix(in srgb,var(--k-orc) 45%,transparent),0 22px 40px -24px rgba(15,23,42,.5)!important;border-color:transparent!important}\n#board.tour .gbox.gs.tsel-orc{box-shadow:0 0 0 1.5px color-mix(in srgb,var(--k-orc) 40%,transparent)!important}\n/* 지금 순서 번호: 은은하게 퍼지는 고리 */\n#board .sbadge.tgbadge{z-index:12;box-shadow:0 0 0 3px #fff,0 4px 10px rgba(15,23,42,.28)!important;transform:scale(1.12)}\n#board .sbadge.tgbadge::after{content:'';position:absolute;inset:-3px;border-radius:12px;border:2px solid var(--k-hu);opacity:0;animation:tbp 1.8s ease-out infinite}\n#board .sbadge.tgbadge.ai::after{border-color:var(--k-ai)}#board .sbadge.tgbadge.hitl::after{border-color:var(--k-hitl)}#board .sbadge.tgbadge.orc::after{border-color:var(--k-orc)}\n@keyframes tbp{0%{opacity:.7;transform:scale(1)}100%{opacity:0;transform:scale(1.7)}}\n/* 잠깐 늘린 박스 */\n#board .tcard{--kc:var(--k-hu);position:absolute;z-index:11;box-sizing:border-box;padding:11px 12px 10px 16px;border-radius:14px;border:1px solid rgba(15,23,42,.08);background:#fff;box-shadow:0 24px 46px -18px rgba(15,23,42,.42),0 3px 10px rgba(15,23,42,.08)!important;animation:tcPop .3s cubic-bezier(.2,.9,.3,1.15) both}\n#board .tcard.k-a{--kc:var(--k-ai)}#board .tcard.k-nh{--kc:var(--k-hitl)}#board .tcard.k-mk{--kc:var(--k-orc)}\n#board .tcard::before{content:'';position:absolute;left:0;top:12px;bottom:12px;width:4px;border-radius:0 4px 4px 0;background:var(--kc)}\n#board .tcard.tghostc{border:1.5px dashed color-mix(in srgb,var(--kc) 55%,transparent);background:color-mix(in srgb,var(--kc) 4%,#fff)}\n@keyframes tcPop{from{opacity:0;transform:translateY(4px) scale(.97)}to{opacity:1;transform:none}}\n#board .tcard .tk-head{display:flex;align-items:flex-start;gap:8px}\n#board .tcard .tk-head .dot{flex:none;width:9px;height:9px;margin-top:4px;border-radius:50%;background:var(--kc);box-shadow:0 0 0 3px color-mix(in srgb,var(--kc) 18%,transparent)}\n#board .tcard .tk-head b{display:block;font-size:13px;line-height:1.3;font-weight:800;color:var(--kc)}\n#board .tcard .tk-head small{display:block;margin-top:1px;font-size:10px;color:var(--ink3)}\n#board .tcard .tk-ctx{display:inline-block;margin:7px 0 6px;padding:2px 8px;border-radius:6px;background:#F3F4F6;font-size:9.8px;line-height:1.5;color:var(--ink2)}\n#board .tcard .tk-list{list-style:none;margin:0;padding:0}\n#board .tcard .tk-list li{--c:var(--k-hu);position:relative;display:flex;align-items:flex-start;gap:9px;padding:5px 6px;border-radius:9px;font-size:11px;line-height:1.4;color:var(--ink2)}\n#board .tcard .tk-list li.ai{--c:var(--k-ai)}#board .tcard .tk-list li.hitl{--c:var(--k-hitl)}#board .tcard .tk-list li.orc{--c:var(--k-orc)}\n#board .tcard .tk-list li:not(:last-child)::after{content:'';position:absolute;left:18px;top:26px;bottom:-5px;width:2px;background:#E5E7EB}\n#board .tcard .tk-list li i{flex:none;position:relative;z-index:1;min-width:26px;height:20px;padding:0 5px;box-sizing:border-box;border-radius:10px;display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:9.8px;font-weight:800;color:var(--c);background:#fff;box-shadow:inset 0 0 0 1.5px var(--c)}\n#board .tcard .tk-list li.done i{background:var(--c);color:#fff;box-shadow:none;opacity:.5}\n#board .tcard .tk-list li.now{background:color-mix(in srgb,var(--c) 9%,#fff);color:var(--ink-strong);font-weight:700}\n#board .tcard .tk-list li.now i{background:var(--c);color:#fff;box-shadow:0 0 0 3px color-mix(in srgb,var(--c) 20%,transparent)}\n#board .tcard .tk-list li.done{opacity:.6}\n#board .tcard .tk-list li small{display:block;font-size:9.5px;font-weight:400;color:var(--ink3)}\n#board .tcard .tk-list li b{color:var(--ink-strong)}\n#board .nd.tghost{border-radius:10px!important;border-width:1.5px!important;box-shadow:0 10px 22px -12px rgba(15,23,42,.35)}\n\n/* 설명 창 조금 더 낮게 (지도가 덜 가리게) */\n#tourcap.tc{padding:14px 20px 18px 22px}\n#tourcap .tc-title{margin:4px 0 10px;font-size:16.5px}\n#tourcap .tc-steps{margin-bottom:10px}\n#tourcap .tc-ctrl{margin-top:11px}\n#tourcap .tc-trans{margin-bottom:10px}\n\n/* ===== 말줄임 없이: 박스 글자 전체 (박스가 늘어남) ===== */\nbody:not(.vflow) #board .nd .lbl,#board .nd .lbl,#board .nd.k-why .lbl,body:not(.vflow) #board .nd.k-why .lbl{display:block!important;-webkit-line-clamp:unset!important;overflow:visible!important;text-overflow:clip!important}\n#afb .nd.afn .lbl,#afb .nd.afn.oth .lbl{display:block!important;-webkit-line-clamp:unset!important;overflow:visible!important}\n#afb .nd.afn .afo{white-space:normal;overflow:visible;text-overflow:clip}\n#board .nd.tghost .lbl{display:block!important;-webkit-line-clamp:unset!important;overflow:visible!important}\n#board .nd.tghost small{white-space:normal;overflow:visible;text-overflow:clip}\n#board .nd.tghost{height:auto!important;min-height:44px}\n#tourcap .tc-steps li span{display:block!important;-webkit-line-clamp:unset!important;overflow:visible!important}\n#tourcap .tc-steps li span b{white-space:normal!important;overflow:visible!important;text-overflow:clip!important}\n.af .afstory li{white-space:normal!important;overflow:visible!important;text-overflow:clip!important}\n/* ===== 선: 반려·순환은 가늘고 옅게 (겹쳐도 덜 무겁게) ===== */\n#edges path.e-rej{stroke:#6B7280!important;stroke-width:1.1!important;stroke-dasharray:4 4!important;opacity:.75}\n#edges path.e-loop{stroke:#9CA3AF!important;stroke-width:1.1!important;stroke-dasharray:1.5 3.5!important}\n/* ===== 상세 창: 받는 것 → 하는 일 → 만드는 것 ===== */\n#panel .pwhat .io{display:grid;grid-template-columns:minmax(0,1fr) 16px minmax(0,1fr) 16px minmax(0,1fr);gap:0;margin:6px 0 10px;align-items:stretch}\n#panel .pwhat .io-a{display:flex;align-items:center;justify-content:center;font-weight:800;color:var(--ink3)}\n#panel .pwhat .io-c{border-radius:10px;padding:8px 9px;background:var(--surface);border:1px solid var(--line);min-width:0}\n#panel .pwhat .io-c.do{background:color-mix(in srgb,var(--k-hu) 6%,var(--surface));border-color:color-mix(in srgb,var(--k-hu) 35%,var(--surface))}\n#panel .pwhat .io.ai .io-c.do{background:var(--k-ai-t);border-color:color-mix(in srgb,var(--k-ai) 35%,var(--surface))}\n#panel .pwhat .io.hitl .io-c.do{background:var(--k-hitl-t);border-color:color-mix(in srgb,var(--k-hitl) 35%,var(--surface))}\n#panel .pwhat .io.orc .io-c.do{background:var(--k-orc-t);border-color:color-mix(in srgb,var(--k-orc) 30%,var(--surface))}\n#panel .pwhat .io-c h5{display:flex;align-items:center;gap:5px;margin:0 0 5px;font-size:10.5px;font-weight:800;color:var(--ink2);letter-spacing:.02em}\n#panel .pwhat .io-c h5 i{font-style:normal;font-size:10px;color:var(--ink3)}\n#panel .pwhat .io-c.out h5{color:var(--ink-strong)}\n#panel .pwhat .io-c ul{margin:0;padding-left:14px}\n#panel .pwhat .io-c li{font-size:11.2px;line-height:1.45;margin:0 0 3px;color:var(--ink)}\n#panel .pwhat .io-c li.more{list-style:none;margin-left:-14px;color:var(--ink3);cursor:help}\n#panel .pwhat .io-c p{margin:0;font-size:11.6px;line-height:1.5;color:var(--ink-strong)}\n#panel .pwhat .io-c.do p b{display:block;font-size:10.5px;color:var(--ink2);margin-bottom:2px}\n#panel .pwhat .io.ai .io-c.do p b{color:var(--k-ai)}#panel .pwhat .io.hitl .io-c.do p b{color:var(--k-hitl)}\n#panel .pwhat .io-c .none{margin:0;color:var(--ink3)}\n#panel .pwhat .io-s{display:flex;flex-wrap:wrap;align-items:center;gap:4px 5px;margin:0 0 9px}\n#panel .pwhat .io-s .io-l{font-size:10px;font-weight:800;color:var(--ink3);margin:0 2px 0 6px}\n#panel .pwhat .io-s .io-l:first-child{margin-left:0}\n#panel .pwhat .io-s em{font-style:normal;font-size:10.5px;line-height:18px;padding:0 8px;border-radius:999px;background:var(--surface);border:1px solid var(--line-strong);color:var(--ink)}\n#panel .pwhat .io-s em.f{background:var(--bg);border-style:dashed;color:var(--ink2)}\n#panel .pwhat > p{font-size:12px;color:var(--ink2)}\n@media (max-width:520px){#panel .pwhat .io{grid-template-columns:1fr}#panel .pwhat .io-a{transform:rotate(90deg);height:14px}}\n\n/* 따라가기 중: 지도 아래쪽 박스도 설명 창 위로 올라오게 여유 공간 */\nbody.touring #inner{padding-bottom:380px}\n\n/* ===== 흐름 따라가기 창 편집 ===== */\n#tourcap .tc-edt{height:32px;padding:0 13px;border-radius:16px;border:1px dashed var(--ink3);background:#fff;font-size:11.5px;font-weight:700;color:var(--ink2);cursor:pointer}\n#tourcap .tc-edt:hover{border-color:var(--ink-strong);color:var(--ink-strong)}\n#tourcap .tc-edt.on{background:var(--k-hitl);border:1px solid var(--k-hitl);color:#fff}\n#tourcap.tc-editing{box-shadow:0 0 0 2px color-mix(in srgb,var(--k-hitl) 55%,transparent),0 28px 64px -24px rgba(15,23,42,.42)}\n#tourcap .tce{outline:1.5px dashed color-mix(in srgb,var(--ink3) 70%,transparent);outline-offset:2px;border-radius:4px;cursor:text;transition:outline-color .15s,background .15s;min-width:1.2em;display:inline-block}\n#tourcap .tce:hover{outline-color:var(--k-hitl);background:color-mix(in srgb,var(--k-hitl) 5%,#fff)}\n#tourcap .tce:focus{outline:2px solid var(--k-hitl);background:#fff;box-shadow:0 0 0 4px color-mix(in srgb,var(--k-hitl) 15%,transparent)}\n#tourcap .tce:empty::before{content:attr(data-ph);color:var(--ink3);font-weight:400}\n#tourcap .tce-d{display:block;padding:2px 4px;margin-top:6px}\n#tourcap .tce-t{padding:0 3px}\n#tourcap .tc-steps li span .tce-v{display:inline;padding:0 2px}\n#tourcap .tc-ctxe{line-height:2}\n#tourcap .tc-ctxe .tce{display:inline;line-height:1.6;padding:0 2px}\n#tourcap .tc-edbar{display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px;margin-top:10px;padding:7px 10px;border-radius:10px;background:color-mix(in srgb,var(--k-hitl) 7%,#fff);border:1px dashed color-mix(in srgb,var(--k-hitl) 45%,transparent);font-size:11px;color:var(--ink2)}\n#tourcap .tc-edbar > b{color:var(--k-hitl);font-size:11.5px}\n#tourcap .tc-edbar button{height:26px;padding:0 10px;border-radius:13px;border:1px solid var(--line-strong);background:#fff;font-size:11px;cursor:pointer}\n#tourcap .tc-edbar button:hover{border-color:var(--ink-strong)}\n#tourcap .tc-edbar span{flex:1;min-width:220px;color:var(--ink3)}\n\n#tourcap .tc-ctx span.tce{display:inline;background:transparent!important;color:var(--ink-strong)!important;font-size:11.5px!important;font-weight:400!important;line-height:1.7!important;padding:0 3px!important;margin:0!important;vertical-align:baseline!important;border-radius:4px}\n#tourcap .tc-ctx span.tce:focus{background:#fff!important}\n#tourcap .tc-steps li span .tce-v{display:inline-block;max-width:100%;padding:0 3px}\n\n/* ===== 요약·범례: 접었다 펴기 (기본 접힘) ===== */\n#infobox{margin:10px 0 4px}\n#infobox .ib-h{display:flex;align-items:center;gap:10px;width:100%;box-sizing:border-box;padding:8px 16px;border:1px solid var(--line);border-radius:14px;background:var(--surface);font:inherit;font-size:11.5px;color:var(--ink2);text-align:left;cursor:pointer;transition:background .15s,border-color .15s}\n#infobox .ib-h:hover{border-color:var(--line-strong);background:color-mix(in srgb,var(--ink-strong) 3%,var(--surface))}\n#infobox .ib-h b{font-size:11.5px;color:var(--ink-strong);white-space:nowrap}\n#infobox .ib-ic{flex:none;width:17px;height:17px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;font-style:italic;color:#fff;background:#94A3B8}\n#infobox .ib-sum{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--ink3)}\n#infobox .ib-sum i{font-style:normal;display:inline-block;width:8px;height:8px;border-radius:50%;margin:0 3px 0 9px;vertical-align:0}\n#infobox .ib-sum i.ai{background:var(--k-ai)}#infobox .ib-sum i.hitl{background:var(--k-hitl)}#infobox .ib-sum i.hu{background:var(--k-hu)}#infobox .ib-sum i.orc{background:var(--k-orc)}\n#infobox .ib-tg{flex:none;font-size:11px;font-weight:700;color:var(--ink2);white-space:nowrap}\n#infobox.ib-closed .ib-body{display:none}\n#infobox:not(.ib-closed) .ib-h{border-radius:16px 16px 0 0;border-bottom:1px dashed var(--line)}\n#infobox:not(.ib-closed) .ib-sum{visibility:hidden}\n#infobox #summary{margin:0!important;border-radius:0!important;border-top:0!important}\n#infobox .ib-body{animation:ibIn .22s ease both}\n@keyframes ibIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}\n\n/* 상세 창 '이 박스는': 하는 일 1~2줄을 먼저, 크게 */\n#panel .pwhat > p.pdesc{font-size:13px;line-height:1.6;color:var(--ink-strong);font-weight:600;margin:4px 0 6px}\n#panel .pwhat > p.ptb{font-size:11.8px;line-height:1.55;color:var(--ink2);margin:0 0 8px;padding:6px 9px;border-radius:8px;background:color-mix(in srgb,var(--k-ai) 5%,var(--surface));border-left:3px solid var(--k-ai)}\n\n/* ===== Agent 구조도: 구조는 장표와 같게, 모양은 HTML 다른 화면과 같은 카드 톤 ===== */\n#amap .amh{display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding-right:44px}\n#amap .amh .ax-pre{margin-left:auto;font-style:normal;font-size:10.5px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ink2);border:1px solid var(--line-strong);border-radius:999px;padding:3px 11px;background:var(--surface)}\n#amap .ax{min-width:1180px;max-width:1560px;margin:12px auto 0;color:var(--ink)}\n#amap .ax-chevs{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:18px;margin-bottom:14px}\n#amap .ax-ch{position:relative;display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--surface);border:1px solid var(--line);border-radius:14px;box-shadow:var(--sh-sm)}\n#amap .ax-ch:not(:last-child)::after{content:'›';position:absolute;right:-14px;top:50%;transform:translateY(-52%);font-size:18px;font-weight:700;color:var(--ink3)}\n#amap .ax-ch > i{flex:none;width:24px;height:24px;border-radius:50%;background:var(--cream);color:var(--ink);font-style:normal;font-size:11.5px;font-weight:700;display:flex;align-items:center;justify-content:center}\n#amap .ax-ch small{display:block;font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--ink3)}\n#amap .ax-ch b{display:block;font-size:13.5px;font-weight:700;color:var(--ink-strong);line-height:1.3}\n#amap .ax-orc{position:relative;display:flex;align-items:stretch;gap:0;background:var(--surface);border:1px solid var(--line);border-radius:16px;box-shadow:var(--sh-sm);margin:0 0 14px;cursor:pointer;transition:border-color .15s,box-shadow .15s;color:var(--ink);min-height:0}\n#amap .ax-orc:hover{border-color:var(--ink-strong);box-shadow:var(--sh-md);filter:none}\n#amap .ax-on{flex:none;width:240px;display:flex;flex-wrap:wrap;align-items:center;align-content:center;gap:4px 10px;padding:12px 16px;margin:0;border-right:1px dashed var(--cream3);text-align:left;justify-content:flex-start}\n#amap .ax-on b{font-size:14.5px;font-weight:800;color:var(--ink-strong);line-height:1.25}\n#amap .ax-on small{display:block;font-size:10.5px;color:var(--ink3);width:100%;padding-left:34px}\n#amap .ax-od{flex:1;padding:12px 18px;display:flex;flex-direction:column;justify-content:center;gap:7px}\n#amap .ax-od p{margin:0;font-size:12.8px;line-height:1.55;color:var(--ink2)}\n#amap .ax-od p b{display:inline-block;margin-right:8px;font-size:10.5px;font-weight:700;color:var(--ink3);letter-spacing:.04em}\n#amap .ax-od span{display:inline-block;margin:0 4px 0 0;padding:3px 11px;border-radius:999px;background:var(--bg);border:1px solid var(--line);font-size:11.5px;color:var(--ink);cursor:pointer;transition:all .15s}\n#amap .ax-od span:hover{border-color:var(--red);color:var(--red);background:var(--surface)}\n#amap .ax-od s{display:none}\n#amap .ax-no{flex:none;width:24px;height:24px;border-radius:50%;background:var(--cream);color:var(--ink);border:0;font-style:normal;font-size:11.5px;font-weight:700;display:flex;align-items:center;justify-content:center;position:static}\n#amap .ax-orc .ax-no{background:var(--mk-bg);color:var(--mk-ink)}\n#amap .ax-cols{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:12px}\n#amap .ax-col{position:relative;display:flex;flex-direction:column;min-width:0;background:var(--surface);border:1px solid var(--line);border-radius:16px;box-shadow:var(--sh-sm);padding:12px;transition:border-color .15s,box-shadow .15s}\n#amap .ax-col:hover{border-color:var(--cream3);box-shadow:var(--sh-md)}\n#amap .ax-col header{position:static;display:flex;align-items:flex-start;justify-content:flex-start;gap:9px;cursor:pointer;padding:0 0 10px;border-bottom:1px dashed var(--cream3);min-height:46px;background:none;color:inherit;text-align:left}\n#amap .ax-col header b{display:block;font-size:13.5px;font-weight:800;line-height:1.3;color:var(--ink-strong)}\n#amap .ax-col header small{display:flex;align-items:center;flex-wrap:wrap;gap:5px;font-size:10.5px;color:var(--ink3);margin-top:3px}\n#amap .ax-col header:hover b{color:var(--red)}\n#amap .ax-col header:hover{filter:none}\n#amap .ax-col:not(:last-child) header::after,#amap .ax-col header::after{display:none;content:none}\n#amap .ax-col.lite header{background:none;color:inherit}\n#amap .ax-note{position:static;display:inline-block;font-style:normal;font-size:10px;font-weight:700;color:var(--need-ink);background:var(--need-bg);border:1px dashed var(--need-bd);border-radius:999px;padding:1px 8px;white-space:nowrap}\n#amap .ax-note::after{display:none;content:none}\n#amap .ax-bul{list-style:none;margin:10px 0 0;padding:0;flex:1;min-height:132px}\n#amap .ax-bul li{position:relative;padding-left:12px;margin:0 0 7px;font-size:12.3px;line-height:1.55;color:var(--ink2)}\n#amap .ax-bul li::before{content:'';position:absolute;left:1px;top:.62em;width:4px;height:4px;border-radius:50%;background:var(--ink3)}\n#amap .ax-sh{background:none;text-align:left;font-size:10.5px;font-weight:700;letter-spacing:.04em;color:var(--ink3);padding:9px 0 0;margin-top:4px;border-top:1px dashed var(--cream3)}\n#amap .ax-sub{list-style:none;margin:7px 0 0;padding:0;min-height:112px;display:flex;flex-direction:column;gap:5px}\n#amap .ax-sub li{padding:4px 10px;margin:0;border-radius:10px;background:var(--bg);border:1px solid var(--line);font-size:11.3px;line-height:1.4;color:var(--ink);cursor:pointer;transition:all .15s}\n#amap .ax-sub li::before{display:none;content:none}\n#amap .ax-sub li:hover{border-color:var(--red);color:var(--red);background:var(--surface);text-decoration:none}\n#amap .ax-pc{margin-top:10px;padding-top:9px;border-top:1px dashed var(--cream3)}\n#amap .ax-pc b{display:block;font-size:10.5px;font-weight:700;letter-spacing:.04em;color:var(--ink3);margin-bottom:6px}\n#amap .ax-pc span{display:flex;gap:4px}\n#amap .ax-pc i{flex:1;max-width:22px;height:20px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:10.5px;font-weight:700;background:var(--cream);color:var(--ink3)}\n#amap .ax-pc i.on{background:var(--red);color:#fff;box-shadow:0 1px 3px color-mix(in srgb,var(--red) 35%,transparent)}\n#amap .amg{display:none}\n\n/* Agent 한눈에 보기: 상세 페이지 폭 전체로 (이중 격자 때문에 왼쪽 칸에만 몰리던 문제) */\n#apm .apovw{display:block;width:100%;margin:0;padding:0;border:0}\n#apm .apovw > .apov{width:100%;box-sizing:border-box}\n#apm .apovw .x4w{width:100%}\n\n/* 카드 안 줄(머리 · 설명 · 세부 Agent 제목 · 목록 · Coverage)을 8개 카드가 같은 높이로 맞춤 */\n@supports (grid-template-rows: subgrid){\n  #amap .ax-cols{grid-template-rows:repeat(5,auto);row-gap:0}\n  #amap .ax-col{display:grid;grid-row:span 5;grid-template-rows:subgrid;row-gap:0}\n  #amap .ax-bul,#amap .ax-sub{min-height:0}\n  #amap .ax-sub{align-content:start}\n}\n\n/* 구조도 Process Coverage: 단계 번호 + 그 단계 업무 수 (지도 기준) */\n#amap .ax-pc b small{margin-left:6px;font-size:10px;font-weight:600;color:var(--ink3);letter-spacing:0}\n#amap .ax-pc .ax-pn,#amap .ax-pc .ax-pv{display:flex;gap:4px}\n#amap .ax-pc .ax-pn{margin-bottom:3px}\n#amap .ax-pc .ax-pn i{flex:1;max-width:22px;height:auto;background:none;font-size:9.5px;font-weight:700;color:var(--ink3);border-radius:0;box-shadow:none}\n#amap .ax-pc .ax-pv i{flex:1;max-width:22px;height:22px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:11px;font-weight:800;background:var(--cream);color:var(--ink3);box-shadow:none}\n#amap .ax-pc .ax-pv i.on.l1{background:color-mix(in srgb,var(--red) 22%,var(--surface));color:var(--red)}\n#amap .ax-pc .ax-pv i.on.l2{background:color-mix(in srgb,var(--red) 60%,var(--surface));color:#fff}\n#amap .ax-pc .ax-pv i.on.l3{background:var(--red);color:#fff}\n#amap .ax-sub li{display:flex;align-items:baseline;justify-content:space-between;gap:6px}\n#amap .ax-sub li em,#amap .ax-od span em{flex:none;font-style:normal;font-size:9.8px;font-weight:600;color:var(--ink3);white-space:nowrap}\n#amap .ax-od span em{margin-left:6px}\n#amap .ax-orc{flex-wrap:nowrap}\n#amap .ax-ocov{flex:none;width:250px;padding:10px 16px;border-left:1px dashed var(--cream3);display:flex;align-items:center}\n#amap .ax-ocov .ax-pc{margin:0;padding:0;border:0;width:100%}\n\n#amap .ax-pc .ax-pch{display:flex;align-items:baseline;justify-content:space-between;gap:6px;margin-bottom:6px;white-space:nowrap}\n#amap .ax-pc .ax-pch b{display:inline;margin:0}\n#amap .ax-pc .ax-pch small{font-size:10px;font-weight:600;color:var(--ink3)}\n\n/* ===== AX 과제 × 제작 Agent 창 ===== */\n#axw{position:fixed;inset:0;z-index:55;background:var(--bg);overflow:auto;padding:20px 22px 40px}\n#axw .amh{display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding-right:44px;max-width:1560px;margin:0 auto}\n#axw .amh b{font-size:18px;color:var(--ink-strong)}\n#axw .amh span{font-size:12px;color:var(--ink2)}\n#axw .amh .ax-pre{margin-left:auto;font-style:normal;font-size:10.5px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--ink2);border:1px solid var(--line-strong);border-radius:999px;padding:3px 11px;background:var(--surface)}\n#axw .px{position:absolute;right:12px;top:10px;border:0;background:var(--cream);font-size:16px;line-height:1;padding:5px 9px;border-radius:999px;cursor:pointer}\n#axw .px:hover{background:var(--cream2)}\n#axw .axw-in{max-width:1560px;margin:12px auto 0}\n#axw .ax-kpi{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:12px}\n#axw .ax-kpi button{display:flex;flex-direction:column;align-items:flex-start;gap:2px;text-align:left;padding:12px 16px;background:var(--surface);border:1px solid var(--line);border-radius:14px;box-shadow:var(--sh-sm);cursor:pointer;font:inherit;color:var(--ink);transition:all .15s}\n#axw .ax-kpi button:hover{box-shadow:var(--sh-md)}\n#axw .ax-kpi button[aria-pressed=\"true\"]{border-color:var(--ink-strong);box-shadow:0 0 0 1px var(--ink-strong)}\n#axw .ax-kpi b{font-size:26px;font-weight:800;line-height:1.1;color:var(--ink-strong)}\n#axw .ax-kpi .k-D b{color:var(--red)}\n#axw .ax-kpi span{font-size:13px;font-weight:700}\n#axw .ax-kpi small{font-size:11px;color:var(--ink3)}\n#axw .ax-ctl{display:flex;flex-wrap:wrap;align-items:center;gap:10px 14px;padding:10px 12px;background:var(--surface);border:1px solid var(--line);border-radius:14px;box-shadow:var(--sh-sm)}\n#axw .ax-ctl .seg{display:inline-flex;padding:3px;border-radius:999px;background:var(--bg);border:1px solid var(--line)}\n#axw .ax-ctl .seg button,#axw .ax-bands button{border:0;background:transparent;font:inherit;font-size:12px;font-weight:600;color:var(--ink2);padding:5px 12px;border-radius:999px;cursor:pointer}\n#axw .ax-ctl .seg button[aria-pressed=\"true\"]{background:var(--surface);color:var(--ink-strong);box-shadow:0 1px 3px rgba(8,15,52,.12)}\n#axw .ax-bands{display:flex;flex-wrap:wrap;align-items:center;gap:4px}\n#axw .ax-bands span{font-size:11px;font-weight:700;color:var(--ink3);margin-right:4px}\n#axw .ax-bands button{border:1px solid var(--line);background:var(--bg);font-size:11.5px;padding:4px 10px}\n#axw .ax-bands button[aria-pressed=\"true\"]{border-color:var(--red);color:var(--red);background:var(--surface)}\n#axw #axq{margin-left:auto;min-width:220px;padding:7px 12px;border:1px solid var(--line-strong);border-radius:999px;font:inherit;font-size:12.5px;background:var(--surface);color:var(--ink)}\n#axw .ax-note{font-size:11px;color:var(--ink3);margin:8px 4px 4px}\n#axw .ax-g{margin-top:16px}\n#axw .ax-g h3{display:flex;align-items:center;gap:10px;font-size:15px;color:var(--ink-strong);margin:0 0 10px}\n#axw .ax-g h3 i{flex:none;width:26px;height:26px;border-radius:50%;background:var(--red);color:#fff;font-style:normal;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center}\n#axw .ax-g h3 i.o{background:var(--cream);color:var(--ink)}\n#axw .ax-g h3 small{font-size:11.5px;font-weight:600;color:var(--ink3)}\n#axw .ax-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:12px}\n#axw .ax-t{position:relative;display:flex;flex-direction:column;gap:7px;background:var(--surface);border:1px solid var(--line);border-radius:14px;box-shadow:var(--sh-sm);padding:12px 14px 10px;transition:box-shadow .15s,border-color .15s}\n#axw .ax-t:hover{box-shadow:var(--sh-md)}\n#axw .ax-t.lv-D{box-shadow:inset 3px 0 0 var(--red),var(--sh-sm)}\n#axw .ax-t.lv-P{box-shadow:inset 3px 0 0 var(--cream3),var(--sh-sm)}\n#axw .ax-t.lv-N{background:color-mix(in srgb,var(--bg) 55%,var(--surface))}\n#axw .ax-t.flash{border-color:var(--red);box-shadow:0 0 0 3px color-mix(in srgb,var(--red) 25%,transparent)}\n#axw .ax-t header{display:flex;align-items:center;flex-wrap:wrap;gap:6px;font-size:11px;color:var(--ink3)}\n#axw .ax-id{font-weight:800;color:var(--ink2)}\n#axw .ax-org{font-weight:600}\n#axw .ax-rk{font-style:normal;font-size:10.5px;font-weight:800;color:#fff;background:var(--red);border-radius:999px;padding:1px 8px}\n#axw .ax-dp{font-style:normal;font-size:10.5px;font-weight:700;color:var(--ink2);border:1px dashed var(--line-strong);border-radius:999px;padding:0 8px}\n#axw .ax-lv{margin-left:auto;font-size:10.5px;font-weight:700;padding:1px 9px;border-radius:999px;background:var(--cream);color:var(--ink2)}\n#axw .lv-D .ax-lv{background:color-mix(in srgb,var(--red) 12%,var(--surface));color:var(--red)}\n#axw .lv-N .ax-lv{background:var(--bg);color:var(--ink3)}\n#axw .ax-t h4{margin:0;font-size:14px;line-height:1.4;color:var(--ink-strong)}\n#axw .ax-bg{margin:0;font-size:12px;line-height:1.55;color:var(--ink2)}\n#axw .ax-how{border-radius:10px;padding:9px 11px;background:var(--bg)}\n#axw .ax-how.D{background:color-mix(in srgb,var(--red) 5%,var(--surface));border:1px solid color-mix(in srgb,var(--red) 18%,var(--surface))}\n#axw .ax-how.P{background:color-mix(in srgb,var(--cream) 55%,var(--surface));border:1px solid var(--cream2)}\n#axw .ax-how b{display:block;font-size:10.5px;font-weight:800;letter-spacing:.04em;color:var(--ink3);margin-bottom:3px}\n#axw .ax-how.D b{color:var(--red)}\n#axw .ax-how p{margin:0;font-size:12.5px;line-height:1.6;color:var(--ink)}\n#axw .ax-how.N p{color:var(--ink3);font-size:12px}\n#axw .ax-ags{display:flex;flex-wrap:wrap;gap:5px;margin-top:8px}\n#axw .ax-ag{border:1px solid var(--line);background:var(--surface);border-radius:999px;padding:3px 10px;font:inherit;font-size:11px;font-weight:600;color:var(--ink);cursor:pointer;transition:all .15s}\n#axw .ax-ag:hover{border-color:var(--red);color:var(--red)}\n#axw .ax-st{display:flex;align-items:center;gap:4px;margin-top:8px}\n#axw .ax-st span{font-size:10px;font-weight:700;color:var(--ink3);margin-right:4px}\n#axw .ax-st i{width:20px;height:18px;border-radius:5px;display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:10px;font-weight:700;background:var(--cream);color:var(--ink3)}\n#axw .ax-st i.on{background:var(--red);color:#fff}\n#axw .ax-more{align-self:flex-start;border:0;background:none;font:inherit;font-size:11px;font-weight:700;color:var(--ink3);cursor:pointer;padding:2px 0}\n#axw .ax-more:hover{color:var(--red)}\n#axw .ax-dt{margin:2px 0 0;padding:8px 0 0;border-top:1px dashed var(--cream3);display:flex;flex-direction:column;gap:6px}\n#axw .ax-dt div{display:grid;grid-template-columns:76px 1fr;gap:8px}\n#axw .ax-dt dt{font-size:10.5px;font-weight:800;color:var(--ink3)}\n#axw .ax-dt dd{margin:0;font-size:11.8px;line-height:1.55;color:var(--ink2)}\n#axw .ax-dups{display:flex;flex-wrap:wrap;gap:4px}\n#axw .ax-dups button{border:1px dashed var(--line-strong);background:var(--surface);border-radius:999px;padding:1px 9px;font:inherit;font-size:11px;cursor:pointer;color:var(--ink2)}\n#axw .ax-dups button:hover{border-color:var(--red);color:var(--red)}\n#axw .ax-empty{padding:30px;text-align:center;color:var(--ink3)}\n\n#axw .ax-g h3 i.o::before{content:'';width:8px;height:8px;border-radius:50%;background:var(--ink3)}\n\n/* ===== AX 과제 커버리지 맵: ① 프로세스 → ② 과제 → ③ Agent ===== */\n#axw .axm-sum{display:flex;flex-wrap:wrap;align-items:center;gap:10px 22px;margin:14px 0 10px;padding:14px 18px;background:var(--surface);border:1px solid var(--line);border-radius:14px;box-shadow:var(--sh-sm)}\n#axw .axm-big b{display:block;font-size:30px;font-weight:800;line-height:1;color:var(--red)}\n#axw .axm-big b small{font-size:15px;color:var(--ink3);font-weight:700;margin-left:2px}\n#axw .axm-big span{font-size:12px;font-weight:700;color:var(--ink2)}\n#axw .axm-bar{flex:1;min-width:260px;height:14px;border-radius:999px;overflow:hidden;display:flex;background:var(--bg)}\n#axw .axm-bar i,#axw .axm-mini i{display:block;height:100%}\n#axw i.d{background:var(--red)}#axw i.p{background:color-mix(in srgb,var(--red) 32%,var(--surface))}#axw i.n{background:var(--line-strong)}\n#axw .axm-leg{display:flex;gap:14px;font-size:11.5px;color:var(--ink2)}\n#axw .axm-leg i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:5px;vertical-align:-1px}\n#axw .axm-hl{flex-basis:100%;font-size:12px;color:var(--ink2);display:flex;align-items:center;gap:10px}\n#axw .axm-hl b{color:var(--red)}\n#axw .axm-hl.tip{color:var(--ink3);font-size:11.5px}\n#axw .axm-hl button{border:1px solid var(--line-strong);background:var(--surface);border-radius:999px;padding:2px 10px;font:inherit;font-size:11px;cursor:pointer}\n#axw .axm{display:grid;grid-template-columns:150px repeat(7,minmax(0,1fr)) repeat(3,minmax(0,1fr)) minmax(0,1.45fr);column-gap:6px;row-gap:0;align-items:stretch;background:var(--surface);border:1px solid var(--line);border-radius:16px;box-shadow:var(--sh-sm);padding:10px 12px 12px;min-width:1240px}\n#axw .axm-gh{font-size:10.5px;font-weight:800;letter-spacing:.04em;padding:2px 2px 6px;color:var(--ink3);border-bottom:2px solid var(--line)}\n#axw .axm-gh.prd{color:var(--red);border-color:color-mix(in srgb,var(--red) 45%,var(--surface))}\n#axw .axm-gh.adj{color:var(--ink2);border-color:var(--cream3)}\n#axw .axm-lab{display:flex;flex-wrap:wrap;align-items:center;gap:2px 7px;padding:12px 4px 6px}\n#axw .axm-lab i{flex:none;width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-style:normal;font-size:11px;font-weight:800;background:var(--cream);color:var(--ink)}\n#axw .axm-lab.l3 i{background:var(--red);color:#fff}\n#axw .axm-lab.l2 i{background:var(--ink-strong);color:#fff}\n#axw .axm-lab b{font-size:12.5px;color:var(--ink-strong)}\n#axw .axm-lab small{flex-basis:100%;font-size:10px;color:var(--ink3);padding-left:29px}\n#axw .l3h{border-top:0}\n#axw .axm-ag{display:flex;flex-direction:column;align-items:flex-start;justify-content:center;gap:0;margin:3px 0;padding:3px 8px;border:1px solid transparent;border-radius:8px;background:none;font:inherit;text-align:left;cursor:pointer;min-height:30px}\n#axw .axm-ag b{font-size:11.2px;font-weight:700;color:var(--ink-strong);line-height:1.25}\n#axw .axm-ag small{font-size:9.8px;color:var(--ink3)}\n#axw .axm-ag:hover,#axw .axm-ag.on{border-color:var(--red);background:color-mix(in srgb,var(--red) 5%,var(--surface))}\n#axw .axm-ag.on b{color:var(--red)}\n#axw .axm-seg{margin:3px 0;min-height:30px;display:flex;align-items:center;justify-content:center;border-radius:8px;cursor:pointer;background:repeating-linear-gradient(90deg,transparent 0 6px,color-mix(in srgb,var(--line) 70%,transparent) 6px 7px);background-size:100% 1px;background-repeat:no-repeat;background-position:center}\n#axw .axm-seg.on{margin:3px -3px;border-radius:0;background:color-mix(in srgb,var(--red) 30%,var(--surface))}\n#axw .axm-seg.on.d{background:var(--red)}\n#axw .axm-seg.on.rs{margin-left:0;border-top-left-radius:9px;border-bottom-left-radius:9px}\n#axw .axm-seg.on.re{margin-right:0;border-top-right-radius:9px;border-bottom-right-radius:9px}\n#axw .axm-seg i{font-style:normal;font-size:11px;font-weight:800;color:#fff}\n#axw .axm-seg.on.p i{color:var(--red)}\n#axw .axm-seg.dim,#axw .axm-ag.dim{opacity:.22}\n#axw .axm-seg:hover{filter:brightness(.96)}\n#axw .axm-cell.l2c{display:flex;flex-direction:column;gap:4px;padding:8px 3px;border-top:2px solid var(--line);margin-top:8px}\n#axw .axm-cell.l2c.prd{background:color-mix(in srgb,var(--red) 2.5%,var(--surface))}\n#axw .axm-cnt{display:flex;flex-wrap:wrap;align-items:center;gap:3px 6px;font-size:10.5px;color:var(--ink3);margin-bottom:2px}\n#axw .axm-cnt b{color:var(--ink-strong);font-size:11.5px}\n#axw .axm-mini{flex:1;min-width:30px;height:6px;border-radius:999px;overflow:hidden;display:flex;background:var(--line)}\n#axw .axm-sub{font-size:10px;font-weight:800;color:var(--ink3);margin:6px 2px 1px;letter-spacing:.02em}\n#axw .axm-sub span{font-weight:600}\n#axw .axm-t{display:block;width:100%;text-align:left;border:1px solid var(--line);border-radius:8px;background:var(--surface);padding:4px 7px;font:inherit;font-size:10.6px;line-height:1.38;color:var(--ink);cursor:pointer;transition:all .12s}\n#axw .axm-t b{display:block;font-size:9.6px;font-weight:800;color:var(--ink3)}\n#axw .axm-t.lv-D{border-color:color-mix(in srgb,var(--red) 35%,var(--surface));background:color-mix(in srgb,var(--red) 6%,var(--surface));box-shadow:inset 3px 0 0 var(--red)}\n#axw .axm-t.lv-D b{color:var(--red)}\n#axw .axm-t.lv-P{background:color-mix(in srgb,var(--cream) 60%,var(--surface));box-shadow:inset 3px 0 0 color-mix(in srgb,var(--red) 32%,var(--surface))}\n#axw .axm-t.lv-N{background:var(--bg);color:var(--ink3)}\n#axw .axm-t:hover{border-color:var(--ink-strong)}\n#axw .axm-t.dim{opacity:.2}\n#axw .axm-t.pick{outline:2px solid var(--ink-strong);outline-offset:1px}\n#axw .axm-pr{display:flex;flex-wrap:wrap;align-items:center;gap:1px 7px;margin-top:8px;padding:9px 9px;border-radius:12px;background:var(--surface);border:1px solid var(--line-strong);box-shadow:var(--sh-sm)}\n#axw .axm-pr i{flex:none;width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-style:normal;font-size:11px;font-weight:800;background:var(--cream);color:var(--ink)}\n#axw .axm-pr b{font-size:12px;color:var(--ink-strong);line-height:1.25}\n#axw .axm-pr small{flex-basis:100%;font-size:9.6px;color:var(--ink3);padding-left:29px}\n#axw .axm-pr.adj{background:color-mix(in srgb,var(--cream) 55%,var(--surface));border-style:dashed}\n#axw .axm-pr.adj small{padding-left:0}\n#axw .axm-lab.l1{margin-top:8px}\n#axw .axm-pick{position:fixed;right:22px;top:84px;width:440px;max-height:calc(100vh - 110px);overflow:auto;z-index:60;background:var(--bg);border-radius:16px;box-shadow:var(--sh-xl);padding:8px}\n#axw .axm-pick .ax-t{box-shadow:var(--sh-sm)}\n#axw .axm-x{position:sticky;top:0;float:right;z-index:2;border:0;background:var(--cream);border-radius:999px;width:28px;height:28px;font-size:16px;cursor:pointer;margin:2px 2px 0 0}\n\n/* 프로세스 층을 화면 바닥에 고정 (과제를 내려 봐도 어느 단계인지 보이게) */\n#axw .axm-pr,#axw .axm-lab.l1{position:sticky;bottom:6px;z-index:5}\n#axw .axm-lab.l1{background:var(--surface);border-radius:10px}\n#axw .axm-pr{box-shadow:0 -6px 16px -8px rgba(8,15,52,.18),var(--sh-sm)}\n#axw .axm-pr.adj{background:color-mix(in srgb,var(--cream) 70%,var(--surface))}\n#axw .axm-more{width:100%;border:1px dashed var(--line-strong);background:var(--surface);border-radius:8px;padding:4px 6px;font:inherit;font-size:10.5px;font-weight:700;color:var(--ink3);cursor:pointer}\n#axw .axm-more:hover{color:var(--ink-strong);border-color:var(--ink-strong)}\n\n/* 바닥 층 사이 틈을 흰 띠로 메워 뒤 과제 칩이 비치지 않게 */\n#axw .axm-pr,#axw .axm-lab.l1{bottom:0;box-shadow:0 0 0 5px var(--surface),0 -14px 18px -8px rgba(8,15,52,.22)}\n#axw .axm-lab.l1{border-radius:0}\n\n/* 바닥 층이 화면 맨 아래에 붙도록: 창 아래 여백은 내용 쪽으로 */\n#axw{padding-bottom:0}\n#axw .axw-in{padding-bottom:40px}\n#axw .axm-pr,#axw .axm-lab.l1{box-shadow:0 0 0 5px var(--surface),0 12px 0 5px var(--surface),0 -14px 18px -8px rgba(8,15,52,.22)}\n\n/* ===== AX 과제 창 v3: Agent 과제 Coverage 표 · 조직별 ===== */\n#axw .ax-ctl{gap:10px 14px}\n#axw .axx-wrap{margin-top:10px;background:var(--surface);border:1px solid var(--line);border-radius:16px;box-shadow:var(--sh-sm);padding:8px 10px 10px;overflow-x:auto}\n#axw table.axx{width:100%;min-width:1180px;border-collapse:separate;border-spacing:4px 4px;table-layout:fixed}\n#axw table.axx th,#axw table.axx td{padding:0;text-align:center;vertical-align:middle}\n#axw table.axx col.c0{width:200px}\n#axw table.axx th.corner{width:200px;text-align:left;font-weight:400;padding:4px 6px;vertical-align:bottom}\n#axw table.axx th.corner b{font-size:12.5px;color:var(--ink-strong)}\n#axw table.axx th.corner small{display:block;font-size:10px;color:var(--ink3);margin-top:3px;line-height:1.4}\n#axw table.axx th.g{font-size:10.5px;font-weight:800;letter-spacing:.04em;padding:2px 4px 5px;border-bottom:2px solid var(--line);color:var(--ink3);text-align:left}\n#axw table.axx th.g.prd{color:var(--red);border-color:color-mix(in srgb,var(--red) 45%,var(--surface))}\n#axw table.axx th.g.adj{color:var(--ink2);border-color:var(--cream3)}\n#axw table.axx th.ch button,#axw table.axx th.rh button{width:100%;border:1px solid var(--line);background:var(--surface);border-radius:10px;font:inherit;cursor:pointer;transition:all .12s}\n#axw table.axx th.ch button{display:flex;flex-direction:column;align-items:center;gap:1px;padding:7px 4px;min-height:58px;justify-content:center}\n#axw table.axx th.ch.prd button i{width:20px;height:20px;border-radius:50%;background:var(--cream);font-style:normal;font-size:10.5px;font-weight:800;display:flex;align-items:center;justify-content:center;color:var(--ink)}\n#axw table.axx th.ch.adj button{background:color-mix(in srgb,var(--cream) 55%,var(--surface));border-style:dashed}\n#axw table.axx th.ch b{font-size:11.5px;color:var(--ink-strong);line-height:1.25}\n#axw table.axx th.ch small{font-size:9.4px;color:var(--ink3);line-height:1.3}\n#axw table.axx th.ch button:hover,#axw table.axx th.rh button:hover{border-color:var(--ink-strong)}\n#axw table.axx th.ch.on button,#axw table.axx th.rh.on button{border-color:var(--red);box-shadow:0 0 0 1px var(--red)}\n#axw table.axx th.rh button{display:flex;flex-direction:column;align-items:flex-start;padding:6px 10px;text-align:left;min-height:44px;justify-content:center}\n#axw table.axx th.rh b{font-size:11.8px;color:var(--ink-strong)}\n#axw table.axx th.rh small{font-size:10px;color:var(--ink3)}\n#axw table.axx td .nb{width:100%;min-height:44px;border:0;border-radius:10px;font:inherit;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;transition:transform .1s,box-shadow .12s}\n#axw table.axx td .nb b{font-size:17px;font-weight:800;line-height:1.1}\n#axw table.axx td .nb small{font-size:9.5px;font-weight:700}\n#axw table.axx td .nb.d{background:color-mix(in srgb,var(--red) calc(var(--a,1) * 100%),var(--surface));color:#fff}\n#axw table.axx td .nb.p{background:color-mix(in srgb,var(--red) 18%,var(--surface));color:var(--red)}\n#axw table.axx td .nb.z{background:var(--bg);color:var(--ink3)}\n#axw table.axx td .nb:hover{transform:translateY(-1px);box-shadow:var(--sh-md)}\n#axw table.axx td .nb.on{box-shadow:0 0 0 2px var(--surface),0 0 0 4px var(--ink-strong)}\n#axw table.axx td .nz{display:block;min-height:44px;line-height:44px;color:var(--line-strong);background:repeating-linear-gradient(135deg,transparent 0 6px,color-mix(in srgb,var(--line) 55%,transparent) 6px 7px);border-radius:10px}\n#axw table.axx td.adj .nb.p{background:color-mix(in srgb,var(--red) 14%,var(--surface))}\n#axw table.axx tfoot th.ft{font-size:10.5px;font-weight:800;color:var(--ink3);text-align:right;padding:4px 10px}\n#axw table.axx tfoot td.ft{font-size:11px;color:var(--ink2);padding:4px 2px;border-top:1px dashed var(--cream3)}\n#axw table.axx tfoot td.ft b{font-size:13px;color:var(--ink-strong);margin-right:3px}\n#axw table.axx tfoot td.ft small{font-size:10px;color:var(--ink3)}\n#axw table.axx tfoot .axm-mini{display:flex;height:5px;margin:3px 6px 1px}\n#axw table.axx .tot b{font-size:13px;color:var(--ink-strong)}#axw table.axx .tot small{font-size:10px;color:var(--ink3)}\n#axw table.axx th.ch.tot{font-size:11px;color:var(--ink2)}\n#axw .axr{margin-top:16px;padding-top:4px}\n#axw .axr-h{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;padding:10px 14px;background:var(--surface);border:1px solid var(--line);border-left:4px solid var(--red);border-radius:12px;box-shadow:var(--sh-sm);margin-bottom:10px}\n#axw .axr-h b{font-size:14px;color:var(--ink-strong)}\n#axw .axr-h span{font-size:11.5px;color:var(--ink3)}\n#axw .axr-h button{margin-left:auto;border:1px solid var(--line-strong);background:var(--surface);border-radius:999px;padding:3px 12px;font:inherit;font-size:11px;cursor:pointer}\n#axw .axr-h button:hover{border-color:var(--ink-strong)}\n#axw .ax-ag.on{border-color:var(--red);background:color-mix(in srgb,var(--red) 8%,var(--surface));color:var(--red)}\n/* 조직별 */\n#axw .axo-top{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:10px;margin-top:12px}\n#axw .axo-c{display:flex;flex-direction:column;align-items:flex-start;gap:3px;text-align:left;padding:11px 13px;background:var(--surface);border:1px solid var(--line);border-radius:14px;box-shadow:var(--sh-sm);font:inherit;cursor:pointer;transition:all .12s}\n#axw .axo-c:hover{box-shadow:var(--sh-md)}\n#axw .axo-c.on{border-color:var(--red);box-shadow:0 0 0 1px var(--red)}\n#axw .axo-c .nm{font-size:12px;font-weight:800;color:var(--ink-strong)}\n#axw .axo-c b{font-size:24px;font-weight:800;color:var(--red);line-height:1.1}\n#axw .axo-c b small{font-size:13px;color:var(--ink3);font-weight:700}\n#axw .axo-c .lb{font-size:10.5px;color:var(--ink2)}\n#axw .axo-c .axm-mini{display:flex;width:100%;height:6px}\n#axw .axo-c > small{font-size:10px;color:var(--ink3)}\n#axw table.axx.axo{min-width:1100px}\n#axw table.axx.axo th.ch button{min-height:46px}\n#axw table.axx.axo td .nb b{font-size:15px}\n#axw table.axx.axo td .nb small{font-size:10px;font-weight:600;opacity:.85}\n#axw .axo-g{margin-bottom:14px}\n#axw .axo-g h4{display:flex;align-items:baseline;gap:8px;font-size:13.5px;color:var(--ink-strong);margin:8px 2px 6px}\n#axw .axo-g h4 small{font-size:11px;color:var(--ink3);font-weight:600}\n#axw table.axo-t{width:100%;border-collapse:separate;border-spacing:0;background:var(--surface);border:1px solid var(--line);border-radius:12px;overflow:hidden;box-shadow:var(--sh-sm)}\n#axw table.axo-t th{font-size:10.5px;font-weight:800;color:var(--ink3);text-align:left;padding:7px 10px;background:var(--bg);border-bottom:1px solid var(--line)}\n#axw table.axo-t th:nth-child(1){width:30%}#axw table.axo-t th:nth-child(2){width:9%}#axw table.axo-t th:nth-child(3){width:37%}#axw table.axo-t th:nth-child(4){width:24%}\n#axw table.axo-t td{vertical-align:top;padding:9px 10px;border-bottom:1px solid var(--line);font-size:12px;line-height:1.55}\n#axw table.axo-t tr:last-child td{border-bottom:0}\n#axw table.axo-t tr.lv-D td.c1{box-shadow:inset 3px 0 0 var(--red)}\n#axw table.axo-t tr.lv-P td.c1{box-shadow:inset 3px 0 0 color-mix(in srgb,var(--red) 30%,var(--surface))}\n#axw table.axo-t tr.lv-N td{color:var(--ink3)}\n#axw table.axo-t td.c1 b{display:block;font-size:12.8px;color:var(--ink-strong);margin:2px 0}\n#axw table.axo-t tr.lv-N td.c1 b{color:var(--ink2)}\n#axw table.axo-t td.c1 p{margin:0 0 3px;font-size:11.2px;color:var(--ink3)}\n#axw table.axo-t td.c2 .ax-lv{display:inline-block;margin:0 0 4px}\n#axw table.axo-t tr.lv-D td.c2 .ax-lv{background:color-mix(in srgb,var(--red) 12%,var(--surface));color:var(--red)}\n#axw table.axo-t td.c2 .ax-rk{display:inline-block}\n#axw table.axo-t td.c3.D{color:var(--ink)}\n#axw table.axo-t td.c4 .ax-ags{margin-top:0}\n#axw table.axo-t .ax-dt{margin-top:6px}\n\n/* 구조도 Process Coverage: 그 Agent가 일하는 단계 번호를 빨강(Agent 색)으로 칠함 — 뒤에 붙은 기본 칸 규칙에 덮이지 않게 더 구체적으로 */\n#amap .ax-pc .ax-pv i.on{background:var(--red);color:#fff;box-shadow:0 1px 3px color-mix(in srgb,var(--red) 35%,transparent)}\n#amap .ax-pc .ax-pv i:not(.on){background:var(--cream);color:var(--ink3);opacity:.75}\n\n/* ===== 준비 상태 3단계: 기존(회색) · 준비중(파랑, 다른 팀이 준비) · 신규 설치 필요(빨강 점선) ===== */\n:root{--prep-ink:#1F5FBF;--prep-bg:color-mix(in srgb,#2F7BF6 9%,var(--surface));--prep-bd:#5B9BF8}\n@media (prefers-color-scheme: dark){:root:not([data-theme=\"light\"]){--prep-ink:#8FB8FF;--prep-bg:color-mix(in srgb,#2F7BF6 20%,var(--surface));--prep-bd:#5B8FE0}}\n:root[data-theme=\"dark\"]{--prep-ink:#8FB8FF;--prep-bg:color-mix(in srgb,#2F7BF6 20%,var(--surface));--prep-bd:#5B8FE0}\n.cp.p{background:var(--prep-bg);border-color:var(--prep-bd);color:var(--prep-ink);border-style:dotted}\n.rk.p,.stp.p,.sst.p,.dst.p,.st-p{color:var(--prep-ink);background:var(--prep-bg);border:1px dotted var(--prep-bd)}\n.st-p{font-weight:700;border-radius:999px;padding:1px 9px}\n.sst.p{border-radius:999px;padding:0 5px;margin-right:6px}\nul.dsl.p li::marker{color:var(--prep-bd)}ul.dsl.p li{color:var(--ink-strong)}\n.fg li.p::marker,.fbx li.p::marker{color:var(--prep-bd)}\n.fg li.p em,.fbx li.p em{color:var(--prep-ink);border:1px dotted var(--prep-bd);background:var(--prep-bg)}\n.sy.p{border:1px dotted var(--prep-bd);background:var(--prep-bg)}.sy.p .st{color:var(--prep-ink)}\n.scg .scr.p{padding-top:3px;border-top:1px dotted var(--line)}\nsmall.stn{display:block;margin:2px 0 4px;font-size:10.8px;line-height:1.45;font-weight:500;color:var(--ink3)}\nsmall.stn.p{color:var(--prep-ink)}\ntable.cb td small.stn{margin:0 0 6px}\ntable.mx td.src small.stn{margin-top:3px}\n\n.cbw{display:flex;flex-direction:column;gap:10px;margin:10px 0 12px}\n.cbk{border:1px solid var(--line);border-radius:12px;padding:9px 11px;background:var(--surface)}\n.cbk .cbt{display:block;font-size:11px;font-weight:800;color:var(--ink3);margin-bottom:6px}\n.cbg{display:flex;flex-wrap:wrap;align-items:center;gap:4px;padding:5px 0;border-top:1px dashed var(--line)}\n.cbg:first-of-type{border-top:0;padding-top:0}\n.cbg .rk{margin-right:4px}\n.cbp{flex-basis:100%}\n.cbp small.stn{margin:2px 0 2px 2px}\n\n/* 준비중: 이름 뒤 괄호로 (어떤 팀이 무엇을 준비중) */\n.prw{font-weight:600;font-size:.92em;color:var(--prep-ink)}\n.prw.blk{display:block;margin-top:2px;font-size:11px;line-height:1.45}\n.sy small.prw{display:block;font-size:11px;line-height:1.4;margin:2px 0 1px;color:var(--prep-ink)}\n\n/* ===== 상세 페이지: 무엇이 필요한가(상위) → 형식·시스템(하위) ===== */\nol.fxl,ol.fxp{list-style:none;margin:6px 0 0;padding:0;display:flex;flex-direction:column;gap:6px}\nol.fxl li,ol.fxp li{display:flex;align-items:flex-start;gap:7px;font-size:12px;line-height:1.45;color:var(--ink)}\n.fxn{flex:none;width:18px;height:18px;border-radius:50%;background:var(--cream);color:var(--ink);font-style:normal;font-size:10px;font-weight:800;display:inline-flex;align-items:center;justify-content:center;margin-top:1px}\nol.fxl li.p .fxn{background:var(--prep-bg);color:var(--prep-ink);box-shadow:inset 0 0 0 1px var(--prep-bd)}\nol.fxl li.n .fxn{background:var(--need-bg);color:var(--need-ink);box-shadow:inset 0 0 0 1px var(--need-bd)}\n.fxb{flex:1;min-width:0}\n.fxb > b{font-weight:700;color:var(--ink-strong)}\nol.fxl li.n .fxb > b{color:var(--ink-strong)}\n.fxt{font-style:normal;font-size:9.5px;font-weight:700;border-radius:999px;padding:0 6px;margin-left:5px;vertical-align:1px}\n.fxt.p{color:var(--prep-ink);border:1px dotted var(--prep-bd);background:var(--prep-bg)}\n.fxt.n{color:var(--red);border:1px dashed var(--red)}\n.fxf{display:flex;flex-wrap:wrap;align-items:center;gap:3px;margin-top:3px}\n.fxf small{font-size:9.5px;font-weight:800;color:var(--ink3);margin-right:2px}\n.fxf i{font-style:normal;font-size:10.5px;line-height:1.35;color:var(--ink2);background:var(--bg);border:1px solid var(--line);border-radius:6px;padding:1px 6px}\n.fx-api > b small{font-weight:600;color:var(--ink3);margin-left:6px;font-size:10px}\n.fxs{display:flex;flex-wrap:wrap;gap:3px;margin-top:3px}\n.fxs i.sx{font-style:normal;font-size:10.8px;line-height:1.4;border-radius:7px;padding:1px 7px;border:1px solid var(--have-bd);background:var(--have-bg);color:var(--have-ink)}\n.fxs i.sx.p{border:1px dotted var(--prep-bd);background:var(--prep-bg);color:var(--prep-ink)}\n.fxs i.sx.n{border:1px dashed var(--need-bd);background:var(--need-bg);color:var(--need-ink)}\n.fxs i.sx u{text-decoration:none;font-size:9px;font-weight:800;margin-right:4px}\nol.fxl.big li{font-size:12.4px}\nol.fxl.big .wh{display:block;margin-top:2px}\n.syl.spw{display:flex;flex-direction:column;gap:10px}\n.spg{border:1px solid var(--line);border-radius:12px;padding:8px 10px;background:var(--surface)}\n.spt{display:flex;align-items:center;gap:7px;margin:0 0 7px;font-size:12.5px;color:var(--ink-strong)}\n.spl{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:6px}\n\n/* 묶음 → 하위 불렛 */\nul.fxsub{list-style:none;margin:4px 0 0;padding:0 0 0 2px;display:flex;flex-direction:column;gap:2px}\nul.fxsub li{position:relative;padding-left:11px;font-size:11.4px;line-height:1.5;color:var(--ink2)}\nul.fxsub li::before{content:'';position:absolute;left:1px;top:.62em;width:4px;height:4px;border-radius:50%;background:var(--ink3)}\nul.fxsub li.p::before{background:var(--prep-bd)}ul.fxsub li.n::before{background:var(--red)}\n.fxsn{color:var(--ink);font-weight:600}\n.fxd{color:var(--ink3)}\n.fxf2{color:var(--ink3)}\n.fxk{font-size:9.5px;font-weight:800;color:var(--ink3);margin-right:5px}\nol.fxl.big ul.fxsub li{font-size:11.8px}\nol.fxl.big ul.fxsub .wh{display:block;margin:1px 0 2px}\nsmall.fxdet{display:block;font-size:10.8px;color:var(--ink3);margin-top:2px;font-weight:500}\n\nol.fxl > li,ol.fxp > li{display:flex}\nul.fxsub li{display:block !important}\n\n.tk-x2{--tkc:#2a8c82;--tkb:color-mix(in srgb,#2a8c82 9%,transparent)}\n.tk-x3{--tkc:#b7791f;--tkb:color-mix(in srgb,#b7791f 9%,transparent)}\n.tk-x4{--tkc:#3b6fb6;--tkb:color-mix(in srgb,#3b6fb6 9%,transparent)}\n.tk-x5{--tkc:#5f8f3e;--tkb:color-mix(in srgb,#5f8f3e 9%,transparent)}\n#board .nd.k-ot,.sw.nd.k-ot{border-style:dashed}\n#board .nd.k-ot{background:var(--surface)}\n.smb .O,.mbar .O{background:repeating-linear-gradient(45deg,var(--ds-gray-medium) 0 3px,var(--surface) 3px 5px)}\n#steps i.stl:nth-of-type(n+4){visibility:hidden}#steps button.stp2[data-st=5]{margin-left:14px;box-shadow:inset 3px 0 0 var(--ds-gray-medium,#ccc)}#scenask{position:fixed;inset:0;z-index:90;background:rgba(8,15,52,.28);display:flex;align-items:center;justify-content:center}#scenask[hidden]{display:none}#scenask .sqbox{background:var(--surface);border:1.5px solid var(--red);border-radius:14px;box-shadow:0 14px 40px rgba(8,15,52,.25);padding:16px 18px;width:min(520px,calc(100vw - 40px));display:flex;flex-direction:column;gap:8px}#scenask small{font-size:11px;color:var(--ink3);font-weight:700}#scenask b{font-size:15px;color:var(--ink-strong)}#scenask .sqopts{display:flex;flex-wrap:wrap;gap:8px;margin-top:4px}#scenask .sqopts button{border:1.5px solid var(--red);background:var(--surface);color:var(--red);border-radius:999px;padding:6px 14px;font-weight:700;cursor:pointer}#scenask .sqopts button:hover{background:var(--red);color:#fff}#scenask .sqall{align-self:flex-start;border:0;background:none;color:var(--ink3);text-decoration:underline;cursor:pointer;padding:2px 0;font-size:12px}#board .gbox.lgrp.lsub{z-index:3;background:transparent;border-style:dashed}#board .gbox.lgrp.lsub .lgl{left:auto;right:8px;top:-8px;background:var(--surface);padding:0 5px;border-radius:5px;line-height:14px}#board .gbox.gb[data-band=B10]{border:1.5px dashed #7B6BB0;background:repeating-linear-gradient(135deg,rgba(123,107,176,.05) 0 8px,transparent 8px 16px)}#board .gbox.gb[data-band=B10] .gt b{color:#5B4B95}#board .gbox.gs[data-band=B10]{border-color:#9C8FD0}#board .gbox.gb[data-band=B11],#board .gbox.gb[data-band=B12],#board .gbox.gb[data-band=B13]{border:1.5px dashed #7B6BB0;background:repeating-linear-gradient(135deg,rgba(123,107,176,.05) 0 8px,transparent 8px 16px)}#board .gbox.gb[data-band=B11] .gt b,#board .gbox.gb[data-band=B12] .gt b,#board .gbox.gb[data-band=B13] .gt b{color:#5B4B95}#board .gbox.gs[data-band=B11],#board .gbox.gs[data-band=B12],#board .gbox.gs[data-band=B13]{border-color:#9C8FD0}/* 세부 Agent 표 편집 */\n.aph .agx-mode,.aph .agx-save{height:30px;padding:0 13px;border-radius:999px;font-size:12px;font-weight:700}\n.aph .agx-mode[aria-pressed=\"true\"]{background:var(--red);border-color:var(--red);color:#fff}\n.aph .agx-save{border-color:var(--ink-strong)}\n.aph .agx-cnt{font-size:11px;color:var(--red);font-weight:700}\ntable.prof.agx-on{border-color:var(--red);box-shadow:0 0 0 2px color-mix(in srgb,var(--red) 18%,transparent)}\ntable.prof .agx-note td{background:color-mix(in srgb,var(--red) 5%,var(--surface));font-size:12.3px;color:var(--ink2);padding:9px 14px}\ntable.prof .agx-note b{color:var(--red);margin-right:6px}\ntable.prof th small.agauto{display:block;margin-top:3px;font-size:10px;font-weight:600;color:var(--ink3)}\ntable.prof.agx-on tr:has(small.agauto) td{background:var(--ds-gray-x-light);color:var(--ink3)}\n.agx-t,.agx-li,.agx-c{display:block;min-height:22px;padding:4px 8px;border:1px dashed var(--line-strong);border-radius:7px;background:var(--surface);outline:none;cursor:text}\n.agx-t:focus,.agx-li:focus,.agx-c:focus,.agx-tb input:focus,.agx-tb select:focus{border:1px solid var(--red);box-shadow:0 0 0 3px color-mix(in srgb,var(--red) 14%,transparent)}\nol.agx-l{margin:0;padding-left:20px}ol.agx-l li{display:flex;align-items:flex-start;gap:6px;margin:0 0 5px}ol.agx-l li .agx-li{flex:1}\n.agx-x{flex:none;width:24px;height:24px;padding:0;border-radius:50%;line-height:20px;font-size:14px;color:var(--ink3)}\n.agx-x:hover{color:var(--red);border-color:var(--red)}\n.agx-add{margin-top:4px;height:26px;padding:0 11px;font-size:11.5px;border-style:dashed;color:var(--ink2)}\n.agx-add:hover{color:var(--red);border-color:var(--red)}\n.agx-tw{overflow-x:auto}\ntable.agx-tb{width:100%;border-collapse:collapse;font-size:12px}\ntable.agx-tb th{text-align:left;font-size:10.5px;color:var(--ink3);font-weight:700;padding:3px 5px;background:none;width:auto;white-space:nowrap;border:0}\ntable.agx-tb td{padding:3px 4px;border:0;vertical-align:top;font-size:12px}\ntable.agx-tb td:first-child{min-width:200px}\ntable.agx-tb input,table.agx-tb select{width:100%;min-width:90px;height:28px;border:1px solid var(--line-strong);border-radius:7px;padding:0 7px;font:inherit;font-size:12px;background:var(--surface);color:var(--ink-strong)}\n.agx-mk{font-size:10.5px;font-weight:700;color:var(--red);border:1px solid var(--red);border-radius:999px;padding:0 8px;margin-right:6px}\n.agx-rs{height:24px;padding:0 10px;font-size:11px;margin-right:6px}\ndetails.agx-asis{margin-top:6px;font-size:11.5px;color:var(--ink3)}details.agx-asis summary{cursor:pointer}\n\n/* ===== 상세 창 글자 수정 · 연결선 수정 ===== */\n#panel.pe-on .pe-u{outline:1px dashed rgba(204,0,0,.55);outline-offset:1px;border-radius:3px;cursor:text}\n#panel.pe-on .pe-u:hover{background:rgba(255,200,70,.18)}\n#panel.pe-on .pe-u:focus{outline:2px solid var(--red);outline-offset:2px;background:#fffaf0;color:var(--ink-strong)}\n#panel.pe-on .pe-u.pe-d{background:rgba(255,200,70,.28)}\n#panel [data-ed=\"text\"][aria-pressed=\"true\"]{background:var(--red);border-color:var(--red);color:var(--ds-text-on-color)}\n#panel .pflow .fed{margin-left:6px;width:22px;height:22px;padding:0;border-radius:50%;font-size:11px;line-height:20px;text-align:center;color:var(--ink2);background:var(--surface);vertical-align:middle}\n#panel .pflow .fed:hover{color:var(--red);border-color:var(--red)}\n#panel .pedf2{display:flex;align-items:center;gap:8px;margin:0 0 6px;font-size:12px;flex-wrap:wrap}\n#panel .pedf2>span{width:64px;color:var(--ink2);font-weight:700}\n#panel .pedf2 .lk{max-width:240px;text-align:left;white-space:normal}\n#panel .pedf2 small{color:var(--ink3)}\n#panel .pedf2 [data-ed]{margin-left:auto;height:28px;padding:0 12px;font-size:12px}\n#panel .pseg{display:inline-flex;flex-wrap:wrap;gap:4px;flex:1}\n#panel .pseg button{height:28px;padding:0 11px;font-size:12px}\n#panel .pseg button[aria-pressed=\"true\"]{background:var(--ink);border-color:var(--ink);color:var(--ds-text-on-color)}\nbody.connecting #panel[data-kind=\"edge\"]{box-shadow:0 0 0 3px var(--red),var(--sh-xl)}\n#apm [data-nmk][contenteditable=\"true\"]{outline:1px dashed rgba(204,0,0,.55);outline-offset:3px;border-radius:4px;cursor:text}\n#apm [data-nmk][contenteditable=\"true\"]:focus{outline:2px solid var(--red);background:#fffaf0}\n#apm.ae-on .ae-it{position:relative}\n#apm.ae-on tr.ae-it > td:first-child{position:relative}\n#apm .ae-bs{display:none;position:absolute;top:-9px;right:-6px;z-index:5;gap:3px;white-space:nowrap}\n#apm.ae-on .ae-it:hover > .ae-bs, #apm.ae-on .ae-it:hover > td > .ae-bs, #apm.ae-on .ae-it:hover > .fxb > .ae-bs, #apm.ae-on .ae-it:hover > h6 > .ae-bs{display:inline-flex}\n#apm .ae-b{width:19px;height:19px;padding:0;border-radius:50%;border:1px solid var(--line-strong);background:var(--surface);color:var(--ink2);font-size:11px;line-height:17px;font-weight:700;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.18)}\n#apm .ae-b.x{border-color:var(--red);color:var(--red)}\n#apm .ae-b:hover{background:var(--red);border-color:var(--red);color:var(--ds-text-on-color)}\n#apm.ae-on .ae-it:hover{box-shadow:inset 0 0 0 1px rgba(204,0,0,.35);border-radius:4px}\n#apm.ae-on .ae-tx{outline:1px dashed rgba(204,0,0,.55);outline-offset:1px;border-radius:3px;cursor:text}\n#apm.ae-on .ae-tx:focus{outline:2px solid var(--red);background:#fffaf0;color:var(--ink-strong)}\n#apm.ae-on .ae-tx:empty{display:inline-block;min-width:120px;min-height:1.2em;vertical-align:middle}\n#apm .ae-b.st{border-color:var(--ink2)}\n#apm.ae-on .ae-pick{cursor:pointer;outline:1px dashed rgba(204,0,0,.55);outline-offset:1px}\n#apm.ae-on .ae-pick:hover{background:rgba(255,200,70,.25)}\n.ae-pop{position:fixed;z-index:100000;width:300px;padding:12px 14px;border-radius:10px;background:var(--surface);border:1px solid var(--line-strong);box-shadow:0 8px 28px rgba(0,0,0,.22);font-size:12.5px;color:var(--ink)}\n.ae-pop .ae-pt{font-weight:700;margin-bottom:8px;line-height:1.35}.ae-pop .ae-pt small{display:block;font-weight:400;color:var(--ink2);font-size:11px}\n.ae-pop label{display:flex;flex-direction:column;gap:3px;margin:0 0 8px;color:var(--ink2);font-size:11.5px}.ae-pop label[hidden]{display:none}\n.ae-pop select,.ae-pop input{font:inherit;font-size:12.5px;padding:5px 7px;border:1px solid var(--line-strong);border-radius:6px;background:var(--surface);color:var(--ink)}\n.ae-pop .ae-pb{display:flex;gap:6px;justify-content:flex-end}.ae-pop .ae-pb button{height:28px;padding:0 13px;border-radius:999px;border:1px solid var(--line-strong);background:var(--surface);font:inherit;font-size:12px;cursor:pointer}.ae-pop .ae-pb .ok{background:var(--red);border-color:var(--red);color:var(--ds-text-on-color)}\n#apm .ae-fmw{display:flex;flex-wrap:wrap;gap:4px;align-items:center}\n#apm .ae-fc{display:inline-flex;align-items:center;gap:3px;padding:1px 4px 1px 8px;border-radius:999px;border:1px solid var(--line-strong);background:var(--surface);font-size:11.5px}\n#apm .ae-fc button{width:16px;height:16px;padding:0;border:none;border-radius:50%;background:transparent;color:var(--ink2);cursor:pointer;font-size:12px;line-height:16px}#apm .ae-fc button:hover{background:var(--red);color:var(--ds-text-on-color)}\n#apm .ae-fa{flex:1;min-width:130px;font:inherit;font-size:12px;padding:3px 6px;border:1px dashed var(--line-strong);border-radius:6px;background:transparent}\n#apm .agx-who{display:block;margin-top:4px;width:100%;font:inherit;font-size:11.5px;padding:3px 6px;border:1px solid var(--line-strong);border-radius:5px}\n#apm .ae-in{width:100%;min-width:140px;font:inherit;font-size:12px;padding:2px 6px;border:2px solid var(--red);border-radius:4px;background:#fffaf0;color:var(--ink-strong)}\n#amap .amh .amed{margin-left:auto;height:28px;padding:0 13px;border:1px solid var(--line-strong);border-radius:999px;background:var(--surface);color:var(--ink);font:inherit;font-size:12px;font-weight:700;cursor:pointer}\n#amap .amh .amed:hover{border-color:var(--red);color:var(--red)}\n#amap .amh .amed[aria-pressed=\"true\"]{background:var(--red);border-color:var(--red);color:var(--ds-text-on-color)}\n#amap .amh .amed + .ax-pre{margin-left:0}\n#amap.ame [contenteditable=\"true\"]{outline:1px dashed rgba(204,0,0,.55);outline-offset:2px;border-radius:3px;cursor:text}\n#amap.ame [contenteditable=\"true\"]:focus{outline:2px solid var(--red);background:#fffaf0;color:var(--ink-strong)}\n\n/* ui_fixes v19 */\n/* 페이지 스크롤: 지도는 화면 높이를 다 씀 */\nbody:not(.present) #wrap{height:calc(100vh - 8px)!important;min-height:420px}\n/* 고정 머리줄 높이는 내용에 맞춰 (headFit) */\n#inner{grid-template-rows:auto auto!important}\n#stagehead{height:auto;min-height:84px}\n#corner{height:auto!important;min-height:84px}\n#corner span{height:auto;min-height:18px}\n/* 단계 바·숫자·게이트: 줄바꿈 허용, 잘림 없음 */\n.cv,.cv .cvi,.cv span{white-space:normal!important;overflow:visible!important;text-overflow:clip!important}\n.cv{align-items:flex-start!important;padding-top:4px!important;padding-bottom:4px!important;line-height:1.3}\n.cv .cvi{display:inline-flex!important;flex-wrap:wrap;max-width:100%;row-gap:2px}\n/* 박스·레인·이름표: 줄 수 제한·말줄임 해제 (박스 높이는 두 가지 — 넘치면 박스 안 스크롤) */\n.nd .lbl,.nd.L4 .lbl,.nd.L5 .lbl,.nd .meta,.nd.k-why .lbl,body:not(.vflow) #board .nd .lbl,body:not(.vflow) #board .nd.k-why .lbl,#board .nd.tghost .lbl,#afb .nd.afn .lbl,#afb .nd.afn.oth .lbl,.lc.sub .scd,#steps li span,#board .sc.narrow .sc-chg{-webkit-line-clamp:unset!important;display:block!important;overflow:visible!important;max-height:none!important}\n.nd .meta .mtx,#afb .nd.afn .nk,#tourcap .tsx,#tourcap .tkey{white-space:normal!important;overflow:visible!important;text-overflow:clip!important}\n#board .nd,#afb .nd{overflow-y:auto;overflow-x:hidden;scrollbar-width:thin}\n#labels .lc b,#labels .lc .ln{white-space:normal;overflow:visible;text-overflow:clip;word-break:keep-all;overflow-wrap:break-word;line-height:1.25}\n#labels .lc{overflow-y:auto;scrollbar-width:thin}\n#labels .lsg{display:block;word-break:keep-all}\n/* v22 상단 압축: 여백·글자 크기만 줄임 (잘라내지 않음) */\n#top .hero{padding:10px 18px 8px!important}#top .hero h1{font-size:20px!important;margin:0!important;line-height:1.25}#top .hero .eyebrow{margin-bottom:1px!important}#top .hero .crumb{font-size:11px!important}\n#top .hero .ver{padding:2px 8px!important}#top #steps{padding:0!important;margin-top:6px!important;gap:6px!important}#top #steps .stp2{padding:4px 8px!important;min-height:0!important}#top #steps .stp2 .stx{font-size:11px!important;line-height:1.3!important}\n#top #controls{padding:4px 8px!important;margin-bottom:4px!important;row-gap:4px!important}#top #controls button{height:26px!important}#top #controls .seg{padding:2px!important}#top #controls .seg button{height:22px!important}\n/* Agent 페이지 머리: 잘리지 않게 */\n#apage header.apt{overflow:visible!important}\n\n#btnBundle.on{background:var(--ink);color:#fff}\n/* v36 연결선 이름표: 원문 전체를 상자 안에서 줄바꿈 (엇갈린 한 줄 고정 규칙 정리) — 띄어쓰기에서 줄바꿈, 최대 폭 200px */\n#board .elab, #apm .elab{white-space:normal!important;max-width:200px!important;width:max-content;text-align:center;word-break:keep-all;overflow-wrap:anywhere;border-radius:9px!important;line-height:1.35}\n/* v30 흐름 따라가기 시작 창·박스 고르기 안내 */\n#tourStartDlg{position:fixed;inset:0;z-index:9000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,.28)}#tourStartDlg[hidden]{display:none}\n#tourStartDlg .tsd-box{position:relative;background:var(--surface,#fff);color:var(--ink);border-radius:14px;padding:22px 24px 18px;box-shadow:0 12px 40px rgba(15,23,42,.25);min-width:300px;max-width:92vw}\n#tourStartDlg p{margin:0 0 14px;font-weight:700;font-size:15px;line-height:1.45}#tourStartDlg .tsd-btns{display:flex;gap:8px;flex-wrap:wrap}\n#tourStartDlg .tsd-btns button{flex:1;min-height:38px;border-radius:10px;border:1px solid var(--line,#ddd);background:var(--surface,#fff);color:var(--ink);font-weight:700;cursor:pointer;padding:0 14px}\n#tourStartDlg .tsd-btns button[data-tsd=\"first\"]{background:var(--red);border-color:var(--red);color:#fff}\n#tourStartDlg .tsd-x{position:absolute;top:6px;right:8px;border:0;background:none;font-size:18px;color:var(--ink2,#666);cursor:pointer}\n#tourPickTip{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:9000;display:flex;gap:10px;align-items:center;background:var(--ink,#111);color:#fff;border-radius:999px;padding:9px 10px 9px 18px;font-size:13px;font-weight:600;box-shadow:0 6px 24px rgba(15,23,42,.3)}#tourPickTip[hidden]{display:none}\n#tourPickTip button{border:0;border-radius:999px;background:rgba(255,255,255,.18);color:#fff;padding:5px 12px;cursor:pointer;font-weight:700}\nbody.tourpick #board .nd{cursor:crosshair}body.tourpick #board .nd:hover{outline:2px solid var(--red);outline-offset:2px}\n/* v30 하단 창 번호: 줄바꿈 없이 숫자 길이만큼 늘어나는 알약 */\n#tourcap .tc-steps li i{white-space:nowrap!important;width:auto!important;line-height:1!important;padding:0 7px!important;overflow:visible!important}\n#tourcap .tc-no{width:auto!important;min-width:26px;padding:0 7px;box-sizing:border-box;border-radius:13px!important;white-space:nowrap}   /* 제목 번호도 숫자 길이만큼 늘어남 */\n#labels .lmemo .lmx{margin-left:4px;border:0;background:var(--red);color:#fff;border-radius:999px;font-size:9px;line-height:13px;padding:0 5px;cursor:pointer}#labels .lmemo.off{opacity:.55;text-decoration:line-through}#labels .lmemo.off .lmx{text-decoration:none;background:var(--ink2)}\n#labels .lmemo{display:inline-block;margin-top:3px;padding:0 6px;border-radius:999px;border:1px dashed var(--ink3);color:var(--ink2);font-size:9.5px;line-height:15px;font-weight:600}\n#labels .lc.lane .lt > b[contenteditable=\"true\"]{outline:2px solid var(--red);background:#fffaf0;border-radius:3px}   /* 레인이 낮아 이름이 다 안 들어가면 칸 안에서 스크롤 (어절 단위 줄바꿈) */\n.agx-li:empty::before{content:attr(data-ph);color:var(--ink3)}\n<\/style>\n<script>window.__BAKED__ = /*BAKED*/{\"ver\":\"v04\"}/*/BAKED*/;<\/script>\n<\/head>\n<body>\n<header id=\"top\">\n  <div class=\"hero\"><div><div class=\"eyebrow\"><span class=\"dot\"><\/span><span data-edit=\"eyebrow\"><\/span><\/div><h1 data-title data-edit=\"title\"><\/h1><div class=\"crumb\" data-edit=\"crumb\"><\/div><\/div><div class=\"ver\" data-edit=\"ver\"><\/div><div class=\"steps\" id=\"steps\"><\/div><\/div>\n  <div id=\"controls\">\n    <span class=\"navb\"><button type=\"button\" data-nav=\"-1\" title=\"뒤로 (Alt + ←)\" aria-label=\"뒤로\">←<\/button><button type=\"button\" data-nav=\"1\" title=\"앞으로 (Alt + →)\" aria-label=\"앞으로\">→<\/button><\/span>\n    <span class=\"stitle\"><span class=\"dot\"><\/span><span data-title><\/span><\/span>\n    <div class=\"grp\"><span>화면<\/span><div class=\"seg\" id=\"scrSeg\"><button type=\"button\" data-scr=\"asis\">As-Is<\/button><button type=\"button\" data-scr=\"ns\">To-be<\/button><\/div><\/div>\n    <div class=\"grp\"><span>레벨<\/span><div class=\"seg\" id=\"lvSeg\"><button type=\"button\" data-lv=\"4\">Lv.4<\/button><button type=\"button\" data-lv=\"5\">Lv.5<\/button><button type=\"button\" data-lv=\"6\">Lv.6<\/button><\/div><\/div>\n    <div class=\"grp\"><span>단계<\/span><div class=\"seg\" id=\"stSeg\"><button type=\"button\" data-st=\"all\">전체<\/button><button type=\"button\" data-st=\"1\" title=\"과제 이해 / THINK\">1<\/button><button type=\"button\" data-st=\"2\" title=\"아이디어 개발 / MAKE\">2<\/button><button type=\"button\" data-st=\"3\" title=\"제안 · 합의 / SELL\">3<\/button><button type=\"button\" data-st=\"4\" title=\"제작 준비 / Pre-Production\">4<\/button><button type=\"button\" data-st=\"5\" title=\"제작 / Production\">5<\/button><button type=\"button\" data-st=\"6\" title=\"편집 · 고도화 / Post-Production\">6<\/button><button type=\"button\" data-st=\"7\" title=\"전개 · 납품 / Delivery\">7<\/button><\/div><\/div>\n    <div class=\"grp\"><span>보기<\/span><div class=\"seg\" id=\"vwSeg\"><button type=\"button\" data-vw=\"compact\" title=\"촘촘하게 전체를 한눈에\">한눈에<\/button><button type=\"button\" data-vw=\"flow\" title=\"간격을 넓혀 화살표·신호 이름이 모두 보이게\">흐름 (넓게)<\/button><\/div><\/div>\n    <div class=\"grp\"><span>경로<\/span><div class=\"seg pathseg\" id=\"pathSeg\"><button type=\"button\" data-path=\"all\" title=\"촬영·비촬영 모두\">전체<\/button><button type=\"button\" data-path=\"촬영\" class=\"ps-sh\" title=\"공통 업무 + 촬영 업무만\">촬영<\/button><button type=\"button\" data-path=\"비촬영\" class=\"ps-ns\" title=\"공통 업무 + 비촬영 업무만 (기존 소스·포스트·GD 업체)\">비촬영<\/button><\/div><\/div>\n    <button type=\"button\" id=\"btnMap\">▣ Agent 구조도<\/button><button type=\"button\" id=\"btnAx\" title=\"제일기획 AX 과제와 AE Agent 연결\">📋 AX 과제<\/button>\n    <button type=\"button\" id=\"btnPage\">▤ Agent 상세 페이지<\/button>\n    <div class=\"grp\"><span>확대<\/span><div class=\"seg\"><button type=\"button\" id=\"zOut\" aria-label=\"축소\">−<\/button><button type=\"button\" id=\"zv\">100%<\/button><button type=\"button\" id=\"zIn\" aria-label=\"확대\">＋<\/button><button type=\"button\" id=\"zFit\" title=\"가로를 화면에 맞춤 (전체 단계 한눈에)\">맞춤<\/button><\/div><\/div>\n    <span class=\"sp\"><\/span>\n    <button type=\"button\" id=\"btnStory\" aria-pressed=\"true\" title=\"박스에 붙는 흐름 따라가기 번호를 켜고 끔\">🔢 흐름 번호<\/button>\n    <button type=\"button\" id=\"btnTour\" data-tourgo=\"1\" title=\"번호 순서대로 박스를 강조하며 설명 (← → Space · Esc)\">▶ 흐름 따라가기<\/button>\n    <button type=\"button\" id=\"btnPresent\">⛶ 발표 모드<\/button>\n    <button type=\"button\" id=\"btnPlay\">▶ 자동 넘김<\/button>\n    <button type=\"button\" id=\"btnFlow\" aria-pressed=\"false\">▦ 흐름도 편집<\/button>\n    <button type=\"button\" id=\"btnEdit\" aria-pressed=\"false\">✎ 문구 편집<\/button>\n    <button type=\"button\" id=\"btnExport\">⤓ 편집본 저장<\/button>\n    <button type=\"button\" id=\"btnPub\" hidden>이 링크에 반영<\/button>\n    <div id=\"edbar\" hidden><b>흐름도 편집 중<\/b><button type=\"button\" id=\"edAdd\">＋ 박스 추가<\/button><button type=\"button\" id=\"edUndo\">↶ 되돌리기<\/button><button type=\"button\" id=\"edReset\">이 화면 초기화<\/button><span class=\"hint\">박스를 끌어 옮기기 · 박스를 누르면 글자·태그·종류·연결 추가·삭제 · 선을 누르면 연결선 수정(종류·이름표·경로·출발/도착)·삭제 · Ctrl+Z 되돌리기 · 편집본 저장으로 보관<\/span><button type=\"button\" id=\"edDone\">편집 끝내기<\/button><\/div>\n  <\/div>\n  <div id=\"infobox\" class=\"ib-closed\">\n    <button type=\"button\" id=\"ibToggle\" class=\"ib-h\" aria-expanded=\"false\" aria-controls=\"ibBody\" title=\"요약 막대와 범례를 펼치거나 접습니다\"><span class=\"ib-ic\">i<\/span><b>요약 · 범례<\/b><span class=\"ib-sum\" id=\"ibSum\"><\/span><span class=\"ib-tg\">펼치기 ▾<\/span><\/button>\n    <div id=\"ibBody\" class=\"ib-body\"><div id=\"summary\"><\/div><div id=\"legend\"><\/div><\/div>\n  <\/div>\n  <div id=\"tourcap\" hidden><\/div>\n<\/header>\n<section id=\"stageWrap\">\n  <div id=\"slbar\"><span class=\"ptitle\" data-title><\/span><div id=\"pctl\" aria-label=\"발표 모드 조작\"><span class=\"navb\"><button type=\"button\" data-nav=\"-1\" title=\"뒤로 (Alt + ←)\" aria-label=\"뒤로\">←<\/button><button type=\"button\" data-nav=\"1\" title=\"앞으로 (Alt + →)\" aria-label=\"앞으로\">→<\/button><\/span><span class=\"pgl\">레벨<\/span><div class=\"seg\" id=\"pLv\" title=\"L 키: 다음 레벨\"><button type=\"button\" data-lv=\"4\">Lv.4<\/button><button type=\"button\" data-lv=\"5\">Lv.5<\/button><button type=\"button\" data-lv=\"6\">Lv.6<\/button><\/div><span class=\"pgl\">단계<\/span><div class=\"seg\" id=\"pSt\" title=\"숫자 1~7: 그 단계만 · 0: 전체\"><button type=\"button\" data-st=\"all\">전체<\/button><button type=\"button\" data-st=\"1\">1<\/button><button type=\"button\" data-st=\"2\">2<\/button><button type=\"button\" data-st=\"3\">3<\/button><button type=\"button\" data-st=\"4\">4<\/button><button type=\"button\" data-st=\"5\">5<\/button><button type=\"button\" data-st=\"6\">6<\/button><button type=\"button\" data-st=\"7\">7<\/button><\/div><div class=\"seg\" id=\"pVw\" title=\"보기\"><button type=\"button\" data-vw=\"compact\">한눈에<\/button><button type=\"button\" data-vw=\"flow\">흐름<\/button><\/div><div class=\"seg pathseg\" id=\"pPath\" title=\"경로\"><button type=\"button\" data-path=\"all\">전체<\/button><button type=\"button\" data-path=\"촬영\" class=\"ps-sh\">촬영<\/button><button type=\"button\" data-path=\"비촬영\" class=\"ps-ns\">비촬영<\/button><\/div><div class=\"seg\" id=\"pZm\"><button type=\"button\" data-pz=\"-1\" title=\"축소 (−)\" aria-label=\"축소\">−<\/button><button type=\"button\" data-pz=\"0\" id=\"pzv\" title=\"100%로\">100%<\/button><button type=\"button\" data-pz=\"1\" title=\"확대 (+)\" aria-label=\"확대\">＋<\/button><button type=\"button\" data-pz=\"fit\" title=\"가로를 화면에 맞춤\">맞춤<\/button><\/div><button type=\"button\" class=\"pbtn\" data-px=\"#btnPlay\" title=\"As-Is ↔ To-be 자동 넘김\">▶ 자동<\/button><button type=\"button\" class=\"pbtn\" data-px=\"#btnMap\">▣ 구조도<\/button><button type=\"button\" class=\"pbtn\" data-px=\"#btnPage\">▤ Agent 페이지<\/button><button type=\"button\" class=\"pbtn\" id=\"pFull\" hidden>⛶ 전체 화면<\/button><\/div><span id=\"sllab\"><\/span><div id=\"sldots\"><button type=\"button\" data-scr=\"asis\">As-Is<\/button><i aria-hidden=\"true\"><\/i><button type=\"button\" data-scr=\"ns\">To-be<\/button><\/div><span><span class=\"slhint\">← → 키 또는 양옆 버튼: 같은 화면에서 박스가 As-Is ↔ To-be 자리로 이동<\/span> <button type=\"button\" id=\"btnExitPresent\">발표 모드 끝내기<\/button><\/span><\/div>\n  <main id=\"wrap\"><div id=\"inner\"><div id=\"corner\"><\/div><div id=\"stagehead\"><\/div><div id=\"labels\"><\/div><div id=\"boardwrap\"><div id=\"board\"><svg id=\"edges\" aria-hidden=\"true\"><\/svg><\/div><\/div><\/div><\/main>\n  <button type=\"button\" id=\"slPrev\" class=\"slnav prev\" aria-label=\"이전: As-Is\">‹<\/button>\n  <button type=\"button\" id=\"slNext\" class=\"slnav next\" aria-label=\"다음: To-be\">›<\/button>\n<\/section>\n<footer id=\"foot\" data-edit=\"foot\"><\/footer>\n<aside id=\"panel\" hidden><\/aside>\n<div id=\"amap\" hidden><\/div>\n<div id=\"axw\" hidden><\/div>\n<div id=\"apage\" hidden><\/div>\n<div id=\"toast\" role=\"status\" aria-live=\"polite\"><\/div>\n<script id=\"pm-data\">/*__DATA__*/<\/script>\n<script id=\"pm-engine\">/*__ENGINE__*/<\/script>\n<\/body>\n<\/html>\n";
const D = window.__PMD__;
const U = Object.assign({srcShort:'원본', src:'Process Map', adv:'고객 접점', orcName:'단계 연계 Agent', orcBasis:'기준선(산출물·일정·비용·회차)', s0bSee:'관련 담당자가 동일한 현황을 확인합니다.', file:'As-Is_To-be_프로세스맵', tagEg:'담당 확인', sysHint:'문서 도구·편집 툴·일반 웹사이트처럼 사람이 직접 쓰는 도구는 빼고, Agent가 API로 연동하는 시스템만 적었습니다.', sublLegend:'', otName:'타 부문', lv4:'Lv.4', lv4btn:'Lv.4'}, D.ui || {});
const PATHS = D.paths || [], SUBL0 = D.subl || [];
const BK = (window.__BAKED__ && typeof window.__BAKED__ === 'object') ? window.__BAKED__ : {ver:'v02'};
let ED = (BK.ed && typeof BK.ed === 'object') ? BK.ed : {}, UNDO = {};
let STX = Object.assign({}, BK.story || {});
const STORY0 = JSON.parse(JSON.stringify(STORY));
function stApply(){ Object.keys(STX).forEach(k => { const p = k.split('|'), st = STORY[p[0]]; if (!st) return; const v = STX[k];
  if (p.length === 2){ st[p[1]] = v; return; } const b = st.beats[+p[1]]; if (!b) return; if (p[2] === 't'){ b.t = v; return; }
  const s = b.steps[+p[2]]; if (!s) return; if (p[3] === 'a' && !v) delete s.a; else s[p[3]] = v; }); }
stApply();
/* ===== 세부 Agent 표 편집: 표의 원본 칸을 고치면 위쪽 Agent 구조도·한눈에 보기·데이터 표에 반영, 편집본 저장에 함께 담김 ===== */
let AGX = (BK.ag && typeof BK.ag === 'object') ? JSON.parse(JSON.stringify(BK.ag)) : {};
['subs', 'story', 'when', 'dfmt', 'sysinfo'].forEach(k => { AGX[k] = AGX[k] || {}; });
let AGE = false;
const AG0 = {}, AGF = ['desc', 'd', 'dg', 's', 'sp', 'of', 'og', 'xw', 'xi', 'xf'];
const agClone = o => JSON.parse(JSON.stringify(o === undefined ? null : o));
function agStoryOf(sid){ const b = (D.bands || []).find(x => x.subs.indexOf(sid) >= 0); if (!b) return null; D.story = D.story || {}; const s = D.story[b.id] || (D.story[b.id] = {subs:{}, imp:[], hum:'', p:''}); s.subs = s.subs || {}; return s.subs[sid] || (s.subs[sid] = {f:[], pn:[], e:''}); }
function agSync(sid){ const s = D.subs[sid]; if (!s || !s.of) return; D.outs = D.outs || {}; D.outs[sid] = s.of.map(x => [x[0], (x[1] || [])[0] || '']); }
(function agApply(){
  Object.keys(D.subs).forEach(sid => { const s = D.subs[sid], st = agStoryOf(sid) || {}; AG0[sid] = agClone({sub:AGF.reduce((o, k) => (o[k] = s[k], o), {}), st:{f:st.f || [], pn:st.pn || [], e:st.e || ''}}); });
  Object.keys(AGX.subs).forEach(sid => { const s = D.subs[sid]; if (!s) return; AGF.forEach(k => { if (AGX.subs[sid][k] !== undefined && AGX.subs[sid][k] !== null) s[k] = agClone(AGX.subs[sid][k]); }); agSync(sid); });
  Object.keys(AGX.story).forEach(sid => { const st = agStoryOf(sid); if (!st) return; ['f', 'pn', 'e'].forEach(k => { if (AGX.story[sid][k] !== undefined) st[k] = agClone(AGX.story[sid][k]); }); });
  ['when', 'dfmt', 'sysinfo'].forEach(k => { D[k] = D[k] || {}; Object.assign(D[k], AGX[k]); });
})();
const agQ = v => String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
const agTx = el => (el ? (el.value !== undefined && el.tagName !== 'DIV' && el.tagName !== 'SPAN' ? el.value : el.innerText) : '').replace(/\s+/g, ' ').trim();
const AGAUTO = ['소속 · 활동 단계', '작동 시점', '사람이 확인하는 지점', '대체하는 As-Is 업무'];
const AGNOTE = '<tr class="agx-note"><td colspan="2"><b>✎ 편집 중</b> 흰 칸을 수정하면 위쪽 Agent 구조도 · 한눈에 보기 · 필요 데이터 표에 반영됩니다. 점선 제목(큰 기능·세부 Agent 이름)을 수정하면 메인 맵·구조도·설명 문장에도 반영됩니다. 회색 "지도 기준 자동" 칸은 프로세스 맵에서 계산되는 값으로 여기서 수정하지 않습니다. 수정을 마친 뒤 위의 <b>⤓ 현재 버전 저장</b>을 누르세요.</td></tr>';
const AGST = [['E', '기존'], ['P', '준비중'], ['N', '신규 설치 필요']];
function agEdited(sid){ return !!(AGX.subs[sid] || AGX.story[sid]); }
function agTxt(sid, k, v){ return '<div class="agx-t" contenteditable="true" data-agx-ed data-agx-sid="' + sid + '" data-agx-k="' + k + '">' + esc(v || '') + '</div>'; }
function agList(sid, k, arr){
  return '<ol class="agx-l" data-agx-list="' + k + '" data-agx-sid="' + sid + '">' + (arr || []).map((q, i) => '<li><span class="agx-li" contenteditable="true" data-agx-ed data-agx-i="' + i + '">' + esc(q[0]) + '</span><button type="button" class="agx-x" data-agx="del" data-agx-sid="' + sid + '" data-agx-k="' + k + '" data-agx-i="' + i + '" title="이 줄 삭제">×</button></li>').join('') + '</ol><button type="button" class="agx-add" data-agx="add" data-agx-sid="' + sid + '" data-agx-k="' + k + '">＋ 줄 추가</button>';
}
function agGrpOf(G, n){ const g = (G || []).find(x => x[1].indexOf(n) >= 0); return g ? g[0] : ''; }
function agDL(id, G){ return '<datalist id="' + id + '">' + (G || []).map(g => '<option value="' + agQ(g[0]) + '"></option>').join('') + '</datalist>'; }
function agItems(sid, k){
  const s = D.subs[sid], arr = s[k] || [], gk = k === 'd' ? 'dg' : 'sp', dl = 'agxdl-' + sid + '-' + k, isD = k === 'd';
  return agDL(dl, s[gk]) + '<div class="agx-tw"><table class="agx-tb"><thead><tr><th>' + (isD ? '데이터' : '시스템') + '</th><th>상태</th><th>묶음' + (isD ? '' : ' (목적)') + '</th>' + (isD ? '<th>형식 (여러 개는 ; 로 구분)</th>' : '') + '<th>근거 메모</th><th></th></tr></thead><tbody data-agx-tb="' + k + '" data-agx-sid="' + sid + '">' +
    arr.map((x, i) => '<tr data-agx-i="' + i + '"><td><div class="agx-c one" contenteditable="true" data-agx-ed data-agx-f="n">' + esc(x[0]) + '</div></td><td><select data-agx-ed data-agx-f="st">' + AGST.map(([v, l]) => '<option value="' + v + '"' + (st3(x) === v ? ' selected' : '') + '>' + l + '</option>').join('') + '</select>' + (st3(x) === 'P' ? '<input class="agx-who" data-agx-ed data-agx-f="who" list="ae-dl-who" value="' + agQ(x[4] || '') + '" placeholder="준비 주체 (누가·무엇을)">' : '') + '</td><td><input data-agx-ed data-agx-f="g" list="' + dl + '" value="' + agQ(agGrpOf(s[gk], x[0])) + '" placeholder="묶음 이름"></td>' + (isD ? '<td><input data-agx-ed data-agx-f="fm" value="' + agQ((x[5] || []).join(' ; ')) + '" placeholder="예: Excel 표 ; DB 기록"></td>' : '') + '<td><input data-agx-ed data-agx-f="note" value="' + agQ(x[3] || '') + '"></td><td><button type="button" class="agx-x" data-agx="del" data-agx-sid="' + sid + '" data-agx-k="' + k + '" data-agx-i="' + i + '" title="삭제">×</button></td></tr>').join('') +
    '</tbody></table></div><button type="button" class="agx-add" data-agx="add" data-agx-sid="' + sid + '" data-agx-k="' + k + '">＋ ' + (isD ? '데이터' : '시스템') + ' 추가</button>';
}
function agOuts(sid){
  const s = D.subs[sid], arr = s.of || [], dl = 'agxdl-' + sid + '-of';
  return agDL(dl, s.og) + '<div class="agx-tw"><table class="agx-tb"><thead><tr><th>To-be 산출물</th><th>형식 · 세부 (여러 개는 ; 로 구분)</th><th>묶음 (산출 시점)</th><th></th></tr></thead><tbody data-agx-tb="of" data-agx-sid="' + sid + '">' +
    arr.map((x, i) => '<tr data-agx-i="' + i + '"><td><div class="agx-c one" contenteditable="true" data-agx-ed data-agx-f="n">' + esc(x[0]) + '</div></td><td><input data-agx-ed data-agx-f="fm" value="' + agQ((x[1] || []).join(' ; ')) + '"></td><td><input data-agx-ed data-agx-f="g" list="' + dl + '" value="' + agQ(agGrpOf(s.og, x[0])) + '" placeholder="묶음 이름"></td><td><button type="button" class="agx-x" data-agx="del" data-agx-sid="' + sid + '" data-agx-k="of" data-agx-i="' + i + '" title="삭제">×</button></td></tr>').join('') +
    '</tbody></table></div><button type="button" class="agx-add" data-agx="add" data-agx-sid="' + sid + '" data-agx-k="of">＋ 산출물 추가</button>';
}
function agOutView(s, outs){
  const asis = outs.length ? '<details class="agx-asis"><summary>As-Is 아웃풋 참고 (' + outs.length + ')</summary><ul>' + outs.map(o => '<li>' + esc(o) + '</li>').join('') + '</ul></details>' : '';
  if (s.of && s.of.length) return '<ul>' + s.of.map(x => '<li>' + esc(x[0]) + ((x[1] || []).length ? '<span class="who">' + esc(x[1].join(' · ')) + '</span>' : '') + '</li>').join('') + '</ul>' + asis;
  return outs.length ? '<ul>' + outs.slice(0, 6).map(o => '<li>' + esc(o) + '</li>').join('') + '</ul>' : '<span class="none">—</span>';
}
function agSubBar(sid){ return agEdited(sid) ? '<span class="agx-mk">수정됨</span><button type="button" class="agx-rs" data-agx="reset" data-agx-sid="' + sid + '">↺ 원래대로</button>' : ''; }
function agGroups(oldG, pairs){
  if (!pairs.some(p => p[1]) && !(oldG || []).length) return [];
  const had = (oldG || []).length, order = (oldG || []).map(g => g[0]), map = {};
  pairs.forEach(([n, g]) => { const k = g || (had ? '직접 추가' : shortNm(n)); if (!map[k]){ map[k] = []; if (order.indexOf(k) < 0) order.push(k); } map[k].push(n); });
  const og = {}; (oldG || []).forEach(g => { og[g[0]] = g[1]; });
  return order.filter(k => map[k] && map[k].length).map(k => { const ref = og[k] || [], pos = n => { const i = ref.indexOf(n); return i < 0 ? 1e6 : i; }; return [k, map[k].map((n, j) => [n, j]).sort((a, b) => (pos(a[0]) - pos(b[0])) || (a[1] - b[1])).map(x => x[0])]; });
}
function agRename(kind, o, n){ if (!o || o === n) return; const ks = kind === 'd' ? ['when', 'dfmt'] : kind === 's' ? ['when', 'sysinfo'] : []; ks.forEach(k => { if (D[k] && D[k][o] !== undefined && D[k][n] === undefined){ D[k][n] = D[k][o]; AGX[k][n] = D[k][o]; } }); if (kind !== 'of' && D.whenHave && D.whenHave[o] !== undefined && D.whenHave[n] === undefined) D.whenHave[n] = D.whenHave[o]; }
function agRead(sid){
  const s = D.subs[sid], st = agStoryOf(sid), root = $('#apm'); if (!s || !root) return false;
  const sel = q => root.querySelector(q), sa = '[data-agx-sid="' + sid + '"]'; let seen = false;
  const dsc = sel('.agx-t' + sa + '[data-agx-k="desc"]'); if (dsc){ s.desc = agTx(dsc); seen = true; }
  const ev = sel('.agx-t' + sa + '[data-agx-k="e"]'); if (ev && st){ st.e = agTx(ev); seen = true; }
  ['f', 'pn'].forEach(k => { const ol = sel('ol[data-agx-list="' + k + '"]' + sa); if (!ol || !st) return; seen = true; const old = st[k] || [];
    st[k] = Array.from(ol.querySelectorAll('.agx-li')).map(sp => { const i = sp.dataset.agxI, prev = (i !== 'n' && old[+i]) || ['', []]; return [agTx(sp), prev[1] || []]; }).filter(q => q[0]); });
  ['d', 's', 'of'].forEach(k => { const tb = sel('tbody[data-agx-tb="' + k + '"]' + sa); if (!tb) return; seen = true; const old = s[k] || [], gk = k === 'd' ? 'dg' : k === 's' ? 'sp' : 'og', pairs = [];
    const items = Array.from(tb.querySelectorAll('tr[data-agx-i]')).map(tr => { const f = n => tr.querySelector('[data-agx-f="' + n + '"]'), i = tr.dataset.agxI, prev = (i !== 'n' && old[+i]) ? agClone(old[+i]) : null, nm_ = agTx(f('n'));
      if (!nm_) return null; if (prev) agRename(k, prev[0], nm_);
      if (k === 'of'){ const x = prev || ['', []]; x[0] = nm_; x[1] = agTx(f('fm')).split(/\s*;\s*/).filter(Boolean); pairs.push([nm_, agTx(f('g'))]); return x; }
      const x = prev || (k === 'd' ? ['', 0, 'N', '', '', []] : ['', 0, 'N', '', '']), stv = f('st').value;
      x[0] = nm_; x[1] = stv === 'E' ? 1 : 0; x[2] = stv; x[3] = agTx(f('note')); while (x.length < 5) x.push(''); x[4] = stv === 'P' ? (f('who') ? agTx(f('who')) : (x[4] || '')) : ''; if (k === 'd') x[5] = agTx(f('fm')).split(/\s*;\s*/).filter(Boolean);
      pairs.push([nm_, agTx(f('g'))]); return x; }).filter(Boolean);
    s[k] = items; s[gk] = agGroups(s[gk], pairs); });
  if (seen) agRec(sid);
  return seen;
}
function agRec(sid){
  const s = D.subs[sid], st = agStoryOf(sid) || {};
  const now = agClone({sub:AGF.reduce((o, k) => (o[k] = s[k], o), {}), st:{f:st.f || [], pn:st.pn || [], e:st.e || ''}});
  if (JSON.stringify(now) === JSON.stringify(AG0[sid])){ delete AGX.subs[sid]; delete AGX.story[sid]; }
  else { AGX.subs[sid] = now.sub; AGX.story[sid] = now.st; DIRTY = true; }
  agSync(sid);
}
function agFlushAll(){ if (!AGE || $('#apage').hidden) return; Object.keys(D.subs).forEach(agRead); preRead(); }
/* v38 선행 요건 — 큰 기능 Agent별 (design story.pre). 세부 Agent 표 편집 중에는 줄 단위로 고치며 AGX.pre에 담겨 편집본 저장에 포함 */
function preList(bid){ const x = (AGX.pre || {})[bid]; return Array.isArray(x) ? x : (((D.story || {})[bid] || {}).pre || []); }
function preHTML(b){ const L = preList(b.id); if (!L.length && !AGE) return '';
  const body = AGE ? '<ol class="agx-l" data-agx-pre="' + b.id + '">' + L.map(x => '<li><span class="agx-li" contenteditable="true" data-agx-ed>' + esc(x) + '</span></li>').join('') + '<li><span class="agx-li" contenteditable="true" data-agx-ed data-ph="＋ 선행 요건 추가"></span></li></ol>'
    : '<ul class="ls">' + L.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>';
  return '<section class="v38-pre"><h3>' + h3i(IC.flag) + '선행 요건 — 이 Agent가 동작하려면 먼저 갖춰야 할 것</h3><div class="panelcard">' + body + '</div></section>'; }
function preRead(){ const ol = $('#apm ol[data-agx-pre]'); if (!ol) return; AGX.pre = AGX.pre || {}; const v = Array.from(ol.querySelectorAll('.agx-li')).map(agTx).filter(Boolean), d0 = ((D.story || {})[ol.dataset.agxPre] || {}).pre || [];
  if (JSON.stringify(v) === JSON.stringify(d0)) delete AGX.pre[ol.dataset.agxPre]; else AGX.pre[ol.dataset.agxPre] = v; DIRTY = true; }
function agRerender(){ const m = $('#apm'), top = m ? m.scrollTop : 0; agentPage(S.page); const m2 = $('#apm'); if (m2) m2.scrollTop = top; }
let agT = null;
function agSched(){ clearTimeout(agT); agT = setTimeout(() => { const a = document.activeElement; if (a && a.closest && a.closest('#apm [data-agx-ed]')) return; agRerender(); }, 250); }
document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('[data-agx]'); if (!b || $('#apage').hidden) return;
  const act = b.dataset.agx, sid = b.dataset.agxSid, k = b.dataset.agxK;
  if (act === 'mode'){ agFlushAll(); AGE = !AGE; agRerender(); toast(AGE ? '내용 편집: 항목에 마우스를 올리면 ✎ 고치기 · × 지우기, 점선 문장은 바로 고치기 · 세부 Agent 줄은 그 Agent만, 합친 표·요약은 이 큰 기능 Agent 전체에 반영 · 비우면 없어짐' : '내용 편집을 껐습니다'); if (AGE){ const f = $('#apm .prof.agx-on'); if (f) f.scrollIntoView({block:'center'}); } return; }
  if (act === 'save'){ agFlushAll(); doExport(); return; }
  if (act === 'reset' && sid && AG0[sid]){ const o = agClone(AG0[sid]), s = D.subs[sid], st = agStoryOf(sid); AGF.forEach(f => { s[f] = o.sub[f]; }); if (st){ st.f = o.st.f; st.pn = o.st.pn; st.e = o.st.e; } delete AGX.subs[sid]; delete AGX.story[sid]; agSync(sid); DIRTY = true; agRerender(); toast('이 세부 Agent를 원래 내용으로 되돌렸습니다'); return; }
  if ((act === 'add' || act === 'del') && sid){ agRead(sid); const s = D.subs[sid], st = agStoryOf(sid);
    if (k === 'f' || k === 'pn'){ const a = st[k] = st[k] || []; if (act === 'add') a.push(['새 항목', []]); else a.splice(+b.dataset.agxI, 1); }
    else { const a = s[k] = s[k] || []; if (act === 'add') a.push(k === 'of' ? ['새 산출물', []] : k === 'd' ? ['새 데이터', 0, 'N', 'To-be 설계 가설 (수기 추가)', '', []] : ['새 시스템', 0, 'N', 'To-be 설계 가설 (수기 추가)', '']);
      else { const gone = a.splice(+b.dataset.agxI, 1)[0], gk = k === 'd' ? 'dg' : k === 's' ? 'sp' : 'og'; if (gone && s[gk]) s[gk] = s[gk].map(g => [g[0], g[1].filter(n => n !== gone[0])]).filter(g => g[1].length); }
      if (act === 'add'){ const gk = k === 'd' ? 'dg' : k === 's' ? 'sp' : 'og'; if ((s[gk] || []).length) s[gk] = agGroups(s[gk], a.map(x => [x[0], agGrpOf(s[gk], x[0])])); } }
    agRec(sid); DIRTY = true; agRerender(); return; }
});
document.addEventListener('focusout', e => { const t = e.target; if (!t.closest || !t.closest('#apm [data-agx-ed]')) return; const w = t.closest('[data-agx-sid]'); const sid = w && w.dataset.agxSid; if (sid && agRead(sid)) agSched(); });
document.addEventListener('change', e => { const t = e.target; if (!t.closest || !t.closest('#apm [data-agx-ed]')) return; const w = t.closest('[data-agx-sid]'); const sid = w && w.dataset.agxSid; if (sid && agRead(sid)) agSched(); });
document.addEventListener('keydown', e => { const t = e.target; if (e.key === 'Enter' && t.closest && t.closest('#apm .one, #apm .agx-li, #apm .agx-tb input')){ e.preventDefault(); t.blur(); } }, true);

let TXT = Object.assign({}, BK.text || {}), DIRTY = false, ART = null, DLP = Promise.resolve(null), playT = null;
const $ = (s, r) => (r || document).querySelector(s), $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const SVGNS = 'http://www.w3.org/2000/svg';
const board = $('#board'), labels = $('#labels'), head = $('#stagehead'), svg = $('#edges'), inner = $('#inner'), wrap = $('#wrap');
const S = {scen:{}, scr:(BK.view && BK.view.scr) || D.start.scr, lv:(BK.view && BK.view.lv) || D.start.lv, stages:new Set(D.stages.map(s => s.n)), zoom:1, edit:false, hl:null, M:null, view:'compact'};
const NODE_EL = {};
const IC = {
 person:'<svg viewBox="0 0 16 16"><circle cx="8" cy="5.3" r="2.6"/><path d="M3.2 13.6c.7-2.5 2.6-3.9 4.8-3.9s4.1 1.4 4.8 3.9"/></svg>',
 check:'<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="5.8"/><path d="M5.4 8.2l1.8 1.8 3.4-3.7"/></svg>',
 spark:'<svg viewBox="0 0 16 16"><path d="M8 1.8l1.5 3.9 3.9 1.5-3.9 1.5L8 12.6 6.5 8.7 2.6 7.2l3.9-1.5z"/><path d="M12.6 11.2l.6 1.5 1.5.6-1.5.6-.6 1.5-.6-1.5-1.5-.6 1.5-.6z"/></svg>',
 plus:'<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="5.8"/><path d="M8 5.2v5.6M5.2 8h5.6"/></svg>',
 cross:'<svg viewBox="0 0 16 16"><path d="M4.5 4.5l7 7M11.5 4.5l-7 7"/></svg>',
 diamond:'<svg viewBox="0 0 16 16"><path d="M8 2.2l5.8 5.8L8 13.8 2.2 8z"/><circle cx="8" cy="8" r="1.4"/></svg>',
 layers:'<svg viewBox="0 0 16 16"><path d="M8 2.2l5.8 3.1L8 8.4 2.2 5.3z"/><path d="M2.2 8.2L8 11.3l5.8-3.1"/><path d="M2.2 11L8 14.1l5.8-3.1"/></svg>',
 flow:'<svg viewBox="0 0 16 16"><rect x="1.8" y="2.4" width="5" height="3.6" rx="1"/><rect x="9.2" y="10" width="5" height="3.6" rx="1"/><path d="M4.3 6v3.2c0 .9.7 1.6 1.6 1.6h3.3"/></svg>',
 flag:'<svg viewBox="0 0 16 16"><path d="M3.5 14V2.5"/><path d="M3.5 3h8.2l-1.8 2.8 1.8 2.8H3.5"/></svg>',
 gear:'<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="2.3"/><path d="M8 1.8v2M8 12.2v2M1.8 8h2M12.2 8h2M3.6 3.6l1.4 1.4M11 11l1.4 1.4M3.6 12.4L5 11M11 5l1.4-1.4"/></svg>',
 target:'<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="5.8"/><circle cx="8" cy="8" r="2.6"/></svg>',
 trend:'<svg viewBox="0 0 16 16"><path d="M2.5 11.5l4-4 2.5 2.5 4.5-5"/><path d="M10 5h3.5v3.5"/></svg>',
 out:'<svg viewBox="0 0 16 16"><path d="M3 8h9"/><path d="M9 4.5L12.5 8 9 11.5"/><path d="M3 3v10"/></svg>',
 info:'<svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="5.8"/><path d="M8 7.2v3.6"/><path d="M8 5.1v.1"/></svg>',
 db:'<svg viewBox="0 0 16 16"><ellipse cx="8" cy="3.8" rx="5" ry="1.9"/><path d="M3 3.8v8.4c0 1 2.2 1.9 5 1.9s5-.9 5-1.9V3.8M3 8c0 1 2.2 1.9 5 1.9s5-.9 5-1.9"/></svg>'
};
const KIC = {h:IC.person, nh:IC.check, a:IC.spark, na:IC.plus, gone:IC.cross, mk:IC.diamond, adv:IC.person, pt:IC.spark, why:IC.info};
function h3i(s){ return '<span class="ic h3i">' + s + '</span>'; }
const KIND = {h:'사람 (잔존)', nh:'담당자 확인', a:'Agent 대체', na:'Agent (신규)', adv:U.adv + ' (신규)', ot:U.otName, gone:'소멸 (흡수)', mk:'Orchestrator 표시', pt:'Agent 참여 (이 Lv5의 일부 업무)', why:'소멸 이유'};
const TYPE6 = {A:'Agent 대체', N:'담당자 확인 (사람 레인)', H:'잔존 (사람)', X:'소멸 (흡수)', ADV:U.adv + ' (신규, As-Is 없음)', O:U.otName + ' To-be', M:'Orchestrator 표시 (신규)'};
function esc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function br(s){ return esc(s).replace(/\n/g, '<br>'); }
function tk(id){ return S.scr + '|' + S.lv + '|' + id; }
function T(k, d){ return TXT[k] != null ? TXT[k] : d; }
/* 읽기 쉬운 문구: 가운뎃점(·)으로 이어 붙인 말을 '와/과'와 쉼표로 풀어 씀 (원본 엑셀 문구는 그대로 두고 화면에서만) */
function josaWa(w){
  const s = String(w || '').replace(/[\s)\]」』'"’”]+$/, ''), ch = s.slice(-1); if (!ch) return '와'; const c = ch.charCodeAt(0);
  if (c >= 0xAC00 && c <= 0xD7A3) return ((c - 0xAC00) % 28) ? '과' : '와';
  if (/[LMNRlmnr]/.test(ch) || /[136780]/.test(ch)) return '과'; return '와';
}
function rd(s){
  s = String(s == null ? '' : s); return s;   /* ui_fixes v19 */ // '·'는 원문 그대로 (조직명·업무명을 바꾸지 않음)
  if (s.indexOf('·') < 0) return s;
  s = s.replace(/\s+·\s+/g, ', ');
  s = s.replace(/\(([^()]*)\)/g, (m, inner) => '(' + inner.replace(/\s*·\s*/g, ', ') + ')');
  s = s.replace(/[^\s,()·\[\]/]+(?:\s*·\s*[^\s,()·\[\]/]+)+/g, m => { const p = m.split(/\s*·\s*/); return p.length === 2 ? p[0] + josaWa(p[0]) + ' ' + p[1] : p.slice(0, -1).join(', ') + ', ' + p[p.length - 1]; });
  return s.replace(/\s*·\s*/g, ', ');
}
function rdTree(root){
  if (!root) return; const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), L = []; while (w.nextNode()) L.push(w.currentNode);
  L.forEach(x => { if (x.nodeValue.indexOf('·') < 0) return; const pe = x.parentElement; if (pe && pe.closest('input, textarea, [contenteditable="true"], .keepdot')) return; x.nodeValue = rd(x.nodeValue); });
}
function plain(h){ const d = document.createElement('div'); d.innerHTML = h; return d.textContent; }
function view(){ return D.views[S.lv][S.scr]; }
const ST3 = {E:['h', '기존'], P:['p', '준비중'], N:['n', '신규 설치 필요']};
const st3 = x => x[2] || (x[1] ? 'E' : 'N'), stNote = x => x[3] || '', st3Groups = arr => ['E', 'P', 'N'].map(k => [k, arr.filter(x => st3(x) === k)]);
const stTag = (x, short) => { const k = st3(x); return '<span class="rk ' + ST3[k][0] + '"' + (stNote(x) ? ' title="' + esc(stNote(x)) + '"' : '') + '>' + (short && k === 'N' ? '신규' : ST3[k][1]) + '</span>'; };
const stNoteHTML = x => stNote(x) ? '<small class="stn ' + ST3[st3(x)][0] + '">' + esc(stNote(x)) + '</small>' : '';
const stWho = x => st3(x) === 'P' ? (x[4] || stNote(x)) : '';
const nmP = x => { const [c, det] = cleanNm(x[0]); return '<span' + (det.length ? ' title="' + esc(det.join(' · ')) + '"' : '') + '>' + esc(c) + '</span>' + (stWho(x) ? ' <span class="prw">(' + esc(stWho(x)) + ')</span>' : ''); };
function chip(x, kind){ const k = st3(x); return '<i class="cp ' + kind + ' ' + ST3[k][0] + '" title="' + esc((kind === 's' ? '시스템 · ' : '데이터 · ') + ST3[k][1] + ' · ' + x[0] + (stNote(x) ? ' — ' + stNote(x) : '')) + '">' + (kind === 's' ? '⚙ ' : '') + esc(x[0]) + '</i>'; }
function chipsHTML(o, max){
  const f = (arr, k) => arr.filter(x => st3(x) === k), q = {dh:f(o.d, 'E'), dp:f(o.d, 'P'), dn:f(o.d, 'N'), sh:f(o.s, 'E'), sp:f(o.s, 'P'), sn:f(o.s, 'N')}, pick = [];
  for (let i = 0; pick.length < max && i < 20; i++) [['dh','d'],['dp','d'],['dn','d'],['sh','s'],['sp','s'],['sn','s']].forEach(([k, kind]) => { if (pick.length < max && q[k][i]) pick.push([q[k][i], kind]); });
  pick.sort((a, b) => (a[1] === b[1] ? ('EPN'.indexOf(st3(a[0])) - 'EPN'.indexOf(st3(b[0]))) : (a[1] === 'd' ? -1 : 1)));
  const more = o.d.length + o.s.length - pick.length;
  if (max < 0) return pick.length;
  return '<span class="chips">' + pick.map(x => chip(x[0], x[1])).join('') + (more > 0 && !chipsHTML.noMore ? '<i class="cp more">+' + more + '</i>' : '') + '</span>';
}


function agentDS(o, maxHave){
  // 데이터·시스템마다 '기존' · '준비중' · '신규' 행으로 나눠서 표시
  const line = (arr, kind, label) => { const rows = st3Groups(arr).map(([k, xs]) => { if (!xs.length) return ''; const hv = k === 'E' ? xs.slice(0, maxHave) : xs, more = xs.length - hv.length;
      return '<div class="scr ' + ST3[k][0] + '"><span class="rk ' + ST3[k][0] + '">' + (k === 'N' ? '신규' : ST3[k][1]) + '</span>' + hv.map(x => chip(x, kind)).join('') + (more > 0 ? '<i class="cp more" title="' + esc(xs.slice(hv.length).map(x => x[0]).join(', ')) + '">+' + more + '</i>' : '') + '</div>'; }).join('');
    return '<div class="scg"><span class="sct">' + label + '</span><div class="scl">' + (rows || '<span class="none">해당 없음</span>') + '</div></div>'; };
  return line(o.d, 'd', '데이터') + line(o.s, 's', '시스템');
}
function subCard(s){ return '<b>' + esc(s.name) + '</b><span class="scd">' + esc(s.desc) + '</span>' + agentDS(s, 5); }
const CARD_H = {};


const RIB = 52;
const GT = 28;  // 지도 안 세부 Agent 묶음 박스의 제목 줄 높이
const CMP = {4:{colW:196, nodeW:168, pad:8, vg:10, gap:24, minH:40, SP:7, sg:12, sv:12}, 5:{colW:142, nodeW:118, pad:8, vg:10, gap:22, minH:40, SP:7, sg:12, sv:12}, 6:{colW:134, nodeW:112, pad:8, vg:10, gap:22, minH:38, SP:7, sg:12, sv:12}};
const CMPF = {4:{colW:300, nodeW:228, pad:16, vg:16, gap:60, minH:56}, 5:{colW:206, nodeW:132, pad:16, vg:16, gap:60, minH:56}, 6:{colW:184, nodeW:118, pad:16, vg:16, gap:60, minH:54}};
const HCACHE = {}, TCACHE = {};
function hkey(n, w){ return S.lv + '|' + (S.view === 'flow' ? 'f' : 'c') + '|' + w + '|' + n.k + '|' + n.id + '|' + (n.tg || '') + '|' + (TXT[tk(n.id)] || '') + '|' + (n.lb || ''); }
function measureH(list, w){
  const need = list.filter(n => HCACHE[hkey(n, w)] == null);
  if (need.length){
    const box = document.createElement('div'); box.style.cssText = 'position:absolute;left:0;top:0;width:0;height:0;overflow:visible;visibility:hidden;pointer-events:none';
    box.innerHTML = need.map(n => '<div class="nd k-' + n.k + ' L' + S.lv + '" style="position:absolute;left:0;top:0;width:' + w + 'px;height:auto;transition:none">' + nodeHTML(n) + '</div>').join('');
    board.appendChild(box); Array.from(box.children).forEach((el, k) => { HCACHE[hkey(need[k], w)] = Math.ceil(el.offsetHeight) + 1; }); box.remove();
  }
  const out = {}; list.forEach(n => { out[n.id] = Math.max(30, HCACHE[hkey(n, w)] || 44); }); return hTier(out, list, w);
}
function titleH(cls, html, w){
  const k = cls + '|' + w + '|' + html; if (TCACHE[k] != null) return TCACHE[k];
  const el = document.createElement('div'); el.className = 'gbox ' + cls; el.style.cssText = 'position:absolute;left:0;top:0;visibility:hidden;width:' + w + 'px;height:auto';
  el.innerHTML = '<div class="gt" style="position:relative;left:0;top:0;width:' + Math.max(20, w - 21) + 'px">' + html + '</div>'; board.appendChild(el); const h = Math.ceil(el.firstChild.offsetHeight) + 9; el.remove(); return (TCACHE[k] = h);
}
const subTitle = sid => '<b>' + esc(D.subs[sid].name) + '</b>';
const bandTitle = b => '<span class="ic gi">' + IC.layers + '</span><b>' + esc(b.name) + '</b>';
// 병렬 줄(Line): 촬영 / 공통 / 비촬영 세 줄만 (촬영 위 · 공통 가운데 · 비촬영 아래).
// 영상·이미지는 따로 줄을 만들지 않고, 같은 줄 안에서 위(영상)·아래(이미지) 갈래로 갈라졌다가 그 줄의 다음 업무로 다시 합쳐진다
const LINE = D.lines ? D.lines : [PATHS[0] ? PATHS[0].v : '\u0001p0', '', PATHS[1] ? PATHS[1].v : '\u0001p1'], SUBL = D.sublines ? D.sublines : [SUBL0[0] || '\u0001s0', '', SUBL0[1] || '\u0001s1'];
const LMODE = U.lineMode || 'lines', SCEN = Object.fromEntries(Object.entries(D.scen || {}).map(([k, v]) => [+k, v]));
const trParts = n => ((n && n.tr) || '').split('·');
const scenLabel = x => x.l + (x.s ? ' · ' + x.s : '');
const scenOK = n => { if (!n) return true; const sel = S.scen[n.st]; if (!sel) return true; const [l, s] = trParts(n); const ls = (SCEN[n.st] || []).map(x => x.l); if (!l || ls.indexOf(l) < 0) return true; if (l !== sel.l) return false; return !sel.s || !s || s === sel.s; };
const lineOf = n => { const t = (n && n.tr) || ''; const h = t.split('·')[0]; if (LMODE === 'none') return ''; if (D.lines) return (h && LINE.indexOf(h) >= 0) ? h : ''; return PATHS.some(p => p.v === h) ? h : ''; };
const subOf = n => { const t = (n && n.tr) || ''; if (LMODE === 'none') return ''; if (D.sublines) { const s = t.split('·')[1]; return (s && SUBL.indexOf(s) >= 0) ? s : ''; } return SUBL0.find(x => t.indexOf(x) >= 0) || ''; };
const trkOf = n => lineOf(n) + '~' + subOf(n);
const lineName = l => l || '공통';
// 경로 고르기: 전체 / 촬영 / 비촬영 — 고른 경로의 업무 + 공통 업무만 보임
const pathOK = n => scenOK(n) && (!S.path || S.path === 'all' || !n || !lineOf(n) || lineOf(n) === S.path);
/* ---------- 흐름 설명 v2: 번호(묶음) 안을 '누가 → 무엇을' 단계로 — 색은 박스 종류에서 자동 (Agent 빨강 · 담당자 확인 갈색 · 사람 회색 · Orchestrator 검정) ---------- */
const rich = s => esc(String(s || '')).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
const plainD = s => String(s || '').replace(/\*\*/g, '');
const LNAME = Object.fromEntries(D.lanes.map(l => [l.k, l.who || l.name]));
const KNAME = {ai:'Agent', hitl:'담당자 확인·판단', hu:'사람 직접', orc:'Orchestrator 신호·호출'};
const n6 = id => findNode(6, 'ns', id);
function stepNode(stp){ for (const id of stp.ids){ const n = n6(id); if (n && n.k !== 'gone' && n.k !== 'why' && pathOK(n)) return n; } for (const id of stp.ids){ const n = n6(id); if (n) return n; } return null; }
function stepKind(stp){ const n = stepNode(stp); if (!n) return 'hu'; return n.k === 'mk' ? 'orc' : (n.k === 'a' || n.k === 'na') ? 'ai' : n.k === 'nh' ? 'hitl' : 'hu'; }
function stepWho(stp){ if (stp.a) return stp.a; const n = stepNode(stp); if (!n) return ''; if (n.k === 'mk') return n.ln === 'S0b' ? 'Orchestrator (진행 현황)' : 'Orchestrator'; if (D.subs[n.ln]) return D.subs[n.ln].name; return LNAME[n.ln] || ((D.lanes.find(l => l.k === n.ln) || {}).name) || n.ln; }
function shortWho(stp){ return stepWho(stp).replace(/ Agent$/, '').replace(/^Orchestrator.*/, 'Orchestrator'); }
const pathOKs = x => !x.p || !S.path || S.path === 'all' || x.p === S.path;
const storyOn = () => S.story !== false;
function storyBeats(st){
  const s = STORY[st]; if (!s) return [];
  return s.beats.filter(pathOKs).map(b => Object.assign({}, b, {_bi:s.beats.indexOf(b), _b:b, steps:b.steps.filter(stp => pathOKs(stp) && stp.ids.some(id => { const n = n6(id); return n && pathOK(n); }))})).filter(b => b.steps.length);
}
function chainHTML(b, st, bi, compact){
  return '<span class="chn">' + b.steps.map((stp, k) => (k ? '<s>›</s>' : '') + '<em class="' + stepKind(stp) + '" data-st="' + st + '" data-bi="' + bi + '" data-si="' + k + '" title="' + esc(stepWho(stp) + ' — ' + plainD(stp.d)) + '">' + (compact ? '' : '<u>' + esc(shortWho(stp)) + '</u>' + esc(stp.v)) + '</em>').join('') + '</span>';
}
function storyHTML(st, w){
  const s = STORY[st]; if (!s) return '';
  if (S.scr !== 'ns') return '<div class="sc asis"><p class="sc-now"><b>지금은</b>' + esc(s.now) + '</p><p class="sc-chg"><b>To-be에서는</b>' + esc(s.chg) + '</p></div>';
  const bs = storyBeats(st), narrow = w < 330, wide = w >= 720;
  return '<div class="sc' + (wide ? ' wide' : '') + (narrow ? ' narrow' : '') + '"><p class="sc-chg"><b>바뀌는 점</b>' + esc(s.chg) + '</p><ol class="sc-bt">'
    + bs.map((b, i) => '<li data-st="' + st + '" data-bi="' + i + '" title="누르면 이 번호부터 흐름 따라가기"><i>' + (i + 1) + '</i><b>' + esc(b.t) + '</b>' + chainHTML(b, st, i, narrow) + '</li>').join('')
    + '</ol><p class="sc-nx">→ ' + esc(s.next) + '</p></div>';
}
const STH = {};
function storyH(vis, SW){
  return 0;   // 지도 맨 위 설명 카드 줄은 쓰지 않음 (설명은 흐름 따라가기 창에서)
  if (!storyOn()) return 0; let mx = 0;
  vis.forEach(s => { const w = Math.max(120, SW[s.n] - 10), k = S.scr + '|' + (S.path || 'all') + '|' + s.n + '|' + Math.round(w);
    if (STH[k] == null){ const m = document.createElement('div'); m.className = 'bg story'; m.style.cssText = 'visibility:hidden;left:0;top:0;width:' + w + 'px;height:auto'; m.innerHTML = storyHTML(s.n, w); board.appendChild(m); STH[k] = m.offsetHeight; m.remove(); }
    mx = Math.max(mx, STH[k]); });
  return mx ? Math.max(mx + 18, S.scr === 'ns' ? 200 : 92) : 0;
}
function idAnchor(id, M){
  // 이야기의 업무 ID → 지금 화면(레벨·보기)의 박스
  const n = n6(id); if (n && !pathOK(n)) return null;
  if (M.agentView) return M.blkOf ? M.blkOf[id] || null : null;
  if (S.lv === 6) return M.pos[id] ? id : null;
  if (S.lv === 5){ const tb = D.TB[id], base = tb && tb.l5 ? tb.l5 : id.split('-').slice(0, 2).join('-'), cs = [id]; if (n && n.ln) cs.push(base + '@' + n.ln); cs.push(base);   /* v37: 사람 레인 카드도 */ return cs.find(c => M.pos[c]) || null; }
  return null;
}
const sideOf = k => (k === 'a' || k === 'na' || k === 'mk') ? 'ai' : 'hu';
function lv5Loc(stp, M){
  // Lv.5 박스는 주 수행자 한 명만 보여 줌 → 단계 주체가 그 박스의 주 수행자면 그 박스, 아니면 주체 자리(그 Agent 묶음 · 그 사람 레인)에 점선 박스
  const out = {boxes:[], ghosts:[]};
  stp.ids.forEach(id => { const n = n6(id); if (!n || !pathOK(n) || n.k === 'gone' || n.k === 'why') return; const a5 = idAnchor(id, M); if (!a5) return; const b5 = M.nodes.find(x => x.id === a5); if (!b5) return;
    const ok = sideOf(b5.k) === sideOf(n.k) && (b5.ln === n.ln || (n.k === 'mk' && b5.k === 'mk'));
    if (ok){ if (out.boxes.indexOf(a5) < 0) out.boxes.push(a5); }
    else if (!out.ghosts.some(g => g.ln === n.ln && g.box === a5)) out.ghosts.push({ln:n.ln, box:a5, n, lb:b5.lb}); });
  return out;
}
function ghostRect(g, M, k){
  const bp = M.pos[g.box]; if (!bp) return null; const W = Math.max(bp.w, 104), H = 44, dy = (k || 0) * 50;
  if (D.subs[g.ln]){
    if (!M.flow && M.segs){
      for (const sg of M.segs){ if (sg.st !== g.n.st) continue; const q = sg.subs.find(z => z.sid === g.ln); if (q){ const x1 = q.x0 + (q.sw || W + 12); return {x:Math.max(q.x0 + 6, Math.min(bp.x, x1 - W - 6)), y:q.y0 + (q.ts || 18) + 2 + dy, w:W, h:H}; } }
      const sb = M.segs.find(sg => sg.st === g.n.st && sg.b.subs.indexOf(g.ln) >= 0); if (sb) return {x:sb.x0 + 8, y:sb.y0 + (sb.th || 22) + 2 + dy, w:W, h:H};
      return {x:M.SX[g.n.st] + 8, y:(M.aiTop || 0) + 30 + dy, w:W, h:H};
    }
    const r = M.RY[g.ln]; if (r) return {x:bp.x, y:r.y + (r.off || 0) + 4 + dy, w:W, h:H}; return null;
  }
  const r = M.RY[g.ln]; if (r) return {x:bp.x, y:r.y + 6 + dy, w:W, h:H}; return null;
}
let BOXNO = {map:{}, range:{}};
function computeBoxNo(M){
  // 흐름 번호: 묶음 안 박스마다 화살표 방향(왼쪽→오른쪽, 위→아래) 순서로 번호. 문장은 그 박스들의 번호 범위
  BOXNO = {map:{}, range:{}};
  M.vis.forEach(s => storyBeats(s.n).forEach((b, bi) => {
    const seen = [], per = [];
    b.steps.forEach(stp => { const an = stepAnchors(stp, M).filter(id => M.pos[id] && seen.indexOf(id) < 0 && !BOXNO.map[id] && !isRelId(id)).sort((x, y) => (M.pos[x].x - M.pos[y].x) || (M.pos[x].y - M.pos[y].y)); an.forEach(id => seen.push(id)); per.push(an); });
    let j = 0; const one = seen.length === 1;
    per.forEach((an, si) => { const nos = an.map(id => { j++; const no = s.n + '-' + (bi + 1) + (one ? '' : '-' + j);   /* v38 (실린더): 단계-묶음-순서 3단 번호 */ BOXNO.map[id] = {no, st:s.n, bi, si}; return no; }); if (nos.length) BOXNO.range[s.n + '|' + bi + '|' + si] = [nos[0], nos[nos.length - 1]]; });
  }));
}
function stepAnchors(stp, M){
  if (S.lv === 5 && !M.agentView) return lv5Loc(stp, M).boxes; const out = []; stp.ids.forEach(id => { const k = idAnchor(id, M); if (k && out.indexOf(k) < 0) out.push(k); }); return out; }
function renderStory(M){
  $$('#board .bg.story, #board .sbadge').forEach(e => e.remove());
  const r = M.rows.find(x => x.t === 'story'), f = document.createDocumentFragment();
  if (r) M.vis.forEach(s => { const w = Math.max(120, M.SW[s.n] - 10), el = document.createElement('div'); el.className = 'bg story' + (S.scr === 'ns' ? '' : ' asis'); el.style.left = (M.SX[s.n] - 1) + 'px'; el.style.top = (r.y + 6) + 'px'; el.style.width = w + 'px'; el.style.height = (r.h - 14) + 'px'; el.innerHTML = storyHTML(s.n, w); f.appendChild(el); });
  if (storyOn() && S.scr === 'ns' && (S.lv !== 4 || M.agentView)){
    computeBoxNo(M); const cnt = {}, seen = {}, lv5 = S.lv === 5 && !M.agentView;
    const put = (id, txt, cls, st, bi, si, tip) => { const p = M.pos[id]; if (!p) return; const k = cnt[id] = (cnt[id] || 0) + 1, el = document.createElement('div'); el.className = 'sbadge ' + cls; el.textContent = txt; el.title = tip;
      el.dataset.st = st; el.dataset.bi = bi; el.dataset.si = si; el.style.left = (p.x - 15 + ((k - 1) % 4) * 24) + 'px'; el.style.top = (p.y - 13 + Math.floor((k - 1) / 4) * 18) + 'px'; f.appendChild(el); };
    M.vis.forEach(s => storyBeats(s.n).forEach((b, bi) => b.steps.forEach((stp, si) => {
      const an = stepAnchors(stp, M); if (!an.length) return; const id = an[0], key = id + '|' + s.n + '|' + bi;
      if (M.agentView){ if (seen[key]) return; seen[key] = 1; put(id, String(bi + 1), stepKind(stp), s.n, bi, si, s.n + '단계 ' + (bi + 1) + '. ' + b.t); return; }
      an.forEach(id2 => { const bn = BOXNO.map[id2]; if (!bn || bn.st !== s.n || bn.bi !== bi || bn.si !== si) return; put(id2, bn.no, boxKind(M, id2) || stepKind(stp), s.n, bi, si, s.n + '단계 ' + bn.no + '. ' + stepWho(stp) + ': ' + plainD(stp.d)); }); }))); }
  board.appendChild(f);
}
/* ---------- 흐름 따라가기 v2: 한 단계씩 '누가 → 무엇을' — 앞 단계 박스는 옅게, 지금 단계 박스는 진하게, 둘 사이 화살표 강조 ---------- */
const TOUR = {on:false, list:[], i:0, auto:null};
const RELB = new Set(U.relBands || []);
function isRelId(id){ const t = D.TB[String(id).split('~')[0]]; const sb = t && (t.t === 'A' || t.t === 'M') && D.subs[t.sub]; return !!(RELB.size && sb && RELB.has(sb.band)); }
function tourList(){ const L = []; (S.M ? S.M.vis : []).forEach(s => storyBeats(s.n).forEach((b, bi) => b.steps.forEach((stp, si) => { if (!(RELB.size && (stp.ids || []).length && stp.ids.every(isRelId))) L.push({st:s.n, bi, si, b, stp}); }))); return L; }
function scenChoices(st){ const L = SCEN[st] || [], out = []; const hasCommon = l => L.some(x => x.l === l && !x.s);
  L.forEach(x => { const y = hasCommon(x.l) ? {l:x.l, s:''} : x; if (!out.some(o => o.l === y.l && o.s === y.s)) out.push(y); }); return out; }
function scenAsk(st, then){ const ch = scenChoices(st); if (ch.length < 2){ then(); return; }
  let el = $('#scenask'); if (!el){ el = document.createElement('div'); el.id = 'scenask'; document.body.appendChild(el); }
  const nm = ((D.stages.find(s => s.n === st) || {}).name || '').replace(/^\d+\.\s*/, '');
  el.innerHTML = '<div class="sqbox"><small>' + st + '단계 · ' + esc(nm) + '</small><b>어떤 경우의 흐름을 따라갈까요?</b><div class="sqopts">' + ch.map((x, i) => '<button type="button" data-sq="' + i + '">' + esc(scenLabel(x)) + '</button>').join('') + '</div><button type="button" data-sq="all" class="sqall">구분 없이 전체 보기</button></div>';
  el.hidden = false;
  el.onclick = ev => { const b = ev.target.closest('[data-sq]'); if (!b) return; el.hidden = true; if (b.dataset.sq === 'all') delete S.scen[st]; else S.scen[st] = ch[+b.dataset.sq]; TOUR._asked[st] = true; render(false); setTimeout(then, 450); };
}
function tourStart(st, bi, si){
  TOUR._asked = TOUR._asked || {};
  if (S.scr === 'ns' && S.M){ const st0 = st != null ? +st : ((S.M.vis[0] || {}).n); if (st0 && !TOUR._asked[st0] && !S.scen[st0] && scenChoices(st0).length > 1){ scenAsk(st0, () => tourStart(st, bi, si)); return; } }
  if (S.scr !== 'ns'){ S.scr = 'ns'; render(true); setTimeout(() => tourStart(st, bi, si), (MT + 0.8) * 1000); return; }
  if (!storyOn()){ S.story = true; render(false); }
  TOUR.list = tourList(); if (!TOUR.list.length) return; TOUR.on = true;
  TOUR.i = st != null ? Math.max(0, TOUR.list.findIndex(x => x.st === +st && x.bi === +(bi || 0) && x.si === +(si || 0))) : 0;
  document.body.classList.add('touring'); closePanel(); S.pin = null; tourShow(true);
}
function tourLoc(stp){
  const M = S.M; if (S.lv === 5 && !M.agentView){ const L = lv5Loc(stp, M); return {ids:L.boxes, ghosts:L.ghosts}; }
  return {ids:stepAnchors(stp, M), ghosts:[]};
}
function tourCtx(){
  // 앞 순서는 번호·단계가 바뀌어도 이어서 보여 줌 (단계가 넘어갈 때도 흐름이 끊기지 않게)
  const it = TOUR.list[TOUR.i]; if (!it || !S.M) return null;
  const C = tourLoc(it.stp), pi = TOUR.list[TOUR.i - 1] || null, P = pi ? tourLoc(pi.stp) : {ids:[], ghosts:[]};
  return {it, pi, same:!!(pi && pi.st === it.st && pi.bi === it.bi), cross:!!(pi && pi.st !== it.st), cur:C.ids, gcur:C.ghosts, prev:P.ids.filter(x => C.ids.indexOf(x) < 0), gprev:P.ghosts};
}
const KCLS = n => n.k === 'ot' ? 'k-h k-ot' : n.k === 'mk' ? 'k-mk' : (n.k === 'a' || n.k === 'na') ? 'k-a' : n.k === 'nh' ? 'k-nh' : 'k-h';
const boxKind = (M, id) => { const n = M.nodes.find(x => x.id === id); return !n ? null : (n.k === 'mk' ? 'orc' : (n.k === 'a' || n.k === 'na') ? 'ai' : n.k === 'nh' ? 'hitl' : 'hu'); };
const K2C = {ai:'k-a', hitl:'k-nh', hu:'k-h', orc:'k-mk'};
const stepNo = (it, si) => { const r = BOXNO.range[it.st + '|' + it.bi + '|' + (si != null ? si : it.si)]; if (r) return r[0] === r[1] ? r[0] : r[0] + '~' + r[1].split('-').pop(); return (it.bi + 1) + (it.b.steps.length > 1 ? '-' + ((si != null ? si : it.si) + 1) : ''); };
function tourClear(){
  $$('#board .tcard, #board .tghost, #board .tgbadge').forEach(e => e.remove()); $$('#edges .tgl, #edges .tarw, #edges .tdot, #edges defs.tdefs').forEach(e => e.remove());
  $$('#board .nd').forEach(el => { if (/\btk2?-|\btcov\b/.test(el.className)) el.classList.remove('tk-ai', 'tk-hitl', 'tk-hu', 'tk-orc', 'tk2-ai', 'tk2-hitl', 'tk2-hu', 'tk2-orc', 'tcov'); });
  $$('#board .gbox.tsel').forEach(e => e.classList.remove('tsel', 'tsel-ai', 'tsel-orc'));
}
function tourCard(kind, rect, head, sub, items, cls){
  // 잠깐 늘린 박스: 머리(어느 Agent · 어느 Lv.5 박스) + 그 자리에서 일어나는 순서(2-1, 2-2 …)
  const el = document.createElement('div'); el.className = 'tcard ' + (cls || '') + ' ' + K2C[kind]; el.style.left = rect.x + 'px'; el.style.top = rect.y + 'px'; el.style.width = rect.w + 'px';
  el.innerHTML = '<div class="tk-head"><i class="dot"></i><div>' + head + '</div></div>' + (sub ? '<div class="tk-ctx">' + sub + '</div>' : '') + '<ol class="tk-list">' + items.map(x => '<li class="' + x.kind + ' ' + (x.cls || 'todo') + '"><i>' + (x.cls === 'done' ? '✓' : esc(x.no)) + '</i><span>' + (x.who ? '<b>' + esc(x.who) + '</b> ' : '') + esc(x.v).replace(/ · (.+)$/, '<small>$1</small>') + '</span></li>').join('') + '</ol>';
  board.appendChild(el); rdTree(el); const W = S.M.W; if (rect.x + el.offsetWidth > W - 6) el.style.left = Math.max(4, W - el.offsetWidth - 6) + 'px';
  return {x:parseFloat(el.style.left), y:rect.y, w:el.offsetWidth, h:el.offsetHeight};
}
function tourPaint(c){
  tourClear(); const M = S.M, lv5 = S.lv === 5 && !M.agentView, R = {cur:[], prev:[]}, it = c.it, kd = stepKind(it.stp);
  const items = keyOK => it.b.steps.map((stp, si) => ({stp, si})).filter(x => keyOK(x.stp)).map(x => ({no:stepNo(it, x.si), kind:stepKind(x.stp), who:shortWho(x.stp), v:x.stp.v, cls:x.si === it.si ? 'now' : (x.si < it.si ? 'done' : '')}));
  // 1) 지금 순서의 실제 박스: 그 시점 주체 색으로 맞춤 (Lv.5 박스 종류와 달라도)
  c.cur.forEach(id => { const el = NODE_EL[id]; if (el) el.classList.add('tk-' + kd); const p = M.pos[id]; if (p) R.cur.push(p); });
  if (lv5){
    // 같은 주체(같은 Agent·같은 사람)가 이 번호에서 여러 순서를 하면 → 그 자리 박스를 잠깐 늘려 2-1, 2-2 …로
    // 다른 주체의 Lv.5 박스 안에서 일어나는 일이면 → 그 주체 자리(Agent 묶음·사람 레인)에 점선 박스를 늘려 어느 Agent인지 크게
    const n0 = stepNode(it.stp), act = n0 ? n0.ln : null, ghost = !c.cur.length && c.gcur.length > 0;
    const mates = it.b.steps.map((stp, si) => ({stp, si, n:stepNode(stp)})).filter(x => x.n && x.n.ln === act && x.n.st === n0.st);
    const lbOf = id => { const q = M.nodes.find(x => x.id === id); return q ? plain(q.lb) : ''; };
    if (n0 && (mates.length >= 2 || ghost)){
      let at = null, covered = null, sub = '';
      if (c.cur.length){ const p = M.pos[c.cur[0]]; if (p){ at = {x:p.x - 4, y:p.y - 4}; covered = c.cur[0]; sub = 'Lv.5 \'' + esc(lbOf(c.cur[0])) + '\''; } }
      else { const g = c.gcur[0], gr = ghostRect(g, M, 0); if (gr){ at = {x:gr.x, y:gr.y}; sub = 'Lv.5 \'' + esc(plain(g.lb)) + '\' 박스 내 업무'; } }
      if (at){
        const sid = D.subs[act] ? act : null, bd = sid ? bandOf(sid) : null, who = sid ? D.subs[sid].name : (n0.k === 'mk' ? 'Orchestrator' : stepWho(it.stp));
        const L = mates.map(x => { const L5 = lv5Loc(x.stp, M), where = L5.boxes.length ? '' : (L5.ghosts[0] ? '\'' + plain(L5.ghosts[0].lb) + '\' 박스 안' : '');
          return {no:stepNo(it, x.si), kind:stepKind(x.stp), who:x.stp.a || '', v:x.stp.v + (where ? ' · ' + where : ''), cls:x.si === it.si ? 'now' : (x.si < it.si ? 'done' : '')}; });
        const r = tourCard(kd, {x:at.x, y:at.y, w:Math.max(252, covered && M.pos[covered] ? M.pos[covered].w + 8 : 0)}, '<b>' + esc(who) + '</b>' + (bd ? '<small>' + esc(bd.name) + ' 소속 · 이 번호에서 ' + mates.length + '개 순서</small>' : (mates.length > 1 ? '<small>이 번호에서 ' + mates.length + '개 순서</small>' : '')), sub, L, ghost ? 'tghostc' : 'tbig');
        if (covered){ const el = NODE_EL[covered]; if (el) el.classList.add('tcov'); R.cur = R.cur.filter(q => q !== M.pos[covered]); }
        R.cur.push(r);
        if (ghost){ const bp = M.pos[c.gcur[0].box]; if (bp){ const pth = document.createElementNS(SVGNS, 'path'); pth.setAttribute('class', 'tgl ' + K2C[kd]); pth.setAttribute('d', 'M' + (bp.x + bp.w / 2) + ',' + (bp.y + bp.h / 2) + ' L' + (r.x + r.w / 2) + ',' + (r.y + 14)); svg.appendChild(pth); } }
      }
    }
    // 한 순서가 다른 주체 박스 여러 곳에 걸치면 나머지도 작게
    c.gcur.slice(ghost ? 1 : 0).forEach((g, k) => { const gr = ghostRect(g, M, (k + 1) * 2); if (!gr) return; const el = document.createElement('div'); el.className = 'nd tghost hl ' + K2C[kd]; el.style.left = gr.x + 'px'; el.style.top = gr.y + 'px'; el.style.width = gr.w + 'px'; el.style.height = gr.h + 'px';
      el.innerHTML = '<small>Lv.5 \'' + esc(plain(g.lb)) + '\' 안</small><div class="lbl"><b>' + esc(shortWho(it.stp)) + '</b> ' + esc(it.stp.v) + '</div>'; board.appendChild(el); R.cur.push(gr); });
  }
  // 2) 앞 순서: 같은 색 점선 테두리 (Lv.5 점선 박스면 작게)
  const pk = c.pi ? stepKind(c.pi.stp) : 'hu';
  c.prev.forEach(id => { const el = NODE_EL[id]; if (el) el.classList.add('tk2-' + pk); const p = M.pos[id]; if (p) R.prev.push(p); });
  if (lv5 && c.pi) c.gprev.forEach((g, k) => { if (c.gcur.some(x => x.ln === g.ln && x.box === g.box)) return; const gr = ghostRect(g, M, k * 2 + c.gcur.length * 2); if (!gr) return; const el = document.createElement('div');
    el.className = 'nd tghost hl2 ' + K2C[pk]; el.style.left = gr.x + 'px'; el.style.top = gr.y + 'px'; el.style.width = gr.w + 'px'; el.style.height = gr.h + 'px';
    el.innerHTML = '<small>앞 순서</small><div class="lbl"><b>' + esc(shortWho(c.pi.stp)) + '</b> ' + esc(c.pi.stp.v) + '</div>'; board.appendChild(el); R.prev.push(gr); });
  // 3) 지금 순서 번호 (그 시점 주체 색)
  const PID = new Map(Object.entries(M.pos).map(([k, v]) => [v, k]));
  R.cur.forEach(r => { const bd = document.createElement('div'); bd.className = 'sbadge tgbadge on ' + kd; const bid = PID.get(r); bd.textContent = (bid && BOXNO.map[bid]) ? BOXNO.map[bid].no : stepNo(it); bd.style.left = (r.x - 15) + 'px'; bd.style.top = (r.y - 13) + 'px'; board.appendChild(bd); });
  // 4) 어느 Agent에서 일어나는지: 그 큰 기능 Agent · 세부 Agent 묶음은 흐려지지 않게
  const n = stepNode(it.stp);
  if (n && D.subs[n.ln]){ const bd = bandOf(n.ln); if (bd){ const orc = bd.id === 'B0', cl = orc ? 'tsel-orc' : 'tsel-ai';
    $$('#board .gbox.gb').forEach(e => { if (e.dataset.band !== bd.id || (e.dataset.st && +e.dataset.st !== n.st)) return; e.classList.add('tsel', cl); });
    $$('#board .gbox.gs').forEach(e => { if (e.dataset.band !== bd.id || (e.dataset.st && +e.dataset.st !== n.st) || (e.dataset.sid && e.dataset.sid !== n.ln)) return; e.classList.add('tsel', cl); }); } }
  return R;
}
function tourArrow(fromR, toR){
  // 앞 순서 → 지금 순서: 실제 연결선이 없을 때 그리는 따라가기 화살표 (단계가 넘어가도 이어서)
  if (!fromR || !toR) return; const ax = fromR.x + fromR.w, ay = fromR.y + fromR.h / 2, bx = toR.x, by = toR.y + Math.min(18, toR.h / 2);
  const back = bx < ax - 10, sx = back ? fromR.x + fromR.w / 2 : ax, sy = back ? fromR.y + fromR.h : ay, ex = back ? toR.x + toR.w / 2 : bx, ey = back ? toR.y : by;
  if (Math.hypot(ex - sx, ey - sy) < 24) return;
  const d = back ? 'M' + sx + ',' + sy + ' C' + sx + ',' + (sy + 60) + ' ' + ex + ',' + (ey - 60) + ' ' + ex + ',' + ey : 'M' + sx + ',' + sy + ' C' + (sx + Math.max(40, (ex - sx) / 2)) + ',' + sy + ' ' + (ex - Math.max(40, (ex - sx) / 2)) + ',' + ey + ' ' + ex + ',' + ey;
  tourFlowPath(d, true);
}
const KCOL = {ai:'#D0021B', hitl:'#0E8A5F', hu:'#7B8290', orc:'#151A22'};
function tourFlowPath(d, draw){
  // 앞 순서 색 → 지금 순서 색 그라데이션 선 + 그 위를 흐르는 점
  const it = TOUR.list[TOUR.i], pi = TOUR.list[TOUR.i - 1], k1 = KCOL[pi ? stepKind(pi.stp) : 'hu'], k2 = KCOL[it ? stepKind(it.stp) : 'hu'], gid = 'tg' + (++tourFlowPath.n);
  const g = document.createElementNS(SVGNS, 'linearGradient'); g.setAttribute('id', gid); g.innerHTML = '<stop offset="0%" stop-color="' + k1 + '"/><stop offset="100%" stop-color="' + k2 + '"/>';
  let defs = svg.querySelector('defs.tdefs'); if (!defs){ defs = document.createElementNS(SVGNS, 'defs'); defs.setAttribute('class', 'tdefs'); svg.appendChild(defs); } defs.appendChild(g);
  if (draw){ const p = document.createElementNS(SVGNS, 'path'); p.setAttribute('class', 'tarw'); p.setAttribute('d', d); p.setAttribute('stroke', 'url(#' + gid + ')'); svg.appendChild(p); }
  const dot = document.createElementNS(SVGNS, 'circle'); dot.setAttribute('class', 'tdot'); dot.setAttribute('r', '4.5'); dot.setAttribute('fill', k2);
  dot.innerHTML = '<animateMotion dur="1.5s" repeatCount="indefinite" path="' + d + '" keyPoints="0;1" keyTimes="0;1" calcMode="linear"/>'; svg.appendChild(dot);
}
tourFlowPath.n = 0;
function tourApply(){
  if (!TOUR.on) return null; const c = tourCtx(); if (!c) return null; const hs = new Set(c.cur), ps = new Set(c.prev); S.hl = hs;
  $$('#board .nd:not(.tghost)').forEach(el => { el.classList.toggle('hl', hs.has(el.dataset.id)); el.classList.toggle('hl2', ps.has(el.dataset.id)); }); board.classList.add('tour');
  let real = false;
  $$('#edges path.e').forEach(p => { const a = p.dataset.a, b = p.dataset.b, on = (hs.has(b) && (hs.has(a) || ps.has(a))); p.classList.toggle('hot', on); p.classList.toggle('tflow', on && ps.has(a)); if (on && ps.has(a)) real = true; });
  if (!svg.querySelector('#m-tarw')){ const d = document.createElementNS(SVGNS, 'defs'); d.innerHTML = '<marker id="m-tarw" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="var(--ink-strong)"/></marker>'; svg.appendChild(d); }
  const R = tourPaint(c); if (!real && R.prev.length && R.cur.length) tourArrow(R.prev[R.prev.length - 1], R.cur[0]);
  if (real) $$('#edges path.e.tflow').forEach(p => { const d = p.getAttribute('d'); if (d) tourFlowPath(d, false); });
  c.rc = R.cur; c.rp = R.prev;
  const it = c.it;
  $$('#board .sbadge:not(.tgbadge)').forEach(el => { el.classList.remove('on'); el.classList.toggle('mate', +el.dataset.st === it.st && +el.dataset.bi === it.bi); });
  return c;
}
function tourFocus(rp, rc){
  // 앞·지금 단계가 한 화면(높이 55%·폭 85%)에 들어오면 둘 다, 아니면 지금 단계만 가운데로
  const all = rp.concat(rc); if (!all.length) return; const wrp = $('#wrap'), z = S.zoom || 1;
  const bb = rs => { const x0 = Math.min.apply(null, rs.map(p => p.x)), y0 = Math.min.apply(null, rs.map(p => p.y)), x1 = Math.max.apply(null, rs.map(p => p.x + p.w)), y1 = Math.max.apply(null, rs.map(p => p.y + p.h)); return {x:x0, y:y0, w:x1 - x0, h:y1 - y0}; };
  let B = bb(all); if (wrp && (B.w * z > wrp.clientWidth * 0.85 || B.h * z > wrp.clientHeight * 0.55)) B = bb(rc.length ? rc : all);
  let fx = $('#tourfocus'); if (!fx){ fx = document.createElement('div'); fx.id = 'tourfocus'; } board.appendChild(fx);
  fx.style.left = B.x + 'px'; fx.style.top = B.y + 'px'; fx.style.width = Math.max(4, B.w) + 'px'; fx.style.height = Math.max(4, B.h) + 'px';
  // 지도 영역이 화면 위쪽에 오게 한 번 맞춘 뒤, 설명 창 위 남는 공간의 가운데로 박스를 옮김
  const sw = $('#stageWrap'), cap = $('#tourcap');
  if (sw){ const r0 = sw.getBoundingClientRect(); if (r0.top > 140 || r0.bottom < window.innerHeight * 0.5) window.scrollBy({top:r0.top - 96, behavior:'smooth'}); }
  setTimeout(() => { const wr = $('#wrap'); if (!wr) return; const wb = wr.getBoundingClientRect(), fr = fx.getBoundingClientRect(), capTop = cap && !cap.hidden ? cap.getBoundingClientRect().top : window.innerHeight;
    const top = Math.max(wb.top, 96), bot = Math.min(wb.bottom, capTop - 14), cy = bot > top + 80 ? (top + bot) / 2 : (wb.top + wb.bottom) / 2;
    wr.scrollBy({top:(fr.top + fr.height / 2) - cy, left:(fr.left + fr.width / 2) - (wb.left + wb.width / 2), behavior:'smooth'}); }, 260);
}
function tourShow(scroll){
  const c = tourApply(); if (!c){ tourEnd(); return; }
  const it = c.it, st = D.stages.find(z => z.n === it.st) || {}, cap = $('#tourcap'), kd = stepKind(it.stp), tot = TOUR.list.length;
  const ed = !!TOUR.edit, ob = it.b._bi != null ? it.b._bi : it.bi, os = (it.b._b || it.b).steps.indexOf(it.stp), kb = it.st + '|' + ob, ks = kb + '|' + os;
  const ce = (k, html, cls, ph) => '<span class="tce ' + (cls || '') + '" contenteditable="true" spellcheck="false" data-sk="' + k + '"' + (ph ? ' data-ph="' + esc(ph) + '"' : '') + '>' + html + '</span>';
  const sname = z => esc(((z && z.name) || '').replace(/^\d+\.\s*/, '').split(' / ')[0]), pst = c.pi ? D.stages.find(z => z.n === c.pi.st) || {} : null;
  const trans = c.cross ? '<div class="tc-trans"><span class="tc-tr"><i>' + c.pi.st + '</i>' + sname(pst) + '</span><span class="tc-arr">→</span><span class="tc-tr on"><i>' + it.st + '</i>' + sname(st) + '</span>' + (STORY[c.pi.st] ? '<small>' + esc(STORY[c.pi.st].next) + '</small>' : '') + '</div>'
    : (c.pi && !c.same ? '<div class="tc-trans sm">↪ <b>' + (c.pi.bi + 1) + '. ' + esc((c.pi.b._b || c.pi.b).t) + '</b>에서 이어집니다 <small>마지막: ' + esc(shortWho(c.pi.stp)) + ' · ' + esc(c.pi.stp.v) + '</small></div>' : '');
  const steps = it.b.steps.map((stp, k) => { const sk = stepKind(stp), cl = k === it.si ? 'now' : (k < it.si ? 'done' : 'todo');
    return '<li class="' + sk + ' ' + cl + '"' + (ed && k === it.si ? '' : ' data-tourjump="' + (TOUR.i - it.si + k) + '"') + ' title="' + esc(stepWho(stp) + ' — ' + plainD(stp.d)) + '"><i>' + (cl === 'done' ? '✓' : stepNo(it, k)) + '</i><span><b>' + esc(shortWho(stp)) + '</b>' + (ed && k === it.si ? ce(ks + '|v', esc(stp.v), 'tce-v') : esc(stp.v)) + '</span></li>'; }).join('');
  const ticks = D.stages.filter(z => TOUR.list.some(x => x.st === z.n)).map(z => { const f = TOUR.list.findIndex(x => x.st === z.n); return '<b style="left:' + (f / tot * 100).toFixed(2) + '%" class="' + (z.n === it.st ? 'on' : '') + '" title="' + z.n + '단계">' + z.n + '</b>'; }).join('');
  const note = !c.rc.length ? '이 화면에는 해당 박스가 없습니다. 경로·단계·레벨을 변경해 확인할 수 있습니다'
    : (c.gcur.length ? 'Lv.5 박스는 주 수행자 한 명만 표시합니다. 이 업무는 \'' + esc(plain(c.gcur[0].lb)) + '\' 박스에 포함되어, ' + (D.subs[c.gcur[0].ln] ? '그 Agent 묶음' : '그 레인') + ' 안에 별도로 표시합니다' : '');
  const isLast = !!(TOUR.list[TOUR.i + 1] && TOUR.list[TOUR.i + 1].st !== it.st), firstOfStage = !TOUR.list[TOUR.i - 1] || TOUR.list[TOUR.i - 1].st !== it.st;
  cap.className = 'tc ' + kd;
  cap.innerHTML = '<button type="button" class="tc-x" data-tour="x" aria-label="닫기" title="닫기 (Esc)">×</button>' + trans
    + '<div class="tc-top"><span class="tc-stage"><i>' + it.st + '</i>' + sname(st) + '</span><span class="tc-count">순서 ' + (it.si + 1) + '/' + it.b.steps.length + ' · 전체 ' + (TOUR.i + 1) + '/' + tot + '</span></div>'
    + '<div class="tc-title"><span class="tc-no">' + (it.bi + 1) + '</span>' + (ed ? ce(kb + '|t', esc((it.b._b || it.b).t), 'tce-t') : esc((it.b._b || it.b).t)) + '</div>'
    + '<ol class="tc-steps" style="--n:' + it.b.steps.length + '">' + steps + '</ol>'
    + '<div class="tc-now ' + kd + '"><div class="tc-who"><i></i><b>' + (ed ? ce(ks + '|a', esc(it.stp.a || ''), 'tce-a', '자동: ' + stepWho(Object.assign({}, it.stp, {a:''}))) : esc(stepWho(it.stp))) + '</b><span>' + KNAME[kd] + '</span></div><p' + (ed ? ' class="tce tce-d" contenteditable="true" spellcheck="false" data-rich="1" data-sk="' + ks + '|d"' : '') + '>' + (ed ? rich(it.stp.d) : rich(rd(it.stp.d))) + '</p></div>'
    + (note ? '<p class="tc-note">' + note + '</p>' : '')
    + (ed && STORY[it.st] ? '<div class="tc-ctx tc-ctxe"><span>바뀌는 점</span>' + ce(it.st + '|chg', esc(STORY[it.st].chg)) + '<br><span class="g">지금은</span>' + ce(it.st + '|now', esc(STORY[it.st].now)) + '<br><span class="g">다음 단계</span>' + ce(it.st + '|next', esc(STORY[it.st].next)) + '</div>' : '')
    + (!ed && STORY[it.st] && (firstOfStage || isLast) ? '<div class="tc-ctx">' + (firstOfStage ? '<span>바뀌는 점</span>' + esc(STORY[it.st].chg) + '<br><span class="g">지금은</span>' + esc(STORY[it.st].now) : '') + (isLast ? (firstOfStage ? '<br>' : '') + '<span class="g">다음 단계</span>' + esc(STORY[it.st].next) : '') + '</div>' : '')
    + (ed ? '<div class="tc-edbar"><b>✎ 편집 중</b><button type="button" data-tourbold="1" title="고른 글자를 굵게 (Ctrl+B)"><b>B</b> 굵게</button><button type="button" data-tourreset="1" title="이 순서의 제목·이름·주체·설명을 처음 문장으로">↺ 이 순서 원래대로</button><span>점선 글자를 눌러 수정 · Enter로 확정 · 편집본 저장 시 함께 저장</span></div>' : '')
    + '<div class="tc-ctrl"><button type="button" class="tc-ic" data-tour="-1"' + (TOUR.i ? '' : ' disabled') + ' title="이전 (←)">‹</button><button type="button" class="tc-ic pri" data-tour="1" title="다음 (→ · Space)">' + (TOUR.i < tot - 1 ? '›' : '✓') + '</button>'
    + '<button type="button" class="tc-play' + (TOUR.auto ? ' on' : '') + '" data-tourauto="1">' + (TOUR.auto ? '❚❚ 멈춤' : '▶ 자동') + '</button>'
    + '<span class="tc-lv"><button type="button" data-tourlv="5" aria-pressed="' + (S.lv === 5) + '">Lv.5</button><button type="button" data-tourlv="6" aria-pressed="' + (S.lv === 6) + '">Lv.6</button></span>'
    + '<span class="tc-key"><i class="ai"></i>Agent<i class="hitl"></i>담당자 확인<i class="hu"></i>사람<i class="orc"></i>Orchestrator</span></div>'
    + '<div class="tc-prog"><span style="width:' + ((TOUR.i + 1) / tot * 100).toFixed(2) + '%"></span>' + ticks + '</div>';
  rdTree(cap); cap.classList.toggle('tc-editing', ed); cap.hidden = false; cap.classList.remove('tc-in'); void cap.offsetWidth; if (!TOUR._noAnim) cap.classList.add('tc-in'); TOUR._noAnim = false;
  if (scroll && c.rc.length) tourFocus(c.rp, c.rc);
}
function tourGo(d, manual){ if (!TOUR.on) return; if (manual !== false && TOUR.auto && d !== 0) tourAuto(false); const k = TOUR.i + d; if (k < 0) return; if (k >= TOUR.list.length){ tourEnd(); return; }
  const cur = TOUR.list[TOUR.i], nx = TOUR.list[k]; TOUR._asked = TOUR._asked || {};
  if (d > 0 && cur && nx && nx.st !== cur.st && !TOUR._asked[nx.st] && !S.scen[nx.st] && scenChoices(nx.st).length > 1){ if (TOUR.auto) tourAuto(false);
    scenAsk(nx.st, () => { TOUR.list = tourList(); const j = TOUR.list.findIndex(x => x.st === nx.st); TOUR.i = j >= 0 ? j : Math.min(k, TOUR.list.length - 1); tourShow(true); }); return; }
  TOUR.i = k; tourShow(true); }
function tourAuto(on){ if (TOUR.auto){ clearInterval(TOUR.auto); TOUR.auto = null; } if (on) TOUR.auto = setInterval(() => { if (TOUR.i >= TOUR.list.length - 1){ tourAuto(false); tourShow(false); return; } TOUR.i++; tourShow(true); }, 4200); if (TOUR.on) tourShow(false); }
function tourEnd(){
  const hadScen = Object.keys(S.scen || {}).length; TOUR._asked = {}; S.scen = {}; if (hadScen) setTimeout(() => render(false), 0); const sq = $('#scenask'); if (sq) sq.hidden = true;
  tourAuto(false); TOUR.on = false; TOUR.edit = false; document.body.classList.remove('touring'); board.classList.remove('tour'); S.hl = null;
  $$('#board .nd.hl, #board .nd.hl2').forEach(e => e.classList.remove('hl', 'hl2')); $$('#edges path.hot, #edges path.tflow').forEach(p => p.classList.remove('hot', 'tflow'));
  $$('#board .sbadge.on, #board .sbadge.mate, #board .sc-bt li.on, #board .sc-bt em.now, #board .sc-bt em.done').forEach(e => e.classList.remove('on', 'mate', 'now', 'done'));
  const c = $('#tourcap'); if (c) c.hidden = true; const fx = $('#tourfocus'); if (fx) fx.remove();
  tourClear();
}
function squeezeCols(nodes, col, ncol, vis){
  // 경로를 고르면 숨긴 업무가 차지하던 빈 열을 당겨 붙임 (순서는 그대로)
  if ((!S.path || S.path === 'all') && !Object.keys(S.scen).length) return;
  vis.forEach(s => { const used = Array.from(new Set(nodes.filter(n => n.st === s.n && n.k !== 'why').map(n => col[n.id]))).sort((a, b) => a - b), m = {}; used.forEach((c, i) => { m[c] = i; });
    nodes.forEach(n => { if (n.st === s.n && m[col[n.id]] != null) col[n.id] = m[col[n.id]]; }); ncol[s.n] = Math.max(1, used.length); });
}
const trkCls = l => { if (!D.lines) return 'tk ' + (l === LINE[2] ? 'tk-ns' : (l === LINE[0] ? 'tk-sh' : 'tk-cm')); const j = LINE.filter(Boolean).indexOf(l); return 'tk ' + (j < 0 ? 'tk-cm' : ['tk-sh', 'tk-ns', 'tk-x2', 'tk-x3', 'tk-x4', 'tk-x5'][j % 6]); };
const TLH = 16;
function stackBands(map, pad, gapB, labelH, minH){
  // map: {'줄~갈래': 내용 높이} → 갈래 줄(bands)과 줄 묶음(lines) 위치
  const keys = Object.keys(map), lns = LINE.filter(l => keys.some(k => k.split('~')[0] === l)), lab = lns.length > 1 || (lns.length === 1 && lns[0] !== '');
  let y = 0; const bands = {}, lines = {}, trs = [];
  lns.forEach((l, li) => { const y0 = y, lh = lab && labelH && l ? labelH : 0; y += lh;
    const subs = SUBL.filter(s => map[l + '~' + s] != null);
    subs.forEach((s, si) => { const k = l + '~' + s, h = Math.max(minH || 0, map[k] + 2 * pad); bands[k] = {y, h, lh:0}; trs.push(k); y += h + (si < subs.length - 1 ? 2 : 0); });
    lines[l] = {y:y0, h:y - y0, lh}; if (li < lns.length - 1) y += gapB; });
  return {bands, lines, h:y, trs, lns, lab};
}
function absBands(B, y0){ const o = {}; if (B) Object.keys(B.bands).forEach(k => { const b = B.bands[k]; o[k] = {y:y0 + b.y, h:b.h, lh:b.lh}; }); return o; }
function absLines(B, y0){ const o = {}; if (B) Object.keys(B.lines).forEach(l => { const b = B.lines[l]; o[l] = {y:y0 + b.y, h:b.h, lh:b.lh}; }); return o; }
const FCOL = {};
function flowCols(lv){
  // As-Is와 To-be의 선을 합쳐 단계 안에서 왼쪽→오른쪽 순서(층)를 매김 — 두 화면이 같은 열을 쓰므로 전환해도 폭이 그대로
  const fk = lv + '|' + (S.path || 'all') + '|' + JSON.stringify(S.scen); if (FCOL[fk]) return FCOL[fk];
  const Va = D.views[lv].asis, Vn = D.views[lv].ns, all = {}, col = {}, ncol = {}, preds = {};
  Va.nodes.concat(Vn.nodes).forEach(n => { if (!all[n.id] && pathOK(n)) all[n.id] = n; });
  Va.edges.concat(Vn.edges).forEach(([a, b, t]) => { if (t === 'l' || t === 'r') return; const A = all[a], B = all[b]; if (!A || !B || A.st !== B.st) return; (preds[b] = preds[b] || []).push(a); });
  const ord = n => (n.o != null ? n.o : 1e6);
  for (let s = 1; s <= D.stages.length; s++){
    const N = Object.values(all).filter(n => n.st === s && n.k !== 'why').sort((a, b) => (ord(a) - ord(b)) || ((a.c || 0) - (b.c || 0)));
    const done = new Set(); let last = 0, mx = 0;
    N.forEach(n => { const ps = (preds[n.id] || []).filter(p => done.has(p)); let c;
      if (ps.length) c = Math.max.apply(null, ps.map(p => col[p] + 1));
      else { const base = String(n.id).split('@')[0]; c = (base !== n.id && col[base] != null) ? col[base] : ((preds[n.id] || []).length || n.k === 'mk' || n.k === 'pt' ? last : 0); }
      col[n.id] = c; done.add(n.id); last = c; if (c + 1 > mx) mx = c + 1; });
    Object.values(all).filter(n => n.st === s && n.k === 'why').forEach(n => { col[n.id] = col[n.of] != null ? col[n.of] : 0; });
    ncol[s] = Math.max(1, mx);
  }
  return (FCOL[fk] = {col, ncol});
}
function layoutFlow(){
  const V = view(), C = Object.assign({}, D.layout[S.lv], CMPF[S.lv]), vis = D.stages.filter(s => S.stages.has(s.n)), ns = S.scr === 'ns';
  const nodes = V.nodes.filter(n => S.stages.has(n.st) && pathOK(n)), FC = flowCols(S.lv), cl = id => (FC.col[id] != null ? FC.col[id] : 0);
  const SX = {}, SW = {}; let x = 8;
  vis.forEach(s => { const w = FC.ncol[s.n] * C.colW; SX[s.n] = x; SW[s.n] = w; x += w + C.gap; });
  const W = Math.max(x, 640), HH = measureH(nodes, C.nodeW), cells = {}, content = {}, cT = {}, ext = {};
  nodes.forEach(n => { const key = n.ln + '|' + trkOf(n) + '|' + n.st + '|' + cl(n.id); (cells[key] = cells[key] || []).push(n); });
  Object.keys(cells).forEach(key => { const arr = cells[key].sort((a, c) => ((a.o || 0) - (c.o || 0)) || ((a.k === 'why') - (c.k === 'why'))), p = key.split('|');
    const h = arr.reduce((s, n) => s + HH[n.id], 0) + (arr.length - 1) * C.vg; content[p[0]] = Math.max(content[p[0]] || 0, h); (cT[p[0]] = cT[p[0]] || {})[p[1]] = Math.max(cT[p[0]][p[1]] || 0, h);
    const x0 = SX[+p[2]] + (+p[3]) * C.colW + (C.colW - C.nodeW) / 2; const e = ext[p[0]] = ext[p[0]] || [1e9, -1e9]; e[0] = Math.min(e[0], x0); e[1] = Math.max(e[1], x0 + C.nodeW); });
  const rows = [], RY = {}, fb = []; let y = 0; const SH = storyH(vis, SW); if (SH){ rows.push({t:'story', k:'_story', y:0, h:SH}); y = SH; }
  D.lanes.forEach((l, i) => { if (l.onlyIn && l.onlyIn !== S.scr) return; const B = cT[l.k] ? stackBands(cT[l.k], C.pad, 10, TLH, 0) : null, h = Math.max(C.minH, B ? B.h : 0), bands = absBands(B, y), lines = absLines(B, y);
    rows.push({t:'lane', k:l.k, y, h, l, i, bands, lines, lns:B ? B.lns : [], lab:!!(B && B.lab)}); RY[l.k] = {y, h, off:0, bands, lines}; y += h; });
  const aiTop = y;
  if (ns){
    const y0 = y; y += 16;
    D.bands.forEach(b => { const subs = b.subs.filter(sid => content[sid] != null); if (!subs.length) return;
      const by0 = y, bw = Math.max.apply(null, subs.map(sid => ext[sid][1] - ext[sid][0])) + 40, th = titleH('gb', bandTitle(b), Math.max(220, bw)); y += th; const qs = [];
      subs.forEach(sid => { const sw = ext[sid][1] - ext[sid][0] + 20, ts = titleH('gs', subTitle(sid), Math.max(160, sw)), SB = stackBands(cT[sid], C.pad, 4, TLH, 0), h = ts + SB.h, bands = absBands(SB, y + ts);
        const lines = absLines(SB, y + ts); RY[sid] = {y, h, off:ts, bands, lines}; qs.push({sid, y0:y, y1:y + h, ts, bands, lines, lns:SB.lns, lab:SB.lab}); y += h + 8; });
      fb.push({b, y0:by0, y1:y + 4, th, subs:qs}); y += 18; });
    rows.push({t:'aih', k:'_ai', y:y0, h:y - y0 + 6}); y += 6;
  }
  const pos = {};
  Object.keys(cells).forEach(key => { const arr = cells[key], n0 = arr[0], ry = RY[n0.ln]; if (!ry || SX[n0.st] == null) return; const bd = ((ry.bandsS && ry.bandsS[n0.st]) || ry.bands || {})[trkOf(n0)] || {y:ry.y + (ry.off || 0), lh:0}; let yy = bd.y + (bd.lh || 0) + C.pad;
    arr.forEach(n => { pos[n.id] = {x:SX[n.st] + cl(n.id) * C.colW + (C.colW - C.nodeW) / 2, y:yy, w:C.nodeW, h:HH[n.id]}; yy += HH[n.id] + C.vg; }); });
  const EDV = ED[S.scr + '|' + S.lv];
  let outN = nodes.filter(n => pos[n.id]);
  if (EDV){
    const del = EDV.del || {}, kd = EDV.kd || {}, tg = EDV.tg || {}, add = EDV.add || {}, mv = EDV.mv || {};
    outN = outN.filter(n => !del[n.id]).map(n => (kd[n.id] || tg[n.id] != null) ? Object.assign({}, n, kd[n.id] ? {k:kd[n.id]} : {}, tg[n.id] != null ? {tg:tg[n.id]} : {}) : n);
    Object.keys(add).forEach(id => { const a = add[id], base = RY[a.ln]; if (!S.stages.has(a.st) || SX[a.st] == null || !base) return;
      pos[id] = {x:SX[a.st] + a.dx, y:base.y + a.dy, w:C.nodeW, h:56}; outN.push({id, st:a.st, ln:a.ln, k:kd[id] || a.k, lb:a.lb, tg:tg[id] != null ? tg[id] : (a.tg || ''), added:1}); });
    Object.keys(mv).forEach(id => { if (pos[id] && !add[id]) pos[id] = Object.assign({}, pos[id], {x:pos[id].x + mv[id][0], y:pos[id].y + mv[id][1]}); });
    Object.keys(del).forEach(id => { delete pos[id]; });
  }
  let W2 = W, H2 = y + 16; outN.forEach(n => { const p = pos[n.id]; if (p){ W2 = Math.max(W2, p.x + p.w + 40); H2 = Math.max(H2, p.y + p.h + 30); } });
  return {V, C, vis, SX, SW, W:W2, H:H2, nodes:outN, rows, pos, bandBox:[], RY, RYS:{}, segs:null, fb, aiTop:ns ? aiTop : null, flow:1};
}
function layoutAgent(){
  const V6 = D.views[6][S.scr], vis = D.stages.filter(s => S.stages.has(s.n)), C = Object.assign({}, D.layout[6], {colW:300, nodeW:248, pad:14, vg:18, gap:96, minH:64});
  const blk = {}, of = {}, list = [];
  V6.nodes.forEach(n => { if (!S.stages.has(n.st) || !pathOK(n) || n.k === 'why' || n.k === 'gone' || n.k === 'pt') return;
    const ai = !!D.subs[n.ln], bd = ai ? bandOf(n.ln) : null, key = ai ? 'BLK:B:' + bd.id + '|' + n.st : 'BLK:H:' + n.ln + '|' + n.st;
    if (!blk[key]){ blk[key] = {id:key, st:n.st, ln:ai ? key : n.ln, ai, band:bd, lane:ai ? null : n.ln, tasks:[], k:'blk', lb:ai ? bd.name : ((D.lanes.find(l => l.k === n.ln) || {}).name || n.ln), o:n.o}; list.push(blk[key]); }
    blk[key].tasks.push(n); of[n.id] = key; });
  const agg = {};
  V6.edges.forEach(([a, b, t, lab]) => { if (t === 'l' || t === 'r') return; const A = of[a], B = of[b]; if (!A || !B || A === B) return;
    const ty = t === 'o' ? 'o' : (blk[A].ai ? 'b' : 'h') + (blk[B].ai ? 'b' : 'h'), key = A + '>' + B + '|' + ty, q = agg[key] = agg[key] || {a:A, b:B, t:ty, n:0, items:[], E:[]};
    q.n++; q.E.push([a, b, t, lab]); const it = t === 'o' ? (lab || '신호') : afItem([a, b, t, lab]); if (it && q.items.indexOf(it) < 0) q.items.push(it); });
  const cut = s => s;   /* 글자 수로 자르지 않음 (v22) */
  const edges = Object.keys(agg).map(k => { const q = agg[k]; return [q.a, q.b, q.t, (q.t === 'o' ? cut(q.items.slice(0, 1).join('')) : (q.n > 1 ? q.n + '건 · ' : '') + cut(q.items[0] || '')), q]; });
  const ns = S.scr === 'ns', HW = 232, AW = 250, CG = 84, TOP = 58, VG = 16, SX = {}, SW = {}, COL = {}; let x = 40;
  vis.forEach(s => { const w = ns ? HW + CG + AW : HW; SX[s.n] = x; SW[s.n] = w; COL[s.n] = {hx:x, ax:x + HW + CG, cx:x + HW + CG / 2, rx:x + w + 14, lx:x - 14}; x += w + C.gap; });
  const HH = {}, mh = (arr, w) => { const r = measureH(arr, w); Object.assign(HH, r); };
  mh(list.filter(b => !b.ai), HW); if (ns) mh(list.filter(b => b.ai), AW);
  const pos = {}, RY = {}, SH = storyH(vis, SW), T0 = TOP + SH; let maxY = 0;
  vis.forEach(s => { let yh = T0, ya = T0;
    D.lanes.forEach(l => { const b = list.find(q => !q.ai && q.lane === l.k && q.st === s.n); if (!b) return; pos[b.id] = {x:COL[s.n].hx, y:yh, w:HW, h:HH[b.id]}; RY[b.id] = {y:yh - 6, h:HH[b.id] + 12, off:0}; yh += HH[b.id] + VG; });
    if (ns) list.filter(q => q.ai && q.st === s.n).sort((p, q) => D.bands.indexOf(p.band) - D.bands.indexOf(q.band)).forEach(b => { pos[b.id] = {x:COL[s.n].ax, y:ya, w:AW, h:HH[b.id]}; RY[b.id] = {y:ya - 6, h:HH[b.id] + 12, off:0}; ya += HH[b.id] + VG; });
    maxY = Math.max(maxY, yh, ya); });
  list.forEach(b => { b.ln = b.id; });
  const rows = (SH ? [{t:'story', k:'_story', y:0, h:SH}] : []).concat([{t:'agv', k:'_agv', y:SH, h:maxY - SH + 20}]);
  const ncols = {}; vis.forEach(s => { ncols[s.n] = 1; });
  return {V:{nodes:list, edges, ncols}, C:Object.assign(C, {colW:HW + 20, nodeW:HW}), vis, SX, SW, COL, TOP:T0, SH, blkOf:of, W:Math.max(x, 640), H:maxY + 30, nodes:list, rows, pos, bandBox:[], RY, RYS:{}, segs:null, fb:null, aiTop:null, agentView:1};
}
function layout(){
  if (S.view === 'agent') return layoutAgent();
  if (S.view === 'flow') return layoutFlow();
  const V = view(), C = gapUp(Object.assign({}, D.layout[S.lv], CMP[S.lv])), vis = D.stages.filter(s => S.stages.has(s.n));
  const nodes = V.nodes.filter(n => S.stages.has(n.st) && pathOK(n)), ns = S.scr === 'ns', rk = n => n.ln + '|' + trkOf(n), gk = n => n.ln + '|' + lineOf(n);
  const byId = {}, preds = {}; nodes.forEach(n => { byId[n.id] = n; }); V.edges.forEach(e => { if (e[2] === 'l' || e[2] === 'r') return; (preds[e[1]] = preds[e[1]] || []).push(e[0]); });
  const col = {}, ncol = {}, kcol = {};
  if (ns){
    // 같은 줄 안 순서 = 업무 순서. 병렬 줄(촬영·비촬영·영상·이미지)은 같은 X에서 시작해 위아래로 나란히
    vis.forEach(s => { const N = nodes.filter(n => n.st === s.n).sort((a, c) => (a.o != null && c.o != null ? a.o - c.o : 0) || ((a.c || 0) - (c.c || 0)) || ((a.r || 0) - (c.r || 0))); const nxt = {}; let mx = 0;
      N.forEach(n => { if (n.k === 'why') return; const k = rk(n); let c = nxt[k] || 0;
        (preds[n.id] || []).forEach(p => { const q = byId[p]; if (q && q.st === n.st && gk(q) === gk(n) && col[p] != null) c = Math.max(c, col[p] + 1); });
        col[n.id] = c; nxt[k] = c + 1; if (c + 1 > mx) mx = c + 1; });
      N.forEach(n => { if (n.k === 'why') col[n.id] = col[n.of] != null ? col[n.of] : 0; });
      Object.keys(nxt).forEach(k => { const key = k.split('|')[0] + '|' + s.n; kcol[key] = Math.max(kcol[key] || 0, nxt[k]); });
      ncol[s.n] = Math.max(1, mx); });
  } else { nodes.forEach(n => { col[n.id] = n.c || 0; }); vis.forEach(s => { ncol[s.n] = V.ncols[s.n] || 1; }); squeezeCols(nodes, col, ncol, vis); }
  const SX = {}, SW = {}; let x = 8;
  if (S.scr === 'ns' && S.view !== 'flow') x += BUNDLE() ? 30 : Math.round(gapNeed(S.lv));
  vis.forEach(s => { const w = ncol[s.n] * C.colW; SX[s.n] = x; SW[s.n] = w; x += w + C.gap; });
  const W = Math.max(x, 640);
  const HH = measureH(nodes, C.nodeW), cells = {}, cT = {}, cST = {};
  nodes.forEach(n => { const key = n.ln + '|' + trkOf(n) + '|' + n.st + '|' + col[n.id]; (cells[key] = cells[key] || []).push(n); });
  Object.keys(cells).forEach(key => { const arr = cells[key].sort((a, c) => ((a.r || 0) - (c.r || 0)) || ((a.k === 'why') - (c.k === 'why'))), p = key.split('|');
    const h = arr.reduce((s, n) => s + HH[n.id], 0) + (arr.length - 1) * C.vg; (cT[p[0]] = cT[p[0]] || {})[p[1]] = Math.max(cT[p[0]][p[1]] || 0, h);
    const ks = p[0] + '|' + p[2]; (cST[ks] = cST[ks] || {})[p[1]] = Math.max(cST[ks][p[1]] || 0, h); });
  const rows = [], RY = {}, RYS = {}, bandBox = [], segs = []; let y = 0; const SH = storyH(vis, SW); if (SH){ rows.push({t:'story', k:'_story', y:0, h:SH}); y = SH; }
  // v38 (S01): 사람 레인 — 단계마다 업무 갈래를 위에서부터 따로 쌓음 (다른 단계의 갈래 때문에 생기던 빈 줄 제거, 레인 높이 = 단계별 높이 중 최대)
  D.lanes.forEach((l, i) => { if (l.onlyIn && l.onlyIn !== S.scr) return; const BS = {}; let hh = 0; const lns = []; let lab = false;
    vis.forEach(s => { const mp = cST[l.k + '|' + s.n]; if (!mp) return; const B = stackBands(mp, C.pad, 8, TLH, 0); BS[s.n] = B; hh = Math.max(hh, B.h); B.lns.forEach(x => { if (lns.indexOf(x) < 0) lns.push(x); }); lab = lab || B.lab; });
    const h = Math.max(C.minH, hh), bandsS = {}, linesS = {}; Object.keys(BS).forEach(k => { bandsS[k] = absBands(BS[k], y); linesS[k] = absLines(BS[k], y); });
    const B0 = cT[l.k] ? stackBands(cT[l.k], C.pad, 8, TLH, 0) : null, bands = absBands(B0, y), lines = absLines(B0, y);
    rows.push({t:'lane', k:l.k, y, h, l, i, bands, lines, bandsS, linesS, lns, lab}); RY[l.k] = {y, h, off:0, bands, lines, bandsS, linesS}; y += h; });
  let aiTop = y;
  if (ns){
    const y0ai = y + 14; let aiH = 0;
    const ins = C.colW - C.nodeW, SP = C.SP;
    vis.forEach(s => {
      const list = [];
      D.bands.forEach(b => {
        const subs = b.subs.filter(sid => cST[sid + '|' + s.n] != null); if (!subs.length) return;
        const sws = subs.map(sid => (kcol[sid + '|' + s.n] || 1) * C.colW - ins + 12), w = Math.max.apply(null, sws) + 2 * SP, th = titleH('gb', bandTitle(b), w);
        const qs = subs.map((sid, i) => { const ts = titleH('gs', subTitle(sid), sws[i]), SB = stackBands(cST[sid + '|' + s.n], C.pad, 3, TLH, 0); return {sid, sw:sws[i], ts, SB, h:ts + SB.h}; });
        list.push({b, st:s.n, w, th, h:th + qs.reduce((a, q) => a + q.h + 5, 0) + 3, subs:qs});
      });
      const L0 = SX[s.n] - 6 + ins / 2, R0 = SX[s.n] + SW[s.n] + 6 - ins / 2; let sx = L0, sy = y0ai, shelf = 0;
      list.forEach(sg => {
        if (sx > L0 + 1 && sx + sg.w > R0){ sx = L0; sy += shelf + C.sv; shelf = 0; }
        sg.x0 = sx; sg.y0 = sy; sg.y1 = sy + sg.h; let yy = sy + sg.th;
        sg.subs.forEach(q => { q.x0 = sx + SP; q.y0 = yy; q.y1 = yy + q.h; q.bands = absBands(q.SB, yy + q.ts); q.lines = absLines(q.SB, yy + q.ts); q.lns = q.SB.lns; q.lab = q.SB.lab;
          RYS[q.sid + '|' + s.n] = {y:yy, h:q.h, off:q.ts, x0:q.x0, segX:sx, shelfY:sy, bands:q.bands, lines:q.lines}; yy += q.h + 5; });
        sx += sg.w + C.sg; shelf = Math.max(shelf, sg.h); segs.push(sg);
      });
      aiH = Math.max(aiH, sy + shelf - y0ai);
    });
    rows.push({t:'aih', k:'_ai', y, h:14 + aiH + 10}); y += 14 + aiH + 10;
  }
  const pos = {};
  Object.keys(cells).forEach(key => { const arr = cells[key], n0 = arr[0], ry = D.subs[n0.ln] ? RYS[n0.ln + '|' + n0.st] : RY[n0.ln]; if (!ry || SX[n0.st] == null) return;
    const bd = ((ry.bandsS && ry.bandsS[n0.st]) || ry.bands || {})[trkOf(n0)] || {y:ry.y + (ry.off || 0), lh:0}; let yy = bd.y + (bd.lh || 0) + C.pad;
    arr.forEach(n => { const bx = ry.x0 != null ? ry.x0 + 6 + col[n.id] * C.colW : SX[n.st] + col[n.id] * C.colW + (C.colW - C.nodeW) / 2; pos[n.id] = {x:bx, y:yy, w:C.nodeW, h:HH[n.id]}; yy += HH[n.id] + C.vg; }); });
  const EDV = ED[S.scr + '|' + S.lv];
  let outN = nodes.filter(n => pos[n.id]);
  if (EDV){
    const del = EDV.del || {}, kd = EDV.kd || {}, tg = EDV.tg || {}, add = EDV.add || {}, mv = EDV.mv || {};
    outN = outN.filter(n => !del[n.id]).map(n => (kd[n.id] || tg[n.id] != null) ? Object.assign({}, n, kd[n.id] ? {k:kd[n.id]} : {}, tg[n.id] != null ? {tg:tg[n.id]} : {}) : n);
    Object.keys(add).forEach(id => { const a = add[id], base = D.subs[a.ln] ? RYS[a.ln + '|' + a.st] : RY[a.ln]; if (!S.stages.has(a.st) || SX[a.st] == null || !base) return;
      pos[id] = {x:SX[a.st] + a.dx, y:base.y + a.dy, w:C.nodeW, h:50}; outN.push({id, st:a.st, ln:a.ln, k:kd[id] || a.k, lb:a.lb, tg:tg[id] != null ? tg[id] : (a.tg || ''), added:1}); });
    Object.keys(mv).forEach(id => { if (pos[id] && !add[id]) pos[id] = Object.assign({}, pos[id], {x:pos[id].x + mv[id][0], y:pos[id].y + mv[id][1]}); });
    Object.keys(del).forEach(id => { delete pos[id]; });
  }
  let W2 = W, H2 = y + 14; outN.forEach(n => { const p = pos[n.id]; if (p){ W2 = Math.max(W2, p.x + p.w + 30); H2 = Math.max(H2, p.y + p.h + 30); } });
  return {V, C, vis, SX, SW, W:W2, H:H2, nodes:outN, rows, pos, bandBox, RY, RYS, segs, aiTop};
}
function noId(s){ return String(s || '').replace(/^(BR|TB)-[0-9A-Z]+(-[0-9]+)?\s*/, ''); }
function sh(s){ return String(s || ''); }
function nm(ids){ return String(ids || '').split(/\s*,\s*/).filter(Boolean).map(x => D.A6[x] ? sh(D.A6[x].n) : (D.A5[x] ? D.A5[x].n : (D.TB[x] ? sh(D.TB[x].lb) : x))).join(', '); }
function deId(s){ return String(s || '').replace(/(?:BR|TB)-[0-9A-Z]+(?:-[0-9]+)?/g, x => D.A6[x] ? '「' + sh(D.A6[x].n) + '」' : (D.A5[x] ? '「' + D.A5[x].n + '」' : (D.TB[x] ? '「' + sh(D.TB[x].lb) + '」' : ''))); }

function tgCls(t){ if (/^[①②③]/.test(t)) return 'gate'; if (t === 'Tool') return 'tool'; if (/즉시|상시|앞당김|재진입/.test(t)) return 'hot'; if (/건$/.test(t)) return 'cnt'; return 'own'; }
const TYM = {'분기':'◇ 분기', '합류':'◎ 합류', '분기·합류':'◇◎ 분기·합류', '시작':'▶ 시작', '종료':'■ 종료'};
function nodeDesc(n){
  // 흐름 (넓게)에서만: 이 박스가 다음으로 넘기는 것
  if (S.lv !== 6 || n.k === 'why' || n.k === 'gone') return '';
  if (n.k === 'mk'){
    const oe = D.views[6].ns.edges.filter(e => e[2] === 'o' && e[0] === n.id), to = uq(oe.map(e => findNode(6, 'ns', e[1])).filter(x => x && x.ln !== 'S0b').map(performer));
    return to.length ? '호출 → ' + to.join(', ') : (n.ln === 'S0b' ? '진행 현황 반영' : '');
  }
  const a6 = D.A6[n.id]; let it = a6 && a6.out ? (splitItems(a6.out)[0] || '') : (D.outnew && D.outnew[n.id]) || '';
  it = String(it).replace(/^[-•·\s]+/, '').trim(); return it ? '→ ' + it : '';
}
function blkHTML(n){
  const ts = n.tasks, cnt = ts.length;
  const sub = n.ai ? uq(ts.map(x => x.ln)).map(sid => D.subs[sid] ? D.subs[sid].name.replace(/ Agent$/, '') + ' ' + ts.filter(x => x.ln === sid).length : '').filter(Boolean).join(' · ')
    : ['h', 'nh', 'mk'].map(k => { const c = ts.filter(x => x.k === k).length; return c ? ({h:'직접 ', nh:'확인·판단 ', mk:''})[k] + c : ''; }).filter(Boolean).join(' · ');
  return '<div class="bh"><b>' + esc(n.lb) + '</b><span class="bc">' + cnt + '</span></div>' + (sub ? '<div class="bs">' + esc(sub) + '</div>' : '')
    + '<ul class="bt">' + ts.slice(0, 4).map(x => '<li>' + esc(rd(plain(T(tk(x.id), x.lb)))) + '</li>').join('') + (cnt > 4 ? '<li class="more">외 ' + (cnt - 4) + '개 — 누르면 전체</li>' : '') + '</ul>';
}
function nodeHTML(n){
  if (n.k === 'blk') return blkHTML(n);
  // 한눈에: 업무 이름만 (최대 3줄). 흐름 (넓게): 업무 이름 + 넘기는 것 한 줄
  const d = S.view === 'flow' ? nodeDesc(n) : '';
  return '<div class="lbl" data-k="' + esc(tk(n.id)) + '">' + T(tk(n.id), esc(rd(n.lb))) + '</div>' + (d ? '<div class="nds">' + esc(rd(d)) + '</div>' : '');
}
function place(el, r){ el.style.left = r.x + 'px'; el.style.top = r.y + 'px'; el.style.width = r.w + 'px'; el.style.height = r.h + 'px'; }
const MT = 1.9;  // As-Is ↔ To-be 전환 시간(초)
const BGP = {}; let RID = 0;
function pbg(key, cls){ let el = BGP[key]; const isNew = !el; if (isNew){ el = document.createElement('div'); BGP[key] = el; board.insertBefore(el, board.firstChild); } el.className = cls; el._rid = RID; el._new = isNew; return el; }
/* Source As-Is uses its own original renderer. No To-be layout or edge mutation applies. */
function sourceAsisView(){
  const source = D.sourceAsis, active = !!source && S.scr === 'asis';
  document.body.classList.toggle('source-asis', active);
  let panel = document.getElementById('sourceAsisPanel');
  if (!source) return false;
  if (!panel){
    const style = document.createElement('style');
    style.textContent = 'body.source-asis #stageWrap,body.source-asis #infobox,body.source-asis #steps,body.source-asis #foot,body.source-asis #tourcap{display:none!important}body.source-asis #controls>*:not(.source-switch):not(#btnExport){display:none!important}#sourceAsisPanel{background:white}#sourceAsisFrame{display:block;width:100%;height:calc(100vh - 90px);min-height:600px;border:0}';
    document.head.appendChild(style);
    document.getElementById('scrSeg').closest('.grp').classList.add('source-switch');
    panel = document.createElement('section'); panel.id = 'sourceAsisPanel';
    const note = document.createElement('div'); note.style.cssText = 'padding:6px 14px;font-size:12px;background:#f5f5f5';
    note.textContent = 'As-Is · 원본 화면 — 레벨·단계는 아래 원본 화면에서 선택하세요.';
    const frame = document.createElement('iframe'); frame.id = 'sourceAsisFrame';
    frame.title = 'As-Is 원본 프로세스 맵'; frame.setAttribute('sandbox', 'allow-scripts allow-downloads');
    frame.srcdoc = new TextDecoder('utf-8').decode(Uint8Array.from(atob(source.bytes_base64), c => c.charCodeAt(0)));
    panel.append(note, frame); document.getElementById('stageWrap').before(panel);
  }
  panel.hidden = !active;
  if (active){ document.body.classList.remove('present'); updateChrome(); return true; }
  return false;
}
function render(anim){
  if (sourceAsisView()) return;
  if (S.view === 'agent') S.view = 'compact';
  const morph = !!anim && render._scr != null && render._scr !== S.scr; render._scr = S.scr;
  clearTimeout(render._t); clearTimeout(render._m);
  document.body.classList.toggle('morph', morph); document.body.classList.toggle('to-ns', morph && S.scr === 'ns');
  document.body.classList.toggle('vflow', S.view === 'flow');   // 박스 크기를 재기 전에 보기별 글자 스타일 적용
  const M = S.M = layout(); RID++;
  board.style.width = M.W + 'px'; board.style.height = M.H + 'px'; labels.style.height = M.H + 'px'; head.style.width = M.W + 'px';
  M.vis.forEach((s, i) => { const el = pbg('st' + s.n, 'bg stband' + (i % 2 ? ' odd' : '')); el.style.left = (M.SX[s.n] - M.C.gap / 2) + 'px'; el.style.width = (M.SW[s.n] + M.C.gap) + 'px'; el.style.height = M.H + 'px'; });
  M.rows.forEach((r, i) => { const el = pbg('row' + r.k, 'bg row-' + r.t + (r.t === 'lane' ? ' ln-' + r.k + (i % 2 ? ' alt' : '') : '')); if (morph && el._new) el.classList.add('gin');
    el.style.top = r.y + 'px'; el.style.height = r.h + 'px'; el.style.width = M.W + 'px'; });
  if (M.agentView) M.vis.forEach(s => { const c = M.COL[s.n], h1 = pbg('agh|h|' + s.n, 'bg agh'); h1.style.left = c.hx + 'px'; h1.style.top = ((M.SH || 0) + 6) + 'px'; h1.style.width = '232px'; h1.textContent = '사람 역할';
    if (S.scr === 'ns'){ const h2 = pbg('agh|a|' + s.n, 'bg agh ai'); h2.style.left = c.ax + 'px'; h2.style.top = ((M.SH || 0) + 6) + 'px'; h2.style.width = '250px'; h2.textContent = 'AI Agent'; } });
  M.vis.forEach((s, i) => { if (!i) return; const el = pbg('sep' + s.n, 'bg sep'); el.style.left = (M.SX[s.n] - M.C.gap / 2) + 'px'; el.style.height = M.H + 'px'; });
  Object.keys(BGP).forEach(k => { if (BGP[k]._rid !== RID){ BGP[k].remove(); delete BGP[k]; } });
  $$('.gbox', board).forEach(e => e.remove());
  const f = document.createDocumentFragment(); groupBoxes(M).forEach(g => { if (morph) g.classList.add('gin'); f.appendChild(g); });
  (M.agentView ? [] : lineGroups(M)).forEach(g => { const el = document.createElement('div'); el.className = 'bg gbox lgrp ' + trkCls(g.l) + (morph ? ' gin' : ''); el.style.left = g.x0 + 'px'; el.style.top = g.y0 + 'px'; el.style.width = (g.x1 - g.x0) + 'px'; el.style.height = (g.y1 - g.y0) + 'px'; el.innerHTML = '<span class="lgl">' + esc(lineName(g.l)) + '</span>'; f.appendChild(el); });
  if (!M.agentView && (U.subBox || []).length){ const SB = new Set(U.subBox), sg = {};
    M.nodes.forEach(n => { const p = M.pos[n.id]; if (!p || n.k === 'why') return; if (S.scr === 'ns' && D.subs[n.ln]) return; const l = lineOf(n), s = subOf(n); if (!l || !s || !SB.has(s)) return;
      const k = l + '~' + s + '~' + n.st + '~' + n.ln; const b = sg[k] = sg[k] || {l, s, x0:1e9, y0:1e9, x1:-1e9, y1:-1e9}; b.x0 = Math.min(b.x0, p.x - 4); b.y0 = Math.min(b.y0, p.y - 6); b.x1 = Math.max(b.x1, p.x + p.w + 4); b.y1 = Math.max(b.y1, p.y + p.h + 3); });
    Object.values(sg).forEach(g => { const el = document.createElement('div'); el.className = 'bg gbox lgrp lsub ' + trkCls(g.l) + (morph ? ' gin' : ''); el.style.left = g.x0 + 'px'; el.style.top = g.y0 + 'px'; el.style.width = (g.x1 - g.x0) + 'px'; el.style.height = (g.y1 - g.y0) + 'px'; el.innerHTML = '<span class="lgl">' + esc(g.s) + '</span>'; f.appendChild(el); }); }
  board.insertBefore(f, board.firstChild);
  renderLabels(M, morph); renderHead(M, morph); syncNodes(M, anim, morph); renderStory(M);
  svg.innerHTML = MARKERS; $$('.elab', board).forEach(e => e.remove());
  const endMs = (MT + (S.mdl || 0)) * 1000;
  render._t = setTimeout(() => { drawEdges(); if (TOUR.on) tourApply(); }, morph ? endMs + 100 : (anim ? 680 : 0));
  if (morph) render._m = setTimeout(() => { document.body.classList.remove('morph', 'to-ns'); Object.keys(NODE_EL).forEach(id => { NODE_EL[id].style.transitionDelay = ''; }); $$('.gin').forEach(e => e.classList.remove('gin')); }, endMs + 180);
  updateChrome(); fitWrap();
  navPush();
  if (S.sel) setTimeout(() => { if (S.sel) showTb(S.sel); }, 0);
}
function groupBoxes(M){
  if (S.scr === 'ns' && M.fb){
    const out = [];
    M.fb.forEach(g => { const qx = [];
      g.subs.forEach(q => { const ps = M.nodes.filter(n => n.ln === q.sid && M.pos[n.id]).map(n => M.pos[n.id]); if (!ps.length) return; q.x0 = Math.min.apply(null, ps.map(p => p.x)) - 12; q.x1 = Math.max.apply(null, ps.map(p => p.x + p.w)) + 12; qx.push(q); });
      if (!qx.length) return; const L = Math.min.apply(null, qx.map(q => q.x0)) - 10, R = Math.max.apply(null, qx.map(q => q.x1)) + 10;
      const el = document.createElement('div'); el.className = 'bg gbox gb'; el.dataset.band = g.b.id; el.style.left = L + 'px'; el.style.width = (R - L) + 'px'; el.style.top = g.y0 + 'px'; el.style.height = (g.y1 - g.y0) + 'px';
      el.innerHTML = '<div class="gt" data-ag="' + g.b.id + '" title="' + esc(g.b.desc) + '">' + bandTitle(g.b) + '</div>'; out.push(el);
      qx.forEach(q => { const e2 = document.createElement('div'); e2.className = 'bg gbox gs'; e2.dataset.band = g.b.id; e2.dataset.sid = q.sid; e2.style.left = q.x0 + 'px'; e2.style.width = (q.x1 - q.x0) + 'px'; e2.style.top = q.y0 + 'px'; e2.style.height = (q.y1 - q.y0) + 'px';
        e2.innerHTML = '<div class="gt" data-ag="' + q.sid + '" title="' + esc(D.subs[q.sid].desc) + '">' + subTitle(q.sid) + '</div>'; out.push(e2); });
      g.L = L; g.R = R; });
    return out;
  }
  if (S.scr !== 'ns' || !M.segs) return [];
  const out = [];
  M.segs.forEach(sg => {
    const el = document.createElement('div'); el.className = 'bg gbox gb'; el.dataset.band = sg.b.id; el.dataset.st = sg.st;
    el.style.left = sg.x0 + 'px'; el.style.width = sg.w + 'px'; el.style.top = sg.y0 + 'px'; el.style.height = (sg.y1 - sg.y0) + 'px';
    el.innerHTML = '<div class="gt" data-ag="' + sg.b.id + '" title="' + esc(sg.b.desc) + ' — 누르면 이 Agent 정보">' + bandTitle(sg.b) + '</div>'; out.push(el);
    sg.subs.forEach(q => {
      const ps = M.nodes.filter(n => n.ln === q.sid && n.st === sg.st && M.pos[n.id]).map(n => M.pos[n.id]); if (!ps.length) return;
      const x0 = Math.min(q.x0, Math.min.apply(null, ps.map(p => p.x)) - 6), x1 = Math.max(q.x0 + q.sw, Math.max.apply(null, ps.map(p => p.x + p.w)) + 6);
      const e2 = document.createElement('div'); e2.className = 'bg gbox gs'; e2.dataset.band = sg.b.id; e2.dataset.st = sg.st; e2.dataset.sid = q.sid;
      e2.style.left = x0 + 'px'; e2.style.width = (x1 - x0) + 'px'; e2.style.top = q.y0 + 'px'; e2.style.height = (q.y1 - q.y0) + 'px';
      e2.innerHTML = '<div class="gt" data-ag="' + q.sid + '" title="' + esc(D.subs[q.sid].desc) + ' — 누르면 데이터·시스템 전체">' + subTitle(q.sid) + '</div>'; out.push(e2);
    });
  });
  return out;
}

function lineGroups(M){
  const out = [], gapX = M.C.colW * 1.5, bk = {};
  M.nodes.forEach(n => { const l = lineOf(n); if (!l) return; const p = M.pos[n.id]; if (!p) return; if (S.scr === 'ns' && D.subs[n.ln]) return;
    const r = D.subs[n.ln] && !M.flow ? (M.RYS || {})[n.ln + '|' + n.st] : M.RY[n.ln]; const LS = r && ((r.linesS && r.linesS[n.st]) || r.lines); if (!LS || !LS[l]) return;
    const k = n.ln + '|' + l + '|' + n.st; (bk[k] = bk[k] || {l, line:LS[l], ps:[]}).ps.push(p); });
  Object.keys(bk).forEach(k => { const g = bk[k], ps = g.ps.sort((a, c) => a.x - c.x); let seg = [ps[0]];
    const flush = () => { const minY = Math.min.apply(null, seg.map(p => p.y)), maxY = Math.max.apply(null, seg.map(p => p.y + p.h));
      out.push({l:g.l, x0:Math.min.apply(null, seg.map(p => p.x)) - 7, x1:Math.max.apply(null, seg.map(p => p.x + p.w)) + 7, y0:Math.max(g.line.y + 1, minY - TLH - 3), y1:maxY + 6}); };
    for (let i = 1; i < ps.length; i++){ const last = seg[seg.length - 1]; if (ps[i].x - (last.x + last.w) > gapX){ flush(); seg = [ps[i]]; } else seg.push(ps[i]); }
    flush(); });
  return out;
}
const LABP = {};
function renderLabels(M, morph){
  const seen = {};
  M.rows.forEach(r => {
    if (r.t !== 'lane' && r.t !== 'aih' && r.t !== 'agv' && r.t !== 'story') return;
    let el = LABP[r.k], html; const isNew = !el;
    if (isNew){ el = document.createElement('div'); LABP[r.k] = el; labels.appendChild(el); }
    el.style.top = r.y + 'px'; el.style.height = r.h + 'px';
    if (r.t === 'story'){ el.className = 'lc story'; html = '<span class="lt"><b>' + (S.scr === 'ns' ? 'To-be 흐름 설명' : 'As-Is → To-be') + '</b><small>' + (S.scr === 'ns' ? '번호 순서대로 진행됩니다. 같은 번호 안(예: 4-1, 4-2)은 수행 주체와 업무 순서이며, 지도의 같은 번호 박스가 해당 업무입니다. 색상은 박스 종류를 나타냅니다.' : '지금 흐름의 문제와 To-be에서 바뀌는 점') + '</small>' + (S.scr === 'ns' ? '<button type="button" class="tourgo" data-tourgo="1">▶ 흐름 따라가기</button><span class="stk"><i class="ai"></i>Agent<br><i class="hitl"></i>담당자 확인·판단<br><i class="hu"></i>사람 직접<br><i class="orc"></i>Orchestrator 신호·호출</span>' : '') + '</span>'; }
    else if (r.t === 'agv'){ el.className = 'lc agv'; html = '<span class="lt"><b>Agent 흐름</b><small>단계별로 왼쪽은 사람 역할, 오른쪽은 큰 기능 Agent의 담당 업무 묶음입니다. 화살표는 묶음 간 업무 흐름이며, 굵을수록 건수가 많습니다.</small><small class="agk"><i class="hb"></i>사람 → Agent<br><i class="bh"></i>Agent → 사람<br><i class="bb"></i>Agent → Agent<br><i class="hh"></i>사람 → 사람<br><i class="o"></i>Orchestrator 신호</small></span>'; }
    else if (r.t === 'lane'){ el.className = 'lc lane ln-' + r.k + (r.lab ? ' has-trk' : ''); html = '<span class="ic lic">' + IC.person + '</span><span class="lt"><b>' + esc(r.l.name) + '</b><small>' + esc(r.l.sub) + '</small></span>'
; }
    else { const bs = {}, ss = {}; (M.segs || []).forEach(sg => { bs[sg.b.id] = 1; sg.subs.forEach(sb => { ss[sb.sid] = 1; }); }); (M.fb || []).forEach(g => { bs[g.b.id] = 1; g.subs.forEach(q => { ss[q.sid] = 1; }); });
      if (M.agentView) M.nodes.forEach(b => { if (b.ai){ bs[b.band.id] = 1; b.tasks.forEach(x => { ss[x.ln] = 1; }); } });
      el.className = 'lc aih ai-all' + (isNew && morph ? ' gin' : '');
      html = '<div class="aiin"><span class="ic lic">' + IC.spark + '</span><span class="lt"><b>AI Agent</b><small>큰 기능 Agent ' + Object.keys(bs).length + ' · 세부 Agent ' + Object.keys(ss).length + '</small></span></div>'; }
    if (el._h !== html){ el.innerHTML = html; el._h = html; }
    seen[r.k] = 1;
  });
  Object.keys(LABP).forEach(k => { if (!seen[k]){ LABP[k].remove(); delete LABP[k]; } });
}
const HEADP = {};
function stageStat(s){
  const sc = S.scen[s.n]; if ((!S.path || S.path === 'all') && !sc) return S.scr === 'ns' ? s.ns : s.asis;
  const pl = sc ? scenLabel(sc) : S.path;
  const V6 = D.views[6][S.scr].nodes.filter(n => n.st === s.n && pathOK(n) && n.k !== 'why' && n.k !== 'pt'), c = ks => V6.filter(n => ks.indexOf(n.k) >= 0).length;
  if (S.scr === 'ns') return pl + ' 경로 · Agent ' + c(['a', 'na']) + ' · 확인 ' + c(['nh']) + ' · 사람 ' + c(['h']) + ' · 소멸 ' + c(['gone']);
  return pl + ' 경로 · Lv5 ' + D.views[5].asis.nodes.filter(n => n.st === s.n && pathOK(n)).length + ' · Lv6 ' + V6.length;
}
function renderHead(M, morph){
  const seen = {};
  M.vis.forEach(s => {
    const L = M.SX[s.n] - 4, W = M.SW[s.n] + 8, wd = M.SW[s.n] > 760 ? ' wide' : '';
    const nmS = (S.scr === 'ns' && s.nameNs) ? s.nameNs : s.name;   /* v38: To-be 단계 재편 — 이름·통합 표시 */
    const rows = [['r1', '<span class="cvi"><span class="sn">' + s.n + '</span><span>' + esc(nmS.replace(/^\d+\.\s*/, '')) + (S.scr === 'ns' && s.into ? ' · To-be에서 ' + s.into + '단계로 통합' : '') + '</span></span>'], ['r2', '<span class="cvi"><span>' + esc(S.scr === 'ns' && s.into && s.intoWhy ? s.intoWhy : stageStat(s)) + '</span></span>']];
    if (S.scr === 'ns') rows.push(['r3', '<span class="cvi"><span>' + esc(s.gate) + '</span></span>']);
    rows.forEach(([r, html]) => { const k = r + s.n; let el = HEADP[k]; const isNew = !el;
      if (isNew){ el = document.createElement('div'); HEADP[k] = el; head.appendChild(el); }
      el.className = 'cv ' + r + wd + (isNew && morph ? ' gin' : ''); el.style.left = L + 'px'; el.style.width = W + 'px'; if (el._h !== html){ el.innerHTML = html; el._h = html; } seen[k] = 1; });
  });
  Object.keys(HEADP).forEach(k => { if (!seen[k]){ HEADP[k].remove(); delete HEADP[k]; } });
  $('#corner').innerHTML = '<b>' + (S.scr === 'ns' ? 'To-be' : 'As-Is') + ' · Lv.' + S.lv + '</b><span>업무 단계 (Lv.4)</span><span>' + (S.scr === 'ns' ? 'Lv6 기준 구성' : '규모') + '</span><span>' + (S.scr === 'ns' ? '판단 게이트' : '') + '</span>';
}
/* v38 ② To-be 재구성: As-Is ↔ To-be 전환 때 ID가 달라도 원본 연결(TB.ref · optMap)을 따라 박스가 그 자리로 이동 (S01) */
let REFS = null, RREF = null;
function refMaps(){ if (REFS) return; REFS = {}; RREF = {};
  Object.keys(D.TB || {}).forEach(id => { const r = (D.TB[id].t !== 'X' && D.TB[id].ref) || []; if (r.length && !(r.length === 1 && r[0] === id)){ REFS[id] = r; r.forEach(x => (RREF[x] = RREF[x] || []).push(id)); } });
  Object.keys(D.optMap || {}).forEach(id => { const r = D.optMap[id].original_l5 || []; REFS[id] = r; r.forEach(x => (RREF[x] = RREF[x] || []).push(id)); }); }
function takeRef(n, M, TAKEN){ refMaps(); const cand = (S.scr === 'ns' ? REFS[n.id] : RREF[n.id]) || [];
  const c = cand.find(x => NODE_EL[x] && !M.pos[x] && !TAKEN.has(x)); if (!c) return null; TAKEN.add(c); const el = NODE_EL[c]; delete NODE_EL[c]; el.dataset.id = n.id; NODE_EL[n.id] = el; return el; }
function syncNodes(M, anim, morph){
  const seen = new Set(), si = {}, TAKEN = new Set(); M.vis.forEach((s, i) => { si[s.n] = i; }); S.mdl = morph ? (M.vis.length - 1) * 0.09 + 0.12 : 0;
  M.nodes.forEach(n => {
    const p = M.pos[n.id]; seen.add(n.id);
    let el = NODE_EL[n.id]; if (!el && morph && D.design_mode === 'restructure') el = takeRef(n, M, TAKEN); const isNew = !el;
    if (isNew){ el = document.createElement('div'); el.dataset.id = n.id; board.appendChild(el); NODE_EL[n.id] = el; place(el, p); if (anim) el.style.opacity = '0'; }
    if (morph){ const d = (si[n.st] || 0) * 0.09 + (D.subs[n.ln] ? 0.12 : 0); el.style.transitionDelay = (isNew ? MT * 0.78 + d : d).toFixed(2) + 's'; } else if (!document.body.classList.contains('morph')) el.style.transitionDelay = '';
    el.className = 'nd k-' + n.k + ' L' + S.lv + (n.k === 'blk' ? (n.ai ? ' blk-ai' + (n.band && n.band.id === 'B0' ? ' blk-orc' : '') : ' blk-h') : '') + (S.hl && S.hl.has(n.id) ? ' hl' : '');
    el.innerHTML = nodeHTML(n); el.title = plain(T(tk(n.id), esc(n.lb))) + painTip(n);
    place(el, p);
    if (isNew && anim) requestAnimationFrame(() => requestAnimationFrame(() => { el.style.opacity = ''; })); else el.style.opacity = '';
  });
  Object.keys(NODE_EL).forEach(id => { if (!seen.has(id)){ const el = NODE_EL[id]; delete NODE_EL[id]; if (anim){ el.style.transitionDelay = '0s'; el.style.opacity = '0'; el.style.pointerEvents = 'none'; setTimeout(() => el.remove(), morph ? 700 : 420); } else el.remove(); } });
  if (S.edit) setEditable(true);
}
const MARKERS = '<defs>' + [['m-g','var(--e-def)',6.5],['m-r','var(--e-ai)',6.5],['m-o','var(--e-hitl)',6.5],['m-v','var(--e-rej)',6.5],['m-p','var(--e-adv)',6.5],['m-x','var(--ds-gray-dark)',5.5],['m-k','var(--ink-strong)',6.5],['m-bhb','var(--ds-chart-gray-400)',5],['m-bbh','var(--k-hitl)',5],['m-bbb','var(--ds-red-200)',5],['m-bsig','var(--ds-chart-gray-400)',4.5]].map(([id, c, s]) => '<marker id="' + id + '" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="' + s + '" markerHeight="' + s + '" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" style="fill:' + c + '"/></marker>').join('') + '</defs>';
const AIK = {a:1, na:1, mk:1};
function edgeCls(t, a, b){
  if (t === 'o') return 'e e-orc';
  let c = 'e';
  if (t === 'l') c += ' e-loop'; else if (t === 'r') c += ' e-rej';
  if (S.scr === 'ns' && t !== 'l' && t !== 'r'){
    const ai = AIK[a.k] || AIK[b.k], hitl = a.k === 'nh' || b.k === 'nh';
    if (a.k === 'adv' || b.k === 'adv') c += ' e-adv'; else if (ai && hitl) c += ' e-hitl'; else if (AIK[a.k] && AIK[b.k]) c += ' e-ai';
  }
  return c;
}
function markerFor(c){ return /agf-bb/.test(c) ? 'm-bbb' : /agf-bh/.test(c) ? 'm-bbh' : /agf-hb/.test(c) ? 'm-bhb' : /agf-hh/.test(c) ? 'm-g' : /e-orc/.test(c) ? 'm-k' : /e-rej/.test(c) ? 'm-v' : /e-hitl/.test(c) ? 'm-o' : /e-adv/.test(c) ? 'm-p' : /e-ai/.test(c) ? 'm-r' : 'm-g'; }
function hits(pts, rects, a, b){
  let n = 0;
  for (let i = 0; i < pts.length - 1; i++){
    const [x1, y1] = pts[i], [x2, y2] = pts[i + 1], mnx = Math.min(x1, x2), mxx = Math.max(x1, x2), mny = Math.min(y1, y2), mxy = Math.max(y1, y2);
    rects.forEach(r => { if (r.id === a || r.id === b) return; if (mxx > r.x + 2 && mnx < r.x + r.w - 2 && mxy > r.y + 2 && mny < r.y + r.h - 2) n++; });
  }
  return n;
}
function despike(p){
  // 같은 x(또는 y) 위에서 갔다가 되돌아오는 꺾임(박스에 닿은 뒤 위로 더 뻗는 선)과 겹친 점을 지운다
  const q = [];
  for (const pt of p){
    if (q.length && Math.abs(q[q.length - 1][0] - pt[0]) < 0.01 && Math.abs(q[q.length - 1][1] - pt[1]) < 0.01) continue;
    q.push(pt);
    while (q.length >= 3){
      const [a, b, c] = q.slice(-3);
      const vx = Math.abs(a[0] - b[0]) < 0.01 && Math.abs(b[0] - c[0]) < 0.01, hy = Math.abs(a[1] - b[1]) < 0.01 && Math.abs(b[1] - c[1]) < 0.01;
      if (vx || hy) q.splice(q.length - 2, 1); else break;
    }
  }
  return q;
}
function toD(p){
  p = despike(p);
  const f = v => v.toFixed(1);
  if (p.length < 3) return 'M' + p.map(q => f(q[0]) + ',' + f(q[1])).join(' L');
  let d = 'M' + f(p[0][0]) + ',' + f(p[0][1]);
  for (let i = 1; i < p.length - 1; i++){
    const [x0, y0] = p[i - 1], [x1, y1] = p[i], [x2, y2] = p[i + 1], l1 = Math.hypot(x1 - x0, y1 - y0), l2 = Math.hypot(x2 - x1, y2 - y1), r = 0;   /* 90도로 꺾음 */
    if (r < 0.5){ d += ' L' + f(x1) + ',' + f(y1); continue; }
    d += ' L' + f(x1 - (x1 - x0) / l1 * r) + ',' + f(y1 - (y1 - y0) / l1 * r) + ' Q' + f(x1) + ',' + f(y1) + ' ' + f(x1 + (x2 - x1) / l2 * r) + ',' + f(y1 + (y2 - y1) / l2 * r);
  }
  const z = p[p.length - 1]; return d + ' L' + f(z[0]) + ',' + f(z[1]);
}
let RINFO = null, TRECTS = [];
function xrowRoute(A, B, t, rects, a, b, off){
  // 촘촘한 To-be 지도: 세로는 열 사이 틈, 가로는 줄 위·아래 여백으로만 다녀서 박스를 지나가지 않게
  const RA = RINFO && RINFO[a], RB = RINFO && RINFO[b]; if (!RA || !RB) return null;
  const same = RA.top === RB.top, fwd = B.x >= A.x + A.w + 4;
  if (same && fwd && t !== 'l' && t !== 'r'){
    // 같은 줄 앞으로 가는 선: 바로 옆이면 직선, 사이에 박스가 있으면 줄 위·아래 여백으로 넘어가기
    const y1 = A.y + A.h / 2, y2 = B.y + B.h / 2, g = (S.M.C.colW - S.M.C.nodeW) / 2, o = off / 3, ao = Math.abs(off) / 2;
    if (Math.abs(y1 - y2) < 1.5 && hits([[A.x + A.w, y1], [B.x - 1, y1]], rects, a, b) === 0) return null;
    // 높이가 달라도 위아래가 겹치면 겹친 부분 가운데로 곧게 (같은 줄 이웃 박스는 늘 직선 화살표)
    const oy0 = Math.max(A.y, B.y), oy1 = Math.min(A.y + A.h, B.y + B.h);
    if (oy1 - oy0 > 8){ const ym = Math.min(oy0 + 14, (oy0 + oy1) / 2) + off / 4, sp = [[A.x + A.w, ym], [B.x - 1, ym]]; if (hits(sp, rects, a, b) === 0) return {pts:sp, ex:B.x, ey:ym, h:0}; }
    const g1 = A.x + A.w + g + o, g2 = B.x - g + o, cand = [];
    [RA.nodeTop + 1 + ao, RA.bottom - 3 - ao].forEach(yc => { const top = yc < B.y;
      cand.push({pts:[[A.x + A.w, y1], [g1, y1], [g1, yc], [g2, yc], [g2, y2], [B.x - 1, y2]], ex:B.x, ey:y2});
      cand.push({pts:[[A.x + A.w, y1], [g1, y1], [g1, yc], [B.x + B.w / 2 + o, yc], [B.x + B.w / 2 + o, top ? B.y - 1 : B.y + B.h + 1]], ex:B.x + B.w / 2 + o, ey:top ? B.y : B.y + B.h}); });
    let best = null; cand.forEach((c, k) => { c.h = hits(c.pts, rects, a, b) * 10 + k * 0.01 + entPen(c.pts); if (!best || c.h < best.h) best = c; });
    return best;
  }
  if ((RA.ai || RB.ai) && S.M.aiTop != null){
    const M = S.M, o = off / 2, ao = Math.abs(off) / 2, g = (M.C.colW - M.C.nodeW) / 2, yTop = M.aiTop + 7 + ao;
    const xa = A.x + A.w / 2 + o, xb = B.x + B.w / 2 + o, stL = st => M.SX[st] - Math.max(7, M.C.gap / 2) + o / 3;
    const cA = RA.ai ? RA.nodeTop + 1 + ao : 0, cB = RB.ai ? RB.nodeTop + 1 + ao : 0;
    let pts;
    if (RA.ai && RB.ai && RA.st === RB.st && RA.segX === RB.segX && RA.shelfY === RB.shelfY){
      const ix = RA.segX + 3 + o / 3; pts = [[xa, A.y], [xa, cA], [ix, cA], [ix, cB], [xb, cB], [xb, B.y - 1]];
    } else {
      pts = [];
      if (RA.ai){ const ix = RA.segX + 3 + o / 3, sy = RA.shelfY - 5 - ao; pts.push([xa, A.y], [xa, cA], [ix, cA], [ix, sy]);
        if (RB.ai && RB.st === RA.st && RB.shelfY === RA.shelfY){ const jx = RB.segX + 3 + o / 3; pts.push([jx, sy], [jx, cB], [xb, cB], [xb, B.y - 1]); return {pts, ex:xb, ey:B.y, h:hits(pts, rects, a, b) * 10}; }
        pts.push([stL(RA.st), sy]);
        if (RB.ai && RB.st === RA.st){ const sy2 = RB.shelfY - 5 - ao, jx = RB.segX + 3 + o / 3; pts.push([stL(RA.st), sy2], [jx, sy2], [jx, cB], [xb, cB], [xb, B.y - 1]); return {pts, ex:xb, ey:B.y, h:hits(pts, rects, a, b) * 10}; }
        pts.push([stL(RA.st), yTop]);
      } else { const gx = A.x + A.w + g + o / 3; pts.push([A.x + A.w, A.y + A.h / 2], [gx, A.y + A.h / 2], [gx, yTop]); }
      if (RB.ai){ const sy2 = RB.shelfY - 5 - ao, jx = RB.segX + 3 + o / 3; pts.push([stL(RB.st), yTop], [stL(RB.st), sy2], [jx, sy2], [jx, cB], [xb, cB], [xb, B.y - 1]); }
      else { const gx = B.x - g + o / 3; pts.push([gx, yTop], [gx, RB.bottom - 3 - ao], [xb, RB.bottom - 3 - ao], [xb, B.y + B.h + 1]); }
    }
    const end = pts[pts.length - 1], up = end[1] > pts[pts.length - 2][1] ? false : true;
    return {pts, ex:end[0], ey:up ? B.y + B.h : B.y, h:hits(pts, rects, a, b) * 10};
  }
  const g = (S.M.C.colW - S.M.C.nodeW) / 2, o = off / 3, cy = A.y + A.h / 2, by = B.y + B.h / 2, ao = Math.abs(off) / 2;
  const chans = same ? [RB.bottom - 3 - ao, RB.nodeTop + 1 + ao] : [RB.top > RA.top ? RB.nodeTop + 1 + ao : RB.bottom - 3 - ao];
  const cand = [];
  chans.forEach(yc => {
    const top = yc < B.y, ent = top ? B.y - 1 : B.y + B.h + 1, ey = top ? B.y : B.y + B.h, xb = B.x + B.w / 2 + off;
    [[A.x + A.w, A.x + A.w + g + o], [A.x, A.x - g + o]].forEach(([sx, gx]) => {
      cand.push({pts:[[sx, cy], [gx, cy], [gx, yc], [xb, yc], [xb, ent]], ex:xb, ey});
      [[B.x - g + o, B.x - 1], [B.x + B.w + g + o, B.x + B.w + 1]].forEach(([gx2, ex]) => cand.push({pts:[[sx, cy], [gx, cy], [gx, yc], [gx2, yc], [gx2, by], [ex, by]], ex, ey:by}));
    });
  });
  let best = null; cand.forEach((c, k) => { c.h = hits(c.pts, rects, a, b) * 10 + k * 0.01 + entPen(c.pts); if (!best || c.h < best.h) best = c; });
  return best;
}
function route(A, B, t, rects, a, b, off){
  const xr = xrowRoute(A, B, t, rects, a, b, off); if (xr && xr.h < 10) return xr;
  const ax2 = A.x + A.w, bx1 = B.x;
  if (t !== 'l' && t !== 'r' && bx1 >= ax2 + 4){
    const y1 = A.y + A.h / 2, y2 = B.y + B.h / 2, cands = [], near = Math.min(18, (bx1 - ax2) / 2);
    if (Math.abs(y1 - y2) < 1.5) cands.push({pts:[[ax2, y1], [bx1 - 1, y1]]});
    [bx1 - near + off, ax2 + near + off, (ax2 + bx1) / 2 + off].forEach(xv => cands.push({pts:[[ax2, y1], [xv, y1], [xv, y2], [bx1 - 1, y2]], vx:xv, vy1:y1, vy2:y2}));
    [A.y + A.h + 16 + Math.abs(off), A.y - 16 - Math.abs(off), B.y - 16 - Math.abs(off), B.y + B.h + 16 + Math.abs(off)].forEach(yg => cands.push({pts:[[ax2, y1], [ax2 + near, y1], [ax2 + near, yg], [bx1 - near, yg], [bx1 - near, y2], [bx1 - 1, y2]], vx:bx1 - near, vy1:yg, vy2:y2}));
    let best = null; cands.forEach((c, k) => { c.h = hits(c.pts, rects, a, b) * 10 + k * 0.01 + entPen(c.pts); if (!best || c.h < best.h) best = c; });
    return Object.assign({ex:bx1, ey:y2}, best);
  }
  const ox1 = Math.max(A.x, B.x), ox2 = Math.min(A.x + A.w, B.x + B.w);
  if (t !== 'l' && t !== 'r' && ox2 - ox1 > 12){
    const x = (ox1 + ox2) / 2 + off;
    if (B.y >= A.y + A.h) return {pts:[[x, A.y + A.h], [x, B.y - 1]], ex:x, ey:B.y, vx:x, vy1:A.y + A.h, vy2:B.y, vert:1};
    if (A.y >= B.y + B.h) return {pts:[[x, A.y], [x, B.y + B.h + 1]], ex:x, ey:B.y + B.h, vx:x, vy1:A.y, vy2:B.y + B.h, vert:1};
  }
  const xa = A.x + A.w / 2 + off, xb = B.x + B.w / 2 - off, cands = [];
  if (t !== 'l' && t !== 'r'){ const down = B.y >= A.y + A.h, upw = A.y >= B.y + B.h;
    if (down || upw) [7, 13, 19].forEach(dv => { const ym = down ? B.y - dv - Math.abs(off) / 2 : B.y + B.h + dv + Math.abs(off) / 2; cands.push({pts:[[xa, down ? A.y + A.h : A.y], [xa, ym], [xb, ym], [xb, down ? B.y - 1 : B.y + B.h + 1]], ex:xb, ey:down ? B.y : B.y + B.h}); }); }
  [16, 30, 46, 64, 84].forEach(dv => {
    const yb = Math.max(A.y + A.h, B.y + B.h) + dv + Math.abs(off), yt = Math.min(A.y, B.y) - dv - Math.abs(off);
    cands.push({pts:[[xa, A.y + A.h], [xa, yb], [xb, yb], [xb, B.y + B.h + 1]], ex:xb, ey:B.y + B.h, loop:1}, {pts:[[xa, A.y], [xa, yt], [xb, yt], [xb, B.y - 1]], ex:xb, ey:B.y, loop:1});
  });
  if (B.x + B.w + 8 < A.x) [B.x + B.w + 16 + Math.abs(off), A.x - 16 - Math.abs(off)].forEach(gx => cands.push({pts:[[A.x, A.y + A.h / 2], [gx, A.y + A.h / 2], [gx, B.y + B.h / 2], [B.x + B.w + 1, B.y + B.h / 2]], ex:B.x + B.w, ey:B.y + B.h / 2, loop:1}));
  let best = null; cands.forEach((c, k) => { c.h = hits(c.pts, rects, a, b) * 10 + k * 0.01 + entPen(c.pts); if (!best || c.h < best.h) best = c; });
  return best;
}
function ov(a, b){ return a.x < b.x + b.w - 1 && b.x < a.x + a.w - 1 && a.y < b.y + b.h - 1 && b.y < a.y + a.h - 1; }
function placeLabel(text, g, cls, rects, placed, host, A, B, eid){
  const el = document.createElement('div'); el.className = 'elab ' + (/agfl/.test(cls) ? 'bl ' + (cls.split(' ')[1] || '') : /bndl/.test(cls) ? 'bl ' + ((cls.match(/bnd-(\w+)/) || [])[1] || '') : /hand/.test(cls) ? 'x' : /e-orc/.test(cls) ? 'k' : /e-rej/.test(cls) ? 'v' : /e-hitl/.test(cls) ? 'o' : /e-ai/.test(cls) ? 'r' : 'g');
  el.textContent = text; el.title = text; if (eid) el.dataset.e = eid; (host || board).appendChild(el);
  const w = el.offsetWidth, h = el.offsetHeight, c = [], P = g.pts;
  for (let i = 0; i < P.length - 1; i++){
    const [x1, y1] = P[i], [x2, y2] = P[i + 1], hz = Math.abs(y1 - y2) < 0.5, len = Math.hypot(x2 - x1, y2 - y1);
    if (len < 22) continue;
    [0.5, 0.3, 0.7, 0.15, 0.85].forEach(f => { const mx = x1 + (x2 - x1) * f, my = y1 + (y2 - y1) * f;
      if (hz) [[-h - 3], [3], [-h - 14], [14]].forEach(([dy]) => c.push([mx - w / 2, my + dy])); else [[5], [-w - 5], [18], [-w - 18]].forEach(([dx]) => c.push([mx + dx, my - h / 2])); });
  }
  const s0 = P[0]; c.push([s0[0] + 4, s0[1] - h - 18], [s0[0] + 4, s0[1] + 18]);
  if (A) c.push([A.x + A.w - w / 2, A.y - h - 5], [A.x + A.w - w / 2, A.y + A.h + 5], [A.x + A.w - w + 10, A.y - h - 5]);
  if (B) c.push([B.x - w / 2, B.y - h - 5], [B.x - w / 2, B.y + B.h + 5], [B.x - w - 6, B.y - h - 5], [B.x + 6, B.y - h - 5]);
  // 더 멀리 떨어진 자리도 후보로 (박스가 빽빽한 곳)
  for (let i = 0; i < P.length - 1; i++){ const [x1, y1] = P[i], [x2, y2] = P[i + 1], hz = Math.abs(y1 - y2) < 0.5, mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
    if (hz) [[-h - 26], [26], [-h - 40], [40]].forEach(([dy]) => c.push([mx - w / 2, my + dy])); else [[30], [-w - 30]].forEach(([dx]) => c.push([mx + dx, my - h / 2])); }
  if (A) c.push([A.x - w - 6, A.y + A.h / 2 - h / 2], [A.x + A.w + 6, A.y - h - 18]);
  if (B) c.push([B.x + B.w + 6, B.y + B.h / 2 - h / 2], [B.x - w - 6, B.y + B.h + 8]);
  if (!c.length) c.push([g.ex - w - 4, g.ey - h - 2]);
  P.forEach(q => [50, 80, 110].forEach(r => [[0, -1], [0, 1], [1, 0], [-1, 0], [1, -1], [-1, -1], [1, 1], [-1, 1]].forEach(([dx, dy]) => c.push([q[0] + dx * r - w / 2, q[1] + dy * r - h / 2]))));   // v36 먼 자리 후보 (앞의 가까운 자리가 먼저)
  let best = c[0], bs = 1e9;
  for (const p of c){ const R = {x:p[0], y:p[1], w, h}, s = rects.filter(r => ov(r, R)).length * 10 + placed.filter(r => ov(r, R)).length * 14; if (s < bs){ bs = s; best = p; if (!s) break; } }
  el.style.left = best[0] + 'px'; el.style.top = best[1] + 'px'; placed.push({x:best[0], y:best[1], w, h});
}
function agRoute(M, na, nb, A, B, i){
  // 같은 단계: 사람→Agent는 두 열 사이 틈으로 가로, Agent→사람은 틈의 다른 자리로 되돌아감, Agent↔Agent는 오른쪽 괄호, 사람↔사람은 왼쪽 괄호. 다른 단계: 위 통로
  const o = ((i % 6) - 2.5) * 5, ca = M.COL[na.st], cb = M.COL[nb.st], ya = A.y + A.h * (na.ai ? .62 : .38), yb = B.y + B.h * (nb.ai ? .38 : .62);
  let pts;
  if (na.st === nb.st){
    if (!na.ai && nb.ai){ const gx = ca.cx - 10 + o / 2; pts = [[A.x + A.w, ya], [gx, ya], [gx, yb], [B.x - 1, yb]]; }
    else if (na.ai && !nb.ai){ const gx = ca.cx + 10 + o / 2; pts = [[A.x, ya], [gx, ya], [gx, yb], [B.x + B.w + 1, yb]]; }
    else if (na.ai && nb.ai){ const rx = ca.rx + Math.abs(o); pts = [[A.x + A.w, A.y + A.h / 2], [rx, A.y + A.h / 2], [rx, B.y + B.h / 2], [B.x + B.w + 1, B.y + B.h / 2]]; }
    else { const lx = ca.lx - Math.abs(o); pts = [[A.x, A.y + A.h / 2], [lx, A.y + A.h / 2], [lx, B.y + B.h / 2], [B.x - 1, B.y + B.h / 2]]; }
  } else {
    const yc = M.TOP - 16 - Math.abs(o) / 2, fw = nb.st > na.st;
    const sx = fw ? M.SX[nb.st] - M.C.gap / 2 + o : M.SX[nb.st] + M.SW[nb.st] + M.C.gap / 2 + o;
    const ex = na.ai ? ca.rx + Math.abs(o) / 2 : (S.scr === 'ns' ? ca.cx + o / 2 : ca.hx + 232 + 10 + o / 2);
    const tx = nb.ai ? cb.cx - 6 + o / 2 : cb.lx + o / 3;
    pts = [[A.x + A.w, A.y + A.h / 2], [ex, A.y + A.h / 2], [ex, yc], [sx, yc], [tx, yc], [tx, B.y + B.h / 2], [nb.ai ? B.x - 1 : B.x - 1, B.y + B.h / 2]];
    if (!nb.ai) pts[5] = [tx, B.y + B.h / 2];
  }
  const P = pts.filter((p, k) => !k || Math.abs(p[0] - pts[k - 1][0]) > .5 || Math.abs(p[1] - pts[k - 1][1]) > .5);
  const L = P[P.length - 1]; return {pts:P, ex:L[0], ey:L[1], h:0};
}
function drawEdges(){
  const M = S.M; svg.setAttribute('width', M.W); svg.setAttribute('height', M.H); svg.style.width = M.W + 'px'; svg.style.height = M.H + 'px';
  svg.innerHTML = MARKERS; $$('.elab', board).forEach(e => e.remove());
  const rects = Object.keys(M.pos).map(id => Object.assign({id}, M.pos[id])), by = {}; M.nodes.forEach(n => { by[n.id] = n; });
  const placed = [], f = document.createDocumentFragment(); M.geo = []; trunkPrep(M);
  TRECTS = []; (M.fb || []).forEach(g => { if (g.L != null) TRECTS.push({x:g.L + 6, y:g.y0 + 3, w:260, h:Math.max(10, g.th - 5)}); g.subs.forEach(q => { if (q.x0 != null) TRECTS.push({x:q.x0 + 6, y:q.y0 + 3, w:240, h:Math.max(10, q.ts - 5)}); }); });
  (M.segs || []).forEach(sg => { TRECTS.push({x:sg.x0 + 6, y:sg.y0 + 3, w:sg.w - 12, h:Math.max(10, sg.th - 5)}); sg.subs.forEach(q => TRECTS.push({x:q.x0 + 6, y:q.y0 + 3, w:q.sw - 12, h:Math.max(10, q.ts - 5)})); });
  RINFO = {}; M.nodes.forEach(n => { const ai = !!D.subs[n.ln], r = ai && !M.flow ? (M.RYS || {})[n.ln + '|' + n.st] : M.RY[n.ln]; if (!r) return; const bd = ((r.bandsS && r.bandsS[n.st]) || r.bands || {})[trkOf(n)];
    RINFO[n.id] = bd ? {top:bd.y, bottom:bd.y + bd.h, nodeTop:bd.y + (bd.lh || 0) + 2, st:n.st, ai:ai && !M.flow, segX:r.segX, shelfY:r.shelfY} : {top:r.y, bottom:r.y + r.h, nodeTop:r.y + (r.off || 0) + 2, st:n.st, ai:ai && !M.flow, segX:r.segX, shelfY:r.shelfY}; });
  const BND = false, segOf = {}, bmap = {}, ENDS = {};
  if (BND) M.segs.forEach(sg => { segOf[sg.b.id + '|' + sg.st] = sg; });
  const gOf = n => !n ? '' : (D.subs[n.ln] ? 'B:' + bandOf(n.ln).id + '|' + n.st : 'H:' + n.ln + '|' + n.st);
  const EDV = ED[S.scr + '|' + S.lv], dels = new Set(((EDV && EDV.ed) || []).map(e => e[0] + '>' + e[1]));
  const ELIST = (M.agentView ? M.V.edges.filter(e => !dels.has(e[0] + '>' + e[1])).concat(((EDV && EDV.ea) || []).map(e => [e[0], e[1], 's', ''])) : effEdges(S.scr + '|' + S.lv)), PRE = sepRoutes(ELIST, M, rects, by);
  ELIST.forEach(([a, b, t, lab, ex, eoff, eadd, ulab], i) => {
    const A = M.pos[a], Bp = M.pos[b]; if (!A || !Bp) return;
    const cls = M.agentView ? 'e agf agf-' + t + (t === 'o' ? ' e-orc' : '') : edgeCls(t, by[a], by[b]), off = eoff || 0, g = PRE[i];
    const d = toD(g.pts); M.geo.push({id:a + '>' + b, d, t, pts:g.pts});   /* v26: 공통 줄기 없음 — 경로는 sepRoutes가 미리 계산·분리 */
    const isX = !M.agentView && S.scr === 'ns' && (t === 'o' ? S.view !== 'flow' : (Math.abs((A.y + A.h / 2) - (Bp.y + Bp.h / 2)) > 24 || g.pts.length > 4));
    const ga = gOf(by[a]), gb = gOf(by[b]), xg = BND && t !== 'l' && t !== 'r' && ga !== gb && (ga[0] === 'B' || gb[0] === 'B') && (ga[0] === 'H' || segOf[ga.slice(2)]) && (gb[0] === 'H' || segOf[gb.slice(2)]);
    if (xg){ const key = ga + '>' + gb + (t === 'o' ? '|o' : ''); const q = bmap[key] = bmap[key] || {ga, gb, o:t === 'o', src:[], dst:[], E:[]}; q.src.push(a); q.dst.push(b); q.E.push([a, b, t, lab]); }
    const p = document.createElementNS(SVGNS, 'path'); p.setAttribute('d', d); p.setAttribute('class', cls + (isX && S.view !== 'flow' ? ' xrow' : '') + (xg ? ' xg' : '')); p.setAttribute('marker-end', 'url(#' + (isX && S.view !== 'flow' ? 'm-x' : markerFor(cls)) + ')'); { const L0 = g.pts[g.pts.length - 1], ek = Math.round(L0[0]) + ',' + Math.round(L0[1]) + (t === 'r' || t === 'l' ? 'x' : ''); if (!M.agentView && ENDS[ek]) p.removeAttribute('marker-end'); else ENDS[ek] = 1; } p.dataset.a = a; p.dataset.b = b; if (M.agentView && ex){ const xs = by[a] && by[b] && by[a].st !== by[b].st; if (xs) p.classList.add('agx'); p.style.strokeWidth = (t === 'o' || xs ? 1.4 : 1.8 + Math.min(4.2, (ex.n - 1) * 0.55)) + 'px'; } if (S.selE === a + '>' + b) p.classList.add('esel'); f.appendChild(p);
    if (S.fedit || S.scr === 'asis'){ const hp = document.createElementNS(SVGNS, 'path'); hp.setAttribute('d', d); hp.setAttribute('class', 'ehit'); hp.dataset.e = a + '>' + b; f.appendChild(hp); }
    if (lab && (t !== 's' || ulab) && (S.view === 'flow' || M.agentView)) placeLabel(lab, g, M.agentView ? 'agfl ' + t : cls, rects.concat(TRECTS), placed, null, A, Bp, a + '>' + b);
  });
  if (BND){
    // 흐름 묶음: 사람 → Agent(맡김) · Agent → 사람(확인·전달) · Agent → Agent(전달) · Orchestrator 신호
    const g = (M.C.colW - M.C.nodeW) / 2, stL = (st, o) => M.SX[st] - 8 + o / 2, keep = new Set();
    const ep = (gk, ids) => { if (gk[0] === 'B'){ const sg = segOf[gk.slice(2)]; return {k:'B', r:{x:sg.x0, y:sg.y0, w:sg.w, h:sg.y1 - sg.y0}, st:sg.st, sy:sg.y0}; }
      const rs = uq(ids).map(id => M.pos[id]).filter(Boolean), x0 = Math.min.apply(null, rs.map(p => p.x)), y0 = Math.min.apply(null, rs.map(p => p.y)), x1 = Math.max.apply(null, rs.map(p => p.x + p.w)), y1 = Math.max.apply(null, rs.map(p => p.y + p.h));
      return {k:'H', r:{x:x0, y:y0, w:x1 - x0, h:y1 - y0}, st:+gk.split('|')[1], ids:uq(ids)}; };
    Object.keys(bmap).forEach((key, i) => {
      const q = bmap[key], A = ep(q.ga, q.src), Bq = ep(q.gb, q.dst), o = ((i % 7) - 3) * 4, yTop = M.aiTop + 8 + Math.abs(o) / 2, pts = [];
      if (A.k === 'H'){ const cy = A.r.y + A.r.h / 2, gx = A.r.x + A.r.w + g + o / 3; pts.push([A.r.x + A.r.w, cy], [gx, cy], [gx, yTop]); }
      else { const x = A.r.x + A.r.w / 2 + o, sy = A.sy - 6 - Math.abs(o) / 3; pts.push([x, A.r.y], [x, sy]);
        if (!(Bq.k === 'B' && Bq.st === A.st && Bq.sy === A.sy)) pts.push([stL(A.st, o), sy], [stL(A.st, o), yTop]); }
      if (Bq.k === 'H'){ const cy = Bq.r.y + Bq.r.h / 2, gx = Bq.r.x - g + o / 3; pts.push([gx, yTop], [gx, cy], [Bq.r.x - 1, cy]); }
      else { const sy2 = Bq.sy - 6 - Math.abs(o) / 3, x = Bq.r.x + Bq.r.w / 2 + o;
        if (A.k === 'B' && Bq.st === A.st && Bq.sy === A.sy) pts.push([x, pts[pts.length - 1][1]], [x, Bq.r.y - 1]);
        else pts.push([stL(Bq.st, o), yTop], [stL(Bq.st, o), sy2], [x, sy2], [x, Bq.r.y - 1]); }
      const P = pts.filter((p, k) => !k || Math.abs(p[0] - pts[k - 1][0]) > .5 || Math.abs(p[1] - pts[k - 1][1]) > .5);
      const ty = q.o ? 'sig' : (A.k === 'H' ? 'hb' : (Bq.k === 'H' ? 'bh' : 'bb'));
      const pth = document.createElementNS(SVGNS, 'path'); pth.setAttribute('d', toD(P)); pth.setAttribute('class', 'bnd bnd-' + ty); pth.setAttribute('marker-end', 'url(#m-b' + ty + ')');
      pth.dataset.src = uq(q.src).join(' '); pth.dataset.dst = uq(q.dst).join(' '); f.appendChild(pth);
      const n = q.E.length, item = q.o ? uq(q.E.map(e => e[3] || '신호')).slice(0, 2).join(' · ') : afItem(q.E[0]);
      const lab = q.o ? item : (n > 1 ? n + '건 · ' + item : item);
      if (lab){ const R2 = rects.filter(r => q.src.indexOf(r.id) < 0 && q.dst.indexOf(r.id) < 0); placeLabel(lab, {pts:P, ex:P[P.length - 1][0], ey:P[P.length - 1][1]}, 'bndl bnd-' + ty, R2.concat(TRECTS), placed, null, null, null, 'bnd:' + key); }
    });
  }
  if (S.lv === 5 && S.scr === 'ns'){
    const cl = {}; M.nodes.forEach(n => { if (n.pid && M.pos[n.id]) (cl[n.pid] = cl[n.pid] || []).push(M.pos[n.id]); });
    Object.keys(cl).forEach(k => { const rs = cl[k]; if (rs.length < 2) return; const x = Math.min.apply(null, rs.map(r => r.x)) - 3, y0 = Math.min.apply(null, rs.map(r => r.y)) + 6, y1 = Math.max.apply(null, rs.map(r => r.y + r.h)) - 6;
      const p = document.createElementNS(SVGNS, 'path'); p.setAttribute('d', 'M' + x + ',' + y0 + ' L' + x + ',' + y1); p.setAttribute('class', 'e e-grp'); f.appendChild(p); });
  }
  svg.appendChild(f); RINFO = null; if (S.pin) applyPin();
}
/* ---------- 상세 팝업 */
function openPanel(h){ const c = $('#controls'); if (c){ const r = c.getBoundingClientRect(); document.documentElement.style.setProperty('--ctlb', Math.max(18, Math.min(r.bottom, 220)) + 'px'); } const p = $('#panel'); p.innerHTML = '<button class="px" type="button" aria-label="닫기">×</button>' + h; rdTree(p); p.hidden = false; p.scrollTop = 0; p.dataset.kind = ''; peAfter(p); }
const NAV = {stack:[], idx:-1, restoring:false};
function navState(){ return {scr:S.scr, lv:S.lv, path:S.path || 'all', st:Array.from(S.stages).sort((a, c) => a - c), page:$('#apage').hidden ? null : S.page, tab:S.apTab === 'cap' ? 'cap' : 'flow', amap:!$('#amap').hidden}; }
function updNavBtns(){ $$('[data-nav]').forEach(x => { x.disabled = +x.dataset.nav < 0 ? NAV.idx <= 0 : NAV.idx >= NAV.stack.length - 1; }); }
function navPush(){
  if (NAV.restoring) return;
  const s = navState(), k = JSON.stringify(s), cur = NAV.stack[NAV.idx]; if (cur && JSON.stringify(cur) === k){ updNavBtns(); return; }
  NAV.stack = NAV.stack.slice(0, NAV.idx + 1); NAV.stack.push(s); NAV.idx = NAV.stack.length - 1;
  if (NAV.stack.length > 300){ NAV.stack.shift(); NAV.idx--; }
  try { if (NAV.idx === 0) history.replaceState({pmnav:0}, ''); else history.pushState({pmnav:NAV.idx}, ''); } catch(e){}
  updNavBtns();
}
function navApply(s){
  NAV.restoring = true;
  try {
    closePanel(); S.scr = s.scr; S.lv = s.lv; S.path = s.path || 'all'; S.stages = new Set(s.st); S.hl = null;
    if (s.page){ S.apTab = s.tab; $('#amap').hidden = true; render(false); agentPage(s.page); }
    else { if (!$('#apage').hidden) closePage(); $('#amap').hidden = true; render(true); if (s.amap) agentMap(); }
  } finally { NAV.restoring = false; }
  updNavBtns();
}
function navGo(d){ const i = NAV.idx + d; if (i < 0 || i >= NAV.stack.length) return; NAV.idx = i; navApply(NAV.stack[i]); }
function navBtns(){ return '<span class="navb"><button type="button" data-nav="-1" title="뒤로 (Alt + ←)" aria-label="뒤로">←</button><button type="button" data-nav="1" title="앞으로 (Alt + →)" aria-label="앞으로">→</button></span>'; }
function closePanel(){ const p = $('#panel'); p.hidden = true; p.innerHTML = ''; p._pe = null; PE = false; p.classList.remove('pe-on'); p.dataset.kind = ''; if (S.reconn){ S.reconn = null; document.body.classList.remove('connecting'); } if (S.selE){ S.selE = null; if (S.M) setTimeout(drawEdges, 0); } $$('.nd.act').forEach(x => x.classList.remove('act')); if (!S.fedit && S.sel && !S.conn){ S.sel = null; if (typeof hideTb === 'function') hideTb(); } }
function markAct(el){ $$('.nd.act').forEach(x => x.classList.remove('act')); if (el) el.classList.add('act'); }
function row(k, v){ return v ? '<tr><th>' + k + '</th><td>' + br(v) + '</td></tr>' : ''; }
function chipBlock(o){
  // 좁은 설명 창: 데이터·시스템마다 기존 → 준비중(누가·무엇을) → 신규 설치 필요 순으로 쌓아서
  const sec = (arr, kind, label) => '<div class="cbk"><b class="cbt">' + label + '</b>' + (st3Groups(arr).map(([k, xs]) => !xs.length ? '' : '<div class="cbg ' + ST3[k][0] + '"><span class="rk ' + ST3[k][0] + '">' + ST3[k][1] + ' ' + xs.length + '</span>' +
    (k === 'P' ? xs.map(x => '<div class="cbp">' + chip(x, kind) + stNoteHTML(x) + '</div>').join('') : xs.map(x => chip(x, kind)).join('')) + '</div>').join('') || '<span class="none">없음</span>') + '</div>';
  return '<div class="cbw">' + sec(o.d, 'd', '데이터') + sec(o.s, 's', '시스템') + '</div>';
}
function a6block(id){ const a = D.A6[id]; if (!a) return ''; return '<table class="kv">' + row('원본 위치', 'Process Map ' + a.row + '행') + row(U.lv4, a.l4) + (a.g4 ? row('Lv.4', a.g4) : '') + row('Lv.5', noId(a.l5)) + row('노드 유형', a.ty) + row('담당', a.team + (a.bon ? ' (' + a.bon + ')' : '')) + row('AI 활용', a.ai) + row('활용 시스템', a.sys) + row('인풋 데이터', a.inp) + row('형식·출처', a.fmt) + row('인풋 작업 팀', a.wt) + row('아웃풋', a.out) + row('선행 / 후행', (nm(a.pre) || '시작') + ' → ' + (nm(a.post) || '끝')) + row('분기 조건', deId(a.br)) + row('반려 시 복귀', a.rej ? nm(a.rej) + (a.rejr ? ' · 사유: ' + a.rejr : '') : '') + row('비고', deId(a.note)) + row('이번 수정 표시', a.hl && a.hl.length ? a.hl.join(', ') : '') + '</table>'; }
function tbLine(id){ const t = D.TB[id], a = D.A6[id]; return '<li><em class="ty ty-' + t.t + '">' + esc(TYPE6[t.t] || t.t) + '</em> ' + esc(t.lb) + (t.sub ? ' <small>· ' + esc(D.subs[t.sub].name) + '</small>' : '') + (t.note ? '<br><small>' + esc(t.note) + '</small>' : '') + (a && t.lb !== a.n ? '<br><small>As-Is: ' + esc(a.n) + '</small>' : '') + '</li>'; }
let DETAIL_CTX = '';
function showNode(id){ id = String(id).replace(/~why$/, ''); const n = S.M.nodes.find(x => x.id === id); if (n) showNodeObj(n); }
function josa(w, a, b){ const s = String(w || '').replace(/\s*[\(\[（][^\)\]）]*[\)\]）]\s*$/, '').replace(/['’”"\s]+$/, ''); const ch = s.charCodeAt(s.length - 1);
  if (ch >= 0xAC00 && ch <= 0xD7A3) return ((ch - 0xAC00) % 28) ? a : b; if (/[LMNlmn136780]$/.test(s)) return a; return b; }
function firstItems(txt, k){ return txt ? splitItems(txt).map(x => x.replace(/^[-•·\s]+/, '').trim()).filter(Boolean).slice(0, k) : []; }
function performer(n){ if (!n) return ''; if (D.subs[n.ln]){ const b = bandOf(n.ln); return b ? b.name : D.subs[n.ln].name; } return (D.lanes.find(l => l.k === n.ln) || {}).name || ''; }
function lines(c){ return String(c || '').split(/\n/).map(v => v.replace(/^[\s\-·•]+|[\s\-·•]+$/g, '')).filter(Boolean); }
function ioCard(n){
  if (S.lv !== 6) return '';
  const a6 = D.A6[n.id] || (S.scr === "ns" && D.optIO && D.optIO[n.id] ? D.optIO[n.id] : null), lv = 6, scr = S.scr, V = D.views[6][scr], who = (scr === 'ns' && D.subs[n.ln]) ? D.subs[n.ln].name : performer(n), lb = plain(TXT[tk(n.id)] != null ? TXT[tk(n.id)] : n.lb);
  const ins = V.edges.filter(e => e[1] === n.id && e[2] !== 'l' && e[2] !== 'r').map(e => findNode(6, scr, e[0])).filter(Boolean), outs = V.edges.filter(e => e[0] === n.id && e[2] !== 'l' && e[2] !== 'r').map(e => findNode(6, scr, e[1])).filter(Boolean);
  let IN = [], OUT = [], inT = '받는 것', outT = '만드는 것';
  if (n.k === 'mk'){ const oe = D.views[6].ns.edges.filter(e => e[2] === 'o'); IN = oe.filter(e => e[1] === n.id).map(e => (e[3] || '신호') + ' 신호 (' + performer(findNode(6, 'ns', e[0])) + ')'); OUT = uq(oe.filter(e => e[0] === n.id).map(e => findNode(6, 'ns', e[1])).filter(Boolean).map(x => x.ln === 'S0b' ? '진행 현황에 반영' : performer(x) + ' 호출')); inT = '받는 신호'; outT = '부르는 곳'; }
  else if (a6){ IN = lines(a6.inp); OUT = lines(a6.out); }
  else { IN = uq(ins.map(x => '앞 업무 결과: ' + plain(x.lb))); OUT = D.outnew && D.outnew[n.id] ? [D.outnew[n.id]] : uq(outs.map(x => '다음: ' + plain(x.lb))); }
  if (n.k === 'nh' && !OUT.length) OUT = ['확정 → 다음 업무 시작'];
  if (n.k === 'gone') return '';
  const li = (a, max) => { const s = a.slice(0, max).map(v => '<li>' + esc(rd(v)) + '</li>').join(''), more = a.length > max ? '<li class="more" title="' + esc(a.slice(max).map(rd).join('\n')) + '">외 ' + (a.length - max) + '개</li>' : ''; return a.length ? '<ul>' + s + more + '</ul>' : '<p class="none">—</p>'; };
  const sys = a6 ? lines(a6.sys) : [], fmt = a6 ? lines(a6.fmt) : [];
  const kd = n.k === 'mk' ? 'orc' : (n.k === 'a' || n.k === 'na') ? 'ai' : n.k === 'nh' ? 'hitl' : 'hu';
  return '<div class="io ' + kd + '"><div class="io-c in"><h5><i>↘</i>' + inT + '</h5>' + li(IN, 5) + '</div><div class="io-a">→</div><div class="io-c do"><h5><i>●</i>하는 일</h5><p><b>' + esc(rd(who)) + '</b>' + esc(rd(lb)) + '</p></div><div class="io-a">→</div><div class="io-c out"><h5><i>↗</i>' + outT + '</h5>' + li(OUT, 5) + '</div></div>'
    + (sys.length || fmt.length ? '<div class="io-s">' + (sys.length ? '<span class="io-l">쓰는 시스템</span>' + sys.map(v => '<em>' + esc(rd(v)) + '</em>').join('') : '') + (fmt.length ? '<span class="io-l">자료 형태·보관 위치</span>' + fmt.map(v => '<em class="f">' + esc(rd(v)) + '</em>').join('') : '') + '</div>' : '');
}
function whatHTML(n){
  const lv = S.lv, scr = S.scr, V = D.views[lv][scr], lb = plain(TXT[tk(n.id)] != null ? TXT[tk(n.id)] : n.lb), q = '‘' + lb + '’';
  const who = performer(n), a6 = D.A6[n.id], tb = D.TB[n.id] || {};
  const outs = E => E.filter(e => e[0] === n.id).map(e => findNode(lv, scr, e[1])).filter(Boolean), ins = E => E.filter(e => e[1] === n.id).map(e => findNode(lv, scr, e[0])).filter(Boolean);
  const inp = a6 ? firstItems(a6.inp, 2) : [], out = a6 ? firstItems(a6.out, 2) : (D.outnew && D.outnew[n.id] ? [D.outnew[n.id]] : []);
  const list = a => a.join(', ');
  let s = '', sub = '', tbl = ''; const DS = Object.assign({A4:{}, T4:{}, A5:{}, A6:{}, T6:{}, M6:{}}, D.desc || {});
  const sent1 = x => String(x || '').split(/(?<=다\.)\s+/)[0];
  if (lv === 6 || (lv === 5 && n.k === 'mk')){
    if (n.k === 'mk' && DS.M6 && DS.M6[n.id]){ s = DS.M6[n.id]; }
    else if (n.k === 'mk'){
      const VE = D.views[6].ns.edges, oe = VE.filter(e => e[2] === 'o'), inS = oe.filter(e => e[1] === n.id), outS = oe.filter(e => e[0] === n.id);
      const from = inS.map(e => '‘' + (e[3] || '신호') + '’ 신호(' + performer(findNode(6, 'ns', e[0])) + ')'), toN = outS.map(e => findNode(6, 'ns', e[1])).filter(Boolean), stOut = toN.some(x => x.ln === 'S0b'), to = uq(toN.filter(x => x.ln !== 'S0b').map(performer)).filter(Boolean);
      if (n.ln === 'S0b') s = '진행 현황 관리 Agent가 ' + (from.length ? from.join(', ') + '를 받아 ' : '') + '프로젝트 현황(진행 단계·승인 대기·비용·회차)에 반영하는 지점입니다. ' + U.s0bSee;
      else s = 'Orchestrator(' + U.orcName + ')가 ' + (from.length ? from.join(', ') + '를 받아, ' : '') + U.orcBasis + '을 기준으로 ' + (to.length ? list(to) + josa(to[to.length - 1], '을', '를') + ' 호출' : '다음 업무를 호출') + (stOut ? '하고 진행 현황에 반영' : '') + '하는 연결 지점입니다.';
    } else if (scr === 'asis' && DS.A6[n.id]){
      s = DS.A6[n.id];
    } else if (scr === 'ns' && (n.k === 'a' || n.k === 'na' || n.k === 'nh') && (DS.T6[n.id] || DS.A6[n.id])){
      s = DS.T6[n.id] || DS.A6[n.id]; if (n.tg && (n.k === 'a' || n.k === 'na')) sub = '확인 지점: ' + n.tg;
    } else if (scr === 'ns' && n.k === 'h' && DS.A6[n.id]){
      s = DS.A6[n.id]; tbl = 'To-be에서도 사람이 직접 수행합니다.';
    } else if (scr === 'asis'){
      s = who + josa(who, '이', '가') + ' ' + (inp.length ? list(inp) + josa(inp[inp.length - 1], '을', '를') + ' 받아 ' : '') + q + josa(lb, '을', '를') + ' 합니다.' + (out.length ? ' 만드는 것: ' + list(out) + '.' : '');
    } else if (n.k === 'a' || n.k === 'na'){
      s = who + josa(who, '이', '가') + ' ' + (inp.length ? list(inp) + josa(inp[inp.length - 1], '을', '를') + ' 바탕으로 ' : '') + q + josa(lb, '을', '를') + ' 처리' + (out.length ? '해 ' + list(out) + josa(out[out.length - 1], '을', '를') + ' 작성합니다.' : '합니다.') + (n.k === 'na' ? ' As-Is에는 없던 새 업무입니다.' : '');
      if (n.tg) sub = '확인 지점: ' + n.tg;
    } else if (n.k === 'nh'){
      const pre = ins(V.edges), fromAI = pre.some(x => !!D.subs[x.ln]);
      s = fromAI ? who + josa(who, '이', '가') + ' 앞 단계 Agent의 산출물을 바탕으로 ' + q + josa(lb, '을', '를') + ' 판단·확정하는 지점입니다. 사람의 확정이 있어야 다음 업무가 시작됩니다.'
        : who + josa(who, '이', '가') + ' ' + q + ' — Agent에 일을 맡기거나 진행을 확정하는 사람 확인 지점입니다. 이 확인이 신호가 되어 Agent가 시작합니다.';
    } else if (n.k === 'ot'){
      s = q + ' — ' + (n.tg || U.otName) + '에서 설계하는 일입니다. 이 부문 To-be에서는 바꾸지 않고 연결만 표시합니다.';
    } else if (n.k === 'h'){
      s = who + josa(who, '이', '가') + ' 직접 수행하는 업무입니다 — ' + q + '. To-be에서도 사람이 담당합니다.' + (inp.length ? ' 필요 Data: ' + list(inp) + '.' : '');
    } else if (n.k === 'gone'){
      s = 'To-be에서 소멸되는 업무입니다 — ' + q + '. ' + (tb.note || '');
    } else s = q + ' 업무입니다.';
    if (tb.note && n.k !== 'gone' && scr === 'ns') sub = (sub ? sub + ' · ' : '') + tb.note;
  } else if (lv === 5){
    if (n.k === 'pt'){ const P = D.P5[n.id] || {mem:[]}; s = who + josa(who, '이', '가') + ' ‘' + plain((D.A5[n.pid] || {}).n || lb) + '’ 업무 중 Lv6 ' + (P.mem || []).length + '개를 맡아 참여합니다.'; }
    else if (scr === 'asis' && DS.A5[n.id]) s = DS.A5[n.id];
    else if (scr === 'ns' && DS.A5[n.id]){ const P = D.P5[n.id] || {mem:[]}, m = P.mem || [], T = x => (D.TB[x] || {}).t;
      const aM = m.find(x => T(x) === 'A' && DS.T6[x]), nM = m.find(x => T(x) === 'N' && DS.T6[x]);
      s = DS.A5[n.id]; tbl = !m.length ? 'To-be에서는 이 묶음의 업무가 다른 단계로 흡수되거나 소멸됩니다.' : (m.every(x => T(x) === 'H') ? 'To-be에서도 사람이 직접 수행합니다.' : 'To-be: ' + (aM ? sent1(DS.T6[aM]) : '') + (nM ? ' ' + sent1(DS.T6[nM]) : '')); }
    else if (scr === 'asis'){ const A = D.A5[n.id] || {}, kids = (A.kids || []).map(k => (D.A6[k] || {}).n).filter(Boolean); s = who + ' 중심의 업무 묶음입니다 — Lv6 ' + kids.length + '개' + (kids.length ? ': ' + kids.slice(0, 2).join(', ') + (kids.length > 2 ? ' 외' : '') : '') + '.'; }
    else { const P = D.P5[n.id] || {mem:[], gone:[]}, m = P.mem || [], cA = m.filter(x => (D.TB[x] || {}).t === 'A').length, cN = m.filter(x => (D.TB[x] || {}).t === 'N').length, cH = m.filter(x => (D.TB[x] || {}).t === 'H').length;
      const oth = uq((n.subs || []).map(sid => bandOf(sid).name).filter(x => x !== who));
      s = q + ' 묶음입니다 — Lv6 ' + m.length + '개 중 Agent ' + cA + ' · 담당자 확인 ' + cN + ' · 사람 ' + cH + (P.gone && P.gone.length ? ' · 소멸 ' + P.gone.length : '') + '. 주로 ' + who + josa(who, '이', '가') + ' 맡습니다.' + (oth.length ? ' 함께 일하는 Agent: ' + oth.join(', ') + '.' : ''); }
  } else {
    const st = D.stages.find(z => z.n === n.st) || {};
    if (D.A4[n.id] && DS.A4[n.st]){ s = DS.A4[n.st]; if (scr === 'ns' && DS.T4[n.st]) tbl = DS.T4[n.st]; }
    else if (n.mem && n.mem.length && D.subs[n.ln]){ s = D.subs[n.ln].desc; tbl = '이 단계 담당 업무 ' + n.mem.length + '건 — ' + n.mem.slice(0, 2).map(x => plain((D.TB[x] || {}).lb || '')).filter(Boolean).join(', ') + (n.mem.length > 2 ? ' 외' : ''); }
    else if (D.A4[n.id]){ const A = D.A4[n.id]; s = (st.name || '').replace(/^\d+\.\s*/, '') + ' 단계 전체입니다 — Lv5 ' + A.kids.length + '개를 묶었고, 주로 ' + who + josa(who, '이', '가') + ' 맡습니다.'; }
    else if (n.mem && n.mem.length){ const ls = n.mem.map(x => plain((D.TB[x] || {}).lb || '')).filter(Boolean); s = who + josa(who, '이', '가') + ' ' + (st.name || '').replace(/^\d+\.\s*/, '') + ' 단계에서 맡는 일 ' + ls.length + '개입니다' + (ls.length ? ' — ' + ls.slice(0, 2).join(', ') + (ls.length > 2 ? ' 외' : '') : '') + '.'; }
    else s = q + ' 업무입니다.';
  }
  const lnv = lineOf(n), sbv = subOf(n); if (lnv || sbv) sub = '병렬 줄: ' + lineName(lnv) + (sbv ? ' · ' + sbv + ' 갈래' : '') + (lnv ? ' — ' + lnv + ' 건에서만 진행' : ' — ' + sbv + ' 산출물에서만 진행') + (sub ? ' · ' + sub : '');
  return '<div class="pwhat"><b>이 박스는</b><p class="pdesc">' + esc(rd(s.replace(/\s+/g, ' ').trim())) + '</p>' + (tbl ? '<p class="ptb">' + esc(rd(tbl)) + '</p>' : '') + ioCard(n) + (sub ? '<small>' + esc(rd(sub)) + '</small>' : '') + '</div>';
}
const uq = a => a.filter((v, k) => v && a.indexOf(v) === k);
function editHTML(n){
  return '<section class="ped" id="edtb"><h4>이 박스 수정</h4><div class="pedr"><button type="button" data-ed="conn">연결 추가</button><button type="button" data-ed="del" class="danger">박스 삭제</button></div>'
    + '<label class="pedf"><span>태그</span><input type="text" data-ed="tag" aria-label="태그" placeholder="예: ' + esc(U.tagEg) + '" value="' + esc(n.tg || '') + '"></label>'
    + '<label class="pedf"><span>박스 종류</span><select data-ed="kind" aria-label="박스 종류">' + KOPT.map(([k, l]) => '<option value="' + k + '"' + (n.k === k ? ' selected' : '') + '>' + l + '</option>').join('') + '</select></label>'
    + '<p class="pedh">글자 수정을 누르면 이 창의 문구를 바로 수정할 수 있습니다 (제목 = 업무 이름 — 수정 시 메인 맵·Agent 페이지·설명 문장에 반영) · 연결 추가: 연결할 다음 박스 선택 · 연결선: 위 목록의 ✎ 또는 흐름도 편집에서 선을 눌러 수정 · Delete 키로도 삭제</p></section>';
}
function flowBlock(n){
  const lv = S.lv, scr = S.scr, V = D.views[lv][scr], EDV = DETAIL_CTX ? null : ED[scr + '|' + lv];
  const E = DETAIL_CTX ? V.edges : effEdges(scr + '|' + lv);
  const who = x => performer(x);
  const nm2 = x => plain(TXT[tk(x.id)] != null ? TXT[tk(x.id)] : x.lb);
  const tagOf = e => e[2] === 'o' ? '신호: ' + (e[3] || '호출') : e[2] === 'r' ? '반려' + (e[3] ? ': ' + e[3] : '') : e[2] === 'l' ? '순환' + (e[3] ? ': ' + e[3] : '') : (e[3] ? '조건: ' + e[3] : '');
  const item = (e, oid) => { const x = findNode(lv, scr, oid) || (DETAIL_CTX ? null : anyNode(oid)); if (!x) return ''; const tg = tagOf(e);
    return '<li><button type="button" class="lk fgo" data-go="' + esc(oid) + '">' + esc(nm2(x)) + '</button><span class="fw">' + esc(who(x)) + (x.st !== n.st ? ' · ' + x.st + '단계' : '') + '</span>' + (tg ? '<span class="ft">' + esc(tg) + '</span>' : '') + (DETAIL_CTX ? '' : '<button type="button" class="fed" data-ee="' + esc(e[0] + '>' + e[1]) + '" title="이 연결선 수정 — 종류·이름표·경로·출발/도착" aria-label="연결선 수정">✎</button>') + '</li>'; };
  const ins = E.filter(e => e[1] === n.id), outs = E.filter(e => e[0] === n.id);
  if (n.k === 'gone') return '<div class="pflow gone"><p>To-be에서 소멸되는 업무로, 이어지는 흐름이 없습니다. 소멸 사유는 아래와 같습니다.</p></div>';
  return '<div class="pflow"><div class="pf in"><h4><span class="ar">←</span> 선행 업무 <small>앞 업무 ' + ins.length + '</small></h4>' + (ins.length ? '<ul>' + ins.map(e => item(e, e[0])).join('') + '</ul>' : '<p class="none">흐름의 시작</p>') + '</div>'
    + '<div class="pf out"><h4>후행 업무 <span class="ar">→</span> <small>다음 업무 ' + outs.length + '</small></h4>' + (outs.length ? '<ul>' + outs.map(e => item(e, e[1])).join('') + '</ul>' : '<p class="none">흐름의 끝</p>') + '</div></div>';
}
function blkPanel(n){
  const M = S.M, by = {}; M.nodes.forEach(x => { by[x.id] = x; });
  const fl = (dir) => M.V.edges.filter(e => (dir ? e[0] : e[1]) === n.id).map(e => { const o = by[dir ? e[1] : e[0]], q = e[4] || {n:1, items:[]};
    return '<li><b>' + esc(o ? o.lb + ' (' + o.st + '단계)' : '') + '</b><span class="ft">' + esc(({hb:'사람 → Agent', bh:'Agent → 사람', bb:'Agent → Agent', hh:'사람 → 사람', o:'신호'})[e[2]] || '') + ' · ' + q.n + '건</span><small>' + esc(q.items.slice(0, 3).join(' / ')) + '</small></li>'; }).join('');
  const st = D.stages.find(z => z.n === n.st) || {};
  let h = '<h3>' + esc(n.lb) + ' <small>' + esc((st.name || '').replace(/^\d+\.\s*/, '')) + '</small></h3><div class="pwhat"><b>이 묶음은</b><p>' + esc(n.lb) + (n.ai ? '가 ' : '이 ') + esc((st.name || '').replace(/^\d+\.\s*/, '')) + ' 단계 담당 업무 ' + n.tasks.length + '개입니다. 화살표는 다른 Agent·사람과의 업무 흐름을 묶어 표시하며, 굵을수록 건수가 많습니다.</p></div>';
  h += '<div class="pflow"><div class="pf in"><h4><span class="ar">←</span> 받는 흐름</h4><ul>' + (fl(0) || '<li class="none">없음</li>') + '</ul></div><div class="pf out"><h4>보내는 흐름 <span class="ar">→</span></h4><ul>' + (fl(1) || '<li class="none">없음</li>') + '</ul></div></div>';
  h += '<h4>업무 ' + n.tasks.length + '개</h4><ul class="ls blkls">' + n.tasks.map(x => '<li>' + esc(plain(T(tk(x.id), x.lb))) + (D.subs[x.ln] ? ' <small>' + esc(D.subs[x.ln].name) + '</small>' : '') + '</li>').join('') + '</ul><p class="hint">두 번 누르면 Lv.6 한눈에 보기에서 해당 업무를 강조 표시합니다.</p>';
  openPanel(h);
}
function showNodeObj(n){
  if (n.k === 'blk'){ blkPanel(n); return; }
  if (n.k === 'why' && n.of){ const o = findNode(S.lv, S.scr, n.of); if (o) n = o; }
  const id = n.id; PEN = {id, ctx:'P|' + S.scr + '|' + S.lv + '|' + id, agent:!!DETAIL_CTX};
  let h = '<h3>' + (TXT[tk(id)] != null ? TXT[tk(id)] : esc(plain(n.lb))) + '</h3>' + whatHTML(n) + flowBlock(n) + (n.meta ? '<div class="pmeta"><b>구성</b>' + n.meta + '</div>' : '');
  if (S.lv === 6){
    if (S.scr === 'asis') h += a6block(id);
    else { const t = D.TB[id] || {};
      if (t.sub) h += '<h4>수행 Agent: ' + esc(bandOf(t.sub).name) + '</h4>' + chipBlock(D.subs[t.sub]);
      if (D.A6[id]) h += '<h4>As-Is 원본</h4>' + a6block(id); else if (D.optIO && D.optIO[id]) h += '<p class="src">As-Is 통합 원본: ' + (D.optIO[id].source_l5 || []).map(x => esc((D.A5[x] || {}).n || x)).join(' / ') + '</p>'; else h += '<p class="none">As-Is 없음 (신규)</p>'; }
  } else if (S.lv === 5){
    if (S.scr === 'asis'){ const a = D.A5[id]; h += '<table class="kv">' + row('원본 위치', 'Process Map ' + a.rows + '행') + row('하위 Lv.6 분포', a.place) + row(U.lv4, a.l4) + (a.g4 ? row('Lv.4', a.g4) : '') + row('노드 유형', a.ty) + row('담당', a.team) + row('선행 / 후행', (nm(a.pre) || '시작') + ' → ' + (nm(a.post) || '끝')) + row('분기 조건', deId(a.br)) + row('반려 시 복귀', a.rej ? nm(a.rej) + (a.rejr ? ' · 사유: ' + a.rejr : '') : '') + row('비고', deId(a.note.join('\n'))) + row('이번 수정 표시', a.hl.join(', ')) + '</table><h4>하위 Lv6 (' + a.kids.length + ')</h4><ul class="ls">' + a.kids.map(k => '<li>' + esc(D.A6[k].n) + ' <small>· ' + esc(D.A6[k].team) + ' · ' + esc(D.A6[k].ai) + (D.A6[k].hl.length ? ' · 수정' : '') + '</small></li>').join('') + '</ul>'; }
    else { const p = D.P5[id] || {mem:[], gone:[]};
      if (D.subs[n.ln]) h += '<h4>주 수행 Agent: ' + esc(bandOf(n.ln).name) + '</h4>' + chipBlock(D.subs[n.ln]);
      if (n.subs && n.subs.length){ const mem = p.mem || [], bs = uq(n.subs.map(sid => bandOf(sid).id)); h += '<h4>이 Lv5에서 일하는 Agent (' + bs.length + ')</h4><ul class="ls">' + bs.map(bid => { const bb = D.bands.find(z => z.id === bid), ts = mem.filter(x => bb.subs.indexOf((D.TB[x] || {}).sub) >= 0).map(x => plain(D.TB[x].lb)); return '<li><button type="button" class="lk" data-ag="' + bid + '">' + esc(bb.name) + '</button>' + (ts.length ? ' <small>' + ts.length + '개 · ' + esc(ts.join(' / ')) + '</small>' : '') + '</li>'; }).join('') + '</ul>'; }
      if (p.mem.length) h += '<h4>묶인 Lv6 (' + p.mem.length + ')</h4><ul class="ls">' + p.mem.map(tbLine).join('') + '</ul>';
      if (p.gone.length) h += '<h4>이 Lv5에서 사라지는 Lv6</h4><ul class="ls">' + p.gone.map(tbLine).join('') + '</ul>';
      if (D.optMap && D.optMap[id]) { const m = D.optMap[id]; h += '<p class="src">As-Is 연결: ' + esc(m.original_l5.map(x => (D.A5[x] || {}).n || x).join(' / ')) + (m.note ? ' · 조건: ' + esc(m.note) : '') + '</p>'; } else if (p.l5 && D.A5[p.l5]) h += '<p class="src">As-Is Lv5: ' + esc(D.A5[p.l5].n) + '</p>'; }
  } else {
    if (n.mem && n.mem.length){ if (D.subs[n.ln]) h += '<h4>' + esc(D.subs[n.ln].name) + '</h4>' + chipBlock(D.subs[n.ln]); h += '<ul class="ls">' + n.mem.map(tbLine).join('') + '</ul>'; }
    else if (D.A4[id]){ h += '<table class="kv">' + row('배치 레인', D.A4[id].ln + ' — 하위 Lv.5가 가장 많은 레인') + row('하위 Lv.5 분포', D.A4[id].place) + row('Lv.4 담당팀 (원본 R열)', D.A4[id].team) + '</table>' + (n.meta ? '<p>' + n.meta + '</p>' : '') + '<h4>하위 Lv5</h4><ul class="ls">' + D.A4[id].kids.map(k => '<li>' + esc(D.A5[k].n) + '</li>').join('') + '</ul>'; }
    if (!DETAIL_CTX) h += '<p class="hint">두 번 누르면 이 단계의 Lv.5로 이동합니다.</p>';
  }
  if (S.lv === 5 && !DETAIL_CTX) h += '<p class="hint">두 번 누르면 이 단계의 Lv.6으로 이동합니다.</p>';
  h += painBox(n);
  if (!DETAIL_CTX && S.M && S.M.pos[n.id]) h += editHTML(n);
  openPanel(h);
}
function refIds(id){ if (D.A6[id]) return [id]; const t = D.TB[id]; return (t && t.ref) || []; }
function painsOf6(ids){ const out = [], seen = {}; ids.forEach(id => { const a = D.A6[id]; if (a && a.pain && !seen[a.pain]){ seen[a.pain] = 1; out.push([id, a.pain, a.l5]); } }); return out; }
function flat(a){ return [].concat.apply([], a); }
function painList(n){
  if (S.lv === 6) return painsOf6(refIds(n.id));
  if (S.lv === 5){ if (S.scr === 'asis') return painsOf6((D.A5[n.id] || {}).kids || []); const p = D.P5[n.id] || {mem:[], gone:[]}; return painsOf6((p.mem.length || p.gone.length) ? flat(p.mem.concat(p.gone).map(refIds)) : refIds(n.id)); }
  if (n.mem && n.mem.length) return painsOf6(flat(n.mem.map(refIds)));
  if (D.A4[n.id]) return painsOf6(flat(D.A4[n.id].kids.map(k => D.A5[k].kids)));
  return [];
}
function painTip(n){ const p = painList(n); if (!p.length) return ''; const x = p[0][1]; return '\n\nPain point: ' + x + (p.length > 1 ? ' (외 ' + (p.length - 1) + '건)' : ''); }
function painBox(n){
  const ps = painList(n); if (!ps.length) return '';
  const own = S.lv === 6 && !!D.A6[n.id];
  const lab = S.scr === 'asis' ? 'Pain point' : (own ? 'As-Is Pain point — 이 To-be 업무가 해소하려는 문제' : 'As-Is Pain point — 이 박스가 해소하려는 문제');
  return '<div class="painbox"><b>' + lab + (ps.length > 1 ? ' (' + ps.length + '건)' : '') + '</b>' + ps.map(([id, txt, l5]) => ((own && ps.length === 1) ? '' : '<small>' + esc(S.lv === 6 || !l5 ? nm(id) : noId(l5)) + '</small>') + '<p>' + br(txt) + '</p>').join('') + '</div>';
}
function showIn(lv, scr, n){ const sv = [S.lv, S.scr]; S.lv = lv; S.scr = scr; DETAIL_CTX = 'agent'; try { showNodeObj(n); } finally { S.lv = sv[0]; S.scr = sv[1]; DETAIL_CTX = ''; } }
function findNode(lv, scr, id){ return D.views[lv][scr].nodes.find(x => x.id === id); }
function showL5Combined(k){
  const a = D.A5[k]; if (!a) return;
  const ids = a.kids.concat(Object.keys(D.TB).filter(x => !D.A6[x] && D.TB[x].l5 === k)), pains = painsOf6(a.kids), c = cntTypes(a.kids);
  let h = '<div class="ph">원본 · ' + esc(U.srcShort + ' ' + U.src) + ' · Lv.5 · To-be는 가설</div><h3>' + esc(a.n) + '</h3><p class="kd">Lv.5 업무 · As-Is → To-be</p>';
  if (pains.length) h += '<div class="painbox"><b>Pain point' + (pains.length > 1 ? ' (' + pains.length + '건)' : '') + '</b>' + pains.map(p => (pains.length > 1 ? '<small>' + esc(nm(p[0])) + '</small>' : '') + '<p>' + br(p[1]) + '</p>').join('') + '</div>';
  h += '<table class="kv">' + row('원본 위치', 'Process Map ' + a.rows + '행') + row('하위 Lv.6 분포', a.place) + row(U.lv4, a.l4) + (a.g4 ? row('Lv.4', a.g4) : '') + row('노드 유형', a.ty) + row('담당', a.team) + row('선행 / 후행', (nm(a.pre) || '시작') + ' → ' + (nm(a.post) || '끝')) + row('분기 조건', deId(a.br)) + row('비고', deId(a.note.join('\n'))) + '</table>';
  h += '<h4>To-be 구성 · Agent ' + c.A + ' · 담당자 확인 ' + c.N + ' · 사람 ' + c.H + ' · 소멸 ' + c.X + '</h4>' + barHTML(c) + '<h4>하위 Lv.6 (As-Is → To-be)</h4><ul class="ls">' + ids.map(tbLine).join('') + '</ul>';
  openPanel(h);
}
function bandOf(sid){ return D.bands.find(b => b.subs.indexOf(sid) >= 0) || {name:''}; }
function showAgent(id){
  const b = D.bands.find(x => x.id === id), s = D.subs[id];
  let h = '<div class="ph">가설 · 팀 검토용 (확정 아님)</div>';
  if (b){ h += '<h3>' + esc(b.name) + '</h3><p>' + esc(b.desc) + '</p>' + chipBlock(b) + '<h4>세부 Agent</h4><ul class="ls">' + b.subs.map(x => '<li><button type="button" class="lk" data-ag="' + x + '">' + esc(D.subs[x].name) + '</button> <small>' + esc(D.subs[x].desc) + ' · ' + D.subs[x].stages.join('·') + '단계</small></li>').join('') + '</ul>'; }
  else if (s){ h += '<h3>' + esc(s.name) + '</h3><p><small>' + esc(bandOf(id).name) + ' 소속 · ' + s.stages.join('·') + '단계</small></p><p>' + esc(s.desc) + '</p>' + chipBlock(s) + '<h4>담당 업무 (' + s.tasks.length + ')</h4><ul class="ls">' + s.tasks.map(tbLine).join('') + '</ul>'; }
  h += '<p class="hint">기존: 현업이 현재 사용 (As-Is 엑셀·인터뷰 기준) · 준비중: 타 팀이 별도 준비 중 (예: DAM 구축, 데이터 인프라 PoC) · 신규 설치 필요: 준비 주체 없음.</p>';
  const pb = b ? b.id : (s ? s.band : null);
  if (pb) h += '<button type="button" class="pgo" data-page="' + pb + '"' + (s ? ' data-sub="' + id + '"' : '') + '>이 Agent 상세 페이지 열기 →</button>';
  openPanel(h);
}
const AMX_BUL = (U.amxBul || {});
const AMX_EN = (U.amxEn || []);
const AMX_NOTE = (U.amxNote || {});
function amxCount(subs){
  // To-be Lv.6 지도에서 그 Agent(세부 Agent들)가 맡은 박스 수를 단계별로 셈
  const c = {}, tasks = {}; liveNodes().forEach(n => { if (!subs.includes(n.ln) || n.k === 'why' || n.k === 'gone') return; c[n.st] = (c[n.st] || 0) + 1; (tasks[n.st] = tasks[n.st] || []).push(plain(n.lb)); }); return {c, tasks};
}
function amxCov(subs){
  const {c} = amxCount(subs);
  return '<div class="ax-pc"><div class="ax-pch"><b>Process Coverage</b></div><span class="ax-pv">' + D.stages.map(s => s.n).map(n => '<i class="' + (c[n] ? 'on' : '') + '" title="' + n + '단계' + (c[n] ? '에서 일함' : ': 이 Agent 업무 없음') + '">' + n + '</i>').join('') + '</span></div>';
}
function agentMap(){
  // 7단계 + 제작 Orchestrator + 큰 기능 Agent 8열 — 설명 · 세부 Agent · Process Coverage 모두 지금 To-be 지도에서 계산
  const el = $('#amap');
  const ko = st => ((st.name || '').replace(/^\d+\.\s*/, '').split(' / ')[0] || '').replace(/\s*·\s*/g, '·');
  const stTag = id => '<em class="keepdot">' + (D.subs[id].stages || []).join('·') + '단계</em>';
  const chev = D.stages.map((st, k) => '<div class="ax-ch"><i>' + st.n + '</i><div><small>' + esc(AMX_EN[k] || '') + '</small><b class="keepdot"' + amA('st|' + st.n) + '>' + esc(ko(st)) + '</b></div></div>').join('');
  const o = D.bands[0];
  const orc = '<section class="ax-orc" data-page="' + o.id + '" title="상세 페이지 열기"><div class="ax-on"><i class="ax-no">1</i><b' + amA('ag|' + o.id) + '>' + esc(o.name) + '</b><small>총괄 · 전 단계</small></div><div class="ax-od"><p' + amA(amBk(o, 0)) + '>' + esc(amBul(o)[0]) + '</p><p><b>세부 Agent</b>' + o.subs.map(id => '<span data-ag="' + id + '">' + (AME ? '<span' + amA('ag|' + id) + '>' + esc(D.subs[id].name) + '</span>' : esc(D.subs[id].name)) + stTag(id) + '</span>').join('') + '</p></div><div class="ax-ocov">' + amxCov(o.subs) + '</div></section>';
  const cols = D.bands.slice(1).filter(b => !(U.relBands || []).includes(b.id)).map((b, k) => { const lite = !!AMX_NOTE[b.id];
    return '<section class="ax-col' + (lite ? ' lite' : '') + '"><header data-page="' + b.id + '" title="상세 페이지 열기"><i class="ax-no">' + (k + 2) + '</i><div><b' + amA('ag|' + b.id) + '>' + esc(b.name) + '</b><small>세부 Agent ' + b.subs.length + '개' + (lite ? '<em class="ax-note">' + esc(AMX_NOTE[b.id]) + '</em>' : '') + '</small></div></header>'
      + '<ul class="ax-bul">' + amBul(b).map((x, i) => '<li' + amA(amBk(b, i)) + '>' + esc(x) + '</li>').join('') + '</ul>'
      + '<div class="ax-sh">세부 Agent</div><ul class="ax-sub">' + b.subs.map(id => '<li data-ag="' + id + '" title="' + esc(D.subs[id].desc || '') + '"><span' + amA('ag|' + id) + '>' + esc(D.subs[id].name) + '</span>' + stTag(id) + '</li>').join('') + '</ul>'
      + amxCov(b.subs) + '</section>'; }).join('');
  el.innerHTML = '<div class="amh">' + navBtns() + '<b>기능별 Agent 구조</b><span>Process Coverage = 현재 To-be 지도에서 해당 Agent가 작동하는 단계 · 큰 기능 Agent를 누르면 상세 페이지, 세부 Agent를 누르면 설명 표시</span><button type="button" class="amed" data-amed aria-pressed="' + AME + '" title="단계 이름 · Agent 이름(전체 반영) · 기능 설명 고치기">' + (AME ? '✓ 글자 수정 끝내기' : '✎ 글자 수정') + '</button><em class="ax-pre">Preliminary · 가설</em><button type="button" class="px" aria-label="닫기">×</button></div>'
    + '<div class="ax"><div class="ax-chevs">' + chev + '</div>' + orc + '<div class="ax-cols">' + cols + '</div></div>';
  el.classList.toggle('ame', AME); el.hidden = false; navPush(); updNavBtns();
}
/* ---------- 화면 제어 */
function updateChrome(){
  $$('#scrSeg button, #sldots button').forEach(b => b.setAttribute('aria-pressed', b.dataset.scr === S.scr));
  $$('#lvSeg button, #pLv button').forEach(b => b.setAttribute('aria-pressed', +b.dataset.lv === S.lv));
  $$('#vwSeg button, #pVw button').forEach(b => b.setAttribute('aria-pressed', b.dataset.vw === S.view)); $$('#pathSeg button, #pPath button').forEach(b => b.setAttribute('aria-pressed', b.dataset.path === (S.path || 'all'))); document.body.dataset.path = S.path || 'all'; const bs = $('#btnStory'); if (bs) bs.setAttribute('aria-pressed', storyOn()); document.body.classList.toggle('vflow', S.view === 'flow'); document.body.classList.toggle('vagent', S.view === 'agent');
  const all = S.stages.size === D.stages.length;
  $$('#stSeg button, #pSt button').forEach(b => b.setAttribute('aria-pressed', b.dataset.st === 'all' ? all : (!all && S.stages.has(+b.dataset.st))));
  if ($('#pzv')) $('#pzv').textContent = Math.round(S.zoom * 100) + '%';
  $('#summary').innerHTML = D.summary.map(s => '<div class="sm' + (s.lv === S.lv ? ' on' : '') + '" title="' + esc(s.tip) + '"><span class="smt">' + esc(s.text) + '</span>' + (s.parts ? '<span class="smb" aria-hidden="true">' + s.parts.filter(q => q[1]).map(q => '<i class="' + q[2] + '" style="flex:' + q[1] + '" title="' + esc(q[0] + ' ' + q[1]) + '"></i>').join('') + '</span>' : '') + '</div>').join('');
  { const cur = D.summary.find(s => s.lv === S.lv) || D.summary[0], el = $('#ibSum'); if (el && cur) el.innerHTML = esc(cur.text) + '<i class="ai"></i>Agent<i class="hitl"></i>담당자 확인<i class="hu"></i>사람<i class="orc"></i>Orchestrator'; }
  $$('#steps .stp2').forEach(x => x.setAttribute('aria-pressed', !all && S.stages.has(+x.dataset.st)));
  const lab = $('#sllab'); lab.className = S.scr; lab.innerHTML = S.scr === 'asis' ? '<b>As-Is</b>현재 · ' + esc(U.srcShort) + ' 원본 그대로' : '<b>To-be</b>가설 · 같은 ' + D.stages.length + '단계 안에서 Agent 재설계';
  $('#slPrev').disabled = S.scr === 'asis'; $('#slNext').disabled = S.scr === 'ns';
}
function set(scr, lv, stages, anim){
  if (scr) S.scr = scr; if (lv) S.lv = lv; if (stages) S.stages = new Set(stages);
  S.hl = null; closePanel(); render(anim !== false);
}
function setEditable(on){ $$('#board .lbl, [data-edit], #steps [data-nmk]').forEach(el => { el.contentEditable = on ? 'true' : 'false'; }); }
function renderSteps(){
  const el = $('#steps'); if (!el) return;
  el.innerHTML = D.stages.map((s, i) => '<button type="button" class="stp2" data-st="' + s.n + '" aria-pressed="false" title="' + esc(s.name + ' — ' + s.ns) + '"><span class="sn">' + s.n + '</span><span class="stx"><b data-nmk="st|' + s.n + '">' + esc(s.name.replace(/^\d+\.\s*/, '').split(' / ')[0]) + '</b><small>Lv6 ' + s.n6 + ' · Agent ' + s.nA + '</small><span class="stbar"><i style="width:' + Math.round(s.nA / Math.max(1, s.n6) * 100) + '%"></i></span></span></button>' + (i < D.stages.length - 1 ? '<i class="stl" aria-hidden="true"></i>' : '')).join('');
  el.addEventListener('click', e => { const b = e.target.closest('.stp2'); if (b){ const x = $('#stSeg button[data-st="' + b.dataset.st + '"]'); if (x) x.click(); } });
}
function initTitle(){ const tt = TXT.title != null ? (String(TXT.title).replace(/<[^>]+>/g, '').trim() || D.text.title) : D.text.title; document.title = tt; $$('[data-title]').forEach(el => { el.textContent = tt; }); }
function initSegs(){
  const stB = (tt) => '<button type="button" data-st="all">전체</button>' + D.stages.map(s => '<button type="button" data-st="' + s.n + '"' + (tt ? ' title="' + esc(s.name.replace(/^\d+\.\s*/, '')) + '"' : '') + '>' + s.n + '</button>').join('');
  $$('[data-lv]').filter(b => b.dataset.lv === '4').forEach(b => { b.textContent = U.lv4btn; });
  if ($('#stSeg')) $('#stSeg').innerHTML = stB(true); if ($('#pSt')) { $('#pSt').innerHTML = stB(false); $('#pSt').title = '숫자 1~' + D.stages.length + ': 그 단계만 · 0: 전체'; }
  const pB = (tt) => '<button type="button" data-path="all"' + (tt ? ' title="' + esc(PATHS.map(p => p.v).join('·')) + ' 모두"' : '') + '>전체</button>' + PATHS.map((p, i) => '<button type="button" data-path="' + esc(p.v) + '" class="' + (i ? 'ps-ns' : 'ps-sh') + '"' + (tt ? ' title="' + esc(p.title || ('공통 업무 + ' + p.v + ' 업무만')) + '"' : '') + '>' + esc(p.v) + '</button>').join('');
  if ($('#pathSeg')) { $('#pathSeg').innerHTML = pB(true); $('#pathSeg').closest('.grp').hidden = !PATHS.length; }
  if ($('#pPath')) { $('#pPath').innerHTML = pB(false); $('#pPath').hidden = !PATHS.length; }
}
function initStatic(){ $$('[data-edit]').forEach(el => { const k = el.dataset.edit; if (D.text[k] != null || TXT[k] != null) el.innerHTML = T(k, D.text[k]); }); }
function legend(){
  const nd = c => '<i class="sw nd ' + c + '"></i>';
  const GT = ['병렬', PATHS.map((p, i) => ['<i class="swg tk ' + (i ? 'tk-ns' : 'tk-sh') + '">' + esc(p.v) + '</i>', p.legend || (p.v + ' 건 박스 묶음')]).concat(U.sublLegend ? [['<span class="sbl">⇉</span>', U.sublLegend]] : [])];
  const GB = ['Agent 흐름 보기', [['<i class="sw ln bhb"></i>', '사람 → Agent (맡김)'], ['<i class="sw ln bbh"></i>', 'Agent → 사람 (확인 요청·결과 전달)'], ['<i class="sw ln bbb"></i>', 'Agent → Agent (전달)'], ['<i class="sw ln bsig"></i>', 'Orchestrator 신호'], ['<span class="sbl">≡</span>', '선이 굵을수록 건수가 많음']]];
  const GN = ['흐름 번호 (▶ 흐름 따라가기)', [['<i class="sbadge lgb ai">4-1</i>', 'Agent'], ['<i class="sbadge lgb hitl">4-2</i>', '담당자 확인·판단'], ['<i class="sbadge lgb hu">4-3</i>', '사람 직접'], ['<i class="sbadge lgb orc">4-4</i>', 'Orchestrator 신호·호출'], ['<span class="sbl">ⓘ</span>', '2-4-1 = 단계-묶음-순서 (묶음 = Lv.5, 순서 = 화살표 방향) · 번호를 누르면 그 순서부터 따라가기']]];
  const hasOT = D.views[6].ns.nodes.some(n => n.k === 'ot');
  const G = [GT, GN, GB, ['박스', [[nd('k-h'), '사람 (잔존)'], ...(hasOT ? [[nd('k-h k-ot'), U.otName]] : []), [nd('k-nh'), '담당자 확인'], [nd('k-a'), 'Agent 대체'], [nd('k-na'), 'Agent (신규)'], [nd('k-gone'), '소멸 (흡수)'], [nd('k-mk'), 'Orchestrator'], [nd('k-why'), '소멸 이유']]],
    ['묶음·선', [['<i class="sw fr big"></i>', '큰 기능 Agent'], ['<i class="sw fr small"></i>', '세부 Agent'], ['<i class="sw ln g"></i>', '일반·분기'], ['<i class="sw ln l"></i>', '순환'], ['<i class="sw ln v"></i>', '반려'], ['<i class="sw ln r"></i>', 'Agent 흐름'], ['<i class="sw ln k"></i>', 'Orchestrator 신호 (수신 신호 및 호출 Agent)'], ['<i class="sw ln x"></i>', '다른 줄로 연결 (마우스를 올리면 강조)']]]];
  $('#legend').innerHTML = G.filter(g => g !== GT || PATHS.length).map(([h, it]) => '<div class="lgg"><b>' + h + '</b>' + it.map(([s, x]) => '<span class="lg">' + s + x + '</span>').join('') + '</div>').join('') + '<div class="lgg hint">박스에는 업무 이름만 — 분기·합류, AI 활용, 태그, PI Crew 검증, 이번 버전 수정은 박스를 누르면 상세 창에서 · 끌면 위치 이동 (Ctrl+Z 되돌리기) · 두 번 누르면 하위 Level</div>';
}
function stamp(){ const d = new Date(), p = n => String(n).padStart(2, '0'); return String(d.getFullYear()).slice(2) + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()); }
function toast(m){ const el = $('#toast'); el.textContent = m; el.classList.add('on'); clearTimeout(toast._t); toast._t = setTimeout(() => el.classList.remove('on'), 2600); }
function buildDoc(){
  const json = JSON.stringify({ver:'x' + Date.now().toString(36), text:TXT, view:{scr:S.scr, lv:S.lv}, ed:ED, story:STX, ag:AGX, nm:NM}).replace(/<\//g, '<\\/');
  const dEl = document.getElementById('pm-data'), eEl = document.getElementById('pm-engine'); if (!dEl || !eEl) return null;
  const html = SHELL.replace('/*__' + 'TITLE__*/', () => esc(D.text.title || '')).replace('/*__' + 'DATA__*/', () => dEl.textContent).replace('/*__' + 'ENGINE__*/', () => eEl.textContent);
  const o = '/*' + 'BAKED*/', c = '/*/' + 'BAKED*/', i = html.indexOf(o), j = html.indexOf(c, i);
  if (i < 0 || j < 0) return null; let out = html.slice(0, i + o.length) + json + html.slice(j);
  const dz = document.getElementById('pm-design'), k = out.lastIndexOf('</' + 'body>');   // 스킬로 업데이트할 때 쓰는 설계 파일도 그대로
  if (dz && k > 0) out = out.slice(0, k) + '<script type="application/gzip+base64" id="pm-design">' + dz.textContent + '</' + 'script>\n' + out.slice(k);
  return out;
}
async function doExport(){
  { const ae = document.activeElement; if (ae && ae.blur && ae.isContentEditable) ae.blur(); }
  try { agFlushAll(); } catch(e){}
  const html = buildDoc(); if (!html){ toast('저장할 원본을 찾지 못했습니다'); return; }
  const filename = U.file + '_편집본_' + stamp() + '.html', dl = await DLP;
  if (dl){ try { await dl.save({filename, data:new Blob([html], {type:'text/html'})}); DIRTY = false; } catch(e){ toast(e && e.code === 'declined' ? '저장을 취소했습니다' : '이 보기에서는 파일 저장을 쓸 수 없습니다'); } return; }
  try { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([html], {type:'text/html'})); a.download = filename; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500); DIRTY = false; }
  catch(e){ toast('이 보기에서는 파일 저장을 쓸 수 없습니다'); }
}
let pubArm = 0;
async function doPublish(){
  const b = $('#btnPub'); if (!ART) return;
  if (Date.now() - pubArm > 4000){ pubArm = Date.now(); b.textContent = '한 번 더 누르면 전체에 반영'; setTimeout(() => { if (Date.now() - pubArm >= 3900) b.textContent = '이 링크에 반영'; }, 4000); return; }
  pubArm = 0; const html = buildDoc(); if (!html) return;
  try { await ART.publish(html); DIRTY = false; toast('같은 링크에 반영했습니다'); }
  catch(e){ const c = e && e.code; if (c === 'not_writer' || c === 'not_granted'){ b.disabled = true; b.textContent = '읽기 전용 보기'; } else if (c !== 'conflict') toast('반영하지 못했습니다 (' + (c || '오류') + ')'); }
  b.textContent = '이 링크에 반영';
}
function slideTo(scr){ if (!scr || scr === S.scr) return; closePanel(); S.scr = scr; S.hl = null; render(true); }
/* ---------- AI Agent 상세 페이지 */
const NS6 = {}; D.views[6].ns.nodes.forEach(n => { NS6[n.id] = n; });
function splitItems(c){ return String(c || '').split(/\n|,|;/).map(v => v.replace(/^[\s\-·•]+|[\s\-·•]+$/g, '')).filter(Boolean); }
function bandStages(b){ const s = new Set(); b.subs.forEach(id => D.subs[id].stages.forEach(x => s.add(x))); return Array.from(s).sort((x, y) => x - y); }
function taskOrder(a, b){ const A = NS6[a] || {}, B = NS6[b] || {}; return ((A.st || 0) - (B.st || 0)) || ((A.c || 0) - (B.c || 0)) || ((A.r || 0) - (B.r || 0)); }
function hitlOf(tasks){ const set = new Set(tasks), out = []; liveEdges().forEach(([a, b]) => { [[a, b], [b, a]].forEach(([x, y]) => { if (set.has(x) && D.TB[y] && D.TB[y].t === 'N' && out.indexOf(y) < 0) out.push(y); }); }); return out.sort(taskOrder); }
function stName(n){ const s = D.stages.find(x => x.n === n); return s ? s.name : n + '단계'; }
function kpi(v, l, sub){ return '<div class="kpi"><b>' + esc(v) + '</b><span>' + esc(l) + '</span>' + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</div>'; }
function matrixRows(b){
  const rows = {}, cnt = (name, kind, ids) => ids.filter(x => D.A6[x] && splitItems(kind === 'd' ? D.A6[x].inp : D.A6[x].sys).indexOf(name) >= 0).length, allIds = Object.keys(D.A6);
  b.subs.forEach(sid => { const s = D.subs[sid]; [['d', s.d], ['s', s.s]].forEach(([kind, arr]) => arr.forEach(x => { const name = x[0], have = x[1], k = kind + '|' + name, r = rows[k] || (rows[k] = {kind, name, have:!!have, st:st3(x), note:stNote(x), who:x[4] || '', subs:[]}); if (r.subs.indexOf(sid) < 0) r.subs.push(sid); })); });
  [['d', b.d], ['s', b.s]].forEach(([kind, arr]) => arr.forEach(x => { const name = x[0], have = x[1], k = kind + '|' + name; if (!rows[k]) rows[k] = {kind, name, have:!!have, st:st3(x), note:stNote(x), who:x[4] || '', subs:[]}; }));
  const tasks = [].concat.apply([], b.subs.map(id => D.subs[id].tasks));
  return Object.keys(rows).map(k => rows[k]).map(r => Object.assign(r, {own:r.have ? cnt(r.name, r.kind, tasks) : 0, all:r.have ? cnt(r.name, r.kind, allIds) : 0}))
    .sort((x, y) => (x.kind !== y.kind ? (x.kind === 'd' ? -1 : 1) : (x.have !== y.have ? (x.have ? 1 : -1) : ((y.subs.length - x.subs.length) || (y.own - x.own)))));
}

function timelineHTML(b){
  return '<div class="tl">' + D.stages.map(s => {
    const cards = b.subs.map(sid => { const ts = D.subs[sid].tasks.filter(x => NS6[x] && NS6[x].st === s.n).sort(taskOrder); if (!ts.length) return '';
      return '<div class="tlc"><b>' + esc(D.subs[sid].name) + '</b><ul>' + ts.map(x => '<li data-tid="' + esc(x) + '">' + esc(D.TB[x].lb) + (D.TB[x].tg ? ' <span class="tg ' + tgCls(D.TB[x].tg) + '">' + esc(D.TB[x].tg) + '</span>' : '') + '</li>').join('') + '</ul></div>'; }).join('');
    return '<div class="tls' + (cards ? ' on' : '') + '"><div class="tlh"><span class="tln">' + s.n + '</span>' + esc(s.name.replace(/^\d+\.\s*/, '')) + '</div><div class="tlb">' + (cards || '<p class="none">이 단계 담당 업무 없음</p>') + '</div></div>';
  }).join('') + '</div>';
}
function painOf(x){ const a = D.A6[x]; if (a) return a.pain ? [[x, a.pain]] : []; return painsOf6((D.TB[x] && D.TB[x].ref) || []).map(p => [p[0], p[1]]); }
/* ---------- 데이터 흐름 그림: Data(형식) → Agent → 산출물(형태), 아래에 API 연동 시스템과 주고받는 정보 */
function whenOf(name, kind, subIds){
  const ts = [].concat.apply([], subIds.map(sid => D.subs[sid].tasks)).filter(x => D.A6[x] && splitItems(kind === 'd' ? D.A6[x].inp : D.A6[x].sys).indexOf(name) >= 0);
  if (ts.length){ ts.sort(taskOrder); const st = Array.from(new Set(ts.map(x => (NS6[x] || {}).st).filter(Boolean))).sort((a, c) => a - c);
    return st.join('·') + '단계 ' + ts.slice(0, 2).map(x => '「' + D.TB[x].lb + '」').join(' · ') + (ts.length > 2 ? ' 외 ' + (ts.length - 2) + '건' : '') + ' 할 때'; }
  const own = subIds.map(sid => (D.subs[sid].wh || {})[name]).find(Boolean);
  return own || (D.when && D.when[name]) || (D.whenHave && D.whenHave[name]) || '이 Agent가 일할 때 (상시)';
}

function flowDiag(o){
  const subs = o.subs || [], s0 = D.subs[subs[0]] || {s:[], sp:[], of:[]}, wh = (x, k) => '<small class="wh"><b>언제</b>' + atS('xw|' + k + '|' + x[0], esc(whenOf(x[0], k, subs))) + '</small>';
  const dataH = o.data.length ? '<ol class="fxl big">' + fxDG(s0).map((g, i) => fxGroup(g, i, 'd', s0, x => wh(x, 'd'))).join('') + '</ol>' : '';
  const ofs = o.of || fxOuts(s0), outH = ofs.length ? '<ol class="fxl big">' + fxOG(s0).map((g, i) => fxGroup(g, i, 'o', s0)).join('') + '</ol>' : '';
  const sp = o.sp || fxPurposes(s0);
  const sysH = sp.map(([p, ns], i) => '<div class="spg"' + agA('sp', p) + '><h6 class="spt"><span class="fxn">' + (i + 1) + '</span>' + esc(p) + '</h6><div class="spl">' + ns.map(n => { const x = o.sys.find(y => y[0] === n) || [n, 1], k = st3(x);
      return '<div class="sy ' + ST3[k][0] + '"' + aiA('s', n) + (stNote(x) ? ' title="' + esc(stNote(x)) + '"' : '') + '><b>' + esc(n) + '</b>' + (stWho(x) ? '<small class="prw">(' + esc(stWho(x)) + ')</small>' : '') + '<span class="st">' + ST3[k][1] + '</span>' + wh(x, 's') + '<small class="ex"><b>주고받는 정보</b>' + atS('xi|s|' + n, esc(sxInfo(n, subs))) + '</small></div>'; }).join('') + '</div></div>').join('');
  return '<div class="dfd">' +
    '<div class="dfc in"><h6><span class="dfn">1</span>투입 Data <small>묶음별 항목·형식 · 우선순위순</small></h6>' + (dataH || '<span class="none">없음</span>') + '</div>' +
    '<div class="dfa a1" aria-hidden="true"></div>' +
    '<div class="dfc ag"><h6><span class="dfn">2</span>' + esc(o.agTitle || 'Agent가 처리') + '</h6><div class="agc"><span class="ic">' + IC.spark + '</span><b>' + esc(o.name) + '</b><ul>' + o.lines.map((l, i) => '<li' + (o.linesF && o.subs && o.subs.length === 1 ? atA('f|' + o.subs[0] + '|' + i) : '') + '>' + l + '</li>').join('') + '</ul></div></div>' +
    '<div class="dfa a2" aria-hidden="true"></div>' +
    '<div class="dfc out"><h6><span class="dfn">4</span>산출물 <small>묶음별 항목·형식</small></h6>' + (outH || '<span class="none">없음</span>') + '</div>' +
    '<div class="dfs"><div class="dfv" aria-hidden="true"><span>API 연동 ⇅</span></div><h6><span class="dfn">3</span>활용 시스템 <small>목적별 시스템</small></h6><div class="syl spw">' + (sysH || '<span class="none">활용 시스템 없음</span>') + '</div></div>' +
  '</div>';
}

/* ---------- 맨 위 데이터 흐름: 세부 Agent 순서대로 [투입 Data 유형 박스] → [세부 Agent 박스 (API 연동 포함)] → [산출물 유형 박스], 아래 Agent로 산출물 전달 */
/* v38 (S01): 세부 Agent a → c 로 산출물을 바로 넘기는지 — 지도에서 두 Agent 업무가 직접 이어지거나, c의 투입 Data가 a의 산출물이거나 a의 이름을 담은 경우만 */
function subHand(a, c){ const A = D.subs[a], C2 = D.subs[c]; if (!A || !C2) return false; const ta = new Set(A.tasks || []), tc = new Set(C2.tasks || []);
  if ((D.views[6].ns.edges || []).some(e => e[2] !== 'l' && e[2] !== 'r' && ta.has(e[0]) && tc.has(e[1]))) return true;
  const outs = (A.of || []).map(x => x[0]).concat(((D.outs || {})[a] || []).map(x => x[0])); return (C2.d || []).some(x => outs.indexOf(x[0]) >= 0 || String(x[0]).indexOf(A.name) >= 0); }
function subOrder(b){ const first = sid => D.subs[sid].tasks.slice().sort(taskOrder)[0]; return b.subs.slice().sort((a, c) => (Math.min.apply(null, D.subs[a].stages) - Math.min.apply(null, D.subs[c].stages)) || taskOrder(first(a), first(c))); }

function orcTable(){
  const V = D.views[6].ns, by = {}; V.nodes.forEach(n => { by[n.id] = n; });
  const oe = V.edges.filter(e => e[2] === 'o'), who = n => !n ? '' : (D.subs[n.ln] ? D.subs[n.ln].name : ((D.lanes.find(l => l.k === n.ln) || {}).name || ''));
  const cell = (x, dir) => '<div class="og"><b>' + esc(x.l) + '</b>' + (dir ? ' → ' : ' · ') + '<span class="ow">' + esc(who(x.n)) + '</span><small>' + esc(plain(T(tk(x.n.id), x.n.lb))) + '</small></div>';
  const marks = V.nodes.filter(n => n.k === 'mk' && n.ln === 'S0a').sort((a, c) => (a.st - c.st) || ((a.c || 0) - (c.c || 0)));
  let rows = '';
  marks.forEach(m => {
    const ins = oe.filter(e => e[1] === m.id && by[e[0]]).map(e => ({n:by[e[0]], l:e[3]})), outs = oe.filter(e => e[0] === m.id && by[e[1]] && by[e[1]].ln !== 'S0b').map(e => ({n:by[e[1]], l:e[3]}));
    const sts = oe.filter(e => e[0] === m.id && by[e[1]] && by[e[1]].ln === 'S0b').map(e => by[e[1]]);
    rows += '<tr><td class="c"><span class="sn">' + m.st + '</span></td><td>' + ins.map(x => cell(x, 0)).join('') + '</td><td class="orc"><span class="ic">' + IC.layers + '</span>' + esc(plain(T(tk(m.id), m.lb))) + '</td><td>' + outs.map(x => cell(x, 1)).join('') + '</td><td>' + (sts.map(s => '<div class="og">' + esc(plain(T(tk(s.id), s.lb))) + '</div>').join('') || '<span class="muted">—</span>') + '</td></tr>';
  });
  V.nodes.filter(n => n.k === 'mk' && n.ln === 'S0b').forEach(s => { const ins = oe.filter(e => e[1] === s.id && by[e[0]] && by[e[0]].ln !== 'S0a').map(e => ({n:by[e[0]], l:e[3]})); if (!ins.length) return;
    rows += '<tr class="sto"><td class="c"><span class="sn">' + s.st + '</span></td><td>' + ins.map(x => cell(x, 0)).join('') + '</td><td class="orc"><span class="ic">' + IC.layers + '</span>현황만 갱신 (호출 없음)</td><td><span class="muted">—</span></td><td><div class="og">' + esc(plain(T(tk(s.id), s.lb))) + '</div></td></tr>'; });
  return '<section class="orcs"><h3>' + h3i(IC.flow) + 'Orchestrator 신호 흐름 — 단계별 수신 신호 및 호출 Agent</h3><p class="orcn">사람의 <b>확정·승인</b>이나 Agent의 <b>완료</b>가 신호로 들어오면, Orchestrator(' + esc(U.orcName) + ')가 ' + esc(U.orcBasis) + '을 기준으로 다음 <b>Agent·담당자를 호출</b>하고, 진행 현황 관리 Agent가 그 결과를 현황에 반영합니다. 1~' + D.stages.length + '단계 모두 참여하며, 지도에서는 <b>진한 점선</b>과 신호 이름으로 보입니다.</p><div class="tblw"><table class="dt orct"><thead><tr><th>단계</th><th>수신 신호 (발신처)</th><th>Orchestrator 판단·호출</th><th>호출 (수신 Agent)</th><th>진행 현황 반영</th></tr></thead><tbody>' + rows + '</tbody></table></div></section>';
}

/* ---------- 상세 페이지 목록: 무엇이 필요한가(상위) → 형식·시스템(하위) */

function fxSysChip(s, n){
  const x = s.s.find(y => y[0] === n) || [n, 1], k = st3(x);
  return '<i class="sx ' + ST3[k][0] + '"' + aiA('s', n) + (stNote(x) ? ' title="' + esc(stNote(x)) + '"' : '') + '>' + (k === 'E' ? '' : '<u>' + (k === 'P' ? '준비중' : '신규') + '</u>') + esc(n) + (stWho(x) ? ' <span class="prw">(' + esc(stWho(x)) + ')</span>' : '') + '</i>';
}
function fxPurposes(s){ return (s.sp && s.sp.length) ? s.sp : [['활용', s.s.map(x => x[0])]]; }
function fxOuts(s){ return (s.of && s.of.length) ? s.of : (((D.outs || {})[s.id]) || []).map(x => [x[0], [x[1]]]); }

/* ---------- 묶음(굵은 메인, 괄호 없음, 우선순위 순) → 하위 불렛(원래 항목 · 형식 · 파일명 같은 세부) */
function cleanNm(n){ const det = []; let c = String(n || '');
  for (let k = 0; k < 3; k++) c = c.replace(/\s*\(([^()]*)\)/g, (m, g) => { det.push(g); return ''; });
  return [c.replace(/\s+/g, ' ').trim(), det]; }
const shortNm = n => cleanNm(n)[0];
function grpTag(xs){ const ks = xs.map(st3), allP = ks.length && ks.every(k => k === 'P'), allN = ks.length && ks.every(k => k === 'N');
  if (allP) return '<em class="fxt p">준비중</em>'; if (allN) return '<em class="fxt n">신규</em>';
  return (ks.includes('P') ? '<em class="fxt p">준비중 포함</em>' : '') + (ks.includes('N') ? '<em class="fxt n">신규 포함</em>' : ''); }
function fxGroup(g, i, kind, s, extra){
  const [gname, names] = g, isD = kind === 'd';
  const xs = names.map(n => isD ? (s.d.find(x => x[0] === n) || [n, 1]) : [n, ((s.of || []).find(x => x[0] === n) || [n, []])[1]]);
  const single = xs.length === 1 && shortNm(xs[0][0]) === gname;
  const subs = xs.map(x => { const [c, det] = cleanNm(x[0]), fm = (isD ? x[5] : x[1]) || [], k = isD ? st3(x) : 'E';
    const fmTxt = fm.join(' '), tok = d => d.split(/[\s·,\/]+/).filter(w => w.length > 1);
    const covered = w => fmTxt.indexOf(w) >= 0 || (/메일$/.test(w) && fmTxt.indexOf('메일') >= 0) || (/회의록|녹취/.test(w) && /회의록|녹취/.test(fmTxt));
    const det2 = det.map(d => { const ws = d.split(/\s*·\s*|\s*,\s*/).filter(Boolean); const keep = ws.filter(w => !tok(w).length || tok(w).some(x => !covered(x))); return keep.join('·'); }).filter(Boolean);
    const tail = fm.concat(det2).map(esc).join(' · ');
    return '<li class="' + ST3[k][0] + '"' + aiA(isD ? 'd' : 'of', x[0]) + (isD && stNote(x) ? ' title="' + esc(stNote(x)) + '"' : '') + '>' + (single ? '<span class="fxk">형식</span>' : '<span class="fxsn">' + esc(c) + '</span>' + (tail ? '<span class="fxd"> — </span>' : '')) +
      '<span class="fxf2">' + tail + '</span>' + (isD && k === 'P' ? ' <span class="prw">(' + esc(stWho(x)) + ')</span>' : '') + (isD && k === 'N' && !single ? ' <em class="fxt n">신규</em>' : '') + (extra ? extra(x) : '') + '</li>'; }).join('');
  return '<li' + agA(isD ? 'dg' : 'og', gname) + ' class="' + (isD ? ST3[xs.every(x => st3(x) === 'P') ? 'P' : xs.every(x => st3(x) === 'N') ? 'N' : 'E'][0] : 'h') + '"><span class="fxn">' + (i + 1) + '</span><div class="fxb"><b>' + esc(gname) + '</b>' + (isD ? grpTag(xs) : '') + '<ul class="fxsub">' + subs + '</ul></div></li>';
}
function fxDG(s){ return (s.dg && s.dg.length) ? s.dg : s.d.map(x => [shortNm(x[0]), [x[0]]]); }
function fxOG(s){ return (s.og && s.og.length) ? s.og : fxOuts(s).map(x => [shortNm(x[0]), [x[0]]]); }
function chainFlow(b){ /* 세부 Agent 박스 클릭: 아래 섹션으로 이동 (apage 클릭 처리에서) */
  const first = sid => D.subs[sid].tasks.slice().sort(taskOrder)[0];
  const order = b.subs.slice().sort((a, c) => (Math.min.apply(null, D.subs[a].stages) - Math.min.apply(null, D.subs[c].stages)) || taskOrder(first(a), first(c)));
  const lim = 4, more = xs => xs.length > lim ? '<li class="more" title="' + esc(xs.slice(lim).map(x => x[0]).join(', ')) + '">외 ' + (xs.length - lim) + '개</li>' : '';
  const box = (f, xs, kind, sid) => {
    if (kind !== 'in') return '<div class="fbx out"><h6>' + esc(f) + '<small>' + xs.length + '</small></h6><ul>' + xs.slice(0, lim).map(x => '<li>' + esc(x[0]) + '</li>').join('') + more(xs) + '</ul></div>';
    return '<div class="fbx in"><h6>' + esc(f) + '<small>' + xs.length + '</small></h6><p class="ifm"><b>투입 형태</b>' + esc((D.form && D.form[f]) || f) + '</p><ul>' + xs.slice(0, lim).map(x => '<li class="' + ST3[st3(x)][0] + '"' + (stNote(x) ? ' title="' + esc(stNote(x)) + '"' : '') + '>' + nmP(x) + (st3(x) === 'E' ? '' : '<em>' + (st3(x) === 'P' ? '준비중' : '신규') + '</em>') + '</li>').join('') + more(xs) + '</ul></div>';
  };
  const rows = order.map((sid, k) => {
    const s = D.subs[sid], bd = bandOf(sid), st = (D.story && D.story[bd.id] && D.story[bd.id].subs[sid]) || {f:[]}, outs = (D.outs || {})[sid] || [];
    const ofs = fxOuts(s);
    const dgs = fxDG(s), ogs = fxOG(s);
    const ins = s.d.length ? '<div class="fbx in"><h6>투입 Data<small>' + dgs.length + '묶음 · ' + s.d.length + '항목</small></h6><ol class="fxl">' + dgs.map((g, i) => fxGroup(g, i, 'd', s)).join('') + '</ol></div>' : '<div class="fbx in none"><h6>투입 Data 없음</h6></div>';
    const ous = ofs.length ? '<div class="fbx out"><h6>산출물<small>' + ogs.length + '묶음 · ' + ofs.length + '항목</small></h6><ol class="fxl">' + ogs.map((g, i) => fxGroup(g, i, 'o', s)).join('') + '</ol></div>' : '<div class="fbx out none"><h6>산출물 없음</h6></div>';
    const api = s.s.length ? '<div class="fx-api"><b>활용 시스템 <small>목적별 시스템</small></b><ol class="fxp">' + fxPurposes(s).map(([p, ns], i) => '<li><span class="fxn">' + (i + 1) + '</span><div class="fxb"><b>' + esc(p) + '</b><span class="fxs">' + ns.map(n => fxSysChip(s, n)).join('') + '</span></div></li>').join('') + '</ol></div>' : '<div class="fx-api"><b>활용 시스템</b><span class="none">없음</span></div>';
    const ag = '<div class="fx-ag" data-ag="' + sid + '"><div class="fx-agh"><span class="x4num">' + (k + 1) + '</span><span><small>세부 Agent · ' + s.stages.join('·') + '단계</small><b>' + esc(s.name) + '</b></span></div><ul class="fx-fn">' + (st.f.length ? st.f.slice(0, 3).map(q => '<li>' + esc(q[0]) + '</li>').join('') : '<li>' + esc(s.desc) + '</li>') + '</ul>' + api + '</div>';
    const row = '<div class="fx-row"><div class="fx-in">' + ins + '</div><div class="fx-gap" aria-hidden="true"></div>' + ag + '<div class="fx-gap" aria-hidden="true"></div><div class="fx-out">' + ous + '</div></div>';
    const nx = order[k + 1], hand = nx && subHand(order[k], nx) ? '<div class="fx-hand"><div><span title="' + esc(ofs.map(x => x[0]).join(', ')) + '">▼ 산출물 전달 → ' + esc(D.subs[nx].name) + '</span></div></div>' : '';
    return row + hand;
  }).join('');
  return '<div class="dfw"><h5><span class="ic">' + IC.flow + '</span>Agent 구조도<small class="dfs2">투입 Data·형식, 목적별 활용 시스템, 산출물·형식 순으로 표시 · 산출물은 다음 세부 Agent로 전달</small></h5>' +
    '<div class="fx"><div class="fx-cap"><span>투입 Data (묶음별 항목·형식, 우선순위순)</span><span>세부 Agent (목적별 활용 시스템)</span><span>산출물 (묶음별 항목·형식)</span></div>' + rows + '</div></div>';
}
function subFlow(s){
  const bd = bandOf(s.id), st = (D.story && D.story[bd.id] && D.story[bd.id].subs[s.id]) || {f:[]};
  return '<div class="dfw sub"><h5><span class="ic">' + IC.flow + '</span>이 Agent의 데이터 흐름</h5>' + flowDiag({linesF:!!st.f.length, name:s.name, lines:(st.f.length ? st.f.map(q => esc(q[0])) : [esc(s.desc)]), data:s.d, sys:s.s, sp:fxPurposes(s), of:fxOuts(s), outs:(D.outs || {})[s.id] || [], lim:5, subs:[s.id]}) + '</div>';
}
function dataTbl(b){
  const U = unionObj(b.subs);
  const rows = U.d.map(e => { const nm_ = e[0], h = e[1], users = b.subs.filter(sid => D.subs[sid].d.some(x => x[0] === nm_)), n = h ? [].concat.apply([], users.map(sid => D.subs[sid].tasks)).filter(x => D.A6[x] && splitItems(D.A6[x].inp).indexOf(nm_) >= 0).length : 0;
    return '<tr' + aiA('d', nm_) + '><td><b>' + esc(shortNm(nm_)) + '</b>' + (cleanNm(nm_)[1].length ? '<small class="fxdet">' + esc(cleanNm(nm_)[1].join(' · ')) + '</small>' : '') + (stWho(e) ? '<span class="prw blk">(' + esc(stWho(e)) + ')</span>' : '') + '</td><td><span class="fmt"' + atA('xf|d|' + nm_) + '>' + esc(dfOf(nm_, users)) + '</span></td><td>' + esc((D.form && D.form[dfOf(nm_, users)]) || '') + '</td><td>' + stTag(e) + '</td><td>' + atS('xw|d|' + nm_, esc(whenOf(nm_, 'd', users))) + '</td><td>' + users.map(sid => esc(D.subs[sid].name)).join(', ') + '</td><td class="src">' + (h ? (n ? 'As-Is ' + n + '행의 인풋 데이터 (AR열)' : '현업 사용 (As-Is 엑셀·인터뷰)') : (st3(e) === 'P' ? '다른 팀이 준비중' : 'To-be 설계 가설')) + stNoteHTML(e) + '</td></tr>'; }).join('');
  return '<div class="tblw"><table class="mx"><thead><tr><th>데이터</th><th>형식</th><th>투입 형태</th><th>상태</th><th>연결·필요 시점</th><th>쓰는 세부 Agent</th><th>근거</th></tr></thead><tbody>' + rows + '</tbody></table></div>';
}
function sysTbl(b){
  const U = unionObj(b.subs);
  if (!U.s.length) return '<p class="none">API로 연동하는 시스템 없음</p>';
  const rows = U.s.map(e => { const nm_ = e[0], h = e[1], users = b.subs.filter(sid => D.subs[sid].s.some(x => x[0] === nm_)), n = h ? [].concat.apply([], users.map(sid => D.subs[sid].tasks)).filter(x => D.A6[x] && splitItems(D.A6[x].sys).indexOf(nm_) >= 0).length : 0;
    return '<tr' + aiA('s', nm_) + '><td><b>' + esc(shortNm(nm_)) + '</b>' + (cleanNm(nm_)[1].length ? '<small class="fxdet">' + esc(cleanNm(nm_)[1].join(' · ')) + '</small>' : '') + (stWho(e) ? '<span class="prw blk">(' + esc(stWho(e)) + ')</span>' : '') + '</td><td>' + stTag(e) + '</td><td>' + atS('xw|s|' + nm_, esc(whenOf(nm_, 's', users))) + '</td><td>' + atS('xi|s|' + nm_, esc(sxInfo(nm_, users))) + '</td><td>' + users.map(sid => esc(D.subs[sid].name)).join(', ') + '</td><td class="src">' + (h ? (n ? 'As-Is ' + n + '행의 활용 시스템 (AQ열)' : '현업 사용 (As-Is 엑셀·인터뷰)') : (st3(e) === 'P' ? '다른 팀이 준비중' : 'To-be 설계 가설')) + stNoteHTML(e) + '</td></tr>'; }).join('');
  return '<div class="tblw"><table class="mx"><thead><tr><th>시스템 (API 연동)</th><th>상태</th><th>연결 시점</th><th>Agent와 주고받는 정보</th><th>쓰는 세부 Agent</th><th>근거</th></tr></thead><tbody>' + rows + '</tbody></table></div><p class="hint">' + esc(U.sysHint) + '</p>';
}
function whoOf(x){ const q = D.TB[x]; if (!q) return ''; if (q.sub) return D.subs[q.sub].name; const a = D.A6[x]; return a ? a.team : ''; }
function profileHTML(s){
  const bd = bandOf(s.id), st = (D.story && D.story[bd.id] && D.story[bd.id].subs[s.id]) || {f:[], pn:[], e:''}, ts = s.tasks.slice().sort(taskOrder), set = new Set(s.tasks), pre = [], nxt = [];
  liveEdges().forEach(([a, c, t2]) => { if (t2 === 'l' || t2 === 'r') return; if (set.has(c) && !set.has(a) && D.TB[a] && pre.indexOf(a) < 0) pre.push(a); if (set.has(a) && !set.has(c) && D.TB[c] && nxt.indexOf(c) < 0) nxt.push(c); });
  pre.sort(taskOrder); nxt.sort(taskOrder);
  const hasIn = new Set(); liveEdges().forEach(([a, c, t2]) => { if (t2 !== 'l' && t2 !== 'r') hasIn.add(c); });
  const startT = ts.some(x => D.TB[x] && D.TB[x].t !== 'M' && !hasIn.has(x));
  const item = x => '<li>「' + esc(sh(D.TB[x].lb, 34)) + '」<span class="who">' + esc(whoOf(x)) + '</span></li>';
  const outs = []; ts.forEach(x => { const a = D.A6[x]; if (a) splitItems(a.out).forEach(o => { if (outs.indexOf(o) < 0) outs.push(o); }); else if (D.TB[x] && D.TB[x].t !== 'M' && outs.indexOf(sh(D.TB[x].lb, 40)) < 0) outs.push(sh(D.TB[x].lb, 40)); });
  const tags = []; ts.forEach(x => { const g = D.TB[x] && D.TB[x].tg; if (g && /확인|선택|판단|확정|체결|발송|브리핑|컨택|선별|병행/.test(g) && tags.indexOf(g) < 0) tags.push(g); });
  const hitl = hitlOf(s.tasks), rep = ts.filter(x => D.A6[x]), neu = ts.filter(x => !D.A6[x]);
  const row = (icon, label, body, cls) => '<tr><th><span class="ic">' + icon + '</span>' + label + (AGE && AGAUTO.indexOf(label) >= 0 ? '<small class="agauto">지도 기준 자동</small>' : '') + '</th><td' + (cls ? ' class="' + cls + '"' : '') + '>' + body + '</td></tr>';
  return '<table class="prof' + (AGE ? ' agx-on' : '') + '"><tbody>' + (AGE ? AGNOTE : '') +
    row(IC.info, '한 줄 정의', AGE ? agTxt(s.id, 'desc', s.desc) : esc(s.desc), AGE ? '' : 'big') +
    row(IC.layers, '소속 · 활동 단계', '<b>' + esc(bd.name) + '</b> 소속<span class="sp2"></span>' + s.stages.map(x => '<span class="stpill">' + esc(stName(x)) + '</span>').join('')) +
    row(IC.flag, '작동 시점', (ts.every(x => D.TB[x] && D.TB[x].t === 'M') ? '<p>상시 — 단계별 게이트 판단 및 진행 현황 갱신 시점에 작동</p>' :
      ((startT ? '<ul><li><b>프로세스 시작</b> — 클라이언트 브리프·요청 접수 시 즉시 시작</li></ul>' : '') + (pre.length ? '<ul>' + pre.slice(0, 5).map(item).join('') + '</ul><p class="nx">위 업무 완료 후 이 Agent가 이어서 수행합니다</p>' : '')))) +
    row(IC.spark, '주요 기능', AGE ? agList(s.id, 'f', st.f) : '<ul>' + st.f.map(q => '<li>' + esc(q[0]) + '</li>').join('') + '</ul>') +
    row(IC.db, '필요한 Data', AGE ? agItems(s.id, 'd') : '<div class="pcol">' + dsList(s.d, 0, 'd') + '</div>') +
    row(IC.gear, '활용 시스템', AGE ? agItems(s.id, 's') : '<div class="pcol">' + dsList(s.s, 0, 's') + '</div>') +
    row(IC.out, '산출물', (AGE ? agOuts(s.id) : agOutView(s, outs)) + (nxt.length ? '<p class="nx"><b>다음으로 넘어가는 업무</b></p><ul>' + nxt.slice(0, 5).map(item).join('') + '</ul>' : '')) +
    row(IC.check, '사람이 확인하는 지점', (tags.length ? tags.map(g => '<span class="tg own big">' + esc(g) + '</span>').join('') : '<span class="none">업무 태그 없음</span>') + (hitl.length ? '<p class="nx"><b>선후 연결된 담당자 확인 업무</b></p><ul>' + hitl.map(x => '<li>' + esc(D.TB[x].lb) + '<span class="who">' + esc(whoOf(x)) + '</span></li>').join('') + '</ul>' : '')) +
    row(IC.target, '해결하는 Pain point', AGE ? agList(s.id, 'pn', st.pn) : '<ul class="pn">' + st.pn.map(q => '<li>' + esc(q[0]) + '</li>').join('') + '</ul>') +
    row(IC.trend, '기대 변화', AGE ? agTxt(s.id, 'e', st.e) : esc(st.e), AGE ? '' : 'eff') +
    row(IC.person, '대체하는 As-Is 업무', (rep.length ? '<ul>' + rep.map(x => '<li>' + esc(D.A6[x].n) + '<span class="who">' + esc(D.A6[x].team) + ' · ' + esc(D.A6[x].ai) + '</span></li>').join('') + '</ul>' : '<span class="none">대체하는 As-Is 업무 없음</span>') + (neu.length ? '<p class="nx"><b>새로 생기는 업무</b></p><ul>' + neu.map(x => '<li>' + esc(D.TB[x].lb) + '</li>').join('') + '</ul>' : '')) +
    '</tbody></table>';
}
function subHTML(s){
  const ts = s.tasks.slice().sort(taskOrder), hitl = hitlOf(s.tasks), outs = [];
  ts.forEach(x => { const a = D.A6[x]; if (a) splitItems(a.out).forEach(o => { if (outs.indexOf(o) < 0) outs.push(o); }); });
  let prev = '';
  const rows = ts.map(x => {
    const tb = D.TB[x], a = D.A6[x], n = NS6[x] || {}, ps = painOf(x), txt = ps.map(p => p[1]).join('\n');
    const pc = !txt ? '<span class="none">—</span>' : (txt === prev ? '<span class="none">↑ 위와 같음</span>' : ps.map(p => (a ? '' : '<small>' + esc(nm(p[0])) + '</small>') + '<p>' + br(p[1]) + '</p>').join(''));
    if (txt) prev = txt;
    return '<tr data-tid="' + esc(x) + '"><td class="c">' + (n.st || '') + '</td><td>' + esc(tb.lb) + (tb.tg ? ' <span class="tg ' + tgCls(tb.tg) + '">' + esc(tb.tg) + '</span>' : '') + '</td><td>' + (a ? esc(a.n) + '<br><small>' + esc(a.team) + ' · ' + esc(a.ai) + '</small>' : '<span class="none">As-Is 없음 (신규)</span>') + '</td><td>' + (a ? br(a.out) : '') + '</td><td class="pc">' + pc + '</td></tr>';
  }).join('');
  return '<article class="sbs" id="sub-' + s.id + '"><header><div><span class="apk">세부 Agent · ' + esc(bandOf(s.id).name) + '</span><h4' + (AGE ? ' data-nmk="ag|' + s.id + '" contenteditable="true" title="세부 Agent 이름 — 고치면 메인 맵·구조도·설명 문장까지 반영"' : '') + '>' + esc(s.name) + '</h4></div><div class="sbm">' + (AGE ? agSubBar(s.id) : '') + '<span class="stpill">업무 ' + s.tasks.length + '개</span></div></header>' + subFlow(s) + profileHTML(s) +
    '<h5>담당 업무 상세 (As-Is 대비 To-be)</h5><div class="tblw"><table class="tk"><thead><tr><th>단계</th><th>To-be 업무</th><th>As-Is 업무 (담당 · AI)</th><th>As-Is 아웃풋</th><th>해소하려는 Pain point</th></tr></thead><tbody>' + rows + '</tbody></table></div></article>';
}
/* ---------- Agent별 프로세스 맵 (capability map: Lv.4 › Lv.5 › Lv.6, As-Is → To-be) */
const L5OF = {}; Object.keys(D.A5).forEach(k => D.A5[k].kids.forEach(x => { L5OF[x] = k; }));
const ST5 = {}; D.stages.forEach(s => D.A4[s.id].kids.forEach(k => { ST5[k] = s.n; }));
const TYN = {A:'Agent', N:'담당자 확인', H:'사람', X:'소멸'};
function l5Of(x){ return L5OF[x] || (D.TB[x] && D.TB[x].l5) || null; }
function cmState(){ return S.cm || (S.cm = {lv:5, view:'both', scope:'rel'}); }
function cntTypes(ids){ const c = {A:0, N:0, H:0, X:0}; ids.forEach(x => { const k = D.TB[x] && D.TB[x].t; if (c[k] != null) c[k]++; }); return c; }
function asisInfo(ids){ const teams = []; let ai = 0; ids.forEach(x => { const a = D.A6[x]; if (!a) return; if (teams.indexOf(a.team) < 0) teams.push(a.team); if (a.ai !== '인간 전담') ai++; }); return {teams, ai, n:ids.length}; }
function barHTML(c){ const tot = (c.A + c.N + c.H + c.X) || 1; return '<div class="cmbar" title="Agent ' + c.A + ' · 담당자 확인 ' + c.N + ' · 사람 ' + c.H + ' · 소멸 ' + c.X + '">' + ['A', 'N', 'H', 'X'].map(k => c[k] ? '<i class="' + k + '" style="width:' + (c[k] / tot * 100).toFixed(1) + '%"></i>' : '').join('') + '</div>'; }
function cmLines(view, asis, tobe, c){ return '<div class="cml">' + (view !== 'tobe' ? '<b>As-Is</b><span>' + asis + '</span>' : '') + (view !== 'asis' ? '<b>To-be</b><span class="tb">' + tobe + '</span>' : '') + '</div>' + (view !== 'asis' ? barHTML(c) : ''); }
function tobeLine(c, mine){ return 'Agent ' + c.A + ' · 확인 ' + c.N + ' · 사람 ' + c.H + (c.X ? ' · 소멸 ' + c.X : '') + (mine ? ' <span class="me">· 이 Agent ' + mine + '</span>' : ''); }
function cmRow(x, tasks, view){
  const a = D.A6[x], tb = D.TB[x] || {}, me = tasks.has(x), isNew = !a;
  const ty = isNew ? (tb.t === 'M' ? 'Orchestrator' : '신규 Agent') : TYN[tb.t];
  const who = tb.sub ? D.subs[tb.sub].name : (a ? a.team : '');
  const name = view === 'tobe' ? (tb.lb || (a && a.n) || '') : (a ? a.n : tb.lb);
  const tip = (a ? 'As-Is: ' + a.n + ' (' + a.team + ' · ' + a.ai + ')\n' : 'As-Is 없음 (신규)\n') + 'To-be: ' + (tb.lb || '') + ' — ' + ty + (who ? ' · ' + who : '') + (a && a.pain ? '\n\nPain point: ' + a.pain : '');
  return '<div class="cmr t-' + (isNew ? 'new' : tb.t) + (me ? ' me' : '') + '" data-id="' + esc(x) + '" title="' + esc(tip) + '"><span class="cn">' + esc(name) + '</span><span class="io">' +
    (view !== 'tobe' ? '<span class="lab">As-Is</span>' + (a ? esc(a.team) + ' · ' + esc(a.ai) : '<span class="none">없음</span>') : '') + (view === 'both' ? '<span class="ar">→</span>' : '') +
    (view !== 'asis' ? '<span class="lab">To-be</span><span class="ty6 ' + (isNew ? 'new' : tb.t) + '">' + esc(ty) + '</span>' + (who ? '<span class="who">' + esc(who) + '</span>' : '') : '') + '</span></div>';
}
function cmHTML(b){
  const st = cmState(), tasks = new Set([].concat.apply([], b.subs.map(id => D.subs[id].tasks)));
  const relL5 = new Set(); tasks.forEach(x => { const l = l5Of(x); if (l) relL5.add(l); });
  const relSt = new Set(Array.from(relL5).map(l => ST5[l]));
  const btn = (k, v, lab) => '<button type="button" data-cm="' + k + ':' + v + '" aria-pressed="' + (String(st[k]) === String(v)) + '">' + lab + '</button>';
  let h = '<div class="cmctl"><div class="grp"><span>레벨</span><div class="seg">' + btn('lv', 4, U.lv4btn) + btn('lv', 5, 'Lv.5') + btn('lv', 6, 'Lv.6') + '</div></div>' +
    '<div class="grp"><span>보기</span><div class="seg">' + btn('view', 'both', 'As-Is → To-be') + btn('view', 'asis', 'As-Is') + btn('view', 'tobe', 'To-be') + '</div></div>' +
    '<div class="grp"><span>범위</span><div class="seg">' + btn('scope', 'rel', '이 Agent 관련만') + btn('scope', 'all', D.stages.length + '단계 전체') + '</div></div>' +
    '<span class="cmlg"><i class="A"></i>Agent <i class="N"></i>담당자 확인 <i class="H"></i>사람 <i class="X"></i>소멸 <span class="sep2"></span><span class="mebox"></span>이 Agent의 담당 업무 <span class="sep2"></span>카드·업무 줄을 누르면 세부 내용</span></div>';
  const stages = D.stages.filter(s => st.scope === 'all' || relSt.has(s.n));
  h += '<div class="cm cm' + st.lv + '">' + stages.map(s => {
    const relS = relSt.has(s.n), extraIds = k => Object.keys(D.TB).filter(x => !D.A6[x] && D.TB[x].l5 === k && (D.TB[x].t !== 'M' || tasks.has(x)));
    let body;
    if (st.lv === 4){
      const ids = flat(D.A4[s.id].kids.map(k => D.A5[k].kids)), c = cntTypes(ids), ai = asisInfo(ids), mine = Array.from(tasks).filter(x => D.TB[x] && D.TB[x].st === s.n).length;
      const subsHere = b.subs.filter(sid => D.subs[sid].stages.indexOf(s.n) >= 0).map(sid => D.subs[sid].name);
      body = '<div class="cmt' + (relS ? ' rel' : ' dim') + '" data-st="' + s.n + '"><h6>' + esc(s.name) + '</h6>' + cmLines(st.view, 'Lv5 ' + D.A4[s.id].kids.length + ' · Lv6 ' + ai.n + ' · 참여 ' + esc(ai.teams.join('·')) + ' · AI 활용 ' + ai.ai, tobeLine(c, mine), c) +
        (subsHere.length && st.view !== 'asis' ? '<p class="cmsub">이 Agent의 세부 Agent: ' + subsHere.map(esc).join(', ') + '</p>' : '') + '</div>';
    } else {
      body = D.A4[s.id].kids.filter(k => st.scope === 'all' || relL5.has(k)).map(k => {
        const a5 = D.A5[k], extra = extraIds(k), ids = a5.kids, c = cntTypes(ids), ai = asisInfo(ids), rel = relL5.has(k), mine = ids.concat(extra).filter(x => tasks.has(x)).length;
        let tile = '<div class="cmt' + (rel ? ' rel' : ' dim') + '" data-l5="' + k + '"><h6>' + esc(a5.n) + '</h6>' +
          cmLines(st.view, esc(a5.team) + ' · Lv6 ' + ai.n + ' · AI 활용 ' + ai.ai + (ai.teams.length > 1 ? ' · 참여 ' + esc(ai.teams.join('·')) : ''), tobeLine(c, mine), c);
        if (st.lv === 6) tile += '<div class="cmrs">' + ids.concat(extra).map(x => cmRow(x, tasks, st.view)).join('') + '</div>';
        return tile + '</div>';
      }).join('');
    }
    return '<div class="cmc' + (relS ? ' rel' : '') + '"><div class="cmh"><span class="tln">' + s.n + '</span>' + esc(s.name.replace(/^\d+\.\s*/, '')) + '</div>' + body + '</div>';
  }).join('') + '</div>';
  return h;
}
/* ---------- Agent 페이지 흐름도: 이 Agent가 맡는 Lv.5 범위의 As-Is ↔ To-be (박스가 Agent 레인으로 이동) */
const AF = {lv:6, scr:'asis', view:'both', els:{}, model:null, play:null, t:null};
const AFL = {5:{colW:150, nodeW:132, rowH:56, nodeH:46, pad:7, gap:26, top:34}, 6:{colW:132, nodeW:116, rowH:56, nodeH:46, pad:7, gap:26, top:34}};
const AFMARK = MARKERS.replace(/id="m-/g, 'id="af-m-');
function afShell(){
  return '<div class="af"><div class="afctl"><div class="seg">' + [5, 6].map(v => '<button type="button" data-af="lv:' + v + '" aria-pressed="' + (AF.lv === v) + '">Lv.' + v + '</button>').join('') + '</div>' +
    '<div class="seg afstg">' + (AF.stList || []).map(s => '<button type="button" data-af="st:' + s + '" aria-pressed="' + (AF.st === s) + '">' + s + '단계</button>').join('') + '<button type="button" data-af="st:all" aria-pressed="' + (AF.st === 'all') + '">전체</button></div>' +
    '<div class="seg afscr"><button type="button" data-af="scr:both" aria-pressed="' + (AF.view === 'both') + '">위아래 비교</button><button type="button" data-af="scr:asis" aria-pressed="' + (AF.view !== 'both' && AF.scr === 'asis') + '">As-Is</button><button type="button" data-af="scr:ns" aria-pressed="' + (AF.view !== 'both' && AF.scr === 'ns') + '">To-be</button></div>' +
    '<button type="button" data-af="play" id="afPlay">▶ 자동 전환</button><button type="button" data-af="fit" id="afFit" aria-pressed="' + (AF.fit !== false) + '">⤢ 한 화면 맞춤</button><span class="afhint">To-be로 전환하면 이 Agent의 담당 업무가 Agent 레인으로 이동합니다</span></div>' +
    '<div class="afwrap"><div class="afsz" id="afsz"><div class="afin" id="afin"><div class="aflab" id="aflab"></div><div class="afboard" id="afb"><svg class="afedges" id="afsvg" aria-hidden="true"></svg></div></div></div></div></div>';
}
function afItem(e){
  // 화살표에 적을 '주고받는 것': 신호선은 신호 이름, 그 밖은 보내는 업무의 산출물
  if (e[2] === 'o') return e[3] || '신호';
  const a = e[0], a6 = D.A6[a];
  if (a6 && a6.out){ const it = splitItems(a6.out)[0]; if (it) return it.replace(/^[-•·\s]+/, ''); }
  const a5 = D.A5[a]; if (a5 && a5.kids){ for (let k = a5.kids.length - 1; k >= 0; k--){ const x = D.A6[a5.kids[k]]; if (x && x.out){ const it = splitItems(x.out)[0]; if (it) return it.replace(/^[-•·\s]+/, ''); } } }
  const tb = D.TB[a]; return tb ? plain(tb.lb).replace(/\s*\(.*\)$/, '') : '';
}
function afModel(b){
  const lv = AF.lv, V = D.views[lv], tasks = new Set([].concat.apply([], b.subs.map(id => D.subs[id].tasks))), rel = new Set();
  tasks.forEach(x => { const l = l5Of(x); if (l) rel.add(l); });
  const inA = n => lv === 6 ? rel.has(n.pid) : rel.has(n.id);
  const inN = n => lv === 6 ? (D.A6[n.id] ? rel.has(n.pid) : !!(D.TB[n.id] && rel.has(D.TB[n.id].l5) && (n.k !== 'mk' || tasks.has(n.id)))) : (rel.has(n.pid) || (n.k === 'mk' && tasks.has(n.id)));
  const A = V.asis.nodes.filter(inA), N0 = V.ns.nodes.filter(n => n.k !== 'why' && n.k !== 'pt' && inN(n)), i0 = new Set(N0.map(n => n.id)), N1 = N0.concat(V.ns.nodes.filter(n => n.k === 'why' && i0.has(n.of)));
  // 이 Agent 업무와 직접 주고받는 다른 Agent·사람 업무도 함께 (흐리게) — 어디로 가고 어디서 오는지 보이게
  const byN = {}; V.ns.nodes.forEach(n => { byN[n.id] = n; }); const i1 = new Set(N1.map(n => n.id)), ext = [];
  V.ns.edges.forEach(e => { if (e[2] === 'l' || e[2] === 'r') return; const ia = i1.has(e[0]), ic = i1.has(e[1]); if (ia === ic) return; const o = ia ? e[1] : e[0], n = byN[o];
    if (!n || n.k === 'why' || n.k === 'pt' || ext.some(x => x.id === o)) return; ext.push(Object.assign({}, n, {ext:1})); });
  const N = N1.concat(ext), L = AFL[lv];
  const bandOf = sid => D.bands.find(z => z.subs.indexOf(sid) >= 0);
  const laneOf = (n, scr) => { if (scr === 'asis') return n.ln; if (n.subs){ const m = b.subs.find(s => n.subs.indexOf(s) >= 0); if (m) return m; }
    if (D.subs[n.ln]){ if (b.subs.indexOf(n.ln) >= 0) return n.ln; return '_oth'; } return n.ln; };
  // 열: 단계 안에서 앞 업무 뒤에 놓되, 같은 레인(As-Is 조직 · To-be 수행 주체)만 겹치지 않게 — 빈 열이 생기지 않아 폭이 짧아짐
  const all = {}, lnA = {}, lnN = {};
  A.forEach(n => { if (!all[n.id]) all[n.id] = n; lnA[n.id] = n.ln; }); N.forEach(n => { if (n.k === 'why') return; if (!all[n.id]) all[n.id] = n; lnN[n.id] = laneOf(n, 'ns'); });
  const pr = {}; V.asis.edges.concat(V.ns.edges).forEach(([a, c, t2]) => { if (t2 === 'l' || t2 === 'r') return; const p = all[a], q = all[c]; if (!p || !q || p.st !== q.st) return; (pr[c] = pr[c] || []).push(a); });
  const ord = n => (n.o != null ? n.o : 1e6), col = {}, colX = {}, stX = []; let x = 10;
  Array.from(new Set(Object.values(all).map(n => n.st))).sort((p, q) => p - q).forEach(s => {
    const Ns = Object.values(all).filter(n => n.st === s).sort((p, q) => (ord(p) - ord(q)) || ((p.c || 0) - (q.c || 0))), nf = {}; let mx = 0;
    Ns.forEach(n => { const ks = []; if (lnA[n.id]) ks.push('A:' + lnA[n.id]); if (lnN[n.id]) ks.push('N:' + lnN[n.id]); let c = 0;
      ks.forEach(k => { c = Math.max(c, nf[k] || 0); }); (pr[n.id] || []).forEach(p => { if (col[p] != null) c = Math.max(c, col[p] + 1); });
      col[n.id] = c; ks.forEach(k => { nf[k] = c + 1; }); mx = Math.max(mx, c + 1); });
    const nc = Math.max(1, mx); stX.push({s, x, w:nc * L.colW, nc}); for (let k = 0; k < nc; k++) colX[s * 1000 + k] = x + k * L.colW; x += nc * L.colW + L.gap; });
  N.forEach(n => { if (n.k === 'why') col[n.id] = col[n.of] != null ? col[n.of] : 0; });
  const human = D.lanes.filter(l => A.some(n => n.ln === l.k) || N.some(n => n.ln === l.k)).map(l => ({k:l.k, name:l.name, sub:l.sub, t:'lane'}));
  const mine = b.subs.filter(sid => N.some(n => laneOf(n, 'ns') === sid)).map(sid => ({k:sid, name:D.subs[sid].name, sub:b.name, t:'sub'}));
  const iA = new Set(A.map(n => n.id)), iN = new Set(N.map(n => n.id)), EN = V.ns.edges.filter(e => iN.has(e[0]) && iN.has(e[1]));
  const uq = a => a.filter((v, k) => v && a.indexOf(v) === k), give = [], take = [];
  EN.forEach(e => { const la = laneOf(byN[e[0]], 'ns'), lc = laneOf(byN[e[1]], 'ns'), mA = b.subs.indexOf(la) >= 0, mC = b.subs.indexOf(lc) >= 0;
    if (mA && lc === '_oth') give.push(afItem(e)); else if (mC && la === '_oth') take.push(afItem(e)); });
  const othNames = uq(N.filter(n => laneOf(n, 'ns') === '_oth').map(n => (bandOf(n.ln) || {}).name));
  const oth = N.some(n => laneOf(n, 'ns') === '_oth') ? [{k:'_oth', name:'다른 Agent', t:'oth', give:uq(give), take:uq(take), sub:othNames.length + '개와 주고받음', names:othNames}] : [];
  return {key:b.id + '|' + lv, tasks, col, colX, stX, W:x + 10, laneOf, byN, bandOf, lanes:{asis:human, ns:human.concat(mine, oth)},
    asis:{nodes:A, edges:V.asis.edges.filter(e => iA.has(e[0]) && iA.has(e[1]))}, ns:{nodes:N, edges:EN}};
}
function afNodeHTML(n, oth){ const bd = oth && D.subs[n.ln] ? D.bands.find(z => z.subs.indexOf(n.ln) >= 0) : null; return (bd ? '<small class="afo">' + esc(bd.name.replace(/ Agent$/, '')) + '</small>' : '') + '<div class="lbl">' + esc(rd(n.lb)) + '</div>'; }
function afEdgeCls(t, a, c){ if (t === 'o') return 'e e-orc'; let k = 'e'; if (t === 'l') k += ' e-loop'; else if (t === 'r') k += ' e-rej'; if (AF.scr === 'ns' && t !== 'l' && t !== 'r' && a && c){ const ai = AIK[a.k] || AIK[c.k], hitl = a.k === 'nh' || c.k === 'nh'; if (ai && hitl) k += ' e-hitl'; else if (AIK[a.k] && AIK[c.k]) k += ' e-ai'; } return k; }


function afStory(b, pos, scr){
  // 상세 Agent 페이지에서는 'To-be 흐름' 목록과 박스 번호를 보여 주지 않음 (요청: 삭제)
  const board = $('#afb'); if (board) $$('.sbadge', board).forEach(e => e.remove());
}
function afFit(W, H){
  // 한 화면 맞춤: 지도 전체가 위아래로 스크롤 없이 보이게 줄임 (너무 작아지면 0.55배에서 멈추고 가로로만 스크롤)
  const wrap = $('#afb') && $('#afb').closest('.afwrap'), sz = $('#afsz'), inn = $('#afin'), lab = $('#aflab'); if (!wrap || !sz || !inn) return;
  const natW = (lab ? lab.offsetWidth : 150) + W + 4, natH = H + 4, cw = wrap.clientWidth - 2, ch = Math.max(340, window.innerHeight - 250);
  // 전체가 0.8배 이상으로 들어가면 통째로 맞추고, 아니면 세로만 한 화면에 맞추고(글자 크기 유지) 가로는 스크롤
  const sAll = Math.min(1, cw / natW, ch / natH); let s = AF.fit === false ? 1 : (sAll >= 0.8 ? sAll : Math.max(0.8, Math.min(1, ch / natH))); AF.scale = s;
  inn.style.width = natW + 'px'; inn.style.transformOrigin = '0 0'; inn.style.transform = s < 1 ? 'scale(' + s.toFixed(3) + ')' : '';
  sz.style.width = Math.ceil(natW * s) + 'px'; sz.style.height = Math.ceil(natH * s) + 'px'; wrap.style.height = 'auto'; wrap.style.maxHeight = 'none';
  const fb = $('#afFit'); if (fb){ fb.setAttribute('aria-pressed', AF.fit !== false); fb.textContent = AF.fit === false ? '⤢ 한 화면 맞춤' : '⤢ 맞춤 ' + Math.round(s * 100) + '%'; }
}
const AFH = {};
function afMeasure(nodes, scr){
  // 박스 글자가 다 보이도록 실제 높이를 잼 (말줄임 없음)
  const M0 = AF.model, L = AFL[AF.lv], out = {}, need = [];
  nodes.forEach(n => { const oth = scr === 'ns' && M0.laneOf(n, scr) === '_oth', html = afNodeHTML(n, oth), k = AF.lv + '|' + L.nodeW + '|' + n.k + '|' + html; if (AFH[k] != null) out[n.id] = AFH[k]; else need.push([n, html, k]); });
  if (need.length){ const host = $('#afb') || document.body, box = document.createElement('div'); box.style.cssText = 'position:absolute;left:0;top:0;visibility:hidden;pointer-events:none;z-index:-1'; host.appendChild(box);
    need.forEach(([n, html, k]) => { const el = document.createElement('div'); el.className = 'nd afn k-' + n.k + ' L' + AF.lv; el.style.cssText = 'position:relative;left:auto;top:auto;width:' + L.nodeW + 'px;height:auto;margin:0 0 4px'; el.innerHTML = html; box.appendChild(el); AFH[k] = Math.max(L.nodeH, el.offsetHeight + 1); /* offsetHeight: 한 화면 맞춤 축소와 무관한 실제 높이 */ out[n.id] = AFH[k]; });
    box.remove(); }
  return out;
}
function afStack(nodes, scr, laneOf, cOf){
  // 같은 레인·같은 열에 여러 박스면 실제 높이대로 아래로 쌓음
  const HM = afMeasure(nodes, scr), cell = {}, off = {}, laneH = {};
  nodes.slice().sort((p, q) => (p.st - q.st) || (cOf(p) - cOf(q)) || ((p.k === 'why') - (q.k === 'why')) || ((p.r || 0) - (q.r || 0))).forEach(n => { const ln = laneOf(n, scr), k = ln + '|' + (n.st * 1000 + cOf(n)), y0 = cell[k] || 0, h = HM[n.id] || AFL[AF.lv].nodeH; off[n.id] = y0; cell[k] = y0 + h + 8; laneH[ln] = Math.max(laneH[ln] || 0, y0 + h); });
  return {HM, off, laneH};
}
function afRenderBoth(){
  AF._ends = {};
  // 위아래 비교: 위 As-Is · 아래 To-be를 같은 열로 — 같은 업무가 사람 레인에서 Agent 레인으로 어떻게 내려가는지 한 화면에
  const b = D.bands.find(x => x.id === S.page), board = $('#afb'), lab = $('#aflab'), sv = $('#afsvg'); if (!b || !board) return;
  if (!AF.model || AF.model.key !== b.id + '|' + AF.lv) AF.model = afModel(b);
  Object.keys(AF.els).forEach(k => AF.els[k].remove()); AF.els = {}; board.classList.remove('morph');
  const M0 = AF.model, L = AFL[AF.lv], stAll = M0.stX.map(s => s.s);
  if (AF.st !== 'all' && stAll.indexOf(AF.st) < 0) AF.st = stAll[0];
  const visS = AF.st === 'all' ? stAll : [AF.st], colX = {}, stX = []; let xs = 10;
  M0.stX.filter(s => visS.indexOf(s.s) >= 0).forEach(s => { stX.push({s:s.s, x:xs, w:s.w}); for (let k = 0; k < s.nc; k++) colX[s.s * 1000 + k] = xs + k * L.colW; xs += s.w + L.gap; });
  const W = xs + 10, vn = n => visS.indexOf(n.st) >= 0, cOf = n => (M0.col[n.id] != null ? M0.col[n.id] : 0);
  const secs = [{scr:'asis', pre:'a:', name:'As-Is · 지금 담당 조직', nodes:M0.asis.nodes.filter(vn), edges:M0.asis.edges}, {scr:'ns', pre:'n:', name:'To-be · 이 Agent가 맡은 뒤', nodes:M0.ns.nodes.filter(vn), edges:M0.ns.edges}];
  const rows = [], pos = {}, items = []; let y = L.top;
  secs.forEach((sc, si) => {
    rows.push({t:'sec', y, h:24, sc}); y += 24;
    const lanes = M0.lanes[sc.scr].filter(l => sc.nodes.some(n => M0.laneOf(n, sc.scr) === l.k)), LY = {}, SK = afStack(sc.nodes, sc.scr, M0.laneOf, cOf);
    lanes.forEach((l, i) => { const h = Math.max((SK.laneH[l.k] || L.nodeH) + 2 * L.pad, 46); LY[l.k] = {y, h}; rows.push({t:l.t, l, y, h, sc, i}); y += h; });
    sc.nodes.forEach(n => { const ly = LY[M0.laneOf(n, sc.scr)], x0 = colX[n.st * 1000 + cOf(n)]; if (!ly || x0 == null) return; const key = sc.pre + n.id;
      pos[key] = {x:x0 + (L.colW - L.nodeW) / 2, y:ly.y + L.pad + (SK.off[n.id] || 0), w:L.nodeW, h:SK.HM[n.id] || L.nodeH}; items.push({key, n, sc}); });
    if (!si) y += 18;
  });
  const H = y + 8;
  board.style.width = W + 'px'; board.style.height = H + 'px'; lab.style.height = H + 'px'; $$('.afbg, .elab, .sbadge', board).forEach(e => e.remove());
  const f = document.createDocumentFragment();
  rows.forEach(r => { const g = document.createElement('div'); g.style.top = r.y + 'px'; g.style.height = r.h + 'px'; g.style.width = W + 'px';
    if (r.t === 'sec'){ g.className = 'afbg afsec ' + r.sc.scr; g.innerHTML = '<span>' + esc(r.sc.name) + '</span>'; } else g.className = 'afbg afrow ' + r.t + (r.t === 'lane' && r.i % 2 ? ' alt' : ''); f.appendChild(g); });
  stX.forEach((s, i) => { const st = D.stages.find(z => z.n === s.s), p = document.createElement('div'); p.className = 'afbg afst'; p.style.left = s.x + 'px'; p.style.width = Math.max(120, s.w - 8) + 'px'; p.innerHTML = '<span class="sn">' + s.s + '</span>' + esc((st ? st.name : '').replace(/^\d+\.\s*/, '')); f.appendChild(p);
    if (i){ const sp = document.createElement('div'); sp.className = 'afbg afsep'; sp.style.left = (s.x - L.gap / 2) + 'px'; sp.style.height = H + 'px'; f.appendChild(sp); } });
  board.insertBefore(f, board.firstChild);
  const lh = l => '<span class="ic lic">' + (l.t === 'lane' ? IC.person : (l.t === 'sub' ? IC.spark : IC.layers)) + '</span><span class="aflt"' + (l.t === 'oth' ? ' title="' + esc((l.names || []).join(', ')) + '"' : '') + '><b>' + esc(l.name) + '</b><small>' + esc(l.t === 'sub' ? '세부 Agent' : (l.sub || '')) + '</small></span>';
  lab.innerHTML = '<div class="afl head" style="top:0;height:' + L.top + 'px">위아래 비교</div>' + rows.map(r => r.t === 'sec' ? '<div class="afl sech ' + r.sc.scr + '" style="top:' + r.y + 'px;height:' + r.h + 'px">' + (r.sc.scr === 'asis' ? 'As-Is' : 'To-be') + '</div>' : '<div class="afl ' + r.t + '" style="top:' + r.y + 'px;height:' + r.h + 'px">' + lh(r.l) + '</div>').join('');
  items.forEach(({key, n, sc}) => { const el = document.createElement('div'), lnx = M0.laneOf(n, sc.scr), oth = sc.scr === 'ns' && lnx === '_oth', mine = sc.scr === 'ns' && b.subs.indexOf(lnx) >= 0;
    el.dataset.id = n.id; el.dataset.scr = sc.scr; el.className = 'nd afn k-' + n.k + ' L' + AF.lv + (mine ? ' mine' : '') + (oth ? ' oth' : '') + (n.ext ? ' ext' : '');
    el.innerHTML = afNodeHTML(n, oth); el.title = plain(n.lb) + (D.subs[n.ln] ? ' — ' + D.subs[n.ln].name : '') + (sc.scr === 'asis' ? ' (As-Is · 마우스를 올리면 To-be 위치 표시)' : ''); place(el, pos[key]); board.appendChild(el); AF.els[key] = el; });
  sv.setAttribute('width', W); sv.setAttribute('height', H); sv.style.width = W + 'px'; sv.style.height = H + 'px'; sv.innerHTML = AFMARK;
  const fr = document.createDocumentFragment(), placed = [], by = {}; AF.geo = [];
  secs.forEach(sc => { const rects = Object.keys(pos).filter(k => k.indexOf(sc.pre) === 0).map(k => Object.assign({id:k}, pos[k])); sc.nodes.forEach(n => { by[sc.pre + n.id] = n; });
    sc.edges.forEach((e, i) => { const a = sc.pre + e[0], c = sc.pre + e[1], A1 = pos[a], B1 = pos[c]; if (!A1 || !B1) return; const t2 = e[2];
      const la = M0.laneOf(by[a], sc.scr), lc = M0.laneOf(by[c], sc.scr), mA = b.subs.indexOf(la) >= 0, mC = b.subs.indexOf(lc) >= 0, hand = sc.scr === 'ns' && t2 !== 'o' && ((mA && lc === '_oth') || (mC && la === '_oth'));
      const cls = (sc.scr === 'ns' ? afEdgeCls(t2, by[a], by[c]) : (t2 === 'l' ? 'e e-loop' : t2 === 'r' ? 'e e-rej' : 'e')) + (hand ? ' hand' : ''), g = route(A1, B1, t2, rects, a, c, 0);
      AF.geo.push({id:a + '>' + c, pts:g.pts, t:t2}); const p = document.createElementNS(SVGNS, 'path'); p.setAttribute('d', toD(g.pts)); p.setAttribute('class', cls); p.setAttribute('marker-end', 'url(#af-' + markerFor(cls) + ')'); { const L0 = g.pts[g.pts.length - 1], ek = sc.scr + Math.round(L0[0]) + ',' + Math.round(L0[1]); if (AF._ends[ek]) p.removeAttribute('marker-end'); else AF._ends[ek] = 1; } fr.appendChild(p);
      if (e[3] && t2 !== 's' && t2 !== 'o') placeLabel(e[3], g, cls, rects, placed, board, A1, B1); }); });
  sv.appendChild(fr);
  const npos = {}; Object.keys(pos).forEach(k => { if (k.indexOf('n:') === 0) npos[k.slice(2)] = pos[k]; }); AF.pos = npos;
  afStory(b, npos, 'ns'); afFit(W, H);
  $$('.afctl [data-af^="st:"]').forEach(x => x.setAttribute('aria-pressed', x.dataset.af === 'st:' + AF.st));
  $$('.afctl [data-af^="lv:"]').forEach(x => x.setAttribute('aria-pressed', x.dataset.af === 'lv:' + AF.lv));
  $$('.afctl [data-af^="scr:"]').forEach(x => x.setAttribute('aria-pressed', x.dataset.af === 'scr:both'));
}
function afRender(anim){
  if (AF.view === 'both') return afRenderBoth();
  AF._ends = {};
  const b = D.bands.find(x => x.id === S.page), board = $('#afb'), lab = $('#aflab'), sv = $('#afsvg'); if (!b || !board) return;
  const afM = !!anim && AF._scr != null && AF._scr !== AF.scr; AF._scr = AF.scr; board.classList.toggle('morph', afM);
  if (!AF.model || AF.model.key !== b.id + '|' + AF.lv){ AF.model = afModel(b); Object.keys(AF.els).forEach(k => AF.els[k].remove()); AF.els = {}; anim = false; }
  const M0 = AF.model, L = AFL[AF.lv], scr = AF.scr, stAll = M0.stX.map(s => s.s);
  if (AF.st !== 'all' && stAll.indexOf(AF.st) < 0) AF.st = stAll[0];
  const visS = AF.st === 'all' ? stAll : [AF.st], colX = {}, stX = []; let x0s = 10;
  M0.stX.filter(s => visS.indexOf(s.s) >= 0).forEach(s => { stX.push({s:s.s, x:x0s, w:s.w}); for (let k = 0; k < s.nc; k++) colX[s.s * 1000 + k] = x0s + k * L.colW; x0s += s.w + L.gap; });
  const vn = n => visS.indexOf(n.st) >= 0, S2 = {nodes:M0[scr].nodes.filter(vn), edges:M0[scr].edges}, M = Object.assign({}, M0, {colX, stX, W:x0s + 10});
  const lanes = M0.lanes[scr].filter(l => S2.nodes.some(n => M0.laneOf(n, scr) === l.k)), row = {}, cnt = {}, maxR = {};
  $$('.afctl [data-af^="st:"]').forEach(x => x.setAttribute('aria-pressed', x.dataset.af === 'st:' + AF.st));
  const cOf = n => (M.col[n.id] != null ? M.col[n.id] : 0);
  const SK = afStack(S2.nodes, scr, M.laneOf, cOf);
  let y = L.top; const LY = {};
  const xch = l => (l.give && l.give.length ? '<span class="xg"><i>보냄</i>' + l.give.slice(0, 2).map(esc).join(' · ') + '</span>' : '') + (l.take && l.take.length ? '<span class="xt"><i>받음</i>' + l.take.slice(0, 2).map(esc).join(' · ') + '</span>' : '');
  const labHTML = l => '<span class="ic lic">' + (l.t === 'lane' ? IC.person : (l.t === 'sub' ? IC.spark : IC.layers)) + '</span><span class="aflt"' + (l.t === 'oth' ? ' title="' + esc(plain(xch(l))) + '"' : '') + '><b>' + esc(l.name) + '</b><small>' + esc(l.t === 'sub' ? '세부 Agent' : (l.sub || '')) + '</small></span>';
  const meas = l => { if (l.t !== 'sub' && l.t !== 'oth') return 0; const k = 'af|' + AF.lv + '|' + S.page + '|' + l.k; if (CARD_H[k]) return CARD_H[k]; const m = document.createElement('div'); m.className = 'afl ' + l.t; m.style.cssText = 'visibility:hidden;top:0;height:auto'; m.innerHTML = labHTML(l); lab.appendChild(m); const h = m.offsetHeight; m.remove(); return (CARD_H[k] = h || 80); };
  lanes.forEach(l => { const h = Math.max((SK.laneH[l.k] || L.nodeH) + 2 * L.pad, Math.min(meas(l) + 6, 62)); LY[l.k] = {y, h, off:0}; y += h; });
  const H = y + 8;
  board.style.width = M.W + 'px'; board.style.height = H + 'px'; lab.style.height = H + 'px';
  $$('.afbg', board).forEach(e => e.remove());
  const f = document.createDocumentFragment();
  let firstSub = true;
  lanes.forEach((l, i) => { const g = document.createElement('div'); g.className = 'afbg afrow ' + l.t + (l.t === 'lane' && i % 2 ? ' alt' : '') + (l.t === 'sub' && firstSub ? ' first' : ''); if (l.t === 'sub') firstSub = false; g.style.top = LY[l.k].y + 'px'; g.style.height = LY[l.k].h + 'px'; g.style.width = M.W + 'px'; f.appendChild(g);
  });
  M.stX.forEach((s, i) => { const st = D.stages.find(z => z.n === s.s), p = document.createElement('div'); p.className = 'afbg afst'; p.style.left = s.x + 'px'; p.style.width = Math.max(120, s.w - 8) + 'px'; p.innerHTML = '<span class="sn">' + s.s + '</span>' + esc((st ? st.name : '').replace(/^\d+\.\s*/, '')); f.appendChild(p);
    if (i){ const sp = document.createElement('div'); sp.className = 'afbg afsep'; sp.style.left = (s.x - L.gap / 2) + 'px'; sp.style.height = H + 'px'; f.appendChild(sp); } });
  board.insertBefore(f, board.firstChild);
  lab.innerHTML = '<div class="afl head" style="top:0;height:' + L.top + 'px">' + (scr === 'asis' ? 'As-Is · 담당 조직' : 'To-be · 수행 주체') + '</div>' + lanes.map(l => '<div class="afl ' + l.t + '" style="top:' + LY[l.k].y + 'px;height:' + LY[l.k].h + 'px">' + labHTML(l) + '</div>').join('');
  const pos = {}, seen = new Set();
  S2.nodes.forEach(n => { const ly = LY[M.laneOf(n, scr)], x0 = M.colX[n.st * 1000 + cOf(n)]; if (!ly || x0 == null) return; pos[n.id] = {x:x0 + (L.colW - L.nodeW) / 2, y:ly.y + (ly.off || 0) + L.pad + (SK.off[n.id] || 0), w:L.nodeW, h:SK.HM[n.id] || L.nodeH}; });
  S2.nodes.forEach(n => { const p = pos[n.id]; if (!p) return; seen.add(n.id); let el = AF.els[n.id]; const isNew = !el;
    if (isNew){ el = document.createElement('div'); el.dataset.id = n.id; board.appendChild(el); AF.els[n.id] = el; place(el, p); if (anim) el.style.opacity = '0'; }
    const lnx = M.laneOf(n, scr), oth = scr === 'ns' && lnx === '_oth', mine = scr === 'ns' && b.subs.indexOf(lnx) >= 0;
    el.className = 'nd afn k-' + n.k + ' L' + AF.lv + (mine ? ' mine' : '') + (oth ? ' oth' : '') + (n.ext ? ' ext' : '');
    el.innerHTML = afNodeHTML(n, oth); el.title = plain(n.lb) + (D.subs[n.ln] ? ' — ' + D.subs[n.ln].name : '');
    place(el, p);
    if (isNew && anim) requestAnimationFrame(() => requestAnimationFrame(() => { el.style.opacity = ''; })); else el.style.opacity = ''; });
  Object.keys(AF.els).forEach(id => { if (!seen.has(id)){ const el = AF.els[id]; delete AF.els[id]; if (anim){ el.style.opacity = '0'; el.style.pointerEvents = 'none'; setTimeout(() => el.remove(), 420); } else el.remove(); } });
  sv.setAttribute('width', M.W); sv.setAttribute('height', H); sv.style.width = M.W + 'px'; sv.style.height = H + 'px'; sv.innerHTML = AFMARK; AF.pos = pos;
  afStory(b, pos, scr); afFit(M.W, H);
  clearTimeout(AF.t);
  AF.t = setTimeout(() => {
    const rects = Object.keys(pos).map(id => Object.assign({id}, pos[id])), by = {}; S2.nodes.forEach(n => { by[n.id] = n; });
    const fr = document.createDocumentFragment(), placed = []; AF.geo = []; AF._lk = new Set(); $$('.elab', board).forEach(e => e.remove());
    S2.edges.forEach((e, i) => { const [a, c, t2] = e, A1 = pos[a], B1 = pos[c]; if (!A1 || !B1) return; const la = M.laneOf(by[a], scr), lc = M.laneOf(by[c], scr);
      const mA = b.subs.indexOf(la) >= 0, mC = b.subs.indexOf(lc) >= 0, hand = scr === 'ns' && t2 !== 'o' && ((mA && lc === '_oth') || (mC && la === '_oth')), cls = afEdgeCls(t2, by[a], by[c]) + (hand ? ' hand' : ''), g = route(A1, B1, t2, rects, a, c, 0); AF.geo.push({id:a + '>' + c, pts:g.pts, t:t2});
      const pth = document.createElementNS(SVGNS, 'path'); pth.setAttribute('d', toD(g.pts)); pth.setAttribute('class', cls); pth.setAttribute('marker-end', 'url(#af-' + markerFor(cls) + ')'); { const L0 = g.pts[g.pts.length - 1], ek = Math.round(L0[0]) + ',' + Math.round(L0[1]); if (AF._ends[ek]) pth.removeAttribute('marker-end'); else AF._ends[ek] = 1; } fr.appendChild(pth);
      const lk = a + '|' + lc;
      if (scr === 'ns' && (hand || (t2 === 'o' && (mA || mC))) && !AF._lk.has(lk)){ AF._lk.add(lk); const txt = afItem(e); if (txt) placeLabel(txt, g, cls, rects, placed, board, A1, B1); }
      else if (e[3] && t2 !== 's') placeLabel(e[3], g, cls, rects, placed, board, A1, B1); });
    sv.appendChild(fr); board.classList.remove('morph');
  }, afM ? MT * 1000 + 400 : (anim ? 680 : 0));
  $$('.afctl [data-af^="lv:"]').forEach(x => x.setAttribute('aria-pressed', x.dataset.af === 'lv:' + AF.lv));
  $$('.afctl [data-af^="scr:"]').forEach(x => x.setAttribute('aria-pressed', AF.view === 'both' ? x.dataset.af === 'scr:both' : x.dataset.af === 'scr:' + AF.scr));
}
function afStop(){ if (AF.play){ clearInterval(AF.play); AF.play = null; } const p = $('#afPlay'); if (p) p.textContent = '▶ 자동 전환'; }
function afPlay(){ if (AF.play){ afStop(); return; } if (AF.view === 'both'){ AF.view = 'one'; AF.scr = 'ns'; afRender(false); } const step = () => { AF.scr = AF.scr === 'asis' ? 'ns' : 'asis'; afRender(true); }; step(); AF.play = setInterval(step, 5600); const p = $('#afPlay'); if (p) p.textContent = '■ 전환 멈춤'; }
/* ---------- Agent 개요: 목적 · Process 개선점 · 세부 Agent별 기능과 해결 Pain point */
function unionObj(subs){ const acc = {d:{}, s:{}}, R = k => 'EPN'.indexOf(k); subs.forEach(sid => ['d', 's'].forEach(k => D.subs[sid][k].forEach(x => { const nm_ = x[0], st = st3(x), r = acc[k][nm_] || (acc[k][nm_] = {n:0, st:'N', note:'', who:''}); r.n++; if (R(st) < R(r.st) || (st === r.st && !r.note)){ r.st = st; r.note = stNote(x) || r.note; r.who = x[4] || r.who; } }))); const out = {}; ['d', 's'].forEach(k => { out[k] = Object.keys(acc[k]).map(x => [x, acc[k][x].st === 'E' ? 1 : 0, acc[k][x].st, acc[k][x].note, acc[k][x].who, acc[k][x].n]).sort((a, c) => (R(a[2]) - R(c[2])) || (c[5] - a[5])); }); return out; }

const X4H = ['주요 기능', '필요 Data', '활용 시스템', '해결하는 Pain point'];
function dsList(arr, maxHave, kind){
  const pre = kind === 's' ? '<span class="dsk">⚙</span>' : '';
  const g = st3Groups(arr).map(([k, xs]) => { if (!xs.length) return ''; const hv = (k === 'E' && maxHave) ? xs.slice(0, maxHave) : xs, more = xs.length - hv.length;
    return '<div class="dsg"><span class="dst ' + ST3[k][0] + '">' + ST3[k][1] + ' ' + xs.length + '개</span><ul class="dsl ' + ST3[k][0] + '">' + hv.map(x => '<li' + aiA(kind, x[0]) + (stNote(x) ? ' title="' + esc(stNote(x)) + '"' : '') + '>' + pre + nmP(x) + '</li>').join('') + (more > 0 ? '<li class="more" title="' + esc(xs.slice(hv.length).map(x => x[0]).join(', ')) + '">외 ' + more + '개</li>' : '') + '</ul></div>'; }).join('');
  return g || '<span class="none">해당 없음</span>';
}
function x4HTML(b){
  const s = D.story && D.story[b.id]; if (!s) return '';
  const U = unionObj(b.subs), cell = (i, h) => '<div class="x4c" data-h="' + (i + 1) + '. ' + X4H[i] + '">' + h + '</div>';
  const head = '<div class="x4 x4h"><div>Agent</div>' + X4H.map((h, i) => '<div><span class="x4n">' + (i + 1) + '</span>' + h + '</div>').join('') + '</div>';
  const big = '<div class="x4 x4r big"><div class="x4a"><span class="ic x4i">' + IC.layers + '</span><small>대분류 Agent</small><b>' + esc(b.name) + '</b><small>세부 Agent ' + b.subs.length + '개</small></div>' +
    cell(0, '<ul class="x4l">' + (s.pb || [s.p]).map((q, i) => '<li' + atA('pb|' + b.id + '|' + i) + '>' + esc(q) + '</li>').join('') + '</ul>') + cell(1, dsList(U.d, 6, 'd')) + cell(2, dsList(U.s, 6, 's')) +
    cell(3, '<ul class="x4l pn">' + b.subs.map(sid => s.subs[sid] && s.subs[sid].pn[0] ? '<li' + atA('pn|' + sid + '|0') + '>' + esc(s.subs[sid].pn[0][0]) + '</li>' : '').join('') + '</ul>') + '</div>';
  const rows = b.subs.map((sid, k) => { const x = s.subs[sid], sub = D.subs[sid]; if (!x) return '';
    return '<div class="x4 x4r"' + (AGE ? ' data-asc="' + sid + '"' : '') + '><div class="x4a"><span class="x4num">' + (k + 1) + '</span><small>세부 Agent</small><b>' + esc(sub.name) + '</b><small>' + sub.stages.join('·') + '단계 · 업무 ' + sub.tasks.length + '개</small></div>' +
      cell(0, '<ul class="x4l">' + x.f.map((q, i) => '<li' + atA('f|' + sid + '|' + i) + '>' + esc(q[0]) + '</li>').join('') + '</ul>') + cell(1, dsList(sub.d, 8, 'd')) + cell(2, dsList(sub.s, 8, 's')) +
      cell(3, '<ul class="x4l pn">' + x.pn.map((q, i) => '<li' + atA('pn|' + sid + '|' + i) + '>' + esc(q[0]) + '</li>').join('') + '</ul><p class="ove"><b>기대 변화</b>' + atS('e|' + sid, esc(x.e)) + '</p>') + '</div>'; }).join('');
  return '<div class="x4w">' + head + big + rows + '</div>';
}
function ovHTML(b){
  const s = D.story && D.story[b.id]; if (!s) return '';
  return '<div class="apov"><div class="ovsw"><h5><span class="ic">' + IC.spark + '</span>Agent 한눈에 보기 — 기능, 필요 Data·시스템, 해결 Pain point</h5>' + x4HTML(b) + '</div>' +
    '<div class="ovi"><h5><span class="ic">' + IC.flow + '</span>Process 개선점 (As-Is → To-be)</h5><ul>' + s.imp.map(q => '<li><span class="ovt">' + esc(q[0]) + '</span><span>' + esc(q[1]) + '</span></li>').join('') + '</ul></div>' +
    '<div class="ovp"><h5><span class="ic">' + IC.person + '</span>사람이 남는 지점</h5><p class="ovh">' + esc(s.hum.replace(/^사람이 남는 지점 — /, '')) + '</p><p class="hint">Pain point는 ' + esc(U.srcShort + ' ' + U.src) + ' 원문(Pain point·비고)의 요약이며, 기능·데이터·시스템·기대 변화는 To-be 가설입니다. 기존: 현업이 현재 사용 · 준비중: 타 팀이 별도 준비 중 (마우스를 올리면 설명) · 신규 설치 필요: 준비 주체 없음.</p></div></div>';
}
const PGB = () => D.bands.filter(x => !(U.relBands || []).includes(x.id));
function agentPage(bid, focus){
  const b = PGB().find(x => x.id === bid) || PGB()[0], i = PGB().indexOf(b);
  if (AF.stFor !== b.id){ AF.stList = bandStages(b).map(Number); AF.st = AF.stList[0]; AF.stFor = b.id; } S.page = b.id; closePanel(); $('#amap').hidden = true;
  const subs = b.subs.map(id => D.subs[id]), tasks = [].concat.apply([], subs.map(s => s.tasks)), asisN = tasks.filter(x => D.A6[x]).length, st = bandStages(b), hitl = hitlOf(tasks);
  const side = PGB().map((x, j) => '<button type="button" class="apn' + (x.id === b.id ? ' on' : '') + '" data-page="' + x.id + '"><span class="apx">' + (j + 1) + '</span><b>' + esc(x.name) + '</b><small>세부 ' + x.subs.length + ' · ' + bandStages(x).join('·') + '단계</small></button>').join('');
  const main = '<header class="apt"><div class="apl"><span class="ic apico">' + IC.spark + '</span><div><span class="apk">큰 기능 Agent ' + (i + 1) + ' / ' + PGB().length + ' · 가설 · 이름은 가칭</span><h2' + (AGE ? ' data-nmk="ag|' + b.id + '" contenteditable="true" title="큰 기능 Agent 이름 — 고치면 메인 맵·구조도·설명 문장까지 반영"' : '') + '>' + esc(b.name) + '</h2>' + ((introOf(b) || AGE) ? '<p class="apintro"><b>이 Agent는</b>' + atS('intro|' + b.id, esc(introOf(b))) + '</p>' : '') + '</div></div><div class="kpis">' + kpi(subs.length, '세부 Agent') +
    kpi(tasks.length, '담당 업무', asisN === tasks.length ? 'As-Is 대체 ' + asisN : (asisN ? 'As-Is 대체 ' + asisN + ' · ' : '') + '신규·표시 ' + (tasks.length - asisN)) + kpi(st.join('·'), '활동 단계') + kpi(hitl.length, '연결된 담당자 확인') + '</div>' + chainFlow(b) + '</header>' +
    '<section class="apmap"><h3>' + h3i(IC.flow) + '프로세스 맵 — As-Is → To-be</h3><div class="aptabs"><button type="button" data-tab="flow" aria-pressed="' + (S.apTab !== 'cap') + '">흐름도 · As-Is ↔ To-be 애니메이션</button><button type="button" data-tab="cap" aria-pressed="' + (S.apTab === 'cap') + '">Capability Map · Lv.4·5·6</button></div>' + '<div id="tab-flow"' + (S.apTab === 'cap' ? ' hidden' : '') + '>' + afShell() + '</div><div id="tab-cap"' + (S.apTab === 'cap' ? '' : ' hidden') + '><div class="panelcard"><div id="cmw">' + cmHTML(b) + '</div></div></div></section>' + '<section class="apovw">' + ovHTML(b) + '</section>' + (b.id === 'B0' ? orcTable() : '') + '<section><h3>' + h3i(IC.flag) + '단계별 역할</h3>' + timelineHTML(b) + '</section>' + preHTML(b) + '<section><h3>' + h3i(IC.layers) + '세부 Agent 상세</h3>' + subs.map(subHTML).join('') + '</section>' + '<section><h3>' + h3i(IC.db) + '필요한 데이터</h3>' + dataTbl(b) + '</section><section><h3>' + h3i(IC.gear) + '활용 시스템 (API 연동)</h3>' + sysTbl(b) + '</section>' +
    '<p class="hint">기존: 현업이 현재 사용 · 준비중: 타 팀이 별도 준비 중 · 신규 설치 필요: 준비 주체 없음 · ←/→ 키로 Agent 이동, Esc로 맵 복귀</p>';
  const el = $('#apage');
  el.innerHTML = '<div class="aph">' + navBtns() + '<span class="dot"></span><b>' + esc(D.text.title) + '</b><span class="aphs">AI Agent 상세 페이지</span><span class="sp"></span>' + (Object.keys(AGX.subs).length ? '<span class="agx-cnt">수정한 세부 Agent ' + Object.keys(AGX.subs).length + '개</span>' : '') + '<button type="button" class="agx-mode" data-agx="mode" aria-pressed="' + AGE + '" title="엑셀·설계 데이터 기반 내용만 수정 — 같은 Agent 안의 구조도·한눈에 보기·표에 함께 반영">✎ 내용 편집</button><button type="button" class="agx-save" data-agx="save" title="수정 내용을 담은 HTML 파일로 저장">⤓ 현재 버전 저장</button><button type="button" class="apv" data-step="-1"' + (i ? '' : ' disabled') + '>‹ 이전 Agent</button><button type="button" class="apv" data-step="1"' + (i < PGB().length - 1 ? '' : ' disabled') + '>다음 Agent ›</button><button type="button" class="apc">× 맵으로</button></div><div class="apb"><nav class="aps">' + side + '</nav><article class="apm" id="apm">' + main + '</article></div>';
  el.hidden = false; rdTree(el); afStop(); AF.model = null; AF.els = {}; if (S.apTab !== 'cap') afRender(false);
  const m = $('#apm'); m.scrollTop = 0;
  if (focus){ const f = document.getElementById('sub-' + focus); if (f) m.scrollTop = Math.max(0, f.offsetTop - 12); }
  navPush(); updNavBtns();
}
function closePage(){ afStop(); $('#apage').hidden = true; navPush(); }
function togglePresent(on){
  document.body.classList.toggle('present', on); setTimeout(fitWrap, 0);
  setTimeout(() => { const sb = $('#slbar'); if (sb) document.documentElement.style.setProperty('--slbar-h', sb.offsetHeight + 'px'); }, 30);
  if (on) toast('발표 모드 · 레벨·단계·뒤로/앞으로·확대는 위 막대에서 · 숫자 1~7 단계 · L 레벨 · 두 번 누르면 하위 · Esc 종료');
  if (on){ try { const r = document.documentElement.requestFullscreen && document.documentElement.requestFullscreen(); if (r && r.catch) r.catch(() => {}); } catch(e){} }
  else if (document.fullscreenElement){ try { document.exitFullscreen(); } catch(e){} }
}
/* ---------- 흐름도 편집: 박스 끌어 옮기기 · 글자·태그·종류 수정 · 박스 추가·삭제 · 연결 추가·삭제 */
function edKey(){ return S.scr + '|' + S.lv; }
function edOf(){ const k = edKey(), e = ED[k] || (ED[k] = {}); ['mv', 'kd', 'tg', 'del', 'add'].forEach(x => { e[x] = e[x] || {}; }); e.ea = e.ea || []; e.ed = e.ed || []; e.em = e.em || {}; return e; }
function edChange(fn){ const k = edKey(), u = UNDO[k] || (UNDO[k] = []); u.push(JSON.stringify(ED[k] || null)); if (u.length > 120) u.shift(); fn(edOf()); DIRTY = true; render(false); if (!S.fedit && S.sel && !$('#panel').hidden && S.M.pos[S.sel]) showNode(S.sel); }
function edUndo(){ const k = edKey(), u = UNDO[k]; if (!u || !u.length){ toast('이 화면에서 되돌릴 편집이 없습니다'); return; } const prev = JSON.parse(u.pop()); if (prev) ED[k] = prev; else delete ED[k]; DIRTY = true; const ek = $('#panel').dataset.kind === 'edge' ? S.selE : null; S.sel = null; S.selE = null; hideTb(); render(false); if (ek) setTimeout(() => { if (edgeRec(ek)) showEdgePanel(ek); else closePanel(); }, 0); toast('한 단계 되돌렸습니다'); }
function edReset(){ if (!ED[edKey()]){ toast('이 화면에는 편집한 내용이 없습니다'); return; } S.sel = null; hideTb(); edChange(() => { delete ED[edKey()]; }); if ($('#panel').dataset.kind === 'edge') closePanel(); toast('이 화면의 편집을 원래대로 되돌렸습니다'); }
function hideTb(){ const tb = board.querySelector('#edtb'); if (tb) tb.remove(); $$('.nd.sel').forEach(x => x.classList.remove('sel')); }
const KOPT = [['h', '사람 (잔존)'], ['nh', '담당자 확인'], ['a', 'Agent 대체'], ['na', 'Agent (신규)'], ['gone', '소멸'], ['mk', 'Orchestrator'], ['ot', U.otName]];
function showTb(id){
  hideTb(); const n = S.M.nodes.find(x => x.id === id), p = S.M.pos[id]; if (!n || !p) return;
  S.sel = id; const el = NODE_EL[id]; if (el) el.classList.add('sel');
  return; // 수정 도구는 상세 창 맨 끝 (editHTML)
  const tb = document.createElement('div'); tb.id = 'edtb';
  tb.innerHTML = '<input type="text" data-ed="tag" aria-label="태그" placeholder="태그 (예: ' + esc(U.tagEg) + ')" value="' + esc(n.tg || '') + '"><select data-ed="kind" aria-label="박스 종류">' + KOPT.map(([k, l]) => '<option value="' + k + '"' + (n.k === k ? ' selected' : '') + '>' + l + '</option>').join('') + '</select><button type="button" data-ed="conn">연결 추가</button><button type="button" data-ed="del" class="danger">박스 삭제</button>';
  board.appendChild(tb); tb.style.left = Math.max(0, p.x) + 'px'; const tt = p.y - tb.offsetHeight - 8; tb.style.top = (tt < 6 ? p.y + p.h + 8 : tt) + 'px';
}
function showEdgeTb(key, x, y){
  hideTb(); S.selE = key; const tb = document.createElement('div'); tb.id = 'edtb';
  tb.innerHTML = '<span class="edl">연결선</span><button type="button" data-ed="edel" class="danger">연결 삭제</button>';
  board.appendChild(tb); tb.style.left = Math.max(0, x - 60) + 'px'; tb.style.top = Math.max(0, y - tb.offsetHeight - 12) + 'px'; drawEdges();
}
function boardPt(e){ const r = board.getBoundingClientRect(); return {x:(e.clientX - r.left) / S.zoom, y:(e.clientY - r.top) / S.zoom}; }
function addBox(){
  const M = S.M, r = board.getBoundingClientRect(), w = wrap.getBoundingClientRect();
  const cx = ((w.left + w.width / 2) - r.left) / S.zoom, cy = ((w.top + w.height / 2) - r.top) / S.zoom;
  let st = M.vis[0].n; M.vis.forEach(s => { if (cx >= M.SX[s.n] - M.C.gap) st = s.n; });
  const lanes = M.rows.filter(q => q.t === 'lane').map(q => ({k:q.k, y:q.y, h:q.h})); Object.keys(M.RYS || {}).forEach(k => { const p = k.split('|'); if (+p[1] === st){ const r = M.RYS[k]; lanes.push({k:p[0], y:r.y, h:r.h}); } });
  lanes.sort((a, c) => a.y - c.y); let ln = lanes[0]; lanes.forEach(q => { if (cy >= q.y) ln = q; });
  const id = 'ADD-' + Date.now().toString(36), nh = D.subs[ln.k] ? (M.C.nodeHA || M.C.nodeH) : M.C.nodeH;
  edChange(E => { E.add[id] = {st, ln:ln.k, dx:Math.max(0, Math.round(cx - M.SX[st] - M.C.nodeW / 2)), dy:Math.max(4, Math.min(Math.max(4, ln.h - nh - 4), Math.round(cy - ln.y - nh / 2))), k:D.subs[ln.k] ? 'a' : 'h', lb:'새 업무'}; });
  setTimeout(() => { showTb(id); editText(id); }, 60);
}
function editText(id){
  const el = NODE_EL[id]; if (!el) return; const lb = el.querySelector('.lbl'); if (!lb) return;
  lb.contentEditable = 'true'; lb.focus(); const sel = window.getSelection(), rg = document.createRange(); rg.selectNodeContents(lb); sel.removeAllRanges(); sel.addRange(rg);
  const done = () => { lb.contentEditable = 'false'; lb.removeEventListener('blur', done); const k0 = edKey(); (UNDO[k0] = UNDO[k0] || []).push(JSON.stringify(ED[k0] || null)); const E = ED[k0]; if (E && E.add && E.add[id]) E.add[id].lb = lb.textContent; TXT[tk(id)] = lb.innerHTML; DIRTY = true; if (!S.fedit && S.sel === id && !$('#panel').hidden) showNode(id); };
  lb.addEventListener('blur', done);
  lb.addEventListener('keydown', ev => { if (ev.key === 'Enter' && !ev.shiftKey){ ev.preventDefault(); lb.blur(); } });
}
let DRAG = null;
function bindFlowEdit(){
  $('#btnFlow').onclick = () => {
    S.fedit = !S.fedit; document.body.classList.toggle('fediting', S.fedit); $('#btnFlow').setAttribute('aria-pressed', S.fedit); $('#edbar').hidden = !S.fedit;
    S.sel = null; S.selE = null; S.conn = null; document.body.classList.remove('connecting'); hideTb(); closePanel();
    if (playT){ clearInterval(playT); playT = null; $('#btnPlay').textContent = '▶ 자동 넘김'; }
    render(false); if (S.fedit) toast('흐름도 편집: 박스를 끌어 옮기고, 박스를 누르면 상세 창에서 글자·태그·종류·연결을, 선을 누르면 연결선을 수정할 수 있습니다');
  };
  $('#edAdd').onclick = addBox; $('#edUndo').onclick = edUndo; $('#edReset').onclick = edReset; $('#edDone').onclick = () => $('#btnFlow').click();
  // 박스 끌어 옮기기: 흐름도 편집을 켜지 않아도 Lv.4·5·6, As-Is·To-be 어디서나 (5px 이상 움직이면 끌기, 아니면 기존 클릭·더블클릭)
  board.addEventListener('pointerdown', e => {
    if (e.button !== 0 || S.edit) return;
    if (e.target.closest('#edtb') || e.target.closest('[contenteditable="true"]')) return;
    const nd = e.target.closest('.nd');
    if (!nd){ { const h0 = e.target.closest('.ehit'); if (!S.fedit && h0 && S.scr === 'asis'){ const pt = boardPt(e); showEdgeTb(h0.dataset.e, pt.x, pt.y); return; } }   /* v38 (실린더): As-Is 연결선은 바로 지우기 */
      if (!S.fedit){ unpin(); if (S.sel && !S.conn){ S.sel = null; hideTb(); } return; } const hit = e.target.closest('.ehit'); if (hit){ showEdgePanel(hit.dataset.e); return; } S.sel = null; S.selE = null; hideTb(); drawEdges(); return; }
    const id = nd.dataset.id, p = S.M.pos[id]; if (!p) return;
    const pt = boardPt(e); DRAG = {id, el:nd, sx:pt.x, sy:pt.y, ox:p.x, oy:p.y, moved:false, pid:e.pointerId};
    if (S.fedit) e.preventDefault();
  });
  window.addEventListener('pointermove', e => {
    if (!DRAG) return; const pt = boardPt(e), dx = pt.x - DRAG.sx, dy = pt.y - DRAG.sy;
    if (!DRAG.moved && Math.hypot(dx, dy) * S.zoom < 5) return;
    if (!DRAG.moved){ DRAG.moved = true; DRAG.el.classList.add('dragging'); document.body.classList.add('dragging-box'); hideTb(); try { DRAG.el.setPointerCapture(DRAG.pid); } catch(err){} window.getSelection && window.getSelection().removeAllRanges(); }
    e.preventDefault();
    const nx = Math.max(0, Math.round((DRAG.ox + dx) / 4) * 4), ny = Math.max(0, Math.round((DRAG.oy + dy) / 4) * 4);
    DRAG.el.style.left = nx + 'px'; DRAG.el.style.top = ny + 'px'; S.M.pos[DRAG.id] = Object.assign({}, S.M.pos[DRAG.id], {x:nx, y:ny});
    const wr = wrap.getBoundingClientRect(), E1 = 46;
    if (e.clientX > wr.right - E1) wrap.scrollLeft += 18; else if (e.clientX < wr.left + 300 + E1 && wrap.scrollLeft > 0) wrap.scrollLeft -= 18;
    if (e.clientY > wr.bottom - E1) wrap.scrollTop += 18; else if (e.clientY < wr.top + 120 && wrap.scrollTop > 0) wrap.scrollTop -= 18;
    if (!DRAG.raf) DRAG.raf = requestAnimationFrame(() => { if (DRAG){ DRAG.raf = 0; drawEdges(); } });
  }, {passive:false});
  const up = () => {
    if (!DRAG) return; const d = DRAG; DRAG = null; d.el.classList.remove('dragging'); document.body.classList.remove('dragging-box');
    if (d.moved){ S.justDragged = Date.now(); const p = S.M.pos[d.id], ddx = p.x - d.ox, ddy = p.y - d.oy;
      edChange(E => { if (E.add[d.id]){ E.add[d.id].dx += ddx; E.add[d.id].dy += ddy; } else { const m = E.mv[d.id] || [0, 0]; E.mv[d.id] = [m[0] + ddx, m[1] + ddy]; } });
      if (S.fedit) setTimeout(() => showTb(d.id), 30); else toast('박스를 옮겼습니다 · Ctrl+Z 되돌리기 · ⤓ 편집본 저장으로 보관');
      return; }
    if (S.reconn){ const rc = S.reconn; S.reconn = null; S.justDragged = Date.now(); document.body.classList.remove('connecting'); eMut(rc.key, r => { r[rc.end] = d.id; }); return; }
    if (S.conn && S.conn !== d.id){ const a = S.conn; S.conn = null; S.justDragged = Date.now(); document.body.classList.remove('connecting'); edChange(E => { E.ed = E.ed.filter(x => !(x[0] === a && x[1] === d.id)); if (!E.ea.some(x => x[0] === a && x[1] === d.id)) E.ea.push([a, d.id]); }); toast('연결을 추가했습니다 · Ctrl+Z 되돌리기'); return; }
    if (!S.fedit) return;
    showTb(d.id);
  };
  window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up);
  // 끌고 난 직후의 클릭·더블클릭은 상세 창·하위 이동으로 이어지지 않게
  board.addEventListener('click', e => { if (Date.now() - (S.justDragged || 0) < 450){ e.stopImmediatePropagation(); e.preventDefault(); } }, true);
  board.addEventListener('dblclick', e => { if (Date.now() - (S.justDragged || 0) < 450){ e.stopImmediatePropagation(); e.preventDefault(); } }, true);
  board.addEventListener('dragstart', e => { if (e.target.closest && e.target.closest('.nd')) e.preventDefault(); });
  const edtbClick = e => {
    const b = e.target.closest('#edtb [data-ed]'); if (!b || b.tagName === 'INPUT' || b.tagName === 'SELECT') return; const id = S.sel, act = b.dataset.ed;
    if (act === 'text'){ peToggle(); }
    else if (act === 'conn' && id){ S.conn = id; document.body.classList.add('connecting'); hideTb(); toast('연결할 다음 박스를 누르세요 (Esc로 취소)'); }
    else if (act === 'del' && id){ S.sel = null; hideTb(); if (!S.fedit){ const p = $('#panel'); p.hidden = true; p.innerHTML = ''; } edChange(E => { if (E.add[id]) delete E.add[id]; else E.del[id] = 1; E.ea = E.ea.filter(x => x[0] !== id && x[1] !== id); }); toast('박스를 삭제했습니다 · 되돌리기로 복구할 수 있습니다'); }
    else if (act === 'edel' && S.selE){ const [a, c] = S.selE.split('>'), isE = $('#panel').dataset.kind === 'edge'; S.selE = null; hideTb(); edChange(E => { const k = E.ea.findIndex(x => x[0] === a && x[1] === c); if (k >= 0) E.ea.splice(k, 1); else { E.ed.push([a, c]); if (E.em) delete E.em[a + '>' + c]; } }); if (isE) closePanel(); toast('연결을 삭제했습니다 · Ctrl+Z 되돌리기'); }
    else if ((act === 'e-a' || act === 'e-b') && S.selE){ S.reconn = {key:S.selE, end:act === 'e-a' ? 'a' : 'b'}; document.body.classList.add('connecting'); toast('새 ' + (act === 'e-a' ? '출발' : '도착') + ' 박스를 지도에서 누르세요 (Esc 취소)'); }
    else if (act === 'e-flip' && S.selE) eMut(S.selE, r => { const t0 = r.a; r.a = r.b; r.b = t0; });
    else if (act === 'e-kind' && S.selE) eMut(S.selE, r => { r.t = b.dataset.v; });
    else if (act === 'e-off' && S.selE) eMut(S.selE, r => { r.off = b.dataset.v === '0' ? 0 : (r.off || 0) + (+b.dataset.v) * 10; });
  };
  const edtbChange = e => {
    const el = e.target.closest('#edtb [data-ed]'); if (el && el.dataset.ed === 'e-lab' && S.selE){ eMut(S.selE, r => { r.lab = el.value.trim(); }); return; } if (!el || !S.sel) return; const id = S.sel;
    if (el.dataset.ed === 'kind') edChange(E => { E.kd[id] = el.value; });
    if (el.dataset.ed === 'tag') edChange(E => { E.tg[id] = el.value; });
  };
  board.addEventListener('click', edtbClick); board.addEventListener('change', edtbChange);
  $('#panel').addEventListener('click', edtbClick); $('#panel').addEventListener('change', edtbChange);
  document.addEventListener('keydown', e => {
    if (e.target && e.target.closest && e.target.closest('input, textarea, select, [contenteditable="true"]')) return;
    if (e.key === 'Escape' && (S.reconn || S.conn)){ e.preventDefault(); e.stopImmediatePropagation(); S.reconn = null; S.conn = null; document.body.classList.remove('connecting'); toast('연결 고르기를 취소했습니다'); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && (S.fedit || (UNDO[edKey()] || []).length) && $('#apage').hidden){ e.preventDefault(); edUndo(); return; }
    if (!S.fedit) return;
    if (false){}
    else if ((e.key === 'Delete' || e.key === 'Backspace') && (S.sel || S.selE)){ e.preventDefault(); const b = $('#edtb [data-ed="del"], #edtb [data-ed="edel"]'); if (b) b.click(); }
    else if (e.key === 'Escape'){ S.conn = null; document.body.classList.remove('connecting'); S.sel = null; S.selE = null; S.pin = null; hideTb(); drawEdges(); }
  }, true);
}
function rdWatch(){
  ['#apage', '#amap', '#panel', '#axw'].forEach(sel => { const el = $(sel); if (!el || el._rdw) return; el._rdw = true;
    new MutationObserver(ms => { ms.forEach(m => m.addedNodes.forEach(nd => { if (nd.nodeType === 1) rdTree(nd); else if (nd.nodeType === 3 && nd.nodeValue.indexOf('·') >= 0 && !(nd.parentElement && nd.parentElement.closest('[contenteditable="true"], .keepdot'))) nd.nodeValue = rd(nd.nodeValue); })); }).observe(el, {childList:true, subtree:true}); });
}
function mdFromHTML(h){ const d = document.createElement('div'); d.innerHTML = h; d.querySelectorAll('b, strong').forEach(b => b.replaceWith('**' + b.textContent + '**')); d.querySelectorAll('br, div, p').forEach(x => x.insertAdjacentText('afterend', ' ')); return d.textContent.replace(/\*\*\s*\*\*/g, '').replace(/\s+/g, ' ').trim(); }
function stGet(k){ const p = k.split('|'), st = STORY[p[0]]; if (!st) return null; if (p.length === 2) return st[p[1]] || ''; const b = st.beats[+p[1]]; if (!b) return null; if (p[2] === 't') return b.t || ''; const s = b.steps[+p[2]]; return s ? (s[p[3]] || '') : null; }
function stGet0(k){ const p = k.split('|'), st = STORY0[p[0]]; if (!st) return ''; if (p.length === 2) return st[p[1]] || ''; const b = st.beats[+p[1]]; if (!b) return ''; if (p[2] === 't') return b.t || ''; const s = b.steps[+p[2]]; return s ? (s[p[3]] || '') : ''; }
function stSet(k, v){
  const p = k.split('|'), st = STORY[p[0]]; if (!st) return;
  if (v === stGet0(k)) delete STX[k]; else STX[k] = v;
  if (p.length === 2){ st[p[1]] = v; return; } const b = st.beats[+p[1]]; if (!b) return; if (p[2] === 't'){ b.t = v; return; }
  const s = b.steps[+p[2]]; if (!s) return; if (p[3] === 'a' && !v) delete s.a; else s[p[3]] = v;
}
function tourSaveField(el){
  const k = el.dataset.sk, v = el.dataset.rich ? mdFromHTML(el.innerHTML) : el.textContent.replace(/\s+/g, ' ').trim(), cur = stGet(k); if (cur == null || v === cur) return;
  if (!v && !/\|a$/.test(k)){ toast('빈 칸으로는 변경할 수 없어 기존 문장을 유지했습니다'); TOUR._noAnim = true; tourShow(false); return; }
  stSet(k, v); DIRTY = true;
  setTimeout(() => { const a = document.activeElement; if (!(a && a.closest && a.closest('#tourcap [data-sk]'))){ TOUR._noAnim = true; tourShow(false); } renderStory(S.M); }, 0);
  toast('흐름 설명을 고쳤습니다 · ⤓ 편집본 저장을 누르면 파일에 함께 저장됩니다');
}

/* ---------- AX 과제 × 제작 Agent: ① Agent 과제 Coverage (가로 프로세스 × 세로 Agent, 숫자를 누르면 과제) ② 조직별 (가로 조직 × 세로 과제 유형) */
const AX = {view:'cov', q:'', open:{}, sel:null, osel:null};
const AX_LV = {D:'직접 연결', P:'부분 연결', N:'연결 없음'};
const AXCOL = (D.ax && D.ax.cols) || D.stages.map(s => ({k:'s' + s.n, st:s.n})).concat([
 {k:'STR', t:'전략·리서치', cats:['STR']}, {k:'BX', t:'체험·이벤트 (BX)', cats:['BX']}, {k:'COM', t:'공통 업무', sub:'회의록·보고서·메일', cats:['COM']},
 {k:'ETC', t:'그 외 제작 밖 업무', sub:'경영지원, 닷컴·앱, 미디어, 데이터, 리테일, GEO, CRM', cats:['MGT', 'DIG', 'MED', 'DAT', 'RET', 'GEO', 'CRM']}]);
const AXTYPE = ['PRD', 'STR', 'BX', 'COM', 'CRM', 'DIG', 'RET', 'GEO', 'DAT', 'MED', 'MGT'];
function axStName(n){ const s = D.stages.find(z => z.n === n) || {}; return (s.name || '').replace(/^\d+\.\s*/, ''); }
function axColOf(t){ if (t.lv === 'D' && t.st.length) return 's' + t.st[0]; const c = AXCOL.find(x => x.cats && x.cats.includes(t.cat)); return c ? c.k : 'ETC'; }
function axColName(k){ const c = AXCOL.find(x => x.k === k); if (!c) return ''; return c.st ? c.st + '단계 ' + axStName(c.st).split(' / ')[0] : c.t; }
function axBandHas(t, bid){ return t.ag.some(s => { const b = bandOf(s); return b && b.id === bid; }); }
function axColTasks(k){
  const c = AXCOL.find(x => x.k === k); if (!c) return [];
  if (c.st) return D.ax.tasks.filter(t => t.lv === 'D' && t.st.includes(c.st));
  return D.ax.tasks.filter(t => !(t.lv === 'D' && t.st.length) && c.cats.includes(t.cat));
}
function axBandIn(t, bid, k){
  // 단계 열: 그 단계에서 일하는 세부 Agent가 이 과제에 연결돼 있으면 덮음 (단계가 하나도 안 겹치면 과제의 첫 단계에 셈)
  const c = AXCOL.find(x => x.k === k); if (!c || !c.st) return axBandHas(t, bid);
  const mine = t.ag.filter(s => { const b = bandOf(s); return b && b.id === bid; }); if (!mine.length) return false;
  if (mine.some(s => (D.subs[s].stages || []).includes(c.st))) return true;
  return !mine.some(s => (D.subs[s].stages || []).some(x => t.st.includes(x))) && t.st[0] === c.st;
}
function axTops(){ return uq(D.ax.tasks.map(t => t.top)); }
function axQ(L){ const q = AX.q.trim().toLowerCase(); return !q ? L : L.filter(t => (t.name + ' ' + t.org + ' ' + t.lab + ' ' + t.bg + ' ' + t.how + ' ' + t.ag.map(s => (D.subs[s] || {}).name || '').join(' ')).toLowerCase().includes(q)); }
const axSort = (a, b) => ({D:0, P:1, N:2}[a.lv] - {D:0, P:1, N:2}[b.lv]) || ((a.rank || 999) - (b.rank || 999)) || (b.score - a.score) || (a.id - b.id);
function axCard(t, hb){
  const ag = t.ag.filter(sid => D.subs[sid]).map(sid => { const b = bandOf(sid); return '<button type="button" class="ax-ag' + (hb && b && b.id === hb ? ' on' : '') + '" data-ag="' + sid + '" title="' + esc((b ? b.name + ' › ' : '') + (D.subs[sid].desc || '')) + '">' + esc(D.subs[sid].name) + '</button>'; }).join('');
  const st = t.st.length ? '<div class="ax-st"><span>단계</span>' + D.stages.map(s => s.n).map(n => '<i class="' + (t.st.includes(n) ? 'on' : '') + '" title="' + n + '단계 ' + esc(axStName(n)) + '">' + n + '</i>').join('') + '</div>' : '';
  const open = !!AX.open[t.id];
  return '<article class="ax-t lv-' + t.lv + (open ? ' open' : '') + '" data-ax="' + t.id + '"><header><span class="ax-id">#' + t.id + '</span><span class="ax-org">' + esc(t.lab || t.org) + '</span>'
    + (t.lv === 'D' ? '<em class="ax-rk" title="우선 선결 과제 순위">우선 ' + t.rank + '</em>' : '')
    + (t.dup.length ? '<em class="ax-dp" title="같은 과제를 낸 조직이 더 있음">' + (t.dup.length + 1) + '개 조직 공통</em>' : '') + '<span class="ax-lv">' + AX_LV[t.lv] + '</span></header>'
    + '<h4>' + esc(t.name) + '</h4>' + (t.bg ? '<p class="ax-bg">' + esc(t.bg) + '</p>' : '')
    + '<div class="ax-how ' + t.lv + '"><b>' + (t.lv === 'N' ? 'AE Agent와의 관계' : 'Agent로 이렇게 실행') + '</b><p>' + esc(t.how) + '</p>' + (ag ? '<div class="ax-ags">' + ag + '</div>' : '') + st + '</div>'
    + (open ? axDetail(t) : '') + '<button type="button" class="ax-more" data-axmore="' + t.id + '">' + (open ? '접기 ▴' : '과제 원문 보기 ▾') + '</button></article>';
}
function axDetail(t){
  const row = (k, v) => v ? '<div><dt>' + k + '</dt><dd>' + esc(v) + '</dd></div>' : '';
  const dups = t.dup.map(i => { const x = D.ax.tasks.find(y => y.id === i); return x ? '<button type="button" data-axgo="' + i + '">#' + i + ' ' + esc(x.lab || x.org) + '</button>' : ''; }).join('');
  return '<dl class="ax-dt">' + row('Pain Points', t.pain) + row('핵심 변화', t.chg) + row('성공 지표', t.kpi) + '<div><dt>원본</dt><dd>' + esc(t.top) + ' › ' + esc(t.org) + ' · 슬라이드 ' + t.slides.join(', ') + '</dd></div>' + (dups ? '<div><dt>같은 과제</dt><dd class="ax-dups">' + dups + '</dd></div>' : '') + '</dl>';
}
function axSum(T){
  const cov = T.filter(t => t.lv !== 'N').length, nD = T.filter(t => t.lv === 'D').length, nP = T.filter(t => t.lv === 'P').length, nN = T.length - cov, pc = x => T.length ? Math.round(x / T.length * 100) : 0;
  return '<div class="axm-sum"><div class="axm-big"><b>' + cov + '<small>/' + T.length + '</small></b><span>Agent 담당 과제 (' + pc(cov) + '%)</span></div>'
    + '<div class="axm-bar"><i class="d" style="width:' + pc(nD) + '%" title="직접 연결 ' + nD + '건"></i><i class="p" style="width:' + pc(nP) + '%" title="부분 연결 ' + nP + '건"></i><i class="n" style="width:' + (100 - pc(nD) - pc(nP)) + '%" title="연결 없음 ' + nN + '건"></i></div>'
    + '<div class="axm-leg"><span><i class="d"></i>직접 연결 ' + nD + ' (우선 선결)</span><span><i class="p"></i>부분 연결 ' + nP + '</span><span><i class="n"></i>연결 없음 ' + nN + '</span></div></div>';
}
/* ① Agent 과제 Coverage */
function axCovHTML(){
  const T = D.ax.tasks, byCol = {}; AXCOL.forEach(c => byCol[c.k] = axColTasks(c.k));
  const S = AX.sel || {};
  const isSel = (b, c) => (S.b === b && S.c === c);
  let h = axSum(T) + '<div class="axx-wrap"><table class="axx"><thead><tr><th class="corner" rowspan="2"><b>Agent</b> ↓ · 프로세스 →<small>숫자 = 해당 Agent가 담당하는 과제 수 · 과제가 여러 단계에 걸치면 단계마다 집계 · 누르면 아래에 과제 표시</small></th><th class="g prd" colspan="' + D.stages.length + '">제작 프로세스</th><th class="g adj" colspan="3">제작 인접 업무</th><th class="g etc">제작 밖 업무</th></tr><tr>'
    + AXCOL.map(c => '<th class="ch' + (c.st ? ' prd' : ' adj') + (S.c === c.k && !S.b ? ' on' : '') + '"><button type="button" data-axcol="' + c.k + '">' + (c.st ? '<i>' + c.st + '</i><b class="keepdot">' + esc(axStName(c.st).split(' / ')[0]) + '</b><small>' + esc(axStName(c.st).split(' / ')[1] || '') + '</small>' : '<b class="keepdot">' + esc(c.t) + '</b>' + (c.sub ? '<small class="keepdot">' + esc(c.sub) + '</small>' : '')) + '</button></th>').join('') + '</tr></thead><tbody>';
  D.bands.forEach(b => {
    const tot = T.filter(t => axBandHas(t, b.id)).length, mx = Math.max(1, ...AXCOL.map(c => byCol[c.k].filter(t => axBandIn(t, b.id, c.k)).length));
    h += '<tr><th class="rh' + (S.b === b.id && !S.c ? ' on' : '') + '"><button type="button" data-axrow="' + b.id + '"><b>' + esc(b.name) + '</b><small>과제 ' + tot + '건 · ' + Math.round(tot / T.length * 100) + '%</small></button></th>'
      + AXCOL.map(c => { const L = byCol[c.k].filter(t => axBandIn(t, b.id, c.k)), n = L.length, d = L.filter(t => t.lv === 'D').length;
        return '<td class="' + (c.st ? 'prd' : 'adj') + '">' + (n ? '<button type="button" class="nb ' + (d ? 'd' : 'p') + (isSel(b.id, c.k) ? ' on' : '') + '" data-axcell="' + b.id + '|' + c.k + '" style="--a:' + (0.35 + 0.65 * n / mx).toFixed(2) + '" title="' + esc(b.name + ' × ' + axColName(c.k) + ': 과제 ' + n + '건 (직접 ' + d + ', 부분 ' + (n - d) + ')') + '"><b>' + n + '</b>' + (d && d < n ? '<small>직접 ' + d + '</small>' : '') + '</button>' : '<span class="nz">–</span>') + '</td>'; }).join('') + '</tr>';
  });
  const colTot = c => byCol[c.k].length, colCov = c => byCol[c.k].filter(t => t.lv !== 'N').length;
  h += '</tbody><tfoot><tr><th class="rh ft">이 단계·영역의 과제</th>' + AXCOL.map(c => '<td class="ft">' + colTot(c) + '건</td>').join('') + '</tr><tr><th class="rh ft">Agent 담당 과제</th>'
    + AXCOL.map(c => { const n = colTot(c), v = colCov(c); return '<td class="ft"><b>' + v + '</b>' + (n ? '<span class="axm-mini"><i class="d" style="width:' + (byCol[c.k].filter(t => t.lv === 'D').length / n * 100) + '%"></i><i class="p" style="width:' + (byCol[c.k].filter(t => t.lv === 'P').length / n * 100) + '%"></i></span><small>' + Math.round(v / n * 100) + '%</small>' : '') + '</td>'; }).join('') + '</tr></tfoot></table></div>';
  // 아래: 선택한 칸의 과제 / 없으면 프로세스별 과제 카드
  let L, title, grouped = false;
  if (S.b && S.c){ const b = D.bands.find(x => x.id === S.b); L = byCol[S.c].filter(t => axBandIn(t, S.b, S.c)); title = esc(b.name) + ' × ' + esc(axColName(S.c)) + ' — 과제 ' + L.length + '건'; }
  else if (S.b){ const b = D.bands.find(x => x.id === S.b); L = T.filter(t => axBandHas(t, S.b)); title = esc(b.name) + '의 담당 과제 — ' + L.length + '건'; grouped = true; }
  else if (S.c){ L = byCol[S.c]; title = esc(axColName(S.c)) + '의 과제 — ' + L.length + '건 (덮음 ' + L.filter(t => t.lv !== 'N').length + ')'; }
  else { L = T; title = '프로세스별 과제 카드 — 전체 ' + T.length + '건'; grouped = true; }
  L = axQ(L).slice().sort(axSort);
  h += '<section class="axr" id="axres"><div class="axr-h"><b>' + title + '</b>' + (AX.sel ? '<button type="button" data-axclear="1">✕ 선택 해제 (전체 카드 보기)</button>' : '<span>위 숫자를 누르면 그 Agent × 프로세스의 과제만 보입니다</span>') + '</div>';
  if (!L.length) h += '<p class="ax-empty">해당 과제가 없습니다</p>';
  else if (grouped){ AXCOL.forEach(c => { const G = L.filter(t => axColOf(t) === c.k); if (!G.length) return; h += '<div class="ax-g"><h3><i' + (c.st ? '' : ' class="o"') + '>' + (c.st || '') + '</i><span class="keepdot">' + esc(axColName(c.k).replace(/^\d단계 /, '')) + '</span><small>' + G.length + '건 · 덮음 ' + G.filter(t => t.lv !== 'N').length + '</small></h3><div class="ax-grid">' + G.map(t => axCard(t, S.b)).join('') + '</div></div>'; }); }
  else h += '<div class="ax-grid">' + L.map(t => axCard(t, S.b)).join('') + '</div>';
  return h + '</section>';
}
/* ② 조직별 */
function axOrgHTML(){
  const T = D.ax.tasks, tops = axTops(), S = AX.osel || {};
  const cell = (o, ct) => T.filter(t => t.top === o && t.cat === ct);
  let h = '<div class="axo-top">' + tops.map(o => { const L = T.filter(t => t.top === o), cv = L.filter(t => t.lv !== 'N').length, d = L.filter(t => t.lv === 'D').length, p = L.filter(t => t.lv === 'P').length;
    return '<button type="button" class="axo-c' + (S.o === o && !S.c ? ' on' : '') + '" data-axorg="' + esc(o) + '"><span class="nm keepdot">' + esc(o) + '</span><b>' + cv + '<small>/' + L.length + '</small></b><span class="lb">Agent 담당 과제 ' + Math.round(cv / L.length * 100) + '%</span><span class="axm-mini"><i class="d" style="width:' + (d / L.length * 100) + '%"></i><i class="p" style="width:' + (p / L.length * 100) + '%"></i></span><small>직접 ' + d + ' · 부분 ' + p + ' · 없음 ' + (L.length - cv) + '</small></button>'; }).join('') + '</div>';
  h += '<div class="axx-wrap"><table class="axx axo"><thead><tr><th class="corner"><b>과제 유형</b> ↓ · 조직 →<small>숫자 = Agent가 담당하는 과제 수 / 그 유형의 과제 수 · 누르면 아래에 상세</small></th>'
    + tops.map(o => '<th class="ch' + (S.o === o && !S.c ? ' on' : '') + '"><button type="button" data-axorg="' + esc(o) + '"><b class="keepdot">' + esc(o) + '</b><small>' + T.filter(t => t.top === o).length + '건</small></button></th>').join('') + '<th class="ch tot"><b>합계</b></th></tr></thead><tbody>';
  AXTYPE.forEach(ct => {
    const all = T.filter(t => t.cat === ct); if (!all.length) return;
    h += '<tr><th class="rh' + (!S.o && S.c === ct ? ' on' : '') + '"><button type="button" data-axtype="' + ct + '"><b>' + esc(D.ax.cat[ct] || ct) + '</b><small>' + all.length + '건 · 덮음 ' + all.filter(t => t.lv !== 'N').length + '</small></button></th>'
      + tops.map(o => { const L = cell(o, ct), cv = L.filter(t => t.lv !== 'N').length, d = L.filter(t => t.lv === 'D').length;
        return '<td>' + (L.length ? '<button type="button" class="nb ' + (d ? 'd' : cv ? 'p' : 'z') + (S.o === o && S.c === ct ? ' on' : '') + '" data-axoc="' + esc(o) + '|' + ct + '" style="--a:' + (cv ? (0.4 + 0.6 * Math.min(1, cv / 6)).toFixed(2) : 1) + '" title="' + esc(o + ' × ' + (D.ax.cat[ct] || ct) + ': 덮음 ' + cv + ' / ' + L.length + '건') + '"><b>' + cv + '</b><small>/' + L.length + '</small></button>' : '<span class="nz">–</span>') + '</td>'; }).join('')
      + '<td class="tot"><b>' + all.filter(t => t.lv !== 'N').length + '</b><small>/' + all.length + '</small></td></tr>';
  });
  h += '</tbody><tfoot><tr><th class="rh ft">조직 합계</th>' + tops.map(o => { const L = T.filter(t => t.top === o); return '<td class="ft"><b>' + L.filter(t => t.lv !== 'N').length + '</b><small>/' + L.length + '</small></td>'; }).join('') + '<td class="ft tot"><b>' + T.filter(t => t.lv !== 'N').length + '</b><small>/' + T.length + '</small></td></tr></tfoot></table></div>';
  // 아래 상세: 어떤 과제를 Agent로 어떻게 실행하는지
  let L = null, title = '';
  if (S.o && S.c){ L = cell(S.o, S.c); title = esc(S.o) + ' × ' + esc(D.ax.cat[S.c] || S.c) + ' — ' + L.length + '건'; }
  else if (S.o){ L = T.filter(t => t.top === S.o); title = esc(S.o) + ' — 과제 ' + L.length + '건 (덮음 ' + L.filter(t => t.lv !== 'N').length + ')'; }
  else if (S.c){ L = T.filter(t => t.cat === S.c); title = esc(D.ax.cat[S.c] || S.c) + ' — 전 조직 ' + L.length + '건'; }
  h += '<section class="axr" id="axres"><div class="axr-h"><b class="keepdot">' + (L ? title : '조직 또는 숫자를 누르면 과제와 Agent 실행 방법 표시') + '</b>' + (L ? '<button type="button" data-axclear="1">✕ 선택 해제</button>' : '') + '</div>';
  if (L){ L = axQ(L).slice().sort(axSort);
    const subs = uq(L.map(t => t.org));
    h += subs.map(sg => { const G = L.filter(t => t.org === sg); return '<div class="axo-g"><h4>' + esc(sg) + '<small>' + G.length + '건 · 덮음 ' + G.filter(t => t.lv !== 'N').length + '</small></h4><table class="axo-t"><thead><tr><th>과제</th><th>연결</th><th>Agent로 이렇게 실행</th><th>연결 Agent · 단계</th></tr></thead><tbody>' + G.map(axRowHTML).join('') + '</tbody></table></div>'; }).join('');
  }
  return h + '</section>';
}
function axRowHTML(t){
  const ag = t.ag.filter(sid => D.subs[sid]).map(sid => '<button type="button" class="ax-ag" data-ag="' + sid + '">' + esc(D.subs[sid].name) + '</button>').join('');
  const st = t.st.length ? '<div class="ax-st">' + D.stages.map(s => s.n).map(n => '<i class="' + (t.st.includes(n) ? 'on' : '') + '">' + n + '</i>').join('') + '</div>' : '';
  const open = !!AX.open[t.id];
  return '<tr class="lv-' + t.lv + '" data-ax="' + t.id + '"><td class="c1"><span class="ax-id">#' + t.id + '</span> <span class="ax-org">' + esc(t.lab || t.org) + '</span>' + (t.dup.length ? ' <em class="ax-dp">' + (t.dup.length + 1) + '개 조직 공통</em>' : '') + '<b>' + esc(t.name) + '</b>' + (t.bg ? '<p>' + esc(t.bg) + '</p>' : '') + '<button type="button" class="ax-more" data-axmore="' + t.id + '">' + (open ? '원문 접기 ▴' : '원문 보기 ▾') + '</button>' + (open ? axDetail(t) : '') + '</td>'
    + '<td class="c2"><span class="ax-lv">' + AX_LV[t.lv] + '</span>' + (t.lv === 'D' ? '<em class="ax-rk">우선 ' + t.rank + '</em>' : '') + '</td><td class="c3 ' + t.lv + '">' + esc(t.how) + '</td><td class="c4">' + (ag ? '<div class="ax-ags">' + ag + '</div>' : '<span class="nz">–</span>') + st + '</td></tr>';
}
function axRender(){
  const el = $('#axw'); if (!el) return; const keep = el.scrollTop;
  const body = AX.view === 'org' ? axOrgHTML() : axCovHTML();
  el.innerHTML = '<div class="amh"><b>AX 과제 × AE Agent</b><span>제일기획 AX 과제 ' + D.ax.tasks.length + '건과 AE Agent 연결 — 연결 과제는 우선 선결 과제이며, 과제 담당자는 실행 Agent 확인</span><em class="ax-pre">Preliminary · 가설</em><button type="button" class="px" aria-label="닫기">×</button></div>'
    + '<div class="axw-in"><div class="ax-ctl"><div class="seg"><button type="button" data-axview="cov" aria-pressed="' + (AX.view === 'cov') + '">Agent 과제 Coverage</button><button type="button" data-axview="org" aria-pressed="' + (AX.view === 'org') + '">조직별</button></div><input type="search" id="axq" placeholder="아래 과제 목록에서 찾기 (과제·조직·Agent)" value="' + esc(AX.q) + '"></div>'
    + '<p class="ax-note">원본: ' + esc(D.ax.src) + ' · 연결 여부와 실행 방법은 To-be 가설이며 과제 담당 조직과 함께 확인이 필요합니다</p>' + body + '</div>';
  el.hidden = false; el.scrollTop = keep;
}
function axOpen(){ $('#amap').hidden = true; closePanel(); axRender(); $('#axw').scrollTop = 0; }
function axToRes(){ setTimeout(() => { const r = $('#axres'); if (r) r.scrollIntoView({block:'start', behavior:'smooth'}); }, 30); }
function bindAx(){
  const w = $('#axw'), btn = $('#btnAx'); if (!w || !btn) return; if (!D.ax || !(D.ax.tasks || []).length){ btn.hidden = true; return; } btn.onclick = axOpen;
  if (U.axDom && U.axDom !== '제작') new MutationObserver(() => { const tw = document.createTreeWalker(w, NodeFilter.SHOW_TEXT); let nd; while ((nd = tw.nextNode())) if (nd.nodeValue.indexOf('제작') >= 0) nd.nodeValue = nd.nodeValue.split('제작').join(U.axDom); }).observe(w, {childList:true, subtree:true});
  w.addEventListener('click', e => {
    if (e.target.closest('.px')){ w.hidden = true; return; }
    const ag = e.target.closest('[data-ag]'); if (ag){ showAgent(ag.dataset.ag); return; }
    const v = e.target.closest('[data-axview]'); if (v){ AX.view = v.dataset.axview; axRender(); w.scrollTop = 0; return; }
    const cl = e.target.closest('[data-axclear]'); if (cl){ AX.sel = null; AX.osel = null; axRender(); return; }
    const c1 = e.target.closest('[data-axcell]'); if (c1){ const [b, c] = c1.dataset.axcell.split('|'); AX.sel = (AX.sel && AX.sel.b === b && AX.sel.c === c) ? null : {b, c}; axRender(); if (AX.sel) axToRes(); return; }
    const rw = e.target.closest('[data-axrow]'); if (rw){ const b = rw.dataset.axrow; AX.sel = (AX.sel && AX.sel.b === b && !AX.sel.c) ? null : {b}; axRender(); if (AX.sel) axToRes(); return; }
    const co = e.target.closest('[data-axcol]'); if (co){ const c = co.dataset.axcol; AX.sel = (AX.sel && AX.sel.c === c && !AX.sel.b) ? null : {c}; axRender(); if (AX.sel) axToRes(); return; }
    const oc = e.target.closest('[data-axoc]'); if (oc){ const [o, c] = oc.dataset.axoc.split('|'); AX.osel = (AX.osel && AX.osel.o === o && AX.osel.c === c) ? null : {o, c}; axRender(); if (AX.osel) axToRes(); return; }
    const og = e.target.closest('[data-axorg]'); if (og){ const o = og.dataset.axorg; AX.osel = (AX.osel && AX.osel.o === o && !AX.osel.c) ? null : {o}; axRender(); if (AX.osel) axToRes(); return; }
    const ty = e.target.closest('[data-axtype]'); if (ty){ const c = ty.dataset.axtype; AX.osel = (AX.osel && AX.osel.c === c && !AX.osel.o) ? null : {c}; axRender(); if (AX.osel) axToRes(); return; }
    const m = e.target.closest('[data-axmore]'); if (m){ const i = +m.dataset.axmore; AX.open[i] = !AX.open[i]; axRender(); return; }
    const g = e.target.closest('[data-axgo]'); if (g){ const i = +g.dataset.axgo; const x = D.ax.tasks.find(y => y.id === i); if (!x) return; AX.open[i] = true; if (AX.view === 'org') AX.osel = {o:x.top}; else AX.sel = {c:axColOf(x)}; AX.q = ''; axRender(); setTimeout(() => { const c = w.querySelector('[data-ax="' + i + '"]'); if (c){ c.scrollIntoView({block:'center', behavior:'smooth'}); c.classList.add('flash'); setTimeout(() => c.classList.remove('flash'), 1400); } }, 40); }
  });
  w.addEventListener('input', e => { if (e.target.id !== 'axq') return; AX.q = e.target.value; clearTimeout(AX._t); AX._t = setTimeout(() => { const pos = e.target.selectionStart; axRender(); const q = $('#axq'); if (q){ q.focus(); try { q.setSelectionRange(pos, pos); } catch(_){} } }, 220); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !w.hidden && $('#panel').hidden){ e.stopPropagation(); if (AX.view === 'cov' && AX.sel){ AX.sel = null; axRender(); return; } if (AX.view === 'org' && AX.osel){ AX.osel = null; axRender(); return; } w.hidden = true; } }, true);
}

function bindInfo(){
  const b = $('#ibToggle'), box = $('#infobox'); if (!b || !box) return;
  b.addEventListener('click', () => { const open = box.classList.toggle('ib-closed') === false; b.setAttribute('aria-expanded', open); b.querySelector('.ib-tg').textContent = open ? '접기 ▴' : '펼치기 ▾'; });
}
function bindTour(){
  rdWatch(); bindInfo(); bindAx();
  document.addEventListener('focusout', e => { const el = e.target && e.target.closest && e.target.closest('#tourcap [data-sk]'); if (el && TOUR.edit) tourSaveField(el); }, true);
  document.addEventListener('mousedown', e => { if (e.target.closest && e.target.closest('[data-tourbold]')){ e.preventDefault(); const a = document.activeElement; if (a && a.closest && a.closest('#tourcap [data-rich]')) document.execCommand('bold'); else toast('설명 문장에서 굵게 할 글자를 먼저 고르세요'); } }, true);
  const tc = $('#tourcap'); if (tc && tc.parentNode !== document.body) document.body.appendChild(tc);
  document.addEventListener('click', e => {
    const tb = e.target.closest('[data-tour]'); if (tb){ const v = tb.dataset.tour; if (v === 'x') tourEnd(); else tourGo(+v); return; }
    const te = e.target.closest('[data-touredit]'); if (te){ TOUR.edit = !TOUR.edit; if (TOUR.edit) tourAuto(false); TOUR._noAnim = true; tourShow(false); if (TOUR.edit) toast('점선 글자를 눌러 수정 · Enter로 확정'); return; }
    const tr = e.target.closest('[data-tourreset]'); if (tr){ const it = TOUR.list[TOUR.i]; if (!it) return; const ob = it.b._bi != null ? it.b._bi : it.bi, os = (it.b._b || it.b).steps.indexOf(it.stp), kb = it.st + '|' + ob, ks = kb + '|' + os; [kb + '|t', ks + '|v', ks + '|d', ks + '|a'].forEach(k => stSet(k, stGet0(k))); DIRTY = true; TOUR._noAnim = true; tourShow(false); renderStory(S.M); toast('이 순서를 처음 문장으로 되돌렸습니다'); return; }
    if (e.target.closest && e.target.closest('#tourcap [data-sk]')) return;
    const tj = e.target.closest('[data-tourjump]'); if (tj){ tourAuto(false); TOUR.i = Math.max(0, Math.min(TOUR.list.length - 1, +tj.dataset.tourjump)); tourShow(true); return; }
    const ta = e.target.closest('[data-tourauto]'); if (ta){ tourAuto(!TOUR.auto); return; }
    const tl = e.target.closest('[data-tourlv]'); if (tl){ const v = +tl.dataset.tourlv; if (S.lv !== v){ S.lv = v; render(false); setTimeout(() => { if (TOUR.on) tourShow(true); }, 450); } return; }
    const tg = e.target.closest('[data-tourgo]'); if (tg){ if (TOUR.on) tourEnd(); else tourStart(); return; }
    const em = e.target.closest('#board .sc-bt li em, #board .sbadge'); if (em){ e.stopPropagation(); tourStart(em.dataset.st, em.dataset.bi, em.dataset.si); return; }
    const li = e.target.closest('#board .sc-bt li'); if (li){ e.stopPropagation(); tourStart(li.dataset.st, li.dataset.bi, 0); return; }
  }, true);
  document.addEventListener('keydown', e => {
    if (!TOUR.on) return; if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return; if (e.target && e.target.isContentEditable && !e.target.closest('#tourcap')) return;
    if (e.target && e.target.isContentEditable && e.target.closest('#tourcap')){ e.stopImmediatePropagation(); if (e.key === 'Enter'){ e.preventDefault(); e.target.blur(); } else if (e.key === 'Escape'){ e.preventDefault(); TOUR._noAnim = true; tourShow(false); } return; }
    if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown'){ e.preventDefault(); e.stopImmediatePropagation(); tourGo(1); }
    else if (e.key === 'ArrowLeft' || e.key === 'PageUp'){ e.preventDefault(); e.stopImmediatePropagation(); tourGo(-1); }
    else if (e.key === 'Escape'){ e.preventDefault(); e.stopImmediatePropagation(); tourEnd(); }
  }, true);
  document.addEventListener('mouseover', e => { const nd = e.target.closest && e.target.closest('#afb .afn[data-scr]'); $$('#afb .afn.twin').forEach(x => x.classList.remove('twin')); if (!nd) return;
    $$('#afb .afn[data-id="' + nd.dataset.id + '"]').forEach(x => { if (x !== nd) x.classList.add('twin'); }); });
  const st = $('#btnStory'); if (st) st.addEventListener('click', () => { S.story = !storyOn(); if (!S.story) tourEnd(); render(false); toast(S.story ? '흐름 번호를 켰습니다: 박스에 따라가기 순서 번호 (색 = 박스 종류)' : '흐름 번호를 껐습니다'); });
}
function bindPath(){
  $$('#pathSeg button, #pPath button').forEach(b => b.addEventListener('click', () => { const v = b.dataset.path; if ((S.path || 'all') === v) return; S.path = v; S.pin = null; render(true); navPush();
    const V6 = D.views[6][S.scr].nodes.filter(n => S.stages.has(n.st) && pathOK(n) && n.k !== 'why' && n.k !== 'pt'), hid = D.views[6][S.scr].nodes.filter(n => S.stages.has(n.st) && !pathOK(n) && n.k !== 'why' && n.k !== 'pt').length;
    toast(v === 'all' ? '전체 경로: ' + PATHS.map(p => p.v).join('·') + ' 업무 전체 표시' : v + ' 경로: 공통 업무 + ' + v + ' 업무만 표시 (Lv.6 ' + V6.length + '개, 다른 경로 ' + hid + '개 숨김)' + (S.lv === 4 ? ' · Lv.4는 단계 묶음이라 경로 구분이 없습니다' : '')); }));
}
function bindView(){
  $$('#vwSeg button, #pVw button').forEach(b => b.addEventListener('click', () => { if (S.view === b.dataset.vw) return; S.view = b.dataset.vw; render(true);
    toast(S.view === 'flow' ? '흐름 보기: 간격을 넓혀 화살표·신호 이름 전체 표시' : S.view === 'agent' ? 'Agent 흐름: 단계별 사람·Agent 업무 묶음과 묶음 간 흐름 (굵기 = 건수)' : '한눈에 보기: 전체 화면 압축 표시'); }));
}
function applyPin(){
  const id = S.pin;
  $$('#board .nd.fsel, #board .nd.fnb').forEach(x => x.classList.remove('fsel', 'fnb', 'fin', 'fout'));
  $$('#edges path.hot').forEach(p => p.classList.remove('hot')); $$('#board .elab.hot').forEach(l => l.classList.remove('hot'));
  if (!id || !S.M || !S.M.pos[id]){ board.classList.remove('efocus', 'pinned'); return; }
  board.classList.add('efocus', 'pinned'); const me = NODE_EL[id]; if (me) me.classList.add('fsel');
  $$('#edges path.e').forEach(p => { const a = p.dataset.a, b = p.dataset.b; if (a !== id && b !== id) return; p.classList.add('hot'); const el = NODE_EL[a === id ? b : a]; if (el) el.classList.add('fnb', a === id ? 'fout' : 'fin'); });
  $$('#edges path.bnd').forEach(p => { p.classList.toggle('hot', (p.dataset.src || '').split(' ').indexOf(id) >= 0 || (p.dataset.dst || '').split(' ').indexOf(id) >= 0); });
  $$('#board .elab').forEach(l => { const e = l.dataset.e; if (!e) return; const [a, b] = e.split('>'); if (a === id || b === id) l.classList.add('hot'); });
}
function pinFocus(id){ S.pin = id; applyPin(); }
function unpin(){ if (!S.pin) return; S.pin = null; applyPin(); }
function bindEdgeFocus(){
  wrap.addEventListener('mousedown', e => { if (e.button !== 0 || e.target.closest('.nd') || e.target.closest('#edtb') || e.target.closest('.slnav')) return; unpin(); });
  board.addEventListener('mouseover', e => { const nd = e.target.closest('.nd'); if (!nd || DRAG || S.pin || document.body.classList.contains('morph')) return; const id = nd.dataset.id; let any = false;
    $$('#edges path.e').forEach(p => { const on = p.dataset.a === id || p.dataset.b === id; p.classList.toggle('hot', on); any = any || on; }); board.classList.toggle('efocus', any);
    $$('#board .elab').forEach(l => { const ee = l.dataset.e; if (!ee) return; const [a, b] = ee.split('>'); l.classList.toggle('hot', a === id || b === id); }); });
  board.addEventListener('mouseout', e => { const nd = e.target.closest('.nd'); if (!nd || S.pin || (e.relatedTarget && nd.contains(e.relatedTarget))) return; board.classList.remove('efocus'); $$('#edges path.hot').forEach(p => p.classList.remove('hot')); $$('#board .elab.hot').forEach(l => l.classList.remove('hot')); });
}
function fitWrap(){
  if (document.body.classList.contains('present') || !S.M){ wrap.style.height = ''; wrap.style.minHeight = ''; return; }
  const want = Math.max(300, Math.min(window.innerHeight * 0.74, (S.M.H + 90) * S.zoom + 14)); wrap.style.height = Math.round(want) + 'px'; wrap.style.minHeight = '0';
}
function bindNav(){
  document.addEventListener('click', e => { const nb = e.target.closest('[data-nav]'); if (nb && !nb.disabled){ e.preventDefault(); navGo(+nb.dataset.nav); } });
  document.addEventListener('keydown', e => { if (e.altKey && (e.key === 'ArrowLeft' || e.key === 'ArrowRight') && !(e.target && (e.target.isContentEditable || /INPUT|TEXTAREA|SELECT/.test(e.target.tagName || '')))){ e.preventDefault(); e.stopPropagation(); navGo(e.key === 'ArrowLeft' ? -1 : 1); } }, true);
  window.addEventListener('mouseup', e => { if (e.button === 3 || e.button === 4){ e.preventDefault(); navGo(e.button === 3 ? -1 : 1); } });
  window.addEventListener('popstate', e => { const i = e.state && typeof e.state.pmnav === 'number' ? e.state.pmnav : null; if (i != null && NAV.stack[i] && i !== NAV.idx){ NAV.idx = i; navApply(NAV.stack[i]); } });
}
function bind(){
  $('#scrSeg').addEventListener('click', e => { const b = e.target.closest('button'); if (b) slideTo(b.dataset.scr); });
  $('#sldots').addEventListener('click', e => { const b = e.target.closest('button'); if (b) slideTo(b.dataset.scr); });
  $('#slPrev').onclick = () => slideTo('asis'); $('#slNext').onclick = () => slideTo('ns');
  $('#btnPresent').onclick = () => togglePresent(true); $('#btnExitPresent').onclick = () => togglePresent(false);
  document.addEventListener('fullscreenchange', () => {
    const pf = $('#pFull'); if (pf) pf.hidden = !!document.fullscreenElement;
    if (document.fullscreenElement || !document.body.classList.contains('present')) return;
    if (!$('#apage').hidden){ closePage(); toast('Agent 페이지를 닫았습니다. 발표 모드는 유지됩니다 (⛶로 전체 화면 전환)'); }
    else if (!$('#panel').hidden){ closePanel(); toast('상세 창을 닫았습니다. 발표 모드는 유지됩니다 (⛶로 전체 화면 전환)'); }
    else if (!$('#amap').hidden){ $('#amap').hidden = true; navPush(); toast('구조도를 닫았습니다 · 발표 모드는 그대로'); }
    else document.body.classList.remove('present');
  });
  $('#lvSeg').addEventListener('click', e => { const b = e.target.closest('button'); if (b) set(null, +b.dataset.lv, null); });
  $('#stSeg').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.st === 'all'){ set(null, null, D.stages.map(s => s.n)); return; }
    const n = +b.dataset.st, all = S.stages.size === D.stages.length; let ns = all ? new Set([n]) : new Set(S.stages);
    if (!all){ if (ns.has(n)) ns.delete(n); else ns.add(n); }
    if (!ns.size) ns = new Set(D.stages.map(s => s.n));
    set(null, null, Array.from(ns).sort());
  });
  board.addEventListener('click', e => { if (S.edit){ const nd = e.target.closest('.nd[data-id]'); if (nd){ const pp = $('#panel'); if (pp.hidden || !pp._pe || pp._pe.id !== nd.dataset.id){ const a = document.activeElement; showNode(nd.dataset.id); if (a && a.isContentEditable) a.focus(); } } return; } const nd = e.target.closest('.nd'); if (nd){ const id = nd.dataset.id; markAct(nd); pinFocus(id); clearTimeout(S.clickT); if (e.detail > 1) return; S.clickT = setTimeout(() => { showNode(id); showTb(id); }, 230); return; } const ag = e.target.closest('[data-ag]'); if (ag) showAgent(ag.dataset.ag); });
  board.addEventListener('dblclick', e => {
    if (S.edit || S.fedit) return; const nd = e.target.closest('.nd'); if (!nd) return; clearTimeout(S.clickT); const n = S.M.nodes.find(x => x.id === nd.dataset.id); if (!n) return;
    if (n.k === 'blk'){ closePanel(); S.view = 'compact'; S.lv = 6; S.stages = new Set([n.st]); S.hl = new Set(n.tasks.map(x => x.id)); render(true); toast(n.lb + ' · ' + n.st + '단계 업무 ' + n.tasks.length + '개를 Lv.6에서 강조했습니다 · Esc로 해제'); return; }
    let kids = [], lv2 = 0;
    if (S.lv === 4){
      lv2 = 5;
      if (D.A4[n.id]) kids = D.A4[n.id].kids.slice();
      else if (n.mem && n.mem.length){ const sid = n.ln; n.mem.forEach(x => { const l5 = L5OF[x] || (D.TB[x] && D.TB[x].l5); if (l5) kids.push(l5, l5 + '@' + sid); kids.push(x); }); }
    } else if (S.lv === 5){
      lv2 = 6;
      if (n.k === 'why') kids = [n.of, n.of + '~why'];
      else if (S.scr === 'asis') kids = ((D.A5[n.id] || {}).kids || []).slice();
      else if (n.id.indexOf('@') > 0) kids = ((D.P5[n.id] || {}).mem || []).slice();
      else { const l5 = n.pid || n.id; Object.keys(D.P5).forEach(k => { const q = D.P5[k]; if ((q.l5 || k) === l5) kids = kids.concat(q.mem || [], q.gone || [], (q.gone || []).map(g => g + '~why')); }); if (n.k === 'mk') kids.push(n.id); }
    } else return;
    closePanel(); S.lv = lv2; S.stages = new Set([n.st]); S.hl = new Set(kids); render(true);
    const shown = kids.filter(k => S.M.pos[k]);
    setTimeout(() => { const ps = shown.map(k => S.M.pos[k]); if (ps.length){ const x = Math.min.apply(null, ps.map(q => q.x)), y = Math.min.apply(null, ps.map(q => q.y)); wrap.scrollTo({left:Math.max(0, x * S.zoom - 160), top:Math.max(0, y * S.zoom - 120), behavior:'smooth'}); } }, 140);
    toast('Lv.' + lv2 + ' 하위 업무 ' + shown.length + '개를 강조했습니다 · Esc로 해제');
  });
  labels.addEventListener('click', e => { const ag = e.target.closest('[data-ag]'); if (ag) showAgent(ag.dataset.ag); });
  $('#panel').addEventListener('click', e => { if (e.target.closest('.px')){ closePanel(); return; } const ee = e.target.closest('[data-ee]'); if (ee){ showEdgePanel(ee.dataset.ee); return; }
    const go = e.target.closest('[data-go]'); if (go){ const id = go.dataset.go; if (DETAIL_CTX === '' && S.M && S.M.pos[id]){ const el = board.querySelector('.nd[data-id="' + id + '"]'); if (el){ el.scrollIntoView({block:'center', inline:'center', behavior:'smooth'}); $$('#board .nd.sel').forEach(x => x.classList.remove('sel')); el.classList.add('sel'); S.sel = id; } showNode(id); } else { const n2 = findNode(S.lv, S.scr, id); if (n2) showNodeObj(n2); } return; } const pg = e.target.closest('[data-page]'); if (pg){ agentPage(pg.dataset.page, pg.dataset.sub); return; } const l = e.target.closest('[data-ag]'); if (l) showAgent(l.dataset.ag); });
  $('#amap').addEventListener('click', e => { if (e.target.closest('[data-nav]')) return; if (e.target.closest('.px')){ AME = false; $('#amap').hidden = true; navPush(); return; }
    if (e.target.closest('[data-amed]')){ AME = !AME; amRedraw(); if (AME) toast('구조도 글자 수정: 점선 칸을 눌러 수정 · Agent·단계 이름은 전체에 반영 · Enter 확정 · Esc 취소 · 비우면 원래 문구'); return; }
    if (AME && e.target.closest('#amap [contenteditable="true"]')) return; const a = e.target.closest('[data-ag]'); if (a){ showAgent(a.dataset.ag); return; } const pg = e.target.closest('[data-page]'); if (pg) agentPage(pg.dataset.page); });
  $('#btnPage').onclick = () => agentPage(S.page || D.bands[0].id);
  $('#apage').addEventListener('click', e => {
    const asb = e.target.closest('.apsub'); if (asb){ const el = document.getElementById('sub-' + asb.dataset.sub); if (el) el.scrollIntoView({behavior:'smooth', block:'start'}); return; }
    const fa = e.target.closest('.fx-ag'); if (fa){ const el = document.getElementById('sub-' + fa.dataset.ag); if (el) el.scrollIntoView({behavior:'smooth', block:'start'}); return; } const afb = e.target.closest('[data-af]'); if (afb){ const v = afb.dataset.af; if (v === 'play') afPlay(); else if (v === 'fit'){ AF.fit = AF.fit === false; afRender(false); } else if (v.indexOf('st:') === 0){ const sv = v.slice(3); AF.st = sv === 'all' ? 'all' : +sv; afStop(); afRender(false); } else { const kv = v.split(':'); afStop(); if (kv[0] === 'lv'){ AF.lv = +kv[1]; AF.model = null; afRender(false); } else if (kv[1] === 'both'){ if (AF.view !== 'both'){ AF.view = 'both'; afRender(false); } } else if (AF.view === 'both' || AF.scr !== kv[1]){ const was = AF.view; AF.view = 'one'; AF.scr = kv[1]; afRender(was !== 'both'); } } return; } const afn = e.target.closest('#afb .afn'); if (afn){ const sc = afn.dataset.scr || AF.scr, n = AF.model && AF.model[sc].nodes.find(x => x.id === afn.dataset.id); if (n){ showIn(AF.lv, sc, n); markAct(afn); } return; } const cmr = e.target.closest('.cmr[data-id]'); if (cmr){ const scr = cmState().view === 'asis' ? 'asis' : 'ns', n = findNode(6, scr, cmr.dataset.id); if (n) showIn(6, scr, n); return; } const cml5 = e.target.closest('.cmt[data-l5]'); if (cml5){ showL5Combined(cml5.dataset.l5); return; } const cmst = e.target.closest('.cmt[data-st]'); if (cmst){ const scr = cmState().view === 'asis' ? 'asis' : 'ns', sg = D.stages.find(z => z.n === +cmst.dataset.st), n = sg && findNode(4, scr, sg.id); if (n) showIn(4, scr, n); return; } const l5r = e.target.closest('[data-l5ref]'); if (l5r){ showL5Combined(l5r.dataset.l5ref); return; } const tli = e.target.closest('[data-tid]'); if (tli){ const n = findNode(6, 'ns', tli.dataset.tid); if (n) showIn(6, 'ns', n); return; } const tbb = e.target.closest('[data-tab]'); if (tbb){ S.apTab = tbb.dataset.tab; $$('.aptabs button').forEach(x => x.setAttribute('aria-pressed', x.dataset.tab === S.apTab)); $('#tab-flow').hidden = S.apTab === 'cap'; $('#tab-cap').hidden = S.apTab !== 'cap'; if (S.apTab !== 'cap') afRender(false); else afStop(); navPush(); return; } const cmb = e.target.closest('[data-cm]'); if (cmb){ const st = cmState(), kv = cmb.dataset.cm.split(':'); st[kv[0]] = kv[0] === 'lv' ? +kv[1] : kv[1]; $('#cmw').innerHTML = cmHTML(D.bands.find(x => x.id === S.page)); return; } if (e.target.closest('.apc')){ closePage(); return; } const v = e.target.closest('.apv'); if (v){ const PB = PGB(), k = PB.findIndex(x => x.id === S.page) + (+v.dataset.step); if (PB[k]) agentPage(PB[k].id); return; } const n = e.target.closest('[data-page]'); if (n) agentPage(n.dataset.page); });
  document.addEventListener('keydown', e => {
    if (!$('#apage').hidden){ if (e.target && e.target.closest && e.target.closest('input, textarea, select, [contenteditable="true"]')) return; if (e.key === 'Escape'){ if (!$('#panel').hidden){ closePanel(); return; } closePage(); return; } if (e.key === 'ArrowRight' || e.key === 'ArrowLeft'){ const PB = PGB(), k = PB.findIndex(x => x.id === S.page) + (e.key === 'ArrowRight' ? 1 : -1); if (PB[k]){ e.preventDefault(); agentPage(D.bands[k].id); } } return; }
    if (e.key === 'Escape'){ if (!$('#panel').hidden){ closePanel(); return; } if (!$('#amap').hidden){ $('#amap').hidden = true; navPush(); return; } if (S.hl){ S.hl = null; render(false); return; } if (document.body.classList.contains('present')) togglePresent(false); return; }
    if (S.edit || (e.target && e.target.closest && e.target.closest('input, textarea, select, [contenteditable="true"]')) || e.altKey || e.ctrlKey || e.metaKey) return;
    if (document.body.classList.contains('present')){
      if (/^[0-7]$/.test(e.key)){ e.preventDefault(); set(null, null, e.key === '0' ? D.stages.map(s => s.n) : [+e.key]); return; }
      if (e.key === 'l' || e.key === 'L'){ e.preventDefault(); const L = [4, 5, 6], k = L.indexOf(S.lv); set(null, L[(k + (e.shiftKey ? 2 : 1)) % 3], null); return; }
      if (e.key === '+' || e.key === '='){ e.preventDefault(); $('#zIn').click(); return; }
      if (e.key === '-' || e.key === '_'){ e.preventDefault(); $('#zOut').click(); return; }
    }
    if (e.key === 'ArrowRight' || e.key === 'PageDown' || (e.key === ' ' && document.body.classList.contains('present'))){ e.preventDefault(); slideTo('ns'); }
    else if (e.key === 'ArrowLeft' || e.key === 'PageUp'){ e.preventDefault(); slideTo('asis'); }
  });
  $('#btnMap').onclick = agentMap;
  $('#pLv').addEventListener('click', e => { const b = e.target.closest('button'); if (b) $('#lvSeg button[data-lv="' + b.dataset.lv + '"]').click(); });
  $('#pSt').addEventListener('click', e => { const b = e.target.closest('button'); if (b) $('#stSeg button[data-st="' + b.dataset.st + '"]').click(); });
  $('#pZm').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; ({'-1':'#zOut', '0':'#zv', '1':'#zIn', 'fit':'#zFit'})[b.dataset.pz] && $(({'-1':'#zOut', '0':'#zv', '1':'#zIn', 'fit':'#zFit'})[b.dataset.pz]).click(); $('#pzv').textContent = Math.round(S.zoom * 100) + '%'; });
  $('#pFull').onclick = () => { try { const r = document.documentElement.requestFullscreen && document.documentElement.requestFullscreen(); if (r && r.catch) r.catch(() => {}); } catch(err){} };
  $('#pctl').addEventListener('click', e => { const b = e.target.closest('[data-px]'); if (!b) return; const t2 = $(b.dataset.px); if (t2) t2.click(); if (b.dataset.px === '#btnPlay') b.textContent = playT ? '■ 멈춤' : '▶ 자동'; });
  const fitBar = () => { const sb = $('#slbar'); if (sb) document.documentElement.style.setProperty('--slbar-h', sb.offsetHeight + 'px'); };
  window.addEventListener('resize', fitBar); document.addEventListener('fullscreenchange', () => setTimeout(fitBar, 60));
  const z = v => { S.zoom = Math.max(0.25, Math.min(1.6, Math.round(v * 20) / 20)); inner.style.zoom = S.zoom; $('#zv').textContent = Math.round(S.zoom * 100) + '%'; fitWrap(); };
  $('#zOut').onclick = () => z(S.zoom - 0.1); $('#zIn').onclick = () => z(S.zoom + 0.1); $('#zv').onclick = () => z(1);
  $('#zFit').onclick = () => { const lbw = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--lbw')) || 168, nat = lbw + S.M.W + 24; z(Math.min(1, (wrap.clientWidth - 8) / nat)); if ($('#pzv')) $('#pzv').textContent = Math.round(S.zoom * 100) + '%'; toast('가로를 화면에 맞췄습니다 · 100%를 누르면 원래 크기'); };
  $('#btnPlay').onclick = () => { const b = $('#btnPlay'); if (playT){ clearInterval(playT); playT = null; b.textContent = '▶ 자동 넘김'; return; } b.textContent = '■ 넘김 멈춤'; const step = () => slideTo(S.scr === 'asis' ? 'ns' : 'asis'); step(); playT = setInterval(step, 6500); };
  $('#btnEdit').onclick = () => { S.edit = !S.edit; $('#btnEdit').setAttribute('aria-pressed', S.edit); document.body.classList.toggle('editing', S.edit); setEditable(S.edit);
    /* v38: 문구 편집 하나로 — 상세 창 글자(설명문)·흐름 따라가기 창 문구도 같이 켜고 끔 */
    PE = S.edit; const pp = $('#panel'); if (!pp.hidden && pp._pe && !pp._pe.agent) peOn(pp, PE);
    if (typeof TOUR !== 'undefined' && TOUR){ TOUR.edit = S.edit; if (TOUR.on){ if (S.edit) tourAuto(false); TOUR._noAnim = true; tourShow(false); } }
    if (S.edit) toast('문구 편집: 점선 글자를 눌러 수정 · 박스를 누르면 상세 창 설명도 함께 수정'); };
  document.addEventListener('input', e => { if (!S.edit) return; const el = e.target.closest('[data-edit]'); if (!el) return; TXT[el.dataset.edit] = el.innerHTML; DIRTY = true; if (el.dataset.edit === 'title') document.title = el.textContent.trim(); });   // 지도 박스 이름은 고치기를 마칠 때 원본 이름으로 (bindNM)
  $('#btnExport').onclick = doExport; $('#btnPub').onclick = doPublish;
  window.addEventListener('beforeunload', e => { if (DIRTY){ e.preventDefault(); e.returnValue = ''; } });
}
/* ===== 상세 창 글자 수정: '글자 수정'을 누르면 상세 창의 글자를 그 자리에서 고침 =====
   제목 = 박스 이름(지도 박스와 같은 칸). 나머지는 박스(화면·레벨)별로 TXT['P|화면|레벨|ID|순번'] = [원래 글자, 고친 글자] → 편집본 저장에 함께 담김 */
let PE = false, PEN = null;
const PE_SEL = 'h3, .ph, .kd, .pdesc, .ptb, .pwhat > small, .io-c.do p, .painbox p, .stn, .ls li, p.src, p.kd, .pmeta';   /* v38: 칸 제목·계산 숫자·Agent 칩·As-Is 원본 표는 잠금 — 받는 것·만드는 것·시스템·형식은 v38 편집기(목록에서 고르기) */
const PE_NO = '.pflow, .ped, .px';
const peNorm = s => String(s || '').replace(/\s+/g, ' ').trim();
function peUnits(p){
  const all = Array.from(p.querySelectorAll(PE_SEL)).filter(el => !el.closest(PE_NO) && !el.querySelector('button, input, select') && peNorm(el.textContent)), set = new Set(all);
  return all.filter(el => { for (let x = el.parentElement; x && x !== p; x = x.parentElement) if (set.has(x)) return false; return true; });
}
function peClean(html){   // 고친 글자 안에 남길 것은 글자 꾸밈 정도만 (붙여 넣은 서식·스크립트는 지움)
  const t = document.createElement('template'); t.innerHTML = html; const OK = /^(B|STRONG|I|EM|SMALL|SPAN|BR|U|SUB|SUP)$/;
  t.content.querySelectorAll('*').forEach(el => { if (!OK.test(el.tagName)){ el.replaceWith(...Array.from(el.childNodes)); return; } Array.from(el.attributes).forEach(a => { if (a.name !== 'class') el.removeAttribute(a.name); }); });
  return t.innerHTML.replace(/(<br>\s*)+$/, '').trim();
}
function peTitle(p){ return p.querySelector(':scope > h3'); }
function peAfter(p){
  const c = PEN; PEN = null; p._pe = c; p.classList.remove('pe-on'); if (!c){ PE = false; return; }
  const units = peUnits(p), pre = c.ctx + '|';
  Object.keys(TXT).forEach(k => { if (k.indexOf(pre) !== 0 || !Array.isArray(TXT[k])) return; const i = +k.slice(pre.length), [o, h] = TXT[k];
    const u = (units[i] && peNorm(units[i].textContent) === o) ? units[i] : units.find(x => peNorm(x.textContent) === o); if (!u) return;
    if (h === ''){ u.style.display = 'none'; return; } u.innerHTML = h; u.classList.add('keepdot', 'pe-d'); });
  if (PE && !c.agent) peOn(p, true);
}
function peOn(p, on){
  p.classList.toggle('pe-on', on); const c = p._pe;
  peUnits(p).forEach((u, i) => { if (on){ u.contentEditable = 'true'; u.spellcheck = false; u.classList.add('pe-u'); u.dataset.pei = i; } else { u.removeAttribute('contenteditable'); u.classList.remove('pe-u'); } });
  $$('#panel [data-ed="text"]').forEach(b => { b.setAttribute('aria-pressed', on); b.textContent = on ? '✓ 글자 수정 끝내기' : '글자 수정'; });
  
}
function peToggle(){ const p = $('#panel'); if (p.hidden || !p._pe || p._pe.agent) return; PE = !PE; peOn(p, PE); }
function peCommit(u){
  const p = $('#panel'), c = p._pe; if (!c || !u._pe0) return; const st = u._pe0; u._pe0 = null;
  if (u._peX){ u._peX = false; u.innerHTML = st.h; return; }
  const txt = peNorm(u.innerText), html = peClean(u.innerHTML); if (txt === st.t) return;
  const n = (S.M && S.M.nodes.find(x => x.id === c.id)) || findNode(S.lv, S.scr, c.id);
  const nk = n ? nameKey(n, S.scr, S.lv) : null;
  if (u === peTitle(p) && nk){   // 제목 = 업무 이름 → 원본 이름을 바꿔 전체에 반영 (비우면 원래 이름)
    if (txt) setTimeout(() => nmRename(nk, txt), 0); else if (NM[nk] && NM0[nk]) setTimeout(() => nmRename(nk, NM0[nk]), 0); else peReopen(); return; }
  if (u === peTitle(p)){   // 흐름도 편집에서 새로 만든 박스: 그 화면 박스 이름만
    const k = tk(c.id), E0 = ED[edKey()];
    if (txt) TXT[k] = html; else delete TXT[k];
    if (E0 && E0.add && E0.add[c.id]) E0.add[c.id].lb = txt || E0.add[c.id].lb;
    const el = NODE_EL[c.id], lb = el && el.querySelector('.lbl'); if (lb) lb.innerHTML = txt ? html : esc(rd(n ? n.lb : ''));
    DIRTY = true; if (!txt) peReopen(); return;
  }
  const key = c.ctx + '|' + u.dataset.pei, prev = TXT[key], orig = Array.isArray(prev) ? prev[0] : st.t;
  if (!txt){ TXT[key] = [orig, '']; u.style.display = 'none'; DIRTY = true; return; }   // 비우면 그 칸은 없어짐
  if (txt === orig){ delete TXT[key]; DIRTY = true; peReopen(); return; }
  TXT[key] = [orig, html]; u.classList.add('keepdot', 'pe-d'); DIRTY = true;
}
function peReopen(){ const p = $('#panel'), sc = p.scrollTop, c = p._pe; if (!c) return; setTimeout(() => { if (S.M && S.M.pos[c.id]) showNode(c.id); $('#panel').scrollTop = sc; }, 0); }
(function bindPE(){
  const P = () => $('#panel'), unit = e => e.target && e.target.closest && e.target.closest('#panel.pe-on .pe-u');
  document.addEventListener('focusin', e => { const u = unit(e); if (u && !u._pe0) u._pe0 = {h:u.innerHTML, t:peNorm(u.textContent)}; }, true);
  document.addEventListener('focusout', e => { const u = unit(e); if (u) peCommit(u); }, true);
  document.addEventListener('keydown', e => { const u = unit(e); if (!u) return; e.stopPropagation();
    if (e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); u.blur(); } else if (e.key === 'Escape'){ e.preventDefault(); u._peX = true; u.blur(); } }, true);
  document.addEventListener('paste', e => { const u = unit(e); if (!u) return; e.preventDefault(); document.execCommand('insertText', false, ((e.clipboardData || window.clipboardData).getData('text/plain') || '').replace(/\r/g, '')); }, true);
})();
/* ===== 연결선 수정: 선 종류 · 이름표 · 경로 옮기기 · 출발/도착 바꾸기 · 방향 뒤집기 (화면별 저장, 되돌리기 가능) ===== */
const EKINDS = [['s', '일반'], ['b', '분기 (조건)'], ['r', '반려'], ['l', '순환'], ['o', 'Orchestrator 신호']];
function effEdges(scrlv){
  // [출발, 도착, 종류, 이름표, 묶음 정보, 경로 옮김, 편집에서 추가, 이름표를 편집에서 정함] — 원래 데이터의 일반선 이름표는 지금처럼 지도에서 숨김
  const q = scrlv.split('|'), V = D.views[+q[1]][q[0]], E = ED[scrlv], dels = new Set(((E && E.ed) || []).map(e => e[0] + '>' + e[1])), em = (E && E.em) || {};
  return V.edges.filter(e => !dels.has(e[0] + '>' + e[1])).map(e => { const m = em[e[0] + '>' + e[1]]; return m ? [e[0], e[1], m.t != null ? m.t : e[2], m.lab != null ? m.lab : (e[3] || ''), e[4], m.off || 0, 0, m.lab != null ? 1 : 0] : [e[0], e[1], e[2], e[3] || '', e[4], 0, 0, 0]; })
    .concat(((E && E.ea) || []).map(e => [e[0], e[1], e[2] || 's', e[3] || '', null, e[4] || 0, 1, e[3] ? 1 : 0]));
}
function edgeRec(key){ return effEdges(edKey()).find(e => e[0] + '>' + e[1] === key) || null; }
function anyNode(id){ return (S.M && S.M.nodes.find(x => x.id === id)) || findNode(S.lv, S.scr, id) || null; }
function eMut(key, fn){
  const [a, b] = key.split('>'), V = D.views[S.lv][S.scr]; let nk = key, bad = '';
  edChange(E => {
    E.em = E.em || {}; const k = E.ea.findIndex(x => x[0] === a && x[1] === b), o = V.edges.find(e => e[0] === a && e[1] === b);
    const m0 = E.em[key] || {}, rec = k >= 0 ? {a, b, t:E.ea[k][2] || 's', lab:E.ea[k][3] || '', off:E.ea[k][4] || 0} : {a, b, t:m0.t != null ? m0.t : (o ? o[2] : 's'), lab:m0.lab != null ? m0.lab : ((o && o[3]) || ''), off:m0.off || 0};
    fn(rec);
    if (rec.a === rec.b){ bad = '같은 박스끼리는 이을 수 없습니다'; return; }
    nk = rec.a + '>' + rec.b;
    if (nk !== key && effEdges(edKey()).some(e => e[0] === rec.a && e[1] === rec.b)){ bad = '이미 같은 연결이 있습니다'; nk = key; return; }
    if (k >= 0){ E.ea[k] = [rec.a, rec.b, rec.t, rec.lab, rec.off]; return; }
    if (nk !== key){ if (o && !E.ed.some(x => x[0] === a && x[1] === b)) E.ed.push([a, b]); delete E.em[key]; E.ea.push([rec.a, rec.b, rec.t, rec.lab, rec.off]); return; }
    const m = {}; if (o){ if (rec.t !== o[2]) m.t = rec.t; if (rec.lab !== (o[3] || '')) m.lab = rec.lab; } if (rec.off) m.off = rec.off;
    if (Object.keys(m).length) E.em[key] = m; else delete E.em[key];
  });
  if (bad){ toast(bad); const u = UNDO[edKey()]; if (u) u.pop(); }
  S.selE = nk; setTimeout(() => showEdgePanel(nk), 0); return nk;
}
function showEdgePanel(key){
  const rec = edgeRec(key); if (!rec){ closePanel(); return; }
  const [a, b, t, lab, , off, added] = rec, na = anyNode(a), nb = anyNode(b);
  S.selE = key; S.sel = null; PEN = null;
  const nmN = n => n ? plain(TXT[tk(n.id)] != null ? TXT[tk(n.id)] : n.lb) : '(이 화면에 없는 박스)', who = n => n ? performer(n) : '';
  const kinds = EKINDS.filter(([k]) => k !== 'o' || S.scr === 'ns' || t === 'o');
  const h = '<div class="ph">' + (S.scr === 'ns' ? 'To-be' : 'As-Is') + ' · Lv.' + S.lv + ' · 연결선</div><h3>연결선 수정</h3>'
    + '<div class="pwhat"><b>이 연결은</b><p class="pdesc">「' + esc(nmN(na)) + '」 → 「' + esc(nmN(nb)) + '」</p><small>' + esc((EKINDS.find(x => x[0] === t) || ['', t || '일반'])[1]) + (lab ? ' · 이름표: ' + esc(lab) : '') + (added ? ' · 편집에서 추가한 선' : '') + '</small></div>'
    + '<section class="ped" id="edtb"><h4>이 연결선 수정</h4>'
    + '<div class="pedf2"><span>출발</span><button type="button" class="lk" data-go="' + esc(a) + '">' + esc(nmN(na)) + '</button><small>' + esc(who(na)) + '</small><button type="button" data-ed="e-a">바꾸기</button></div>'
    + '<div class="pedf2"><span>도착</span><button type="button" class="lk" data-go="' + esc(b) + '">' + esc(nmN(nb)) + '</button><small>' + esc(who(nb)) + '</small><button type="button" data-ed="e-b">바꾸기</button></div>'
    + '<div class="pedr"><button type="button" data-ed="e-flip">⇄ 방향 뒤집기</button></div>'
    + '<div class="pedf"><span>선 종류</span><div class="pseg">' + kinds.map(([k, l]) => '<button type="button" data-ed="e-kind" data-v="' + k + '" aria-pressed="' + ((t || 's') === k) + '">' + l + '</button>').join('') + '</div></div>'
    + '<label class="pedf"><span>이름표</span><input type="text" data-ed="e-lab" aria-label="선 이름표" placeholder="예: 조건 · 반려 사유 · 신호 이름" value="' + esc(lab) + '"></label>'
    + '<div class="pedf"><span>경로</span><div class="pseg"><button type="button" data-ed="e-off" data-v="-1">◀ 옆으로</button><button type="button" data-ed="e-off" data-v="0"' + (off ? '' : ' disabled') + '>원래대로</button><button type="button" data-ed="e-off" data-v="1">옆으로 ▶</button></div></div>'
    + '<p class="pedh">이름표는 ‘흐름 (넓게)’ 보기에서 선 위에 보입니다 · 경로는 겹친 선을 옆으로 비켜 놓습니다' + (off ? ' (지금 ' + (off > 0 ? '+' : '') + off + 'px)' : '') + '</p>'
    + '<div class="pedr"><button type="button" data-ed="edel" class="danger">연결 삭제</button></div>'
    + '<p class="pedh">바꾸기를 누른 뒤 지도에서 새 박스를 누르세요 (Esc 취소) · Ctrl+Z 되돌리기 · Delete 키로도 삭제 · 지금 화면(' + (S.scr === 'ns' ? 'To-be' : 'As-Is') + ' Lv.' + S.lv + ')에만 반영</p></section>';
  openPanel(h); $('#panel').dataset.kind = 'edge'; drawEdges();
}
/* ===== 이름 바꾸기: Agent·업무 이름을 고치면 메인 맵·상세 창·구조도·상세 페이지·설명 문장(흐름 설명 포함)에 모두 반영 =====
   데이터 원본은 그대로 두고 NM['종류|ID'] = [지금 이름, 예전 이름…]으로 기억 → 열 때마다 다시 적용, 편집본 저장에 함께 담김.
   종류: ag = 큰 기능·세부 Agent, t6 = To-be Lv.6, a6 = As-Is Lv.6, l5 = As-Is Lv.5(양쪽 화면 공통), n5 = To-be Lv.5(최적화 묶음), l4 = Lv.4 */
let NM = (BK.nm && typeof BK.nm === 'object') ? JSON.parse(JSON.stringify(BK.nm)) : {};
const NM0 = {};
function nmCur(kind, id){
  if (kind === 'ag'){ const b = D.bands.find(x => x.id === id); return b ? b.name : (D.subs[id] || {}).name; }
  if (kind === 't6') return (D.TB[id] || {}).lb;
  if (kind === 'a6') return (D.A6[id] || {}).n;
  if (kind === 'l5') return (D.A5[id] || {}).n;
  if (kind === 'l4') return (D.A4[id] || {}).n;
  if (kind === 'n5'){ const n = D.views[5].ns.nodes.find(x => x.id === id); return n && n.lb; }
  if (kind === 'st') return (D.stages.find(x => String(x.n) === id) || {}).name;
  if (kind === 'ln') return (D.lanes.find(x => x.k === id) || {}).name;
}
function nameKey(n, scr, lv){   // 박스 이름이 어느 원본 이름인지 (없으면 null → 예전처럼 그 화면 박스 이름만)
  if (!n || n.k === 'why' || n.added) return null; const id = n.id, E = ED[scr + '|' + lv]; if (E && E.add && E.add[id]) return null;
  if (lv === 6) return scr === 'ns' ? (D.TB[id] ? 't6|' + id : null) : (D.A6[id] ? 'a6|' + id : null);
  if (lv === 5){ if (D.A5[id]) return 'l5|' + id; if (n.pid && D.A5[n.pid] && n.lb === D.A5[n.pid].n) return 'l5|' + n.pid; if (D.TB[id]) return 't6|' + id; return scr === 'ns' ? 'n5|' + id : null; }
  if (lv === 4) return D.A4[id] ? 'l4|' + id : null;
  return null;
}
function nmFields(kind, id, old){   // 지금 이름이 들어 있는 데이터 칸 [객체, 칸, 새 값 만들기]
  const L = [], add = (o, k, f) => { if (o && typeof o[k] === 'string') L.push([o, k, f]); }, views = (scrs, lvs, test) => lvs.forEach(lv => scrs.forEach(sc => D.views[lv][sc].nodes.forEach(n => { if (test(n)) add(n, 'lb'); })));
  if (kind === 'ag'){ const b = D.bands.find(x => x.id === id); add(b || D.subs[id], 'name'); }
  else if (kind === 'st') add(D.stages.find(x => String(x.n) === id), 'name');
  else if (kind === 'ln'){ const L = D.lanes.find(x => x.k === id); add(L, 'name'); if (L && L.who === old) add(L, 'who'); }
  else if (kind === 't6'){ add(D.TB[id], 'lb'); views(['ns'], [4, 5, 6], n => n.id === id); }
  else if (kind === 'a6'){ add(D.A6[id], 'n'); views(['asis'], [6], n => n.id === id); }
  else if (kind === 'n5'){ views(['ns'], [5], n => n.id === id); }
  else if (kind === 'l5'){ add(D.A5[id], 'n'); views(['asis', 'ns'], [5], n => n.id === id || (n.pid === id && n.lb === old));
    ((D.A5[id] || {}).kids || []).forEach(x => { const q = D.A6[x]; if (q && q.l5 === id + ' ' + old) add(q, 'l5', v => id + ' ' + v); }); }
  else if (kind === 'l4'){ add(D.A4[id], 'n'); views(['asis', 'ns'], [4], n => n.id === id && n.lb === old);
    [D.A6, D.A5].forEach(M => Object.keys(M).forEach(k => { if (M[k].g4 === old) add(M[k], 'g4'); if (M[k].l4 === old) add(M[k], 'l4'); })); }
  return L;
}
/* 설명 문장 속 이름: Agent 이름은 그대로, 업무 이름은 「」 안에서만 바꿈 — 바로 뒤 조사(이/가·을/를·은/는·과/와·으로/로)도 새 이름에 맞춤 */
const NMJ = [['으로', '로'], ['이', '가'], ['을', '를'], ['은', '는'], ['과', '와']];
function nmBat(w){ const s = String(w || '').replace(/[\s)\]」』'"’”]+$/, ''), ch = s.slice(-1); if (!ch) return false; const c = ch.charCodeAt(0); if (c >= 0xAC00 && c <= 0xD7A3) return (c - 0xAC00) % 28 !== 0; return /[LMNRlmnr136780]$/.test(s); }
function nmJosa(name, after){ for (const [a, b] of NMJ) for (const p of [a, b]){ if (!after.startsWith(p)) continue; const nx = after.charAt(p.length); if (nx && /[가-힣A-Za-z0-9]/.test(nx)) continue;
  const c = String(name).slice(-1).charCodeAt(0), rieul = c >= 0xAC00 && c <= 0xD7A3 && (c - 0xAC00) % 28 === 8; return [p.length, a === '으로' ? (nmBat(name) && !rieul ? '으로' : '로') : (nmBat(name) ? a : b)]; } return null; }
const nmRx = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function nmText(v, old, nv, ag){
  if (typeof v !== 'string' || !v || v.indexOf(old) < 0) return v;
  let rx, hit;
  if (ag){ const all = D.bands.map(b => b.name).concat(Object.keys(D.subs).map(k => D.subs[k].name)).concat([old]).filter(Boolean).sort((a, b) => b.length - a.length);
    rx = new RegExp(Array.from(new Set(all)).map(nmRx).join('|'), 'g'); hit = m => m === old; }
  else { rx = new RegExp('「' + nmRx(old) + '」', 'g'); hit = () => true; }
  let out = '', last = 0, m;
  while ((m = rx.exec(v))){ if (!hit(m[0])) continue; const end = m.index + m[0].length, j = nmJosa(nv, v.slice(end, end + 4));
    out += v.slice(last, m.index) + (ag ? nv : '「' + nv + '」'); last = end; if (j){ out += j[1]; last = end + j[0]; } }
  return last ? out + v.slice(last) : v;
}
function nmProse(old, nv, ag){
  const f = (o, k) => { if (o && typeof o[k] === 'string'){ const w = nmText(o[k], old, nv, ag); if (w !== o[k]) o[k] = w; } };
  Object.keys(D.desc || {}).forEach(c => Object.keys(D.desc[c]).forEach(id => f(D.desc[c], id)));
  Object.keys(STORY).forEach(k => { const s = STORY[k]; ['now', 'chg', 'next'].forEach(x => f(s, x)); (s.beats || []).forEach(b => { f(b, 't'); (b.steps || []).forEach(x => { f(x, 'v'); f(x, 'd'); f(x, 'a'); }); }); });
  Object.keys(STX).forEach(k => f(STX, k));
  Object.keys(D.story || {}).forEach(bid => { const s = D.story[bid]; ['p', 'hum', 'intro'].forEach(x => f(s, x)); (s.pb || []).forEach((_, i) => f(s.pb, i)); (s.imp || []).forEach(q => { f(q, 0); f(q, 1); });
    Object.keys(s.subs || {}).forEach(sid => { const x = s.subs[sid]; (x.f || []).forEach(q => f(q, 0)); (x.pn || []).forEach(q => f(q, 0)); f(x, 'e'); }); });
  D.bands.forEach(b => f(b, 'desc')); Object.keys(D.subs).forEach(k => f(D.subs[k], 'desc')); Object.keys(D.TB).forEach(k => f(D.TB[k], 'note'));
  ['outnew', 'when', 'whenHave', 'sysinfo'].forEach(dn => { const d = D[dn]; if (d) Object.keys(d).forEach(k => f(d, k)); });
  ((D.ax && D.ax.tasks) || []).forEach(t => Object.keys(t).forEach(k => f(t, k)));
  Object.keys(AMX_BUL).forEach(k => (AMX_BUL[k] || []).forEach((_, i) => f(AMX_BUL[k], i)));
  ['story'].forEach(k => { const st = AGX && AGX[k]; if (st) Object.keys(st).forEach(sid => { const x = st[sid]; (x.f || []).forEach(q => f(q, 0)); (x.pn || []).forEach(q => f(q, 0)); f(x, 'e'); }); });
  if (AGX && AGX.subs) Object.keys(AGX.subs).forEach(sid => f(AGX.subs[sid], 'desc'));
  Object.keys(TXT).forEach(k => { const v = TXT[k]; if (Array.isArray(v)){ v[0] = nmText(v[0], old, nv, ag); v[1] = nmText(v[1], old, nv, ag); } else f(TXT, k); });   // 상세 창에서 고친 글자 속 이름도
}
function nmSet(key, nv){   // 데이터 이름 칸 + 설명 문장을 지금 이름 → 새 이름으로
  const [kind, id] = key.split('|'), old = nmCur(kind, id); if (old == null) return false;
  if (!(key in NM0)) NM0[key] = old;
  if (old !== nv){ nmFields(kind, id, old).forEach(([o, k, fn]) => { o[k] = fn ? fn(nv) : nv; }); nmProse(old, nv, kind === 'ag' || kind === 'ln'); }
  const scr = kind === 'a6' ? ['asis'] : kind === 'l5' || kind === 'l4' ? ['asis', 'ns'] : ['ns'], lvs = kind === 't6' ? [6, 5, 4] : kind === 'a6' ? [6] : kind === 'l4' ? [4] : [5];
  if (kind !== 'st' && kind !== 'ag' && kind !== 'ln') scr.forEach(sc => lvs.forEach(lv => { delete TXT[sc + '|' + lv + '|' + id]; }));   // 그 화면 박스 이름만 덮어쓴 예전 수정은 지움 (원본 이름이 보이게)
  return true;
}
function nmApplyAll(){   // 열 때: 원래 이름과 예전 이름들 → 지금 이름 (예전에 저장한 표 수정·흐름 설명 속 이름까지)
  Object.keys(NM).forEach(key => { const h = NM[key]; if (!Array.isArray(h) || !h[0]) return; nmSet(key, h[0]); h.slice(1).forEach(p => { if (p && p !== h[0]) nmProse(p, h[0], /^(ag|ln)$/.test(key.split('|')[0])); }); });
}
function nmRename(key, nv){
  nv = String(nv || '').replace(/\s+/g, ' ').trim(); const [kind, id] = key.split('|'), old = nmCur(kind, id);
  if (!nv || old == null || nv === old) return false;
  if (kind === 'ag' && [...(D.bands || []).map(b => b.name), ...Object.values(D.subs).map(x => x.name)].includes(nv)){ toast('같은 이름의 Agent가 이미 있습니다'); return false; }   // v38 (S01)
  nmSet(key, nv); const h = NM[key] || []; NM[key] = [nv].concat([old].concat(h.slice(1)).filter((x, i, a) => x && x !== nv && a.indexOf(x) === i));
  DIRTY = true; nmRefresh(); toast('이름을 바꿨습니다 · 메인 맵·구조도·상세 페이지·설명 문장에 모두 반영 · ⤓ 편집본 저장으로 보관'); return true;
}
function nmRefresh(){
  const p = $('#panel'), pe = p._pe, psc = p.scrollTop, pg = !$('#apage').hidden, mp = !$('#amap').hidden, ax = !$('#axw').hidden;
  try { initSegs(); renderSteps(); } catch(e){}
  render(false);
  if (pg) agRerender(); else if (mp){ const sc = $('#amap').scrollTop; agentMap(); $('#amap').scrollTop = sc; }
  if (!pg && pe && !pe.agent && S.M && S.M.pos[pe.id]){ showNode(pe.id); $('#panel').scrollTop = psc; }
  if (ax && typeof axRender === 'function') axRender();
}
/* 이름 고치는 곳: 상세 창 제목(글자 수정), ✎ 문구 편집의 지도 박스, 세부 Agent 표 편집 중 Agent 이름(큰 기능·세부) */
(function bindNM(){
  const nmEl = e => e.target && e.target.closest && e.target.closest('#apm [data-nmk][contenteditable="true"], #amap [data-nmk][contenteditable="true"], #steps [data-nmk][contenteditable="true"]');
  document.addEventListener('focusin', e => { const el = nmEl(e); if (el) el._nm0 = el.textContent; const lb = e.target.closest && e.target.closest('#board .lbl[data-k]'); if (lb && S.edit) lb._t0 = lb.textContent; }, true);
  document.addEventListener('focusout', e => {
    const el = nmEl(e); if (el){ const v = el.textContent.replace(/\s+/g, ' ').trim(); if (el._nmX){ el._nmX = false; el.textContent = el._nm0; return; } if (v && v !== String(el._nm0 || '').trim()){ let nv = v; const k = el.dataset.nmk;
      if (k.indexOf('st|') === 0){ const st = D.stages.find(x => String(x.n) === k.slice(3)), m = String(st.name).match(/^(\d+\.\s*)?(.*?)(\s\/\s.*)?$/); nv = (m[1] || '') + v + (m[3] || ''); }   // 구조도는 번호·영문 뒤쪽을 뺀 이름만 보여 주므로 다시 붙임
      setTimeout(() => nmRename(k, nv), 0); } else el.textContent = el._nm0; return; }
    const lb = e.target.closest && e.target.closest('#board .lbl[data-k]'); if (!lb || !S.edit) return;
    const v = lb.textContent.replace(/\s+/g, ' ').trim(); if (v === String(lb._t0 || '').replace(/\s+/g, ' ').trim()) return;
    const q = lb.dataset.k.split('|'), n = S.M && S.M.nodes.find(x => x.id === q[2]), key = n ? nameKey(n, q[0], +q[1]) : null;
    if (key && v) setTimeout(() => nmRename(key, v), 0); else { TXT[lb.dataset.k] = lb.innerHTML; DIRTY = true; } }, true);
  document.addEventListener('keydown', e => { const el = nmEl(e); if (!el) return; e.stopPropagation(); if (e.key === 'Enter'){ e.preventDefault(); el.blur(); } else if (e.key === 'Escape'){ e.preventDefault(); el._nmX = true; el.blur(); } }, true);
})();

/* ===== Agent 구조도 글자 수정: 머리 막대 '✎ 글자 수정' → 단계 이름 · 큰 기능/세부/Orchestrator Agent 이름(전체 반영) · 기능 설명 줄 =====
   설명 줄: 구조도 전용 줄(ui.amxBul)이 있으면 TXT['AMX|큰기능ID|순번'](구조도에서만), 없으면 큰 기능 Agent 설명 원본 TXT['BD|큰기능ID'](설명이 쓰이는 모든 곳) */
let AME = false; const BD0 = {};
const amA = k => (AME && k) ? (/^(ag|st)\|/.test(k) ? ' data-nmk="' : ' data-amk="') + esc(k) + '" contenteditable="true" spellcheck="false"' : '';
const amBk = (b, i) => AMX_BUL[b.id] ? 'AMX|' + b.id + '|' + i : 'BD|' + b.id;
function amBul(b){ const L = AMX_BUL[b.id]; return L ? L.map((x, i) => TXT['AMX|' + b.id + '|' + i] != null ? TXT['AMX|' + b.id + '|' + i] : x) : [b.desc]; }
function bdApply(){ Object.keys(TXT).forEach(k => { if (k.indexOf('BD|') !== 0 || typeof TXT[k] !== 'string') return; const b = D.bands.find(x => x.id === k.slice(3)); if (!b) return; if (!(b.id in BD0)) BD0[b.id] = b.desc; b.desc = TXT[k]; }); }
function amRedraw(){ const a = $('#amap'), sc = a.scrollTop; agentMap(); a.scrollTop = sc; }
(function bindAM(){
  const amEl = e => e.target && e.target.closest && e.target.closest('#amap [data-amk][contenteditable="true"]');
  document.addEventListener('focusin', e => { const el = amEl(e); if (el) el._a0 = el.textContent; }, true);
  document.addEventListener('focusout', e => { const el = amEl(e); if (!el) return; const k = el.dataset.amk, v = el.innerText.replace(/\s+/g, ' ').trim();
    if (el._aX){ el._aX = false; el.textContent = el._a0; return; } if (v === String(el._a0 || '').replace(/\s+/g, ' ').trim()) return;
    if (k.indexOf('BD|') === 0){ const b = D.bands.find(x => x.id === k.slice(3)); if (!b) return; if (!(b.id in BD0)) BD0[b.id] = b.desc;
      if (v){ TXT[k] = v; b.desc = v; } else { delete TXT[k]; b.desc = BD0[b.id]; } }
    else if (v) TXT[k] = v; else delete TXT[k];
    DIRTY = true; if (!v) setTimeout(amRedraw, 0); }, true);
  document.addEventListener('keydown', e => { const el = amEl(e); if (!el) return; e.stopPropagation(); if (e.key === 'Enter' && !e.shiftKey){ e.preventDefault(); el.blur(); } else if (e.key === 'Escape'){ e.preventDefault(); el._aX = true; el.blur(); } }, true);
  document.addEventListener('keydown', e => { const el = e.target && e.target.closest && e.target.closest('#amap [contenteditable="true"]'); if (el) e.stopPropagation(); }, false);
})();

/* ===== Agent 상세 페이지 내용 편집 (데이터 기준) =====
   '✎ 내용 편집'을 켜면 엑셀·설계 데이터로 채운 칸만 고칠 수 있다 (제목·항목명·머리글·지도에서 계산되는 값은 고정).
   어디서 고치든 그 세부 Agent의 데이터(D.subs·D.story)를 바꾸고 페이지를 다시 그리므로, 같은 Agent 안의 구조도·한눈에 보기·표가 함께 바뀐다.
   범위: 세부 Agent 영역(구조도의 그 Agent 줄·한눈에 보기의 그 Agent 줄·세부 Agent 상세)은 그 세부 Agent만, 합쳐 보여주는 곳(한눈에 보기 맨 위 줄·데이터 표·시스템 표)은 그 큰 기능 Agent의 세부 Agent 모두. 다른 큰 기능 Agent에는 반영하지 않는다.
   '언제 쓰나'·'주고받는 정보'·'형식'은 원래 이름 기준 공용 설명이라, 고치면 그 세부 Agent 전용(xw·xi·xf)으로 떼어 저장한다. 비우면 그 항목·문장은 없어진다 */
const AEG = {d:'dg', s:'sp', of:'og'}, AEK = {dg:'d', sp:'s', og:'of'};
const aiA = (kind, name) => (AGE && kind && name != null) ? ' data-ai="' + esc(kind + '|' + name) + '"' : '';
const agA = (gk, name) => (AGE && name != null) ? ' data-agg="' + esc(gk + '|' + name) + '"' : '';
const atA = k => AGE ? ' data-at="' + esc(k) + '"' : '';
const atS = (k, t) => AGE ? '<span class="ae-t"' + atA(k) + '>' + t + '</span>' : t;

function aeOv(map, name, subs){ for (const sid of (subs || [])){ const s = D.subs[sid], o = s && s[map]; if (o && o[name] != null) return o[name]; } return null; }
const sxInfo = (n, subs) => { const o = aeOv('xi', n, subs); return o != null ? o : ((D.sysinfo && D.sysinfo[n]) || ''); };
const dfOf = (n, subs) => { const o = aeOv('xf', n, subs); return o != null ? o : ((D.dfmt && D.dfmt[n]) || '문서 (PPT·PDF·Word)'); };
{ const W0 = whenOf; whenOf = function(name, kind, subIds){ const o = aeOv('xw', name, subIds); return o != null ? o : W0.apply(this, arguments); }; }

const aeSubs = sc => sc === '*' ? ((D.bands.find(b => b.id === S.page) || {subs:[]}).subs || []) : (D.subs[sc] ? [sc] : []);




function pbApply(){ Object.keys(TXT).forEach(k => { if (k.indexOf('PB|') !== 0) return; const st = D.story && D.story[k.slice(3)]; try { if (st) st.pb = JSON.parse(TXT[k]); } catch(e){} }); }








const introOf = b => TXT['IN|' + b.id] != null ? TXT['IN|' + b.id] : (((D.story || {})[b.id] || {}).intro || b.desc || '');
/* ===== 흐름도 편집을 Agent 페이지·구조도 계산에 반영 =====
   To-be Lv.6 흐름도 편집 기록(ED['ns|6'])을 원래 지도 위에 얹어 계산: 지운 박스는 빠지고, 종류를 바꾸면 Agent 업무에 들고 나며(Agent·Orchestrator만 맡는 업무),
   Agent 레인에 추가한 박스는 그 세부 Agent 업무로, 연결선 수정(추가·삭제·종류)은 앞뒤 업무·사람이 확인하는 지점에. 원래 값은 기억해 두고 매번 다시 계산 (되돌리기 가능) */
const KT = {h:'H', nh:'N', a:'A', na:'A', gone:'X', mk:'M', ot:'O'}, LV0 = {ok:0, tb:{}, tasks:{}, stages:{}};
const lvE = () => ED['ns|6'] || {};
function liveEdges(){ const del = lvE().del || {}; return effEdges('ns|6').filter(e => !del[e[0]] && !del[e[1]]); }
function liveNodes(){ const E = lvE(), del = E.del || {}, kd = E.kd || {}, tg = E.tg || {}, add = E.add || {};
  return D.views[6].ns.nodes.filter(n => !del[n.id]).map(n => (kd[n.id] != null || tg[n.id] != null) ? Object.assign({}, n, kd[n.id] != null ? {k:kd[n.id]} : {}, tg[n.id] != null ? {tg:tg[n.id]} : {}) : n)
    .concat(Object.keys(add).map(id => ({id, k:add[id].k, ln:add[id].ln, st:add[id].st, lb:add[id].lb, tg:add[id].tg || '', c:999, r:0, added:1}))); }
function liveSync(){
  if (!LV0.ok){ Object.keys(D.TB).forEach(id => { LV0.tb[id] = {t:D.TB[id].t, tg:D.TB[id].tg, sub:D.TB[id].sub}; }); Object.keys(D.subs).forEach(sid => { LV0.tasks[sid] = (D.subs[sid].tasks || []).slice(); LV0.stages[sid] = (D.subs[sid].stages || []).slice(); }); LV0.ok = 1; }
  Object.keys(D.TB).forEach(id => { if (LV0.tb[id]) Object.assign(D.TB[id], LV0.tb[id]); else if (D.TB[id].added){ delete D.TB[id]; delete NS6[id]; } });
  const E = lvE(), del = E.del || {}, kd = E.kd || {}, tg = E.tg || {}, add = E.add || {}, work = t => t === 'A' || t === 'M';
  Object.keys(kd).forEach(id => { if (D.TB[id] && KT[kd[id]]) D.TB[id].t = KT[kd[id]]; });
  Object.keys(tg).forEach(id => { if (D.TB[id]) D.TB[id].tg = tg[id]; });
  Object.keys(add).forEach(id => { const a = add[id], lb = TXT['ns|6|' + id] != null ? plain(TXT['ns|6|' + id]) : a.lb;
    D.TB[id] = {t:KT[a.k] || 'H', sub:D.subs[a.ln] ? a.ln : null, lb, tg:a.tg || '', st:a.st, note:'', added:1}; NS6[id] = {id, st:a.st, c:999, r:0, ln:a.ln, k:a.k}; });
  const lane = id => (NS6[id] || {}).ln;
  Object.keys(D.subs).forEach(sid => { const s = D.subs[sid], base = LV0.tasks[sid] || [];
    let ts = base.filter(id => !del[id] && D.TB[id] && work(D.TB[id].t));
    Object.keys(D.TB).forEach(id => { if (del[id] || ts.indexOf(id) >= 0) return; const t = D.TB[id]; if (!work(t.t)) return;
      if ((t.added && t.sub === sid) || (kd[id] != null && (t.sub === sid || (!t.sub && lane(id) === sid)))){ ts.push(id); if (!t.sub) t.sub = sid; } });
    s.tasks = ts;
    s.stages = (ts.length === base.length && ts.every((x, i) => x === base[i])) ? (LV0.stages[sid] || []).slice() : Array.from(new Set(ts.map(id => (D.TB[id] || {}).st || (NS6[id] || {}).st).filter(Boolean))).sort((a, b) => a - b); });
}
{ const AP2 = agentPage; agentPage = function(){ try { liveSync(); } catch(e){ console.error(e); } return AP2.apply(this, arguments); }; }
{ const AM2 = agentMap; agentMap = function(){ try { liveSync(); } catch(e){ console.error(e); } return AM2.apply(this, arguments); }; }
{ const SA2 = showAgent; showAgent = function(){ try { liveSync(); } catch(e){ console.error(e); } return SA2.apply(this, arguments); }; }
/* ===== 내용 편집: 상태(기존·준비중·신규 설치 필요) 드롭다운 + 준비 주체, 합친 데이터 표 '형식' 분류 드롭다운, 데이터·산출물 형식 추천 목록 ===== */








/* ui_fixes v19 */
/* 박스 높이 두 가지: 기본 = 박스 80%가 들어가는 높이, 긴 글 = 가장 긴 박스(기본의 2.2배까지, 넘으면 박스 안 스크롤) */
const TIER = {};
function hTier(out, list, w){
  /* v22: 레벨(Lv.4·5·6)·보기·박스 폭마다 그 레벨의 모든 박스(As-Is·To-be, 전 단계)로 두 높이를 한 번 정함 → 화면·단계가 바뀌어도 같은 두 높이 (설명 메모도 같은 두 높이) */
  const key = S.lv + '|' + S.view + '|' + w;
  if (!TIER[key]){
    const all = D.views[S.lv].asis.nodes.concat(D.views[S.lv].ns.nodes).filter(n => !/^(pt|grp)$/.test(n.k)), box = document.createElement('div');
    box.style.cssText = 'position:absolute;left:0;top:0;width:0;height:0;overflow:visible;visibility:hidden;pointer-events:none';
    box.innerHTML = all.map(n => '<div class="nd k-' + n.k + ' L' + S.lv + '" style="position:absolute;left:0;top:0;width:' + w + 'px;height:auto;transition:none">' + nodeHTML(n) + '</div>').join('');
    board.appendChild(box); const hs = Array.from(box.children).map(el => Math.max(30, Math.ceil(el.offsetHeight) + 1)).sort((a, b) => a - b); box.remove();
    const H1 = hs[Math.min(hs.length - 1, Math.floor(hs.length * 0.8))] || 44, H2 = Math.min(hs[hs.length - 1] || H1, Math.round(H1 * 2.2));
    TIER[key] = {H1, H2: Math.max(H2, H1)};
  }
  const {H1, H2} = TIER[key], by = {}; list.forEach(n => { by[n.id] = n; });
  Object.keys(out).forEach(id => { if (by[id] && !/^(pt|grp)$/.test(by[id].k)) out[id] = out[id] <= H1 ? H1 : H2; }); return out;
}
/* 연결선 줄기: 한 박스에서 오른쪽으로 여러 갈래가 나가면 같은 세로 줄기에서 갈라지고, 여러 갈래가 한 박스로 모이면 같은 세로 줄기에서 합쳐짐 */
let TRK = {out:{}, inn:{}};
function trunkPrep(M){
  TRK = {out:{}, inn:{}}; const E = M.agentView ? [] : effEdges(S.scr + '|' + S.lv), P = M.pos, cnt = {o:{}, i:{}};
  E.forEach(([a, b, t]) => { if (t === 'l' || t === 'r' || !P[a] || !P[b]) return; const A = P[a], B = P[b]; if (B.x < A.x + A.w + 8) return;
    (cnt.o[a] = cnt.o[a] || []).push(B.x - (A.x + A.w)); (cnt.i[b] = cnt.i[b] || []).push(B.x - (A.x + A.w)); });
  Object.keys(cnt.o).forEach(a => { if (cnt.o[a].length > 1){ const A = P[a]; TRK.out[a] = A.x + A.w + Math.min(18, Math.min.apply(null, cnt.o[a]) / 2); } });
  Object.keys(cnt.i).forEach(b => { if (cnt.i[b].length > 1){ const B = P[b]; TRK.inn[b] = B.x - Math.min(18, Math.min.apply(null, cnt.i[b]) / 2); } });
  const vo = {}, vi = {}; E.forEach(([a, b, t]) => { if (t === 'l' || t === 'r' || !P[a] || !P[b]) return; const A = P[a], B = P[b]; if (B.y >= A.y + A.h + 8){ (vo[a] = vo[a] || []).push(b); (vi[b] = vi[b] || []).push(a); } });
  TRK.vout = {}; TRK.vin = {}; Object.keys(vo).forEach(a => { if (vo[a].length > 1) TRK.vout[a] = P[a].y + P[a].h + 10; }); Object.keys(vi).forEach(b => { if (vi[b].length > 1) TRK.vin[b] = P[b].y - 10; });   /* 아래로 여러 갈래 = 박스 바로 아래 한 줄에서 갈라짐, 여러 갈래가 모임 = 박스 바로 위 한 줄에서 모임 */
}

/* 고정 머리줄: 단계 바·숫자·게이트 줄을 글 길이에 맞춰 쌓고, 머리줄 높이와 왼쪽 칸 이름표를 같이 맞춤 */
function headFit(){
  const rows = {r1:[], r2:[], r3:[]};
  Object.keys(HEADP).forEach(k => { const el = HEADP[k], r = k.slice(0, 2); if (rows[r] && el.isConnected){ el.style.height = 'auto'; rows[r].push(el); } });
  let y = 6; const tops = {}, hs = {};
  ['r1', 'r2', 'r3'].forEach(r => { if (!rows[r].length){ hs[r] = 0; return; } const h = Math.max.apply(null, rows[r].map(el => el.offsetHeight)); tops[r] = y; hs[r] = h; rows[r].forEach(el => { el.style.top = y + 'px'; el.style.height = h + 'px'; }); y += h + 4; });
  const H = Math.max(84, y + 4); head.style.height = H + 'px';
  const sp = $$('#corner span'); ['r1', 'r2', 'r3'].forEach((r, i) => { if (sp[i]){ sp[i].style.height = hs[r] ? (hs[r] + 4) + 'px' : '0px'; sp[i].style.overflow = 'visible'; } });
}
{ const RH0 = renderHead; renderHead = function(){ const r = RH0.apply(this, arguments); try { headFit(); } catch(e){ console.error(e); } return r; }; }
window.addEventListener('resize', () => { try { headFit(); } catch(e){} });
/* 레인(조직) 이름: 원문 그대로, '>' 기준으로 줄만 나눔 */
function laneSplit(root){ (root || labels).querySelectorAll('b, strong, .ln, .lnm').forEach(el => {
  const has = el.querySelector('.lsg'); if (!has && (el.children.length || el.textContent.indexOf('>') < 0)) return;
  if (!has){ el.innerHTML = el.textContent.split(/\s*>\s*/).map(x => '<span class="lsg">' + esc(x) + '</span>').join(''); }
  fitSegs(el); }); }
/* '>'로 나눈 조각은 한 줄로 ("비즈니스 1, 3부문"이 갈라지지 않게) — 칸보다 길면 글자를 9.5px까지 줄이고, 그래도 길면 어절 단위로 줄바꿈 */
function fitSegs(el){ el.querySelectorAll('.lsg').forEach(s => { s.style.fontSize = ''; s.style.whiteSpace = 'nowrap'; let f = parseFloat(getComputedStyle(s).fontSize) || 11.5;
  while (s.scrollWidth > s.clientWidth + 0.5 && f > 9.5){ f -= 0.5; s.style.fontSize = f + 'px'; } if (s.scrollWidth > s.clientWidth + 0.5) s.style.whiteSpace = 'normal'; }); }
/* ===== v26 연결선: 왼쪽 옆구리로 들어가기 + 겹치지 않게 자기 통로 ===== */
function gapUp(c){ /* v26: To-be 한눈에 보기는 화살표 통로가 모자라 열 간격·박스 세로 간격·Agent 묶음 간격을 넓힘 (As-Is는 그대로) */
  if (S.scr === 'ns' && S.view !== 'flow'){ c.colW += BUNDLE() ? 6 : 14; c.vg += BUNDLE() ? 2 : 8; c.pad += BUNDLE() ? 2 : 4; c.sg += 6; c.sv += 6; const nd = BUNDLE() ? 36 : gapNeed(S.lv); if (nd > c.gap) c.gap = nd; } return c; }
function BUNDLE(){ return S.bundle != null ? S.bundle : !!(D.ui && D.ui.edgeBundle); }   /* 세로선 합치기: 화면 버튼 또는 설계 ui.edgeBundle(프롬프트로 정한 기본값) */
const GAPNEED = {};
function gapNeed(lv){   /* 단계 사이 세로 통로 폭: 그 단계에서 Agent 레인을 오가는 화살표 수만큼 (화살표 사이 7px) — 데이터로 미리 계산 */
  if (GAPNEED[lv] != null) return GAPNEED[lv]; const V = D.views[lv] && D.views[lv].ns; if (!V){ GAPNEED[lv] = 0; return 0; }
  const N = {}; V.nodes.forEach(n => { N[n.id] = n; }); const cnt = {};
  V.edges.forEach(([a, b, t]) => { const A = N[a], B = N[b]; if (!A || !B || A.ln === B.ln) return; if (!(D.subs[A.ln] || D.subs[B.ln])) return; [A.st, B.st].forEach(st => { cnt[st] = (cnt[st] || 0) + 1; }); });
  GAPNEED[lv] = Math.min(220, Math.max(0, ...Object.values(cnt).map(v => v * 7 + 16))); return GAPNEED[lv]; }
function entPen(p){ const n = p.length; if (n < 2) return 0; const a = p[n - 2], b = p[n - 1]; if (Math.abs(a[1] - b[1]) < .6) return b[0] > a[0] ? 0 : 1.5; return .6; }   /* 왼쪽으로 들어가면 0, 위·아래 .6, 오른쪽 1.5 (박스를 지나는 10보다 작음) */
function leftTail(g, A, B, rects, a, b){
  /* 위·아래로 들어가는 경로를 '다음 박스 왼쪽 틈으로 가서 왼쪽 가운데로'로 바꿈 — 박스를 지나지 않을 때만 */
  if (!g || !g.pts || g.pts.length < 2) return g; const p = g.pts, n = p.length, L = p[n - 1], P = p[n - 2];
  const ai = RINFO && RINFO[b] && RINFO[b].ai, gap = (S.M.C.colW - S.M.C.nodeW) / 2, gx = B.x - (ai ? 5 : Math.max(5, Math.min(12, gap - 2))), cy = B.y + B.h / 2;
  if (Math.abs(L[1] - P[1]) < .6 && L[0] < P[0] - .5){   /* 오른쪽으로 들어가는 선: 박스 위·아래 여백으로 돌아 왼쪽으로 */
    for (const yr of [B.y - 9, B.y + B.h + 9]){ const q2 = simp(p.slice(0, n - 1).concat([[P[0], yr], [gx, yr], [gx, cy], [B.x - 1, cy]])); if (hits(q2, rects, a, b) <= hits(p, rects, a, b)) return Object.assign({}, g, {pts:q2, ex:B.x, ey:cy}); }
    return g; }
  if (Math.abs(L[0] - P[0]) > .6) return g;   /* 이미 왼쪽에서 가로로 들어감 */
  let q = null;
  if (n >= 3 && Math.abs(p[n - 3][1] - P[1]) < .6) q = p.slice(0, n - 2).concat([[gx, P[1]], [gx, cy], [B.x - 1, cy]]);
  else if (n === 2){ const top = L[1] <= B.y + 1, ym = top ? (A.y + A.h + B.y) / 2 : (B.y + B.h + A.y) / 2; if (Math.abs((top ? B.y - (A.y + A.h) : A.y - (B.y + B.h))) < 10) return g; q = [p[0], [p[0][0], ym], [gx, ym], [gx, cy], [B.x - 1, cy]]; }
  if (!q) return g; q = simp(q);
  if (hits(q, rects, a, b) > hits(p, rects, a, b)) return g;
  return Object.assign({}, g, {pts:q, ex:B.x, ey:cy, h:hits(q, rects, a, b) * 10});
}
{ const xr0 = xrowRoute; xrowRoute = function(A, B, t, rects, a, b, off){ let g = xr0(A, B, t, rects, a, b, off); if (!g || t === 'l' || t === 'r') return g;
    /* Agent 레인을 오가는 선: 단계 왼쪽 공용 통로 대신 각 박스의 열 틈으로 곧게 (박스를 지나지 않을 때만) */
    const RA = RINFO && RINFO[a], RB = RINFO && RINFO[b], M = S.M;
    if (RA && RB && (RA.ai !== RB.ai) && RA.st === RB.st){
      const gap = (M.C.colW - M.C.nodeW) / 2, cyB = B.y + B.h / 2, cyA = A.y + A.h / 2; let alt = null;
      if (RA.ai){ const ix = RA.segX + 3, sy = RA.shelfY - 5, cA = RA.nodeTop + 1, xa = A.x + A.w / 2, gxB = B.x - Math.max(5, Math.min(12, gap - 2));
        alt = [[xa, A.y], [xa, cA], [ix, cA], [ix, sy], [gxB, sy], [gxB, cyB], [B.x - 1, cyB]]; }
      else { const gxA = A.x + A.w + Math.max(5, Math.min(12, gap - 2)), sy2 = RB.shelfY - 5, jx = RB.segX + 3, cB = RB.nodeTop + 1;
        alt = [[A.x + A.w, cyA], [gxA, cyA], [gxA, sy2], [jx, sy2], [jx, cB], [B.x - 5, cB], [B.x - 5, cyB], [B.x - 1, cyB]]; }
      alt = simp(alt); if (hits(alt, rects, a, b) === 0) g = {pts:alt, ex:B.x, ey:cyB, h:0}; }
    return leftTail(g, A, B, rects, a, b); }; }
{ const route0 = route; route = function(A, B, t, rects, a, b, off){ const g = route0(A, B, t, rects, a, b, off); return (t === 'l' || t === 'r') ? g : leftTail(g, A, B, rects, a, b); }; }
function simp(p){ const q = []; p.forEach(pt => { const L = q[q.length - 1]; if (L && Math.abs(L[0] - pt[0]) < .5 && Math.abs(L[1] - pt[1]) < .5) return; q.push([pt[0], pt[1]]); });
  for (let i = q.length - 2; i > 0; i--){ const a = q[i - 1], b = q[i], c = q[i + 1]; if ((Math.abs(a[0] - b[0]) < .6 && Math.abs(b[0] - c[0]) < .6) || (Math.abs(a[1] - b[1]) < .6 && Math.abs(b[1] - c[1]) < .6)) q.splice(i, 1); } return q; }
function ortho(q){ for (let i = 0; i < q.length - 1; i++){ if (Math.abs(q[i][0] - q[i + 1][0]) >= .6 && Math.abs(q[i][1] - q[i + 1][1]) >= .6) return false; } return true; }   /* 모든 조각이 가로 또는 세로 (90도 꺾임 유지) */
function dedetour(p, A, B, rects, a, b){
  /* 되돌아가는 꺾임(U자)·몇 px짜리 잔꺾임을 없앰 — 박스를 더 지나게 되거나 왼쪽 진입이 깨지면 그 수정은 버림 */
  const H = (u, v) => Math.abs(u[1] - v[1]) < .6, V = (u, v) => Math.abs(u[0] - v[0]) < .6, base = hits(p, rects, a, b);
  const okEnd = q => { const n = q.length, L = q[n - 1], P = q[n - 2]; return !(H(P, L) && L[0] < P[0]) || !(H(p[p.length - 2], p[p.length - 1]) && p[p.length - 1][0] > p[p.length - 2][0]); };
  for (let it = 0; it < 12; it++){ let ch = false;
    for (let i = 0; i + 3 < p.length; i++){ const [P0, P1, P2, P3] = [p[i], p[i + 1], p[i + 2], p[i + 3]];
      for (const ax of [0, 1]){ const along = ax === 0 ? H : V, cross = ax === 0 ? V : H;   /* ax 0: 가로-세로-가로, ax 1: 세로-가로-세로 */
        if (!(along(P0, P1) && cross(P1, P2) && along(P2, P3))) continue;
        const d1 = Math.sign(P1[ax] - P0[ax]), d3 = Math.sign(P3[ax] - P2[ax]), lo = Math.min(P0[ax], P3[ax]), hi = Math.max(P0[ax], P3[ax]);
        let nx = null;
        if (d1 && d3 && d1 !== d3) nx = Math.max(lo, Math.min(hi, P1[ax]));   /* U자: 바깥으로 나갔다 돌아오지 않게 안쪽에서 꺾음 */
        else if (Math.abs(P1[1 - ax] - P2[1 - ax]) < 6 && d1 === d3){   /* 잔꺾임(6px 미만): 뒤쪽 조각을 앞 조각 높이에 맞춰 한 줄로 */
          if (i + 3 === p.length - 1){ const lo2 = ax === 0 ? B.y + 4 : B.x + 4, hi2 = ax === 0 ? B.y + B.h - 4 : B.x + B.w - 4; if (P0[1 - ax] < lo2 || P0[1 - ax] > hi2) continue; }   /* 끝점은 박스 옆면 안에서만 */
          const q = p.map(x => x.slice()); q[i + 2][1 - ax] = P0[1 - ax]; q[i + 3][1 - ax] = P0[1 - ax];
          const r = simp(q); if (ortho(r) && hits(r, rects, a, b) <= base && okEnd(r)){ p.splice(0, p.length, ...r); ch = true; break; } continue; }
        if (nx != null && i === 0 && ax === 0 && A && Math.abs(P0[0] - (A.x + A.w)) < 1.5 && d3 < 0){   /* 오른쪽으로 나갔다가 왼쪽으로 돌아오는 선: 박스 왼쪽으로 나감 */
          const q = p.map(x => x.slice()), xo = A.x - 8; q[0] = [A.x, P0[1]]; q[1] = [xo, P0[1]]; q[2] = [xo, P2[1]]; const r = simp(q);
          if (ortho(r) && hits(r, rects, a, b) <= base && okEnd(r)){ p.splice(0, p.length, ...r); ch = true; break; } }
        if (nx != null && i === 0 && ax === 1 && A && Math.abs(P0[1] - A.y) < 1.5 && d3 > 0){   /* 위로 나갔다가 아래로 돌아오는 선: 박스 아래로 나감 */
          const q = p.map(x => x.slice()), yo = A.y + A.h + 8; q[0] = [P0[0], A.y + A.h]; q[1] = [P0[0], yo]; q[2] = [P2[0], yo]; const r = simp(q);
          if (ortho(r) && hits(r, rects, a, b) <= base && okEnd(r)){ p.splice(0, p.length, ...r); ch = true; break; } }
        if (nx == null || Math.abs(nx - P1[ax]) < .5) continue;
        if (i === 0) nx += (P3[ax] > P0[ax] ? 8 : -8) * (Math.abs(nx - P0[ax]) < 8 ? 1 : 0);   /* 박스 옆면에서 바로 꺾이지 않게 */
        if (i + 3 === p.length - 1 && ax === 0) nx = Math.min(nx, P3[0] - 5);   /* 왼쪽으로 들어가는 끝 조각은 유지 */
        const q = p.map(x => x.slice()); q[i + 1][ax] = nx; q[i + 2][ax] = nx; const r = simp(q);
        if (ortho(r) && hits(r, rects, a, b) <= base && okEnd(r)){ p.splice(0, p.length, ...r); ch = true; break; } }
      if (ch) break; }
    if (!ch) break; }
  return p;
}
function sepRoutes(EL, M, rects, by){
  /* 모든 경로를 먼저 구한 뒤, 같은 선 위(7px 안)에서 겹치는 서로 다른 화살표 조각을 각자 통로로 벌림. 박스 옆면에 붙은 조각은 그 옆면 안에서만, 벌린 뒤 박스를 지나게 되면 되돌림 */
  const G = EL.map(([a, b, t, lab, ex, eoff], i) => { const A = M.pos[a], B = M.pos[b]; if (!A || !B) return null; return M.agentView ? agRoute(M, by[a], by[b], A, B, i) : route(A, B, t, rects, a, b, eoff || 0); });
  if (M.agentView) return G;
  const SPc = 7; G.forEach(g => { if (g && g.pts) g.pts = simp(g.pts); });
  const SEP = np => { for (let pass = 0; pass < np; pass++){   /* 분리 단계 (U자 정리 뒤에 한 번 더) */
    const segs = [];
    G.forEach((g, k) => { if (!g) return; const p = g.pts, A = M.pos[EL[k][0]], B = M.pos[EL[k][1]];
      for (let i = 0; i < p.length - 1; i++){ const h = Math.abs(p[i][1] - p[i + 1][1]) < .6, v = Math.abs(p[i][0] - p[i + 1][0]) < .6; if (h === v) continue;
        let mn = 6, mx = (h ? M.W : M.W) - 6; if (h){ mn = 6; mx = M.H - 6; } const lim = (R, H) => { if (H){ mn = Math.max(mn, R.y + 5); mx = Math.min(mx, R.y + R.h - 5); } else { mn = Math.max(mn, R.x + 6); mx = Math.min(mx, R.x + R.w - 6); } };
        if (i === 0) lim(A, h); if (i === p.length - 2) lim(B, h);
        const nL = p.length; if (!h && i === nL - 3 && Math.abs(p[nL - 1][1] - p[nL - 2][1]) < .6){ if (p[nL - 1][0] > p[nL - 2][0]) mx = Math.min(mx, B.x - 3); else mn = Math.max(mn, B.x + B.w + 3); }   /* 왼쪽으로 들어가기 직전 세로 조각은 박스 왼쪽 밖 */
        if (!h && i === 1 && Math.abs(p[0][1] - p[1][1]) < .6){ if (p[1][0] > p[0][0]) mn = Math.max(mn, A.x + A.w + 3); else mx = Math.min(mx, A.x - 3); }   /* 오른쪽으로 나온 직후 세로 조각은 박스 오른쪽 밖 */
        segs.push({k, i, h, c:h ? p[i][1] : p[i][0], lo:Math.min(h ? p[i][0] : p[i][1], h ? p[i + 1][0] : p[i + 1][1]), hi:Math.max(h ? p[i][0] : p[i][1], h ? p[i + 1][0] : p[i + 1][1]), mn, mx}); } });
    let moved = 0;
    [true, false].forEach(H => {
      const L = segs.filter(x => x.h === H).sort((x, y) => x.c - y.c || x.lo - y.lo), done = new Set();
      for (let x = 0; x < L.length; x++){ if (done.has(x)) continue; const grp = [x];
        for (let y = x + 1; y < L.length && L[y].c - L[grp[grp.length - 1]].c < SPc - .5; y++){
          if (grp.some(gi => L[gi].k !== L[y].k && Math.min(L[gi].hi, L[y].hi) - Math.max(L[gi].lo, L[y].lo) > 2 && Math.abs(L[gi].c - L[y].c) < SPc - .5)) grp.push(y); }
        if (new Set(grp.map(gi => L[gi].k)).size < 2) continue;
        grp.forEach(gi => done.add(gi)); const base = grp.reduce((s, gi) => s + L[gi].c, 0) / grp.length, n = grp.length, ord = grp.slice().sort((u, v) => L[u].lo - L[v].lo || L[u].k - L[v].k), ax = H ? 1 : 0;
        if (BUNDLE()){   /* 선 합치기(세로·가로): 같은 종류는 한 줄기(가운데), 점선은 그 옆 줄기 — 박스에 붙은 첫·끝 조각은 제외 */
          const dashK = k => /^(r|l|o)$/.test(EL[k][2]);
          ord.forEach(gi => { const sg = L[gi]; if (sg.i === 0 || sg.i === G[sg.k].pts.length - 2) return; const g = G[sg.k], p = g.pts, nc = Math.max(sg.mn, Math.min(sg.mx, Math.round(base) + (dashK(sg.k) ? SPc : 0)));
            const keep = p.map(q => q.slice()), h0 = hits(p, rects, EL[sg.k][0], EL[sg.k][1]); p[sg.i][ax] = nc; p[sg.i + 1][ax] = nc; if (hits(p, rects, EL[sg.k][0], EL[sg.k][1]) > h0) g.pts = keep; });
          continue; }
        /* 가운데·한쪽(-)·다른 쪽(+) 세 가지로 벌려 보고, 박스를 지나게 되는 조각이 가장 적은 쪽을 고름 */
        const plans = [j => base + (j - (n - 1) / 2) * SPc, j => base - j * SPc, j => base + j * SPc].map(fp => { let bad = 0; const pos = ord.map((gi, j) => { const sg = L[gi], nc = Math.max(sg.mn, Math.min(sg.mx, fp(j)));
            const p = G[sg.k].pts, q = p.map(x => x.slice()); q[sg.i][ax] = nc; q[sg.i + 1][ax] = nc; if (hits(q, rects, EL[sg.k][0], EL[sg.k][1]) > hits(p, rects, EL[sg.k][0], EL[sg.k][1])) bad++; return nc; }); return {pos, bad}; });
        const best = plans.reduce((x, y) => y.bad < x.bad ? y : x);
        ord.forEach((gi, j) => { const sg = L[gi], g = G[sg.k], p = g.pts, nc = best.pos[j];
          if (Math.abs(nc - sg.c) < .3) return; const keep = p.map(q => q.slice()), h0 = hits(p, rects, EL[sg.k][0], EL[sg.k][1]);
          p[sg.i][ax] = nc; p[sg.i + 1][ax] = nc;
          if (hits(p, rects, EL[sg.k][0], EL[sg.k][1]) > h0){ g.pts = keep; return; } moved++; });
      }
    });
    if (!moved) break;
  } };
  SEP(6);
  G.forEach((g, k) => { if (g && g.pts){ dedetour(g.pts, M.pos[EL[k][0]], M.pos[EL[k][1]], rects, EL[k][0], EL[k][1]); } });
  SEP(3);   /* U자 정리로 다시 겹친 조각을 벌림 */
  G.forEach(g => { if (g && g.pts){ g.pts = simp(g.pts); const L = g.pts[g.pts.length - 1]; g.ex = L[0]; g.ey = L[1]; } });   /* 마지막에 되돌아가는 꺾임·잔꺾임 정리 */
  return G;
}
/* ===== v33 Agent 이름을 바꾸면 박스 이름(게이트 "… → ○○ Agent 호출" 등) 속 이름도 함께 — a) 지도·b) 상세 페이지·c) 흐름 따라가기 모두 같은 이름 ===== */
{ const np0 = nmProse; nmProse = function(old, nv, ag){ np0(old, nv, ag); if (!ag) return;
    Object.keys(D.TB || {}).forEach(k => { const t = D.TB[k]; if (t && typeof t.lb === 'string' && t.lb.indexOf(old) >= 0) t.lb = nmText(t.lb, old, nv, true); });
    [4, 5, 6].forEach(lv => ['ns'].forEach(sc => { const V = D.views[lv] && D.views[lv][sc]; (V ? V.nodes : []).forEach(n => { if (typeof n.lb === 'string' && n.lb.indexOf(old) >= 0) n.lb = nmText(n.lb, old, nv, true); }); }));
  }; }
/* ===== v30 흐름 따라가기 시작 창: [처음부터] / [원하는 단계부터 → 박스 누르기] ===== */
let TPASS = false, TPICK = false;
function tourStartDlg(){
  let d = document.getElementById('tourStartDlg');
  if (!d){ d = document.createElement('div'); d.id = 'tourStartDlg'; d.setAttribute('role', 'dialog');
    d.innerHTML = '<div class="tsd-box"><p>어떤 부분부터 흐름 따라가기를 시작할까요?</p><div class="tsd-btns"><button type="button" data-tsd="first">처음부터</button><button type="button" data-tsd="pick">원하는 단계부터</button></div><button type="button" class="tsd-x" data-tsd="close" aria-label="닫기">×</button></div>';
    document.body.appendChild(d);
    d.addEventListener('click', e => { const b = e.target.closest('[data-tsd]'); if (!b && e.target !== d) return; const k = b ? b.dataset.tsd : 'close'; d.hidden = true;
      if (k === 'first'){ TPASS = true; document.getElementById('btnTour').click(); }
      else if (k === 'pick') tourPickOn(); }); }
  d.hidden = false; const f = d.querySelector('[data-tsd="first"]'); if (f) f.focus();
}
function tourPickOn(){
  TPICK = true; let t = document.getElementById('tourPickTip');
  if (!t){ t = document.createElement('div'); t.id = 'tourPickTip'; t.innerHTML = '<span>흐름 따라가기를 시작하고 싶은 프로세스를 누르세요</span><button type="button">취소</button>'; document.body.appendChild(t);
    t.querySelector('button').addEventListener('click', tourPickOff); }
  t.hidden = false; document.body.classList.add('tourpick');
}
function tourPickOff(){ TPICK = false; const t = document.getElementById('tourPickTip'); if (t) t.hidden = true; document.body.classList.remove('tourpick'); }
function tourStepOf(id){   /* 누른 박스가 들어 있는 걸음 — Lv.5·Lv.4 묶음이면 그 묶음의 첫 걸음, 흐름에 없는 박스면 그 다음 걸음 */
  const L = tourList(); if (!L.length) return null;
  const has = x => (x.stp.ids || []).some(i => i === id || String(i).startsWith(id + '-'));
  let it = L.find(has); if (it) return it;
  const key = s => String(s).split('-').map(n => ('000' + n).slice(-3)).join('-'), kid = key(id);
  return L.find(x => (x.stp.ids || []).some(i => key(i) > kid)) || L[0];
}
document.addEventListener('click', e => {
  const bt = e.target.closest && e.target.closest('#btnTour');
  if (bt){ if (TPASS){ TPASS = false; return; } if (TOUR && TOUR.on) return; e.stopImmediatePropagation(); e.preventDefault(); tourStartDlg(); return; }
  if (TPICK){ const n = e.target.closest && e.target.closest('#board .nd'); if (!n) return; e.stopImmediatePropagation(); e.preventDefault();
    const it = tourStepOf(n.dataset.id); tourPickOff(); if (it) tourStart(it.st, it.bi, it.si); }
}, true);
document.addEventListener('keydown', e => { if (e.key === 'Escape'){ if (TPICK) tourPickOff(); const d = document.getElementById('tourStartDlg'); if (d && !d.hidden) d.hidden = true; } }, true);
/* 흐름 따라가기: 따라가는 박스가 항상 보이게 (v25 시험) */
tourFocus = function(rp, rc){
  const all = rp.concat(rc); if (!all.length) return; const wr = $('#wrap'), z = S.zoom || 1;
  const bb = rs => { const x0 = Math.min.apply(null, rs.map(p => p.x)), y0 = Math.min.apply(null, rs.map(p => p.y)), x1 = Math.max.apply(null, rs.map(p => p.x + p.w)), y1 = Math.max.apply(null, rs.map(p => p.y + p.h)); return {x:x0, y:y0, w:x1 - x0, h:y1 - y0}; };
  const cap = $('#tourcap'), hd = $('#stagehead'), lb = $('#labels');
  const area = () => { const wb = wr.getBoundingClientRect(), capTop = cap && !cap.hidden ? cap.getBoundingClientRect().top : innerHeight;
    const top = Math.max(wb.top, 0, hd ? hd.getBoundingClientRect().bottom : wb.top) + 8, bot = Math.min(wb.bottom, innerHeight, capTop) - 12;
    const left = Math.max(wb.left, lb ? lb.getBoundingClientRect().right : wb.left) + 8, right = Math.min(wb.right, innerWidth) - 8;
    return {top, bot, left, right}; };
  let A0 = area(), B = bb(all);
  if (B.w * z > (A0.right - A0.left) * 0.9 || B.h * z > Math.max(120, A0.bot - A0.top) * 0.9) B = bb(rc.length ? rc : all);   /* 앞·지금 단계가 함께 안 들어가면 지금 단계만 */
  let fx = $('#tourfocus'); if (!fx){ fx = document.createElement('div'); fx.id = 'tourfocus'; } board.appendChild(fx);
  fx.style.left = B.x + 'px'; fx.style.top = B.y + 'px'; fx.style.width = Math.max(4, B.w) + 'px'; fx.style.height = Math.max(4, B.h) + 'px';
  const wt = wr.getBoundingClientRect().top; if (Math.abs(wt) > 1) window.scrollTo({top: window.scrollY + wt, behavior: 'auto'});   /* 지도 상자를 화면 맨 위에 */
  requestAnimationFrame(() => { const A = area(), fr = fx.getBoundingClientRect();
    const cy = A.bot > A.top + 40 ? (A.top + A.bot) / 2 : A.top + 40, cx = (A.left + A.right) / 2;
    const dy = fr.height > A.bot - A.top ? fr.top - A.top : (fr.top + fr.height / 2) - cy, dx = fr.width > A.right - A.left ? fr.left - A.left : (fr.left + fr.width / 2) - cx;
    wr.scrollBy({top: dy, left: dx, behavior: 'smooth'}); });
};
/* 레인: 엑셀 조직명에 붙어 있던 메모(괄호 안 '확인 필요' 등)는 이름에서 빼고 작은 표시로 */
function laneMemo(){ labels.querySelectorAll('.lc.lane').forEach(lc => { const k = (lc.className.match(/(?:^|\s)ln-(\S+)/) || [])[1], L = D.lanes.find(x => x.k === k), lt = lc.querySelector('.lt');
  if (!L || !L.memo || !lt) return; const off = TXT['LM|' + k] || NM['ln|' + k]; let m = lt.querySelector('.lmemo');   /* 이름을 고쳤거나 지운 레인은 표시 없음 (문구 편집 중에는 '지움' + 되살리기) */
  if (off && !S.edit){ if (m) m.remove(); return; }
  if (!m){ m = document.createElement('small'); m.className = 'lmemo'; lt.appendChild(m); }
  m.classList.toggle('off', !!off); m.title = '엑셀 원문 메모: ' + L.memo;
  m.innerHTML = off ? '확인 필요 (지움) <button class="lmx" data-lm="' + k + '" data-on="1" title="표시 되살리기">되살리기</button>' : '확인 필요' + (S.edit ? ' <button class="lmx" data-lm="' + k + '" title="확인 필요 표시 지우기">×</button>' : ''); }); }
labels.addEventListener('click', e => { const bt = e.target.closest('.lmx'); if (!bt) return; e.stopPropagation(); e.preventDefault(); const k = bt.dataset.lm, on = !!bt.dataset.on;
  if (on) delete TXT['LM|' + k]; else TXT['LM|' + k] = '1'; DIRTY = true; laneMemo(); toast(on ? '확인 필요 표시를 다시 보였습니다' : '확인 필요 표시를 지웠습니다 — 편집본 저장에 남습니다 (문구 편집 중 되살리기)'); }, true);
{ const be = document.getElementById('btnEdit'); if (be) be.addEventListener('click', () => setTimeout(() => { try { laneMemo(); } catch(_){} }, 60)); }
{ const bt = document.getElementById('btnTour'); if (bt && !document.getElementById('btnBundle')){ const b = document.createElement('button'); b.id = 'btnBundle'; b.className = bt.className; b.type = 'button';
    const lab = () => { b.textContent = BUNDLE() ? '┃ 선 합침 (켜짐)' : '┇ 선 합치기'; b.classList.toggle('on', BUNDLE()); };
    b.addEventListener('click', () => { S.bundle = !BUNDLE(); lab(); render(false); toast(BUNDLE() ? '같은 종류의 세로·가로선을 한 줄기로 합쳐 표시합니다 · 박스에 마우스를 올리면 해당 박스의 화살표만 강조' : '화살표별 개별 선으로 표시합니다'); });
    lab(); bt.parentNode.insertBefore(b, bt.nextSibling); } }
{ const RL0 = renderLabels; renderLabels = function(){ const r = RL0.apply(this, arguments); try { laneSplit(labels); laneMemo(); } catch(e){} return r; }; }
/* 레인 이름 고치기: ✎ 문구 편집 중 레인 이름을 누르면 그 자리에서 고침 → 이름 바꾸기(NM 'ln')로 상세 창·흐름 따라가기·Agent 페이지 문장까지 반영, 편집본 저장에 남음 */
labels.addEventListener('click', e => { if (!S.edit) return; const b = e.target.closest('.lc.lane .lt > b'); if (!b || b.isContentEditable) return;
  const lc = b.closest('.lc'), k = (lc.className.match(/(?:^|\s)ln-(\S+)/) || [])[1], L = D.lanes.find(x => x.k === k); if (!L) return;
  e.stopPropagation(); e.preventDefault(); b.textContent = L.name; b.contentEditable = 'true'; b.focus(); try { getSelection().selectAllChildren(b); } catch(_){}
  let fin = false; const done = ok => { if (fin) return; fin = true; b.contentEditable = 'false'; const v = b.textContent.replace(/\s+/g, ' ').trim(); if (ok && v && v !== L.name) nmRename('ln|' + k, v); else render(false); };
  b.onkeydown = ev => { ev.stopPropagation(); if (ev.key === 'Enter'){ ev.preventDefault(); done(true); } else if (ev.key === 'Escape'){ ev.preventDefault(); done(false); } };
  b.onblur = () => done(true); }, true);
/* 페이지 먼저 스크롤: 지도가 화면 맨 위에 닿을 때까지는 페이지가 올라가고, 그다음부터 지도 안이 스크롤됨 */
let WST = wrap.scrollTop, USR = 0;   /* USR: 사람이 스크롤바·키보드로 스크롤하는 동안만 (프로그램 스크롤은 제외) */
window.addEventListener('keydown', e => { if (/^(PageDown|PageUp|ArrowDown|ArrowUp|End|Home| )$/.test(e.key) || e.code === 'Space') USR = Date.now() + 1000; }, true);
wrap.addEventListener('pointerdown', e => { if (e.offsetX >= wrap.clientWidth - 1 || e.offsetY >= wrap.clientHeight - 1) USR = Date.now() + 600000; });
window.addEventListener('pointerup', () => { if (USR > Date.now() + 2000) USR = Date.now() + 300; }, true);
wrap.addEventListener('scroll', () => { const top = wrap.getBoundingClientRect().top, d = wrap.scrollTop - WST;   /* 스크롤바·키보드로 내려도 위쪽 탭이 먼저 올라감 */
  if (d > 0 && top > 1 && Date.now() < USR && !document.body.classList.contains('present')){ const m = Math.min(d, top); window.scrollBy(0, m); wrap.scrollTop -= m; } WST = wrap.scrollTop; }, {passive:true});
wrap.addEventListener('wheel', e => { if (e.ctrlKey || document.body.classList.contains('present')) return; const top = wrap.getBoundingClientRect().top;
  if (e.deltaY > 0 && top > 1){ e.preventDefault(); window.scrollBy(0, Math.min(e.deltaY, top)); } }, {passive:false});

function init(){
  nmApplyAll(); bdApply(); pbApply(); try { liveSync(); } catch(e){} initSegs(); initStatic(); initTitle(); renderSteps(); legend(); bindNav(); bind(); bindFlowEdit(); bindEdgeFocus(); bindView(); bindPath(); bindTour(); render(false); window.addEventListener('resize', fitWrap);
  if (window.claude && typeof window.claude.use === 'function'){
    window.claude.use('artifact').then(a => { ART = a; if (a) $('#btnPub').hidden = false; }).catch(() => {});
    DLP = window.claude.use('downloads').catch(() => null);
  }
  window.__PM3__ = {effEdges:k => effEdges(k), TXT:() => TXT, dirty:() => DIRTY, set:(scr, lv, st) => set(scr, lv, st, false), M:() => S.M, S, AF, NAV, navGo, ED:() => ED, showNode:id => showNode(id), AGX:() => AGX, setDirty:() => { DIRTY = true; }, agRerender:() => { try { if (!$('#apage').hidden) agRerender(); } catch(e){} }};
}
init();
})();
/* ===== v38 화면 기능 (실린더 v3.6.2 · S01 v3.4 일반화) — 엔진 뒤에 붙음, window.__PM3__ 사용
   ① Agent 흐름 따라가기 (전체 단계를 펼친 채 그 Agent의 단계 묶음을 하나씩, 문장 설명)  ② 맵에서 맡는 업무 보기 (Agent 상세 페이지)
   ③ 상세 창 '들어오는 업무 / 이어지는 업무'  ④ 병행 단계 안내  ⑤ As-Is 대비 변경 (D.trace)  ⑥ 데이터·시스템 항목 상세  ⑦ 하단 단계표 가독성 ===== */
(function(){
const D = window.__PMD__, P = window.__PM3__; if (!D || !P) return;
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const css = document.createElement('style'); css.textContent = `
#tourcap.tc{width:min(1080px,calc(100vw - 36px))!important;max-width:1080px!important}
#tourcap .tc-steps{grid-template-columns:repeat(var(--n),minmax(116px,1fr))!important;overflow-x:auto!important;overflow-y:hidden!important;scrollbar-width:thin;padding-bottom:8px!important}
#tourcap .tc-steps li span{white-space:normal!important;word-break:keep-all!important}
#cmw{overflow-x:auto;max-width:100%}#apage .af .afctl{flex-wrap:wrap;max-width:100%;row-gap:6px}#apage .af .afctl .seg{flex-wrap:wrap;max-width:100%}
#agt38{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(14px + env(safe-area-inset-bottom,0px));z-index:58;width:min(980px,calc(100vw - 32px));background:var(--surface);border-radius:16px;box-shadow:var(--sh-xl);padding:14px 18px;font-size:12.5px;line-height:1.6;border-top:4px solid var(--red)}
#agt38 .h{display:flex;align-items:center;gap:8px;margin-bottom:6px;flex-wrap:wrap}#agt38 .h b{font-size:14px;color:var(--ink-strong)}#agt38 .h .sp{flex:1}
#agt38 .pill{display:inline-flex;align-items:center;min-width:22px;height:22px;padding:0 8px;border-radius:999px;background:var(--ink-strong);color:#fff;font-size:11px;font-weight:800}
#agt38 .steps{display:flex;gap:4px;overflow-x:auto;padding:2px 0 8px;scrollbar-width:thin}#agt38 .steps button{flex:0 0 auto;padding:2px 9px;font-size:11px}
#agt38 .steps button[aria-pressed="true"]{background:var(--red);border-color:var(--red);color:#fff}
#agt38 .sent{margin:2px 0 6px;color:var(--ink)}#agt38 .par{margin:4px 0;color:var(--ink2);font-size:11.5px}
#agt38 details{margin-top:2px}#agt38 ul{margin:4px 0 0;padding-left:18px;max-height:150px;overflow:auto}#agt38 li a{cursor:pointer;text-decoration:underline dotted}
#agtmenu38{position:fixed;z-index:59;background:var(--surface);border-radius:14px;box-shadow:var(--sh-xl);padding:8px;width:340px;max-height:70vh;overflow:auto}
#agtmenu38 button{display:grid;grid-template-columns:24px 1fr auto;gap:8px;align-items:center;width:100%;text-align:left;border:0;box-shadow:none;border-radius:9px;padding:8px 7px;background:transparent}
#agtmenu38 button:hover{background:var(--cream)}#agtmenu38 i{width:22px;height:22px;border-radius:50%;background:var(--red);color:#fff;display:flex;align-items:center;justify-content:center;font-style:normal;font-size:11px;font-weight:800}#agtmenu38 small{color:var(--ink3);font-size:10px}
#board .nd.agt38-on{outline:3px solid var(--red);outline-offset:2px;opacity:1!important}#board.agt38 .nd:not(.agt38-on){opacity:.32}
#onmap38{position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:58;background:var(--ink-strong);color:#fff;border-radius:999px;padding:7px 10px 7px 16px;font-size:12px;display:flex;gap:8px;align-items:center;box-shadow:var(--sh-xl)}
#onmap38 button{height:26px;padding:0 11px;border-radius:999px;font-size:11.5px}
#panel .v38-mode{display:inline-block;margin:2px 0 8px;padding:3px 10px;border-radius:999px;background:var(--cream);font-size:11.5px;color:var(--ink2)}#panel .v38-mode b{color:var(--ink-strong)}
#panel .v38-flow{display:grid;gap:8px;margin:4px 0 12px}#panel .v38-flow .pf{border:1px solid var(--line);border-radius:12px;padding:8px 12px;background:var(--surface)}
#panel .v38-flow .pf.in{border-left:3px solid var(--ink2)}#panel .v38-flow .pf.out{border-left:3px solid var(--red)}#panel .v38-flow h4{margin:0 0 4px;font-size:11.5px;color:var(--ink2)}
#panel .v38-flow a{cursor:pointer;text-decoration:underline dotted}#panel .v38-flow li{margin:1px 0}#panel .v38-flow ul{margin:0;padding-left:16px}
#panel .v38-delta{border:1px solid var(--line-strong);border-left:4px solid var(--ink2);border-radius:11px;padding:10px 12px;margin:10px 0;background:var(--bg)}#panel .v38-delta h4{margin:0 0 4px}#panel .v38-delta p{margin:2px 0}#panel .v38-delta ul{margin:4px 0 0;padding-left:18px}
#iod38{position:fixed;z-index:60;right:24px;top:90px;width:360px;max-height:70vh;overflow:auto;background:var(--surface);border-radius:14px;box-shadow:var(--sh-xl);padding:14px 16px;font-size:12px}#iod38 h4{margin:0 0 6px;font-size:13px}#iod38 .x{float:right;padding:0 8px}#iod38 ul{padding-left:18px;margin:4px 0}
#apage tr[data-v38io]{cursor:pointer}#apage tr[data-v38io]:hover td{background:var(--cream)}
#tourcap .v38-par{margin:6px 0 0;font-size:11.5px;color:var(--ink2)}#tourcap .v38-par button,#agt38 .par button{height:22px;padding:0 8px;font-size:11px;margin-left:4px}`;
document.head.appendChild(css);
const TB = D.TB || {}, TR = D.trace || {}, A6 = D.A6 || {}, A5 = D.A5 || {};
const nm = id => (TB[id] && TB[id].lb) || (A6[id] && A6[id].n) || (A5[id] && A5[id].n) || ((P.M() && P.M().nodes || []).find(n => n.id === id) || {}).lb || id;
const stName = n => ((D.stages || []).find(s => s.n === n) || {}).name || '';
const allSt = () => (D.stages || []).map(s => s.n);
/* ④ 병행 단계: 한 단계의 한 업무에서 서로 다른 여러 단계의 업무가 동시에 시작되면 그 단계들은 병행 (예: [A]~[D] 트랙) */
const PAR = (() => { const g = []; const E = ((D.views[6] || {}).asis || {}).edges || [], st = {}; ((D.views[6] || {}).asis || {nodes:[]}).nodes.forEach(n => { st[n.id] = n.st; });
  const out = {}; E.forEach(e => { if (e[2] === 'r' || e[2] === 'l') return; (out[e[0]] = out[e[0]] || new Set()).add(st[e[1]]); });
  Object.keys(out).forEach(k => { const ss = [...out[k]].filter(x => x != null && x !== st[k]); if (ss.length >= 2){ const key = ss.sort((a, b) => a - b).join(','); if (!g.includes(key)) g.push(key); } });
  return g.map(k => k.split(',').map(Number)); })();
const parOf = n => (PAR.find(g => g.includes(n)) || []).filter(x => x !== n);
function parHTML(n, cls){ const o = parOf(n); if (!o.length) return ''; return '<p class="' + cls + '">↔ 이 단계와 동시에 진행: ' + o.map(x => esc(x + '단계 ' + stName(x).replace(/^\d+\.\s*/, '').split('(')[0].trim()) + '<button type="button" data-v38go="' + x + '">이동</button>').join(' · ') + '</p>'; }
/* ⑤ As-Is 대비 변경 */
function deltaHTML(id){ const t = TR[id]; if (!t) return ''; let h = '<div class="v38-delta"><h4>As-Is 대비 변경</h4>';
  if (t.kind) h += '<p><b>' + esc(t.kind) + '</b>' + (t.from ? ' · As-Is 수행: ' + esc(t.from) : '') + (t.to ? ' → To-be 수행: ' + esc(t.to) : '') + '</p>';
  if (t.old && t.old !== t.cur) h += '<p>As-Is 업무명: ' + esc(t.old) + '</p>';
  if (t.src && t.src.length) h += '<p>이어받은 As-Is 업무</p><ul>' + t.src.map(x => '<li>' + esc(x[1]) + (x[2] ? ' — ' + esc(x[2]) : '') + '</li>').join('') + '</ul>';
  if (t.merged && t.merged.length) h += '<p>함께 통합한 As-Is 업무</p><ul>' + t.merged.map(x => '<li>' + esc(x[1]) + '</li>').join('') + '</ul>';
  if (t.why) h += '<p>' + esc(t.why) + '</p>';
  if (t.abs && t.abs.length) h += '<p>이 업무로 흡수된 As-Is 업무</p><ul>' + t.abs.map(x => '<li>' + esc(x[1]) + (x[2] ? ' — ' + esc(x[2]) : '') + '</li>').join('') + '</ul>';
  return h + '</div>'; }
/* ③ 들어오는 업무 / 이어지는 업무 (S01 '어디서 왔나/어디로 가나') */
function flowHTML(id){ const S = P.S, V = ((D.views[S.lv] || {})[S.scr] || {}); const E = V.edges || [];
  const ins = E.filter(e => e[1] === id && e[2] !== 'r' && e[2] !== 'l'), outs = E.filter(e => e[0] === id && e[2] !== 'r' && e[2] !== 'l'); if (!ins.length && !outs.length) return '';
  const li = (x, lab) => '<li><a data-v38n="' + esc(x) + '">' + esc(nm(x)) + '</a>' + (lab ? ' <small>(' + esc(lab) + ')</small>' : '') + '</li>';
  return '<div class="v38-flow">' + (ins.length ? '<div class="pf in"><h4>들어오는 업무 — 앞 단계에서</h4><ul>' + ins.map(e => li(e[0], e[3])).join('') + '</ul></div>' : '') + (outs.length ? '<div class="pf out"><h4>이어지는 업무 — 다음 단계로</h4><ul>' + outs.map(e => li(e[1], e[3])).join('') + '</ul></div>' : '') + '</div>'; }
let CUR = null;
const _show = P.showNode; P.showNode = id => { CUR = String(id); _show(id); };
document.addEventListener('click', e => { const nd = e.target.closest('#board .nd[data-id]'); if (nd) CUR = nd.dataset.id; }, true);
const pan = $('#panel');
if (pan) new MutationObserver(() => { if (pan.hidden || !CUR || pan.querySelector('.v38-flow, .v38-delta, .v38-mark')) return; const h3 = pan.querySelector('h3'); if (!h3) return;
  const box = document.createElement('div'); box.className = 'v38-mark'; const io = P.S.scr === 'ns' ? (D.optIO || {})[CUR] : null; box.innerHTML = (io && io.mode ? '<p class="v38-mode">실행 방식 <b>' + esc(io.mode) + '</b></p>' : '') + flowHTML(CUR) + (P.S.scr === 'ns' && P.S.lv === 6 ? deltaHTML(CUR) : ''); if (!box.innerHTML) return;
  h3.parentNode.insertBefore(box, h3.nextSibling.nextSibling || null); }).observe(pan, {childList:true, subtree:true, attributes:true, attributeFilter:['hidden']});
document.addEventListener('click', e => { const a = e.target.closest('#panel [data-v38n]'); if (a){ e.preventDefault(); P.showNode(a.dataset.v38n); }
  const g = e.target.closest('[data-v38go]'); if (g){ P.set(P.S.scr, P.S.lv, [+g.dataset.v38go]); } }, true);
/* ④ 흐름 따라가기 창: 병행 단계 안내 */
const tc = $('#tourcap'); if (tc) new MutationObserver(() => { if (tc.hidden || tc.querySelector('.v38-par')) return; const st = (P.S.stages && P.S.stages.size === 1) ? [...P.S.stages][0] : null; const sn = st || +((tc.querySelector('[data-st]') || {}).dataset || {}).st; if (!sn) return; const h = parHTML(+sn, 'v38-par'); if (!h) return; const t = tc.querySelector('.tc-steps'); if (t) t.insertAdjacentHTML('afterend', h); }).observe(tc, {childList:true, subtree:true, attributes:true, attributeFilter:['hidden']});
/* ⑥ 데이터·시스템 항목 상세 (Agent 상세 페이지 표의 행을 누르면) */
const ap = $('#apage');
if (ap) new MutationObserver(() => { if (ap.hidden) return; $$('#apm table.mx tbody tr').forEach(tr => { if (tr.dataset.v38io) return; const b0 = tr.querySelector('td b'); if (b0) tr.dataset.v38io = b0.textContent.trim(); });
  const hd = $('#apage .aph'); if (hd && !hd.querySelector('[data-v38map]')){ const b = document.createElement('button'); b.type = 'button'; b.className = 'apv'; b.dataset.v38map = '1'; b.textContent = '◉ 맵에서 담당 업무 보기'; const sv = hd.querySelector('.agx-save'); (sv || hd.lastChild).after(b); } }).observe(ap, {childList:true, subtree:true, attributes:true, attributeFilter:['hidden']});
document.addEventListener('click', e => { const tr = e.target.closest('#apage tr[data-v38io]'); if (!tr || e.target.closest('[contenteditable="true"], input, select, button')) return;
  const name = tr.dataset.v38io, uses = []; Object.values(D.subs).forEach(s => [...(s.d || []), ...(s.s || [])].forEach(x => { if (String(x[0]).indexOf(name) === 0) uses.push([s, x]); })); if (!uses.length) return;
  const it = uses[0][1], st = ({E:'기존', P:'준비중', N:'신규 설치 필요'})[it[2]] || '상태 확인 필요', tasks = [];
  uses.forEach(([s]) => (s.tasks || []).forEach(k => { const a = A6[k]; if (a && ((a.inp || '') + (a.sys || '')).indexOf(name.slice(0, 12)) >= 0 && tasks.indexOf(k) < 0) tasks.push(k); }));
  let el = $('#iod38'); if (!el){ el = document.createElement('div'); el.id = 'iod38'; document.body.appendChild(el); }
  el.innerHTML = '<button type="button" class="x">×</button><h4>' + esc(name) + '</h4><p>상태: <b>' + st + '</b>' + (it[3] ? ' · ' + esc(it[3]) : '') + '</p>' + (((D.when || {})[it[0]] || (D.whenHave || {})[it[0]]) ? '<p>연결 시점: ' + esc((D.when || {})[it[0]] || D.whenHave[it[0]]) + '</p>' : '') + ((D.sysinfo || {})[it[0]] ? '<p>주고받는 정보: ' + esc(D.sysinfo[it[0]]) + '</p>' : '')
    + '<p>쓰는 세부 Agent: ' + [...new Set(uses.map(u => u[0].name))].map(esc).join(', ') + '</p>' + (tasks.length ? '<p>원본 입력·시스템 열로 연결된 업무 ' + tasks.length + '개</p><ul>' + tasks.slice(0, 30).map(k => '<li>' + esc(nm(k)) + '</li>').join('') + '</ul>' : '<p class="none">원본 입력·시스템 열과 직접 연결된 업무는 없습니다. To-be 설계 가설 항목입니다.</p>');
  el.hidden = false; el.querySelector('.x').onclick = () => { el.hidden = true; }; }, true);
/* ① Agent 흐름 따라가기 · ② 맵에서 담당 업무 보기 */
const bands = (D.bands || []).filter(b => (b.subs || []).some(s => ((D.subs[s] || {}).tasks || []).length));
const bandTasks = b => b.subs.flatMap(s => (D.subs[s].tasks || []));
function plan(b){ const by = {}; b.subs.forEach(s => (D.subs[s].tasks || []).forEach(k => { const st = (TB[k] || {}).st; if (st) (by[st] = by[st] || []).push(k); })); return Object.keys(by).map(Number).sort((x, y) => x - y).map(st => ({st, ids:by[st]})); }
const laneName = k => ((D.lanes || []).find(l => l.k === k) || {}).name || '';
function sentence(b, step){ const note = (((D.story || {})[b.id] || {}).tourSt || {})[step.st]; if (note) return note;
  const bySub = {}; step.ids.forEach(k => { const s = TB[k].sub; (bySub[s] = bySub[s] || []).push(k); });
  const ks = Object.keys(bySub).sort((x, y) => bySub[y].length - bySub[x].length), top = ks.slice(0, 3);
  const parts = top.map(s => (D.subs[s] || {}).name + '가 「' + nm(bySub[s][0]) + '」' + (bySub[s].length > 1 ? ' 등 ' + bySub[s].length + '개 업무' : ''));
  const more = ks.length > 3 ? ' (그 밖에 세부 Agent ' + (ks.length - 3) + '개)' : '';
  const ids = new Set(step.ids), E = (D.views[6].ns.edges || []), hum = {};
  E.forEach(e => { if (ids.has(e[0]) && TB[e[1]] && TB[e[1]].t === 'N' && TB[e[1]].st === step.st){ const ln = ((P.M() && P.M().nodes || []).find(n => n.id === e[1]) || {}).ln; const l = laneName(ln) || ''; if (l) hum[l] = (hum[l] || 0) + 1; } });
  const hs = Object.keys(hum); return parts.join(', ') + '를 맡습니다' + more + '.' + (hs.length ? ' Agent 결과는 ' + hs.map(x => x + '(' + hum[x] + '건)').join(', ') + '가 확인·결정합니다.' : ''); }
let T = null;
function clearHL(){ $$('#board .nd.agt38-on').forEach(n => n.classList.remove('agt38-on')); const bd = $('#board'); if (bd) bd.classList.remove('agt38'); }
function paint(ids, scroll){ clearHL(); const bd = $('#board'); if (bd) bd.classList.add('agt38'); ids.forEach(id => $$('#board .nd[data-id="' + id + '"]').forEach(n => n.classList.add('agt38-on'))); const f = $('#board .nd.agt38-on'); if (f && scroll) f.scrollIntoView({block:'center', inline:'center', behavior:'smooth'}); }
function go(i){ if (!T) return; T.i = Math.max(0, Math.min(T.plan.length - 1, i)); const all = allSt(); if (P.S.scr !== 'ns' || P.S.lv !== 6 || P.S.stages.size !== all.length) P.set('ns', 6, all);
  setTimeout(() => paint(T.plan[T.i].ids, true), 350); render(); }
function render(){ if (!T) return; let el = $('#agt38'); if (!el){ el = document.createElement('div'); el.id = 'agt38'; document.body.appendChild(el); }
  const b = T.b, step = T.plan[T.i];
  el.innerHTML = '<div class="h"><span class="pill">' + (T.i + 1) + ' / ' + T.plan.length + '</span><b>' + esc(b.name) + '</b><span>· ' + step.st + '단계 ' + esc(stName(step.st).replace(/^\d+\.\s*/, '')) + '</span><span class="sp"></span><button type="button" data-a="p"' + (T.i ? '' : ' disabled') + '>‹ 이전</button><button type="button" data-a="n"' + (T.i < T.plan.length - 1 ? '' : ' disabled') + '>다음 ›</button><button type="button" data-a="page">상세 페이지</button><button type="button" data-a="x">종료 ×</button></div>'
    + '<div class="steps">' + T.plan.map((p, j) => '<button type="button" data-j="' + j + '" aria-pressed="' + (j === T.i) + '">' + p.st + '단계</button>').join('') + '</div>'
    + '<p class="sent">' + esc(sentence(b, step)) + '</p>' + parHTML(step.st, 'par')
    + '<details><summary>이 단계의 담당 업무 ' + step.ids.length + '개</summary><ul>' + step.ids.map(k => '<li><a data-id="' + k + '">' + esc(nm(k)) + '</a> <small>' + esc((D.subs[TB[k].sub] || {}).name || '') + '</small></li>').join('') + '</ul></details>';
  el.hidden = false; }
function start(bid, at){ const b = bands.find(x => x.id === bid); if (!b) return; stopMap(); T = {b, plan:plan(b), i:0}; if (!T.plan.length) return; go(at || 0); }
function stop(){ T = null; clearHL(); const el = $('#agt38'); if (el) el.hidden = true; }
let MAPB = null;
function showOnMap(bid){ const b = bands.find(x => x.id === bid); if (!b) return; stop(); MAPB = b; const ap0 = $('#apage'); if (ap0 && !ap0.hidden){ const x = ap0.querySelector('.px, [aria-label="닫기"]'); if (x) x.click(); else ap0.hidden = true; }
  P.set('ns', 6, allSt()); const ids = bandTasks(b); setTimeout(() => paint(ids, true), 400);
  let el = $('#onmap38'); if (!el){ el = document.createElement('div'); el.id = 'onmap38'; document.body.appendChild(el); }
  el.innerHTML = '<span>◉ ' + esc(b.name) + ' 담당 업무 ' + ids.length + '개 · ' + plan(b).length + '개 단계</span><button type="button" data-om="tour">▶ 단계별로 따라가기</button><button type="button" data-om="x">× 해제</button>'; el.hidden = false; }
function stopMap(){ MAPB = null; clearHL(); const el = $('#onmap38'); if (el) el.hidden = true; }
document.addEventListener('click', e => {
  const a = e.target.closest('#agt38 [data-a]'); if (a){ const v = a.dataset.a; if (v === 'p') go(T.i - 1); else if (v === 'n') go(T.i + 1); else if (v === 'page'){ const id = T.b.id; stop(); if (P.navGo) try { P.navGo({t:'page', id}); } catch(_){} const btn = $('#btnPage'); if (btn) btn.click(); setTimeout(() => { const pb = $('#apage .apn[data-page="' + id + '"]'); if (pb) pb.click(); }, 300); } else stop(); return; }
  const j = e.target.closest('#agt38 [data-j]'); if (j){ go(+j.dataset.j); return; }
  const l = e.target.closest('#agt38 a[data-id]'); if (l){ P.showNode(l.dataset.id); return; }
  const om = e.target.closest('#onmap38 [data-om]'); if (om){ if (om.dataset.om === 'tour' && MAPB) start(MAPB.id); else stopMap(); return; }
  const mp = e.target.closest('#apage [data-v38map]'); if (mp){ const on = $('#apage .apn.on'); if (on) showOnMap(on.dataset.page); return; }
  const m = e.target.closest('#agtmenu38 button[data-b]'); if (m){ $('#agtmenu38').hidden = true; start(m.dataset.b); return; }
  if (e.target.closest('#btnAgt38')){ let mn = $('#agtmenu38'); if (!mn){ mn = document.createElement('div'); mn.id = 'agtmenu38'; document.body.appendChild(mn); }
    mn.innerHTML = bands.map((b, i) => '<button type="button" data-b="' + b.id + '"><i>' + (i + 1) + '</i><b>' + esc(b.name) + '</b><small>' + plan(b).length + '개 단계</small></button>').join('');
    const r = e.target.closest('#btnAgt38').getBoundingClientRect(); mn.style.left = Math.min(r.left, innerWidth - 360) + 'px'; mn.style.top = (r.bottom + 6) + 'px'; mn.hidden = false; return; }
  const mn = $('#agtmenu38'); if (mn && !mn.hidden && !e.target.closest('#agtmenu38')) mn.hidden = true;
}, true);
document.addEventListener('keydown', e => { if (!T || e.target.closest('[contenteditable="true"],input,textarea,select')) return; if (e.key === 'Escape') stop(); else if (e.key === 'ArrowRight'){ go(T.i + 1); e.preventDefault(); e.stopPropagation(); } else if (e.key === 'ArrowLeft'){ go(T.i - 1); e.preventDefault(); e.stopPropagation(); } }, true);
function addBtn(){ const c = $('#controls'); if (!c || $('#btnAgt38')) return; const b = document.createElement('button'); b.type = 'button'; b.id = 'btnAgt38'; b.textContent = '▶ Agent 흐름 따라가기'; const tour = $('#btnTour'); if (tour) tour.after(b); else c.appendChild(b); }
addBtn(); new MutationObserver(addBtn).observe(document.body, {childList:true});
window.__PM38__ = {startAgent:start, showOnMap, parOf, PAR};
})();

/* ⑧ 상세 창 받는 것·만드는 것·쓰는 시스템·자료 형태 편집 (문구 편집 중) — 항목 × 삭제 · ＋ 추가(후보 목록·검색·직접 입력)
   저장: TXT['IO|화면|레벨|ID'] = {inp, out, sys, fmt} (편집본 저장에 포함) · 수행 Agent 표에 없는 항목을 추가하면 표에도 넣음 (삭제는 이 박스만) */
(function(){
const D = window.__PMD__, P = window.__PM3__; if (!D || !P || !P.TXT) return;
const $ = s => document.querySelector(s), esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const A6 = D.A6 || {}, TB = D.TB || {};
const css = document.createElement('style'); css.textContent = `
#panel.pe-on .pwhat .io-c li,#panel.pe-on .pwhat .io-s em{position:relative;outline:1.5px dashed color-mix(in srgb,var(--ink3) 60%,transparent);outline-offset:1px}
#panel .v38t{outline:none}#panel .v38x{display:none;position:absolute;top:-7px;right:-7px;width:16px;height:16px;padding:0;border-radius:50%;font-size:10px;line-height:14px;background:var(--ink-strong);color:#fff;border:0;cursor:pointer}
#panel.pe-on .io-c li:hover .v38x,#panel.pe-on .io-s em:hover .v38x{display:block}
#panel .v38add{height:22px;padding:0 9px;margin:4px 4px 0 0;border:1px dashed var(--ink3);border-radius:999px;background:transparent;font-size:11px;color:var(--ink2);cursor:pointer}
#iop38{position:fixed;z-index:70;width:330px;max-height:360px;overflow:auto;background:var(--surface);border-radius:12px;box-shadow:var(--sh-xl);padding:8px;font-size:12px}
#iop38 input{width:100%;box-sizing:border-box;margin-bottom:6px;padding:5px 8px;border:1px solid var(--line-strong);border-radius:8px}
#iop38 h6{margin:6px 4px 2px;font-size:10.5px;color:var(--ink3)}#iop38 button{display:block;width:100%;text-align:left;border:0;box-shadow:none;background:transparent;padding:5px 8px;border-radius:7px;font-size:12px}
#iop38 button:hover{background:var(--cream)}#iop38 .own{color:var(--ink2);font-style:italic}`;
document.head.appendChild(css);
const lines = v => String(v || '').split(/\n/).map(x => x.replace(/^\s*[-•·]\s*/, '').trim()).filter(Boolean);
const cur = () => { const p = $('#panel'); return p && p._pe ? p._pe.id : null; };
const key = id => 'IO|' + P.S.scr + '|' + P.S.lv + '|' + id;
function rows(id){ const tb = TB[id] || {}; return ((tb.ref && tb.ref.length) ? tb.ref : [id]).filter(x => A6[x]); }
function fromRows(id, f){ const io = (D.optIO || {})[id] || {}; return [...new Set([...lines(io[f]), ...rows(id).flatMap(r => lines(A6[r][f]))])]; }
function stored(id){ const v = P.TXT()[key(id)]; return v && typeof v === 'object' && !Array.isArray(v) ? v : null; }
function readIO(w){ const g = q => [...w.querySelectorAll(q)].map(x => x.dataset.v || x.textContent.replace(/×$/, '').trim()).filter(Boolean);
  const s = w.querySelector('.io-s'), sys = [], fmt = []; let m = 'sys';
  if (s) [...s.children].forEach(c => { if (c.classList.contains('io-l')) m = /형태/.test(c.textContent) ? 'fmt' : 'sys'; else if (c.tagName === 'EM') (m === 'fmt' ? fmt : sys).push(c.dataset.v || c.textContent.replace(/×$/, '').trim()); });
  return {inp:g('.io-c.in li'), out:g('.io-c.out li'), sys, fmt}; }
function writeIO(w, v, ed){ const x = ed ? '<button type="button" class="v38x" contenteditable="false" title="지우기">×</button>' : '';
  ['in', 'out'].forEach(c => { const col = w.querySelector('.io-c.' + c); if (!col) return; col.querySelectorAll('ul, p.none, .v38add').forEach(e => e.remove()); const arr = v[c === 'in' ? 'inp' : 'out'];
    col.insertAdjacentHTML('beforeend', (arr.length ? '<ul>' + arr.map(t => '<li data-v="' + esc(t) + '">' + (ed ? '<span class="v38t" contenteditable="true">' + esc(t) + '</span>' : esc(t)) + x + '</li>').join('') + '</ul>' : '<p class="none">—</p>') + (ed ? '<button type="button" class="v38add" data-k="' + (c === 'in' ? 'inp' : 'out') + '">＋ 추가</button>' : '')); });
  let s = w.querySelector('.io-s'); if (!s){ s = document.createElement('div'); s.className = 'io-s'; w.appendChild(s); }
  s.innerHTML = '<span class="io-l">쓰는 시스템</span>' + v.sys.map(t => '<em data-v="' + esc(t) + '">' + esc(t) + x + '</em>').join('') + (ed ? '<button type="button" class="v38add" data-k="sys">＋ 추가</button>' : '')
    + '<span class="io-l">자료 형태·보관 위치</span>' + v.fmt.map(t => '<em class="f" data-v="' + esc(t) + '">' + esc(t) + x + '</em>').join('') + (ed ? '<button type="button" class="v38add" data-k="fmt">＋ 추가</button>' : ''); }
function save(w, id){ P.TXT()[key(id)] = readIO(w); P.setDirty(); }
function addToAgent(id, k, name, own){ const sub = (TB[id] || {}).sub, S = D.subs[sub]; if (!S) return; const f = {inp:'d', out:'of', sys:'s'}[k]; if (!f) return; S[f] = S[f] || [];
  if (S[f].some(x => x[0] === name)) return;
  S[f].push(f === 'of' ? [name, []] : f === 'd' ? [name, own ? 0 : 1, own ? 'N' : 'E', '상세 창에서 추가', '', []] : [name, own ? 0 : 1, own ? 'N' : 'E', '상세 창에서 추가', '']);
  const X = P.AGX(); X.subs = X.subs || {}; X.subs[sub] = X.subs[sub] || {}; X.subs[sub][f] = JSON.parse(JSON.stringify(S[f])); P.agRerender(); }
function cands(id, k){ const sub = (TB[id] || {}).sub, S = D.subs[sub] || {}, V = ((D.views[P.S.lv] || {})[P.S.scr] || {});
  if (k === 'inp'){ const up = []; (V.edges || []).forEach(e => { if (e[1] === id && e[2] !== 'r' && e[2] !== 'l'){ const st = stored(e[0]); (st ? st.out : fromRows(e[0], 'out')).forEach(x => up.push(x)); } });
    return [['이 업무의 인풋 데이터', fromRows(id, 'inp')], ['수행 Agent의 투입 Data', (S.d || []).map(x => x[0])], ['앞 업무가 만드는 것', up]]; }
  if (k === 'out') return [['이 업무의 아웃풋', fromRows(id, 'out')], ['수행 Agent의 산출물', [...(S.of || []).map(x => x[0]), ...((D.outs || {})[sub] || []).map(x => x[0])]]];
  if (k === 'sys') return [['수행 Agent의 활용 시스템', (S.s || []).map(x => x[0])], ['이 업무의 시스템 칸', fromRows(id, 'sys')], ['전체 시스템', [...new Set(Object.values(D.subs).flatMap(s => (s.s || []).map(x => x[0])))]]];
  return [['형식 분류', Object.keys(D.form || {})], ['이 업무의 형식·출처', fromRows(id, 'fmt')]]; }
function pick(btn, w, id){ const k = btn.dataset.k, have = new Set(readIO(w)[k]); let pop = $('#iop38'); if (!pop){ pop = document.createElement('div'); pop.id = 'iop38'; document.body.appendChild(pop); }
  const G = cands(id, k).map(([t, a]) => [t, [...new Set(a)].filter(x => x && !have.has(x))]).filter(g => g[1].length);
  const draw = q => { pop.querySelector('.lst').innerHTML = G.map(([t, a]) => { const b = a.filter(x => !q || x.indexOf(q) >= 0); return b.length ? '<h6>' + esc(t) + '</h6>' + b.map(x => '<button type="button" data-pick="' + esc(x) + '">' + esc(x) + '</button>').join('') : ''; }).join('') + (q ? '<button type="button" class="own" data-pick="' + esc(q) + '" data-own="1">＋ 직접 입력: ' + esc(q) + '</button>' : (G.length ? '' : '<h6>후보가 없습니다 — 입력하면 직접 추가</h6>')); };
  pop.innerHTML = '<input type="search" placeholder="검색 또는 직접 입력"><div class="lst"></div>'; draw('');
  const r = btn.getBoundingClientRect(); pop.style.left = Math.max(8, Math.min(r.left, innerWidth - 340)) + 'px'; pop.style.top = Math.min(r.bottom + 4, innerHeight - 370) + 'px'; pop.hidden = false;
  const inp = pop.querySelector('input'); inp.oninput = () => draw(inp.value.trim()); inp.onkeydown = e => { if (e.key === 'Enter' && inp.value.trim()){ e.preventDefault(); done(inp.value.trim(), true); } else if (e.key === 'Escape') pop.hidden = true; }; setTimeout(() => inp.focus(), 0);
  const done = (v, own) => { const now = readIO(w); now[k].push(v); writeIO(w, now, true); save(w, id); addToAgent(id, k, v, own); pop.hidden = true; };
  pop.onclick = e => { const b = e.target.closest('[data-pick]'); if (b) done(b.dataset.pick, !!b.dataset.own); }; }
const pan = $('#panel'); if (!pan) return;
function apply(){ const w = pan.querySelector('.pwhat'), id = cur(); if (!w || !id || !w.querySelector('.io')) return; const ed = pan.classList.contains('pe-on') && P.S.edit;
  const st = ed + '|' + id + '|' + P.S.scr + P.S.lv; if (w.dataset.v38io === st) return; w.dataset.v38io = st; writeIO(w, stored(id) || readIO(w), ed); }
new MutationObserver(apply).observe(pan, {childList:true, subtree:true, attributes:true, attributeFilter:['class', 'hidden']});
pan.addEventListener('click', e => { const w = pan.querySelector('.pwhat'), id = cur(); if (!w || !id) return;
  const x = e.target.closest('.v38x'); if (x){ e.preventDefault(); e.stopPropagation(); x.closest('li, em').remove(); writeIO(w, readIO(w), true); save(w, id); return; }
  const a = e.target.closest('.v38add'); if (a){ e.preventDefault(); e.stopPropagation(); pick(a, w, id); } }, true);
pan.addEventListener('focusout', e => { const t = e.target.closest && e.target.closest('.v38t'); if (!t) return; const w = pan.querySelector('.pwhat'), id = cur(), li = t.closest('li'); const v = t.textContent.trim();
  if (!v) li.remove(); else li.dataset.v = v; save(w, id); }, true);
pan.addEventListener('keydown', e => { const t = e.target.closest && e.target.closest('.v38t'); if (t && e.key === 'Enter'){ e.preventDefault(); t.blur(); } e.target.closest && e.target.closest('.v38t') && e.stopPropagation(); }, true);
document.addEventListener('mousedown', e => { const pop = $('#iop38'); if (pop && !pop.hidden && !e.target.closest('#iop38, .v38add')) pop.hidden = true; }, true);
})();
