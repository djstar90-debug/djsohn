"""Checkpointed preparation → validation/build → full browser QC → certification.

prepare --excel input.xlsx --source-html asis.html --spec 3 --work work
enrich --work work          # optional deterministic fill after core design exists
validate --work work        # all preflight errors in diagnostics.json
run --work work --output outputs/crm --wait 50
run --work work --output outputs/crm --background
status --work work

Exit 0=prepared/validated/passed, 2=fix required, 3=running. A candidate is
never reported as a certified deliverable. Changed inputs invalidate caches.
"""
import argparse
import contextlib
import copy
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tempfile
import time
import uuid

ROOT=Path(__file__).resolve().parents[1]
STATE='pipeline-state.json'

def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def file_hash(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def json_hash(value): return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def atomic(path,value):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_name(p.name+'.'+uuid.uuid4().hex+'.tmp')
    temp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,p)

def code_hash():
    files=list((ROOT/'scripts').glob('*.py'))+[ROOT/'assets'/name for name in ('engine.js','shell.html','phrasebook.json')]
    return json_hash({str(p.relative_to(ROOT)):file_hash(p) for p in sorted(files) if p.is_file()})

def fingerprint(work):
    w=Path(work)
    import qc_browser
    return {'asis':file_hash(w/'asis.json'),'design':file_hash(w/'design.json'),'code':code_hash(),'qc_runner':qc_browser.runner_fingerprint()}

@contextlib.contextmanager
def lock(work):
    p=Path(work);p.mkdir(parents=True,exist_ok=True)
    with (p/'.pipeline.lock').open('a') as f:
        try: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise ValueError('같은 작업이 실행 중입니다. status로 확인하세요.')
        try: yield
        finally: fcntl.flock(f,fcntl.LOCK_UN)

def quiet_call(fn,*args,**kwargs):
    # Keep complete logs on disk; tool output remains compact.
    buf=io.StringIO()
    with contextlib.redirect_stdout(buf): result=fn(*args,**kwargs)
    return result,buf.getvalue()

def prepare(work,excel=None,source_html=None,spec='3',asis_json=None,stage=None):
    w=Path(work).resolve();w.mkdir(parents=True,exist_ok=True)
    sources={}
    for name,path in [('excel',excel),('source_html',source_html),('asis_json',asis_json)]:
        if path: sources[name]={'path':str(Path(path).resolve()),'sha256':file_hash(path)}
    signature=json_hash({'sources':sources,'spec':spec,'stage':stage,'code':code_hash()})
    with lock(w):
        if (w/STATE).exists():
            old=read(w/STATE)
            if old.get('prepare_signature')!=signature: raise ValueError('입력 또는 파서가 변경되었습니다. 기존 설계를 보존하기 위해 새 --work 폴더에서 prepare하세요.')
            if not (w/'asis.json').is_file() or file_hash(w/'asis.json')!=old.get('prepared_asis_sha256'):
                raise ValueError('준비된 asis.json이 변경/누락되었습니다. 원천 입력을 재검토하세요.')
            return status(w)
        if (w/'design.json').exists() or (w/'asis.json').exists(): raise ValueError('기존 asis/design 파일이 있습니다. 새 --work 폴더를 사용하세요.')
        import parse_excel as PE
        import source_asis
        import verify_input
        import autofill
        if asis_json: a=read(asis_json)
        elif excel:
            wb,ws=PE.open_sheet(excel)
            try: fmt=PE.detect(ws)[0]
            finally: wb.close()
            if fmt=='F2': a=PE.build_f2(excel,int(spec),source_html=source_html)
            else:
                nums=[int(x) for x in re.split(r'[,+]',spec)]
                a=PE.build(excel,nums[0]) if len(nums)==1 else PE.merge([PE.build(excel,n) for n in nums])
                if stage: a=PE.stage_lv3(a)
        else: raise ValueError('--excel 또는 --asis-json 필요')
        issues=verify_input.validate(a)
        if any(i['severity']=='error' for i in issues): raise ValueError('\n'.join(i['message'] for i in issues if i['severity']=='error'))
        if source_html: a=source_asis.attach(a,source_html)
        if a.get('source_html'): source_asis.validate(a['source_html'],a)
        d=autofill.skeleton(a);d['tobe_flow']=[];d['design_contract']={'version':1,'redesign':[]}
        atomic(w/'asis.json',a);atomic(w/'design.json',d)
        (w/'lv4_sheet.md').write_text(autofill.lv4_sheet(a),encoding='utf-8')
        intake={'sources':sources,'spec':spec,'stage':stage,'counts':{k:len(a[k]) for k in ('A4','A5','A6')},
                'issues':issues,'source_scope':a.get('source_html',{}).get('scope_difference',{}),
                'recovered_ids':a.get('meta',{}).get('recovered_ids',[])}
        atomic(w/'intake.json',intake)
        state={'version':'1.3.0','status':'design_required','work':str(w),'prepare_signature':signature,
               'prepared_asis_sha256':file_hash(w/'asis.json'),'created_at':time.time(),'counts':intake['counts']}
        atomic(w/STATE,state)
        return state

def enrich(work):
    import restructure as R
    import autofill
    w=Path(work).resolve()
    with lock(w):
        a,d=read(w/'asis.json'),read(w/'design.json')
        a2,d2=R.synth(a,copy.deepcopy(d));(filled,counts),log=quiet_call(autofill.fill,a2,d2)
        for key in R.ABSORB:
            if key in filled: d[key]=filled[key]
        for key,t in filled['tb'].items():
            if key in d['tb'] and d['tb'][key].get('t')=='M':
                d['tb'][key].update({f:v for f,v in t.items() if f in ('st','l5','o','sub')})
        old_hash=file_hash(w/'design.json')
        backup=w/'design-history'/(old_hash+'.json');backup.parent.mkdir(exist_ok=True)
        if not backup.exists(): backup.write_bytes((w/'design.json').read_bytes())
        atomic(w/'design.json',d)
        result={'status':'enriched_requires_review','changes':dict(counts),'backup':str(backup)}
        atomic(w/'enrich-report.json',result)
        return result

def validate(work):
    import release
    w=Path(work).resolve()
    result,log=quiet_call(release.validate_only,read(w/'asis.json'),read(w/'design.json'))
    atomic(w/'diagnostics.json',result)
    (w/'validation.log').write_text(log,encoding='utf-8')
    return result

def certified_intact(state):
    candidate=Path(state['candidate'])
    receipts=state.get('certified_receipts',{})
    if set(receipts)!={'manifest.json','browser-qc.json'}: return False
    try: return intact(candidate) and all(file_hash(candidate/name)==value for name,value in receipts.items())
    except OSError:return False

def intact(candidate):
    try:
        m=read(Path(candidate)/'manifest.json')
        expected={'asis.json','design.json','pmd.json','map.html','map.xlsx'}
        if not expected.issubset(m.get('files',{})): return False
        return all(file_hash(Path(candidate)/name)==h for name,h in m['files'].items())
    except (OSError,ValueError,KeyError): return False

def checkpoint(work,state):
    if state.get('status')!='passed': state.pop('deliverables',None)
    state['updated_at']=time.time();atomic(Path(work)/STATE,state)
    if state.get('output'): atomic(Path(state['output'])/'status.json',state)

def failure(work,state,exc,phase):
    messages=str(exc).splitlines() or [type(exc).__name__]
    detail={'status':'requires_fix','phase':phase,'issues':[{'severity':'error','message':m} for m in messages]}
    # Preserve structured validation exceptions when supplied by release.
    if isinstance(getattr(exc,'report',None),dict): detail.update(exc.report)
    atomic(Path(work)/'diagnostics.json',detail)
    state.update(status='requires_fix',phase=phase,diagnostics=str(Path(work)/'diagnostics.json'),error_count=detail.get('counts',{}).get('errors',len(messages)))
    checkpoint(work,state);return state

def run(work,output=None,wait=50,retry_qc=False):
    import release
    import qc_browser
    w=Path(work).resolve()
    with lock(w):
        if not (w/STATE).exists(): raise ValueError('prepare를 먼저 실행하세요.')
        state=read(w/STATE)
        try: verify_sources(w)
        except ValueError as exc: return failure(w,state,exc,'input_changed')
        fp=fingerprint(w);signature=json_hash(fp)
        if output:
            out=str(Path(output).resolve())
            if state.get('output') and state['output']!=out: raise ValueError('출력 폴더가 기존 작업과 다릅니다. 기존 --output을 사용하세요.')
            state['output']=out
        if not state.get('output'): raise ValueError('첫 run에 --output이 필요합니다.')
        # Never reuse a pass after edited design, source, renderer or checker.
        same=state.get('fingerprint')==fp
        candidate=Path(state.get('candidate','')) if same and state.get('candidate') else None
        if candidate and intact(candidate):
            if state.get('status')=='passed' and certified_intact(state):
                state['cache_hit']=True;checkpoint(w,state);return state
        else:
            if not same:
                for key in ('deliverables','diagnostics','error_count','qc_summary','cache_hit'):
                    state.pop(key,None)
            candidate=Path(state['output'])/'revisions'/signature[:16]
            if candidate.exists():
                # Keep incomplete/tampered prior files for diagnosis, never overwrite.
                candidate=candidate.with_name(candidate.name+'-'+uuid.uuid4().hex[:8])
            state.update(fingerprint=fp,candidate=str(candidate),status='building',phase='build')
            checkpoint(w,state)
            try:
                result,log=quiet_call(release.build,read(w/'asis.json'),read(w/'design.json'),candidate)
                (w/'build.log').write_text(log,encoding='utf-8')
                state['counts']=result.get('counts',{});state['cache_hit']=False
            except Exception as exc: return failure(w,state,exc,'build')
        state.update(status='running',phase='browser_qc');checkpoint(w,state)
        try:
            retry_parts=None
            if retry_qc and (candidate/'qc/final.json').is_file():
                retry_parts=read(candidate/'qc/final.json').get('repair',{}).get('failed_parts') or None
            report,log=quiet_call(qc_browser.final_wait,str(candidate/'map.html'),str(candidate/'qc'),timeout=min(50,max(0,wait)),resume=True,rerun_parts=retry_parts)
            with (w/'qc.log').open('a',encoding='utf-8') as f:f.write(log)
            if report is None or report.get('status')=='pending':
                state['qc_status']=report or {'status':'pending'};checkpoint(w,state);return state
            if report.get('status')!='passed' or qc_browser.failures(report):
                diagnostics={'status':'requires_fix','phase':'browser_qc','issues':report.get('diagnostics',[]),
                             'failures':qc_browser.failures(report),'report':str(candidate/'qc/final.json')}
                atomic(w/'diagnostics.json',diagnostics)
                state.update(status='requires_fix',phase='browser_qc',diagnostics=str(w/'diagnostics.json'),qc_summary=report.get('summary',{}))
                checkpoint(w,state);return state
            state.update(phase='certify');checkpoint(w,state)
            result,log=quiet_call(release.certify,candidate,candidate/'qc/final.json')
            if fingerprint(w)!=fp: raise ValueError('검사 중 입력이 변경됐습니다. 최신 입력으로 run을 다시 실행하세요.')
            state.update(status='passed',phase='complete',qc_summary=result.get('browser_qc_summary'),
                         deliverables={k:str(candidate/k) for k in ('map.html','map.xlsx','manifest.json')})
            state.pop('diagnostics',None);state.pop('qc_status',None);state.pop('error_count',None)
            state['certified_receipts']={name:file_hash(candidate/name) for name in ('manifest.json','browser-qc.json')}
            checkpoint(w,state);return state
        except Exception as exc: return failure(w,state,exc,state.get('phase','browser_qc'))

def verify_sources(work):
    intake=Path(work)/'intake.json'
    if not intake.exists(): return
    for name,item in read(intake).get('sources',{}).items():
        path=Path(item['path'])
        if path.is_file() and file_hash(path)!=item['sha256']:
            raise ValueError(f'원천 {name} 파일이 준비 이후 변경됐습니다. 새 --work에서 prepare하고 설계를 대조하세요.')

def wait_parent_lock(work,timeout=10):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        try:
            with lock(work):return
        except ValueError:time.sleep(0.02)
    raise ValueError('백그라운드 시작 대기 한도: 다른 작업의 완료 후 run 재시도')

def status(work):
    w=Path(work).resolve()
    if not (w/STATE).is_file(): return {'status':'not_prepared','work':str(w)}
    state=read(w/STATE)
    try: verify_sources(w)
    except ValueError as exc:
        state.update(status='inputs_changed',phase='prepare_required',message=str(exc));state.pop('deliverables',None);return state
    if state.get('fingerprint'):
        if fingerprint(w)!=state['fingerprint']:
            state.update(status='inputs_changed',phase='run_required');state.pop('deliverables',None)
        elif state.get('status')=='passed' and not certified_intact(state):
            state.update(status='artifacts_changed',phase='run_required');state.pop('deliverables',None)
    return state

def worker_alive(worker):
    try:
        pid=worker['pid'];os.kill(pid,0)
        cmd=Path(f'/proc/{pid}/cmdline').read_bytes().decode(errors='replace')
        return worker['token'] in cmd and 'pipeline.py' in cmd
    except (OSError,KeyError):return False

def background(work,output=None,retry_qc=False):
    w=Path(work).resolve();w.mkdir(parents=True,exist_ok=True)
    with lock(w):
        record=w/'worker.json'
        if record.exists() and worker_alive(read(record)):return dict(status='running',worker=read(record),checkpoint=str(w/STATE))
        token=uuid.uuid4().hex
        cmd=[sys.executable,str(Path(__file__).resolve()),'run','--work',str(w),'--worker-token',token]
        if output:cmd+=['--output',str(Path(output).resolve())]
        if retry_qc:cmd+=['--retry-qc']
        with (w/'worker.log').open('a',encoding='utf-8') as f:
            process=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        info={'pid':process.pid,'token':token,'started_at':time.time()};atomic(record,info)
        return dict(status='running',worker=info,checkpoint=str(w/STATE),log=str(w/'worker.log'))

def compact(result,work):
    keys=('status','phase','candidate','deliverables','counts','cache_hit','qc_summary','diagnostics','log')
    out={k:result[k] for k in keys if k in result and (k!='deliverables' or result.get('status')=='passed')}
    issues=result.get('issues') or []
    if not issues and result.get('diagnostics'):
        try:
            detail=read(result['diagnostics']);issues=detail.get('issues') or detail.get('failures') or []
        except (OSError,ValueError):pass
    if issues:
        out['issue_count']=len(issues);out['issues']=issues[:8]
    if result.get('status') in ('running','requires_fix','inputs_changed','artifacts_changed'):
        out['resume_command']='python scripts/pipeline.py run --work '+shlex.quote(str(Path(work).resolve()))
    return out

def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__);subs=ap.add_subparsers(dest='command',required=True)
    p=subs.add_parser('prepare');p.add_argument('--work',required=True);g=p.add_mutually_exclusive_group(required=True)
    g.add_argument('--excel');g.add_argument('--asis-json');p.add_argument('--source-html');p.add_argument('--spec',default='3');p.add_argument('--stage',choices=('lv3',))
    for name in ('enrich','validate','status'):subs.add_parser(name).add_argument('--work',required=True)
    p=subs.add_parser('run');p.add_argument('--work',required=True);p.add_argument('--output');p.add_argument('--wait',type=float,default=50)
    p.add_argument('--background',action='store_true');p.add_argument('--retry-qc',action='store_true');p.add_argument('--worker-token',help=argparse.SUPPRESS)
    a=ap.parse_args(argv)
    try:
        if a.command=='prepare':result=prepare(a.work,a.excel,a.source_html,a.spec,a.asis_json,a.stage)
        elif a.command=='enrich':result=enrich(a.work)
        elif a.command=='validate':result=validate(a.work)
        elif a.command=='status':result=status(a.work)
        elif a.background:result=background(a.work,a.output,a.retry_qc)
        elif a.worker_token:
            wait_parent_lock(a.work)
            deadline=time.monotonic()+900
            while True:
                result=run(a.work,a.output,50,a.retry_qc)
                a.retry_qc=False
                if result.get('status')!='running' or time.monotonic()>deadline:break
            if result.get('status')=='running':
                result['worker_note']='자동 실행 시간 한도. 작업 상태와 QC 프로세스는 보존됨; run으로 재개 가능'
                checkpoint(a.work,result)
        else:result=run(a.work,a.output,a.wait,a.retry_qc)
        print(json.dumps(compact(result,a.work),ensure_ascii=False,indent=2))
        if result.get('status') in ('requires_fix','failed','invalid'):return 2
        if result.get('status') in ('running','inputs_changed','artifacts_changed'):return 3
        return 0
    except (ValueError,KeyError,TypeError,IndexError,OSError) as exc:
        print(json.dumps({'status':'requires_fix','error':str(exc)},ensure_ascii=False),file=sys.stderr);return 2

if __name__=='__main__':sys.exit(main())
