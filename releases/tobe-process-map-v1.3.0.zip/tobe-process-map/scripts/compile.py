"""컴파일 층: asis.json + design.json → 화면 데이터(__PMD__)  (결정적)"""
import sys, json, re, os
from collections import defaultdict, Counter, OrderedDict
def ids(s, pat=None): return [x for x in re.split(r'[,;\s]+', s or '') if x]

# ---------- 경로 태그 ----------
def tags(s):
    m = re.match(r'^\[([^\]]+)\]', s or ''); return m.group(1) if m else None
def tr_of(n6, n5, paths):
    P, M = [], []
    for tg in (tags(n5), tags(n6)):
        if not tg: continue
        head, _, sub = tg.partition('-')
        hs = [h for h in re.split(r'[/·]', head) if h]
        if all(h in paths for h in hs):
            if len(hs) == 1 and hs[0] not in P: P.append(hs[0])
            if sub and sub not in M: M.append(sub)
        else:
            for h in hs:
                if h not in M: M.append(h)
    return '·'.join(P + M) or None
def path_vocab(A5):
    v = []
    for a in A5.values():
        tg = tags(a['n'])
        if tg:
            for h in re.split(r'[/·]', tg.partition('-')[0]):
                if h and h not in v: v.append(h)
    return v

# ---------- 배치: 단계 안 최장 경로 열, (단계·레인·열) 안 순번 행 ----------
def layout(order, st, lane, edges, fixed_c=None, newc=None):
    pos = {}; col = {}
    idx = {n: i for i, n in enumerate(order)}
    pred = defaultdict(list)
    for a, b, t, _ in edges:
        if a in idx and b in idx and t != 'r': pred[b].append((a, t))
    for n in order:
        if fixed_c and n in fixed_c: col[n] = fixed_c[n]; continue
        ps = [(p, t) for p, t in pred[n] if p in col and st[p] == st[n] and idx[p] < idx[n]]
        col[n] = max([col[p] + (newc(n) if newc else 1) for p, t in ps], default=0)
    occ = Counter()
    for n in order:
        key = (st[n], lane[n], col[n]); pos[n] = (col[n], occ[key]); occ[key] += 1
    return pos

def bypass(E0, X):
    """소멸 노드를 빼고 앞뒤를 잇는다. 소멸 노드로 가는 반려선은 버린다."""
    E = [list(e) for e in E0 if not (e[2] == 'r' and e[1] in X)]
    for x in [e for e in dict.fromkeys(a for e in E0 for a in e[:2])] :
        if x not in X: continue
        ins = [e for e in E if e[1] == x]; outs = [e for e in E if e[0] == x]
        at = min([E.index(e) for e in outs], default=len(E))
        E2 = [e for e in E if x not in e[:2]]
        add = []
        for i in ins:
            for o in outs:
                if i[2] == 'r' or o[2] == 'r': continue
                t = 's'; lab = ''   # v26: 소멸 박스를 건너뛴 새 연결은 순차선 (특수 화살표는 확인받은 지점에만)
                if not any(e[:2] == [i[0], o[1]] for e in E2 + add): add.append([i[0], o[1], t, lab])
        k0 = sum(1 for e in E[:at] if x not in e[:2])
        E = E2[:k0] + add + E2[k0:]
    return E
def lead_tag(s):
    m = re.match(r'^\[([^\]]+)\]', s or ''); return m.group(1).strip() if m else None
def parallelize(E, A6, tr):
    """같은 Lv.5 안에서 1:1로 이어진 연속 행이 대괄호 태그만 다르면(예: [영상] → [이미지]) 병렬로 다시 잇는다.
    앞 업무 → 묶음 각 행 → 뒤 업무. 앞·뒤 업무에 같은 태그 갈래가 있으면 그 갈래끼리만 잇는다. 엑셀 원문은 그대로 둔다."""
    outs = defaultdict(list); ins = defaultdict(list)
    for e in E:
        if e[2] != 'r': outs[e[0]].append(e); ins[e[1]].append(e)
    l5 = lambda k: A6[k]['l5'].split(' ')[0]
    groups, used = [], set()
    for k in A6:
        if k in used or not lead_tag(A6[k]['n']): continue
        g = [k]
        while True:
            o = outs[g[-1]]
            if len(o) != 1: break
            nx = o[0][1]
            if nx not in A6 or len(ins[nx]) != 1 or l5(nx) != l5(k) or not lead_tag(A6[nx]['n']) or lead_tag(A6[nx]['n']) in [lead_tag(A6[x]['n']) for x in g]: break
            g.append(nx)
        if len(g) > 1:
            groups.append(g); used.update(g)
    if not groups: return E, []
    E = [list(e) for e in E]
    toks = lambda x: (tr.get(x) or '').split('·')
    for g in groups:
        G = set(g); tags = {x: lead_tag(A6[x]['n']) for x in g}
        pin = [e for e in E if e[1] == g[0] and e[2] != 'r']
        pout = [e for e in E if e[0] == g[-1] and e[2] != 'r']
        chain = [e for e in E if e[0] in G and e[1] in G and e[2] != 'r']
        at = min(E.index(e) for e in pin + chain + pout)
        drop = pin + chain + pout
        rest = [e for e in E if e not in drop]
        add = []
        for e in pin:
            m = [x for x in g if tags[x] in toks(e[0])]
            for x in (m or g): add.append([e[0], x, e[2], e[3]] if m else [e[0], x, 'b', tags[x]])
        for e in pout:
            m = [x for x in g if tags[x] in toks(e[1])]
            for x in (m or g): add.append([x, e[1], e[2], e[3]])
        k0 = sum(1 for e in E[:at] if e not in drop)
        E = rest[:k0] + add + rest[k0:]
    return E, groups
def apply_fix(nodes, fix):
    for n in nodes:
        if n['id'] in fix: n.update(fix[n['id']])
    return nodes
def struct_warn(stc, Ens, X):
    """확인받은 As-Is 구조(structure.py → 설계 파일 structure)와 To-be 연결 비교"""
    E = {(e[0], e[1]) for e in Ens if e[2] != 'r'}; out = []
    for p in stc.get('parallel', []):
        alive = [x for x in p['to'] if x not in X]
        for i, x in enumerate(alive):
            for y in alive[i + 1:]:
                if (x, y) in E or (y, x) in E: out.append(f"[구조] 병행이 순차로 바뀜: {x} → {y} (확인한 구조: {p['from']} 다음에 동시 진행)")
    for j in stc.get('join', []):
        if j['to'] in X: continue
        alive = [x for x in j['from'] if x not in X]; ins = {a for a, b in E if b == j['to']}
        if len(alive) >= 2 and len(ins) < 2: out.append(f"[구조] 합류 누락: {j['to']} (확인한 구조: {', '.join(j['from'])}에서 모임)")
    for br in stc.get('branch', []):
        tos = [x for x in br['to'].values() if x not in X]
        for i, x in enumerate(tos):
            for y in tos[i + 1:]:
                if (x, y) in E or (y, x) in E: out.append(f"[구조] 분기끼리 이어짐: {x} ↔ {y} (조건별로 따로 진행)")
    for a, b, t, lab in stc.get('extra', []):
        if a not in X and b not in X and not any(e[0] == a and e[1] == b for e in Ens): out.append(f'[구조] 확인한 연결 누락: {a} → {b} ({lab or t})')
    labs = {(e[0], e[1]): (e[2], e[3]) for e in Ens}
    for br in stc.get('branch', []):
        for cond, tgt in br['to'].items():
            if tgt in X or br['from'] in X: continue
            t_ = labs.get((br['from'], tgt))
            if t_ and (t_[0] != 'b' or not t_[1]): out.append(f"[구조] 분기 이름표 누락: {br['from']} → {tgt} ('{cond}')")
    for w in out: print(w)
    return out

def compile_(asis, dz):
    A6, A5, A4 = asis['A6'], asis['A5'], asis['A4']
    for k, t in dz['tb'].items():   # v33: 소멸 설명 — 흡수 대상 번호(to)+사유(why)면 대상의 현재 이름으로 문구를 만든다 (이름이 바뀌어도 옛 이름이 남지 않게)
        if t.get('t') != 'X': continue
        if t.get('to'):
            tt = dz['tb'].get(t['to']) or {}; nm = tt.get('lb') or (A6.get(t['to']) or {}).get('n', t['to'])
            t['note'] = f"흡수 → 「{nm}」 {t.get('why', '').strip()}".strip()
        elif t.get('kind') == '삭제': t['note'] = f"삭제 — {t.get('why', '').strip()}"
    stc0 = dz.get('structure') or {}; TYC = {}   # v26: 상세 창 ◇ 분기·◎ 합류 표시도 확인받은 구조로
    for br in stc0.get('branch', []): TYC[br['from']] = '분기'
    for j in stc0.get('join', []): TYC[j['to']] = '분기·합류' if TYC.get(j['to']) == '분기' else '합류'
    lanes = dz['lanes']; BYBON = any(l.get('bon') for l in lanes)   # 레인이 담당본부 기준이면 행은 담당본부로 레인에 들어감
    LN = {t: l['k'] for l in lanes for t in (l.get('bon') or l['team'])}
    lk = (lambda a: a.get('bon') or a['team']) if BYBON else (lambda a: a['team'])
    lname = {l['k']: l['name'] for l in lanes}
    TB = dz['tb']
    st_of_l4 = {k: i+1 for i, k in enumerate(A4)}
    paths = path_vocab(A5)
    # ---- As-Is A6/A5/A4 (화면 형식) ----
    norm = lambda s: ', '.join(ids(s))
    oA6 = OrderedDict()
    for k, a in A6.items():
        oA6[k] = dict(a, pre=norm(a['pre']), post=norm(a['post']), rej=norm(a['rej']))
        for f in ('status', 'track', 'cowork'): oA6[k].pop(f, None)
        g4 = A5[a['l5'].split(' ')[0]].get('g4')
        if g4: oA6[k]['g4'] = g4
    oA5 = OrderedDict()
    for k, a in A5.items():
        cnt = Counter(lname[LN[lk(A6[x])]] for x in a['kids'])
        place = ' · '.join(f'{n} {c}' for n, c in sorted(cnt.items(), key=lambda x: -x[1]))
        notes = []
        for x in a['kids']:
            if A6[x]['note'] and A6[x]['note'] not in notes: notes.append(A6[x]['note'])
        oA5[k] = dict(n=a['n'], l4=a['l4'], team=a['team'], place=place, kids=a['kids'], ty=a['ty'], br=a['br'],
                      rejr=a['rejr'], rej=norm(a['rej']), pre=norm(a['pre']), post=norm(a['post']), pain=a['pain'], note=notes,
                      rows=f"{min(a['r'])}~{max(a['r'])}", hl=[])
        if a.get('g4'): oA5[k]['g4'] = a['g4']
    # ---- 엣지 (As-Is Lv6) ----
    E6 = []
    for k, a in A6.items():
        brt = {}
        for line in re.split(r'\n|\s/\s', re.sub(r'^\s*병렬 진행\s*:\s*', '', a['br'] or '')):
            m = re.match(r'(.+?)\s*→\s*(\S+)', line.strip())
            if m: brt[m.group(2)] = m.group(1).strip()
        for p in ids(a['post']):
            if p in A6: E6.append([k, p, 'b' if p in brt else 's', brt.get(p, '')])
    for k, a in A6.items():
        for p in ids(a['rej']):
            if p in A6: E6.append([k, p, 'r', a['rejr']])
    st6 = {k: st_of_l4[A5[a['l5'].split(' ')[0]]['l4id']] for k, a in A6.items()}
    order6 = list(A6)
    tr_pre = {k: tr_of(a['n'], A5[a['l5'].split(' ')[0]]['n'], paths) for k, a in A6.items()}
    PAR = []
    if dz.get('parallel_tags', True): E6, PAR = parallelize(E6, A6, tr_pre)
    pos = layout(order6, st6, {k: LN[lk(A6[k])] for k in A6}, E6)
    tr6 = {k: tr_of(a['n'], A5[a['l5'].split(' ')[0]]['n'], paths) for k, a in A6.items()}
    asis6 = []
    for i, k in enumerate(order6):
        a = A6[k]; c, r = pos[k]
        n = dict(id=k, st=st6[k], c=c, r=r, ln=LN[lk(a)], k='h', lb=a['n'], pid=a['l5'].split(' ')[0], chg=0,
                 vf=1 if 'PI Crew 검증' in a['note'] else 0, o=i)
        if tr6[k]: n['tr'] = tr6[k]
        if a['ai'] != '인간 전담': n['ai'] = a['ai']
        ty = TYC.get(k) if (a['ty'] in ('분기', '합류', '분기·합류') or TYC.get(k)) else a['ty']
        if ty and ty != '세부작업': n['ty'] = ty
        asis6.append(n)
    # ---- To-be Lv6 ----
    stc = dz.get('structure') or {}
    for a, b, t, lab in stc.get('extra', []):   # 확인한 구조: As-Is HTML에만 있던 연결도 그림
        if a in A6 and b in A6 and not any(e[0] == a and e[1] == b for e in E6): E6.append([a, b, t, lab])
    confB = {(br['from'], t_) for br in stc.get('branch', []) for t_ in br['to'].values()}
    confR = {(r_['from'], r_['to']) for r_ in stc.get('rework', [])} | {(x[0], x[1]) for x in stc.get('extra', []) if x[2] in ('r', 'l')}
    # Source topology is never downgraded because a confirmation record is absent.
    # An attached HTML is authoritative; empty edge lists are meaningful too.
    if asis.get('source_html'):
        from source_asis import validate, mapped_edges
        validate(asis['source_html'], asis)
        E6 = mapped_edges(asis['source_html'])
    elif 'source_edges' in stc:
        E6 = [list(e) for e in stc['source_edges']]
    X = {k for k in A6 if TB[k]['t'] == 'X'}
    E = bypass(E6, X)
    newE = dz['new_edges']
    # 신규 노드가 끼어든 As-Is 엣지는 끊는다 (a→신규…→b 가 있으면 a→b 제거)
    newids = [k for k in TB if k not in A6]
    succ = defaultdict(set)
    for a, b, t, _ in newE: succ[a].add(b)
    def reach(a):
        seen, st_ = set(), [a]
        while st_:
            x = st_.pop()
            for y in succ[x]:
                if y not in seen: seen.add(y); 
                if y in newids: st_.append(y)
        return seen
    cut = set()
    for e in E:
        a, b = e[0], e[1]
        if any(y in newids for y in succ[a]) and b in reach(a): cut.add((a, b))
    E = [e for e in E if (e[0], e[1]) not in cut]
    g = OrderedDict()
    for e in E:
        if e[2] != 'r': g.setdefault(e[0], []).append(e)
    E = [e for k in g for e in reversed(g[k])] + [e for e in E if e[2] == 'r']
    Ens = E + [list(e) for e in newE]
    if dz.get('structure'): struct_warn(dz['structure'], Ens, X)   # 확인받은 병행·분기·합류 구조와 어긋나면 [구조] 경고
    KMAP = {'A': 'a', 'N': 'nh', 'H': 'h', 'X': 'gone', 'M': 'mk', 'O': 'ot'}
    ns = []
    nodes = {}
    for i, k in enumerate(order6):
        t = TB[k]; n = dict(id=k, st=st6[k], c=pos[k][0], r=0, ln=t['sub'] if t['t'] == 'A' else LN[lk(A6[k])],
                            k=KMAP[t['t']], lb=t.get('lb') or A6[k]['n'], o=i)
        nodes[k] = n
    for k in newids:
        t = TB[k]; nodes[k] = dict(id=k, st=t['st'], c=None, r=0, ln=t.get('sub') or t['lane'],
                                   k='na' if t['t'] == 'A' else KMAP[t['t']], lb=t['lb'], o=t['o'])
    # 신규 노드 열: 선행 노드 열 + 1 (Orchestrator는 같은 열)
    pred = defaultdict(list)
    for a, b, t, _ in Ens: pred[b].append(a)
    for k in sorted(newids, key=lambda k: nodes[k]['o']):
        ps = [nodes[p]['c'] for p in pred[k] if p in nodes and nodes[p]['c'] is not None]
        nodes[k]['c'] = max(ps) + (0 if TB[k]['t'] == 'M' else 1) if ps else 0
    # why 노드
    for k in X:
        g = nodes[k]; nodes[k + '~why'] = dict(id=k + '~why', st=g['st'], c=g['c'], r=0, ln=g['ln'], k='why',
            lb=TB[k].get('note', ''), tg='소멸 이유', pid=A6[k]['l5'].split(' ')[0], of=k, o=g['o'] + 0.0001)
    occ = Counter()
    for n in sorted(nodes.values(), key=lambda n: n['o']):
        key = (n['st'], n['ln'], n['c']); n['r'] = occ[key]; occ[key] += 1
    allo = [nodes[k] for k in order6] + [nodes[k] for k in newids] + [nodes[k + '~why'] for k in order6 if k in X]
    # 필드 마무리
    trn = dict(tr6)
    for k in sorted(newids, key=lambda k: nodes[k]['o']):
        ps = [p for p in pred[k] if p in nodes]
        if TB[k]['t'] == 'M': trn[k] = next((trn.get(p) for p in ps if trn.get(p)), None)   # 신호: 첫 선행의 경로
        else:                                                                               # 업무: 선행 경로가 모두 같을 때만
            vals = {trn.get(p) for p in ps}; trn[k] = vals.pop() if len(vals) == 1 else None
    out = []
    for n in allo:
        k = n['id']; base = k.split('~')[0]
        m = dict(id=k, st=n['st'], c=n['c'], r=n['r'], ln=n['ln'], k=n['k'], lb=n['lb'])
        tg = n.get('tg') or TB.get(k, {}).get('tg')
        if tg: m['tg'] = tg
        if k in A6 or n['k'] == 'why' or TB[k]['t'] != 'M':
            m['pid'] = A6[base]['l5'].split(' ')[0] if base in A6 else TB[k]['l5']
        if k in A6: m['vf'] = 1 if 'PI Crew 검증' in A6[k]['note'] else 0
        if n['k'] == 'why': m['of'] = n['of']
        t = trn.get(base)
        if t: m['tr'] = t
        m['o'] = n['o']
        out.append(m)
    ns6 = out
    # ================= Lv.5 =================
    L5 = list(A5)
    st5 = {k: st_of_l4[A5[k]['l4id']] for k in L5}
    E5 = []
    for k, a in A5.items():
        brt = {}
        for line in re.split(r'\n|\s/\s', re.sub(r'^\s*병렬 진행\s*:\s*', '', a['br'] or '')):
            m = re.match(r'(.+?)\s*→\s*(\S+)', line.strip())
            if m: brt[m.group(2)] = m.group(1).strip()
        for p in ids(a['post']):
            if p in A5: E5.append([k, p, 'b' if p in brt else 's', brt.get(p, '')])
    for k, a in A5.items():
        for p in ids(a['rej']):
            if p in A5: E5.append([k, p, 'r', a['rejr']])
    def maj(kids):
        c = Counter(LN[lk(A6[x])] for x in kids); b = max(c.values())
        return next(LN[lk(A6[x])] for x in kids if c[LN[lk(A6[x])]] == b)
    ln5 = {k: maj(A5[k]['kids']) for k in L5}
    pos5 = layout(L5, st5, ln5, E5)
    vf6 = {k: 1 if 'PI Crew 검증' in A6[k]['note'] else 0 for k in A6}
    tr5 = {k: tr_of('', A5[k]['n'], paths) for k in L5}
    asis5 = []
    for i, k in enumerate(L5):
        a = A5[k]; kids = a['kids']
        n = dict(id=k, st=st5[k], c=pos5[k][0], r=pos5[k][1], ln=ln5[k], k='h', lb=a['n'])
        nai = [A6[x]['ai'] for x in kids if A6[x]['ai'] != '인간 전담']
        if nai: n['ai'] = f"{Counter(nai).most_common(1)[0][0]} {len(nai)}/{len(kids)}"
        n['pid'] = a['l4id']
        if a['ty'] != '업무': n['ty'] = a['ty']
        n['chg'] = 0; n['vf'] = 1 if any(vf6[x] for x in kids) else 0; n['o'] = i
        if tr5[k]: n['tr'] = tr5[k]
        asis5.append(n)
    # To-be Lv.5
    l5of = {k: A6[k]['l5'].split(' ')[0] for k in A6}
    for k in newids:
        if TB[k]['t'] != 'M': l5of[k] = TB[k]['l5']
    subname = {s: v['name'] for s, v in dz['subs'].items()}
    P5 = OrderedDict(); ns5 = {}; mbar = {}
    for i, k in enumerate(L5):
        kids = A5[k]['kids']
        mem = [x for x in kids if TB[x]['t'] != 'X'] + [x for x in newids if TB[x]['t'] != 'M' and TB[x].get('l5') == k]
        gone = [x for x in kids if TB[x]['t'] == 'X']
        ts = [TB[x]['t'] for x in mem]; nA, nN, nH, nO, nX = ts.count('A'), ts.count('N'), ts.count('H'), ts.count('O'), len(gone)
        sa = [TB[x]['sub'] for x in mem if TB[x]['t'] == 'A']
        cs = Counter(sa); subs = sorted(dict.fromkeys(sa), key=lambda s: (-cs[s], sa.index(s)))
        if not mem: kk = 'gone'
        elif set(ts) <= {'H', 'O'}: kk = 'h'
        elif nA >= nN + nH + nO: kk = 'a'
        else: kk = 'nh'
        if kk == 'a':
            cnt = Counter(TB[x]['sub'] for x in mem if TB[x]['t'] == 'A')
            best = max(cnt.values()); ln = next(s for s in subs if cnt[s] == best)
        else: ln = ln5[k]
        parts = [(c, n) for c, n in (('A', nA), ('N', nN), ('H', nH), ('O', nO), ('X', nX)) if n]
        lab = {'A': 'Agent', 'N': '확인', 'H': '사람', 'O': '타 부문', 'X': '소멸'}
        meta = '<span class="mbar">' + ''.join(f'<i class="{c}" style="flex:{n}"></i>' for c, n in parts) + '</span><span class="mtx">' + ' · '.join(f'{lab[c]} {n}' for c, n in parts) + '</span>'
        n = dict(id=k, st=st5[k], c=pos5[k][0], r=0, ln=ln, k=kk, lb=A5[k]['n'])
        if kk == 'a': n['tg'] = subname[ln].replace(' Agent', '')
        elif kk == 'nh': n['tg'] = f'Agent {nA}'
        n['meta'] = meta; n['pid'] = k
        if mem: n['mem'] = mem
        n['vf'] = 1 if any(vf6[x] for x in kids) else 0
        if subs: n['subs'] = subs
        n['o'] = i
        if tr5[k]: n['tr'] = tr5[k]
        ns5[k] = n
        P5[k] = dict(l5=k, mem=mem, gone=gone, note='' if mem else ' / '.join(TB[x]['note'] for x in gone if TB[x].get('note')))
        for s in subs:
            if s != ln: P5[f'{k}@{s}'] = dict(l5=k, mem=[x for x in mem if TB[x].get('sub') == s and TB[x]['t'] == 'A'], gone=[], note='')
    # 신규 M 노드: 선행(Lv.6) 노드가 속한 Lv.5의 열
    m5 = {}
    for k in sorted([k for k in newids if TB[k]['t'] == 'M'], key=lambda k: nodes[k]['o']):
        p = next(p for p in pred[k] if p in nodes)
        ref = m5[p] if p in m5 else ns5[l5of[p]]
        n = dict(id=k, st=ref['st'], c=ref['c'], r=0, ln=TB[k]['sub'], k='mk', lb=TB[k]['lb'], o=(ref['o'] if p in m5 else ref['o'] + 1e-6))
        if trn.get(k): n['tr'] = trn[k]
        m5[k] = n
    order5 = L5 + [k for k in newids if k in m5]
    why5 = []
    for k in L5:
        if ns5[k]['k'] == 'gone':
            g = ns5[k]
            why5.append(dict(id=k + '~why', st=g['st'], c=g['c'], r=0, ln=g['ln'], k='why', **({'tr': g['tr']} if g.get('tr') else {}),   # v33: 경로 줄 그대로 (Lv.5 설명 박스가 박스 밑에)
                             lb=' / '.join(TB[x]['note'] for x in A5[k]['kids'] if TB[x].get('note')), tg='소멸 이유', pid=k, of=k, o=g['o'] + 0.0001))
    # v37 Lv.5 사람 역할 카드: 같은 Lv.5 안에서 주 수행 레인과 다른 조직 레인의 담당자 확인·사람 업무를 그 레인에 따로 표시 (Lv.6과 1:1)
    hc5 = []
    lane_of = lambda x: LN[lk(A6[x])] if x in A6 else TB[x].get('lane')
    for i, k in enumerate(L5):
        m = ns5[k]; mem = m.get('mem') or []
        byl = OrderedDict()
        for x in mem:
            if TB[x]['t'] in ('N', 'H') and lane_of(x) and lane_of(x) != m['ln']: byl.setdefault(lane_of(x), []).append(x)
        for l, xs in byl.items():
            nN_, nH_ = sum(1 for x in xs if TB[x]['t'] == 'N'), sum(1 for x in xs if TB[x]['t'] == 'H')
            parts = [(c, n) for c, n in (('N', nN_), ('H', nH_)) if n]; lab = {'N': '확인', 'H': '사람'}
            meta = '<span class="mbar">' + ''.join(f'<i class="{c}" style="flex:{n}"></i>' for c, n in parts) + '</span><span class="mtx">' + ' · '.join(f'{lab[c]} {n}' for c, n in parts) + '</span>'
            hc = dict(id=f'{k}@{l}', st=m['st'], c=m['c'], r=0, ln=l, k='nh' if nN_ else 'h', lb=A5[k]['n'], tg='사람 역할', meta=meta, pid=k, mem=xs, o=m['o'] + 0.5)
            if m.get('tr'): hc['tr'] = m['tr']
            hc5.append(hc); P5[hc['id']] = dict(l5=k, mem=xs, gone=[], note='')
    all5 = [ns5[k] for k in L5] + hc5 + [m5[k] for k in order5 if k in m5] + why5
    for n in all5 + [{'id': '__'}]:
        if n['id'] in m5 or '~why' in n['id']: P5[n['id']] = dict(l5=None, mem=[], gone=[], note='')
    occ = Counter()
    for n in sorted(all5, key=lambda n: n['o']):
        key = (n['st'], n['ln'], n['c']); n['r'] = occ[key]; occ[key] += 1
    # 엣지: As-Is Lv.5 + Lv.6 Orchestrator 신호를 Lv.5로 투영
    gone5 = {k for k in L5 if ns5[k]['k'] == 'gone'}
    E5n = bypass(E5, gone5)
    g5 = OrderedDict()
    for e in E5n:
        if e[2] != 'r': g5.setdefault(e[0], []).append(e)
    E5n = [e for k in g5 for e in reversed(g5[k])] + [e for e in E5n if e[2] == 'r']
    up = lambda x: x if x in m5 else l5of.get(x, x)
    for a, b, t, lab in Ens:
        if t != 'o': continue
        e = [up(a), up(b), 'o', lab]
        if e[0] != e[1] and not any(f[:3] == e[:3] for f in E5n): E5n.append(e)
    # ================= Lv.4 =================
    L4 = list(A4); short = {l['k']: l.get('short', l['name']) for l in lanes}
    E4 = []
    for i in range(len(L4) - 1): E4.append([L4[i], L4[i+1], 's', ''])
    for k, a in A4.items():
        for p in ids(a.get('rej', '')):
            if p in A4: E4.append([k, p, 'r', '반려'])
    oA4 = OrderedDict(); asis4 = []; ns4 = []; stages = []
    kids6 = lambda k4: [x for k5 in A4[k4]['kids'] for x in A5[k5]['kids']]
    for i, k in enumerate(L4):
        a = A4[k]; st = i + 1; k6 = kids6(k)
        c5 = Counter(ln5[x] for x in a['kids']); c6 = Counter(LN[lk(A6[x])] for x in k6)
        lnk = sorted(c5, key=lambda l: (-c5[l], -c6[l], [ln5[x] for x in a['kids']].index(l)))[0]
        tname = next(t for t, v in LN.items() if v == lnk)
        tie = len([l for l in c5 if c5[l] == c5[lnk]]) > 1
        place = ' · '.join(f'{lname[l]} {c5[l]}' for l in sorted(c5, key=lambda l: (-c5[l], [ln5[x] for x in a['kids']].index(l))))
        oA4[k] = dict(n=a['n'], kids=a['kids'], ty=a['ty'], team=tname, place=place + (' (동수 → 그 아래 레벨 수)' if tie else ''), ln=tname)
        nai = sum(1 for x in k6 if A6[x]['ai'] != '인간 전담')
        part = list(dict.fromkeys(LN[lk(A6[x])] for x in k6))
        n = dict(id=k, st=st, c=0, r=0, ln=lnk, k='h', lb=a['n'],
                 meta=f"Lv5 {len(a['kids'])} · Lv6 {len(k6)}<br>참여 {'·'.join(short[l] for l in part)}<br>AI 활용 {nai}/{len(k6)}")
        if a['ty'] != '단계': n['ty'] = a['ty']
        n['o'] = i; asis4.append(n)
        # To-be
        mem6 = [x for x in k6] + [x for x in newids if TB[x]['st'] == st]
        live = [x for x in mem6 if TB[x]['t'] != 'X']
        cnt = Counter(TB[x]['t'] for x in mem6)
        nA, nN, nH, nO, nX = cnt['A'], cnt['N'], cnt['H'], cnt['O'], cnt['X']
        hum = [x for x in k6 if TB[x]['t'] in 'NH'] + [x for x in newids if TB[x]['st'] == st and TB[x]['t'] in 'NH']
        hl = ' · '.join(nodes[x]['lb'] for x in hum[:3]) + (f' 등 {len(hum)}개' if len(hum) > 3 else '')
        parts = [f'{lab} {v}' for lab, v in (('Agent', nA), ('담당자 확인', nN), ('사람', nH), ('타 부문', nO), ('소멸', nX)) if v]
        ns4.append(dict(id=k, st=st, c=0, r=0, ln=lnk, k='h', lb=a['n'], meta=' · '.join(parts) + (f'<br>사람: {hl}' if hum else ''), o=st * 100 - 100))
        for s in dz['subs']:
            ms = [x for x in live if TB[x].get('sub') == s]
            if not ms: continue
            lbs = [nodes[x]['lb'] for x in ms]
            kk = 'mk' if TB[ms[0]]['t'] == 'M' else ('na' if all(x in newids for x in ms) else 'a')
            ns4.append(dict(id=f'{s}@{st}', st=st, c=0, r=0, ln=s, k=kk, lb=' · '.join(lbs[:3]) + (f' 등 {len(lbs)}개' if len(lbs) > 3 else ''),
                            tg=f'{len(ms)}건', mem=ms, o=st * 100 - 98))
        stages.append(dict(n=st, id=k, name=a['n'] + (' (공통/제반)' if re.search(r'공통|제반', a.get('lv1', '') or '') and '공통' not in a['n'] else ''), asis=f"Lv5 {len(a['kids'])} · Lv6 {len(k6)} · AI 활용 {nai}",
                           ns=' · '.join(f'{lab} {v}' for lab, v in (('Agent', nA), ('확인', nN), ('사람', nH), ('타 부문', nO), ('소멸', nX)) if v),
                           gate=dz['stage_gate'].get(k, ''), n6=len(k6), nA=nA, nN=nN, nH=nH, nX=nX, **({'nO': nO} if nO else {})))
    up4 = {}
    for x in nodes:
        b = x.split('~')[0]; t = TB.get(b, {})
        if t.get('t') in ('A', 'M') and x == b: up4[x] = f"{t['sub']}@{nodes[x]['st']}"
        else: up4[x] = L4[nodes[x]['st'] - 1]
    E4n = [list(e) for e in E4]
    for a, b, t, lab in Ens:
        if t == 'r': continue
        e = [up4[a], up4[b], 'o' if t == 'o' else 's', lab if t == 'o' else '']
        if e[0] == e[1]: continue
        if any(f[:3] == e[:3] or (e[2] == 's' and f[:2] == e[:2]) for f in E4n): continue
        E4n.append(e)
    g4 = lv4_groups(A4, A5, TB, newids, ln5, E5, asis4, ns4, oA4, {n['id']: i for i, n in enumerate(ns6)}) if any(a.get('g4') for a in A5.values()) else None
    if g4:
        asis4, ns4, E4 = g4; E4n = [list(e) for e in E4]
        g_of = {k5: n['id'] for n in asis4 if (n['id'].count('-') == 3 or n['id'] not in A4) for k5 in A4.get(n['id'], {}).get('kids', []) or oA4[n['id']]['kids']}
        for n in asis5:
            if n['id'] in g_of: n['pid'] = g_of[n['id']]
    return dict(PAR=PAR, A6=oA6, A5=oA5, A4=oA4, stages=stages, P5=P5, asis4=dict(nodes=asis4, edges=E4), ns4=dict(nodes=ns4, edges=E4n), asis6=dict(nodes=asis6, edges=E6), ns6=dict(nodes=ns6, edges=Ens),
                asis5=dict(nodes=asis5, edges=E5), ns5=dict(nodes=apply_fix(all5, dz.get('pos_fix', {}).get('5', {})), edges=E5n))

def lv4_groups(A4, A5, TB, newids, ln5, E5, asis4, ns4, oA4, ord6=None):
    """v15 방식 Lv.4: 엑셀 Lv.4 묶음을 박스로 (F2 양식). 공통/제반 단계(Lv.1에 '공통' '제반')는 단계 박스 하나 그대로"""
    L4 = list(A4); G = OrderedDict(); gst = {}
    for i, k in enumerate(L4):
        if re.search(r'공통|제반', A4[k].get('lv1', '') or ''): continue
        for k5 in A4[k]['kids']:
            g = A5[k5].get('g4id') or '-'.join(k5.split('-')[:4]); G.setdefault(g, []).append(k5); gst[g] = i + 1
    if not G: return None
    box, order = {}, []
    for i, k in enumerate(L4):
        for k5 in A4[k]['kids']:
            b = A5[k5].get('g4id') or '-'.join(k5.split('-')[:4]); box[k5] = b if b in G else k
            if box[k5] not in order: order.append(box[k5])
    stn = {g: gst[g] for g in G}; stn.update({k: i + 1 for i, k in enumerate(L4) if k in order and k not in G})
    E4 = []
    for a, b, t, lab in E5:
        ga, gb = box.get(a), box.get(b)
        if not ga or not gb or ga == gb: continue
        e = [ga, gb, 'r', lab] if t == 'r' else [ga, gb, 's', '']
        if not any(f[:2] == e[:2] for f in E4): E4.append(e)
    pred = defaultdict(list)
    for a, b, t, _ in E4:
        if t != 'r' and stn[a] == stn[b]: pred[b].append(a)
    col = {}
    def colof(g, path=()):
        if g in col: return col[g]
        col[g] = max([colof(a, path + (g,)) + 1 for a in pred[g] if a not in path], default=0); return col[g]
    for g in order: colof(g)
    old_a = {n['id']: n for n in asis4}; old_n = {n['id']: n for n in ns4}
    out_a, out_n, rowc = [], [], defaultdict(int)
    for o, g in enumerate(order):
        ks5 = G.get(g) or A4[g]['kids']; k6 = [x for k5 in ks5 for x in A5[k5]['kids']]
        l5s = [ln5[x] for x in ks5]; c5 = Counter(l5s); lnk = sorted(c5, key=lambda l: (-c5[l], l5s.index(l)))[0]
        st, c = stn[g], col[g]; r = rowc[(st, lnk, c)]; rowc[(st, lnk, c)] += 1
        if g not in G:
            out_a.append(dict(old_a[g], c=c, r=r)); out_n.append(dict(old_n[g], c=c, r=r)); continue
        mem6 = k6 + sorted([x for x in newids if TB[x].get('l5') in ks5 and TB[x]['t'] != 'M'], key=lambda x: (ord6 or {}).get(x, 0))
        cnt = Counter(TB[x]['t'] for x in mem6); nA, nN, nH, nO, nX = cnt['A'], cnt['N'], cnt['H'], cnt['O'], cnt['X']
        nm = A5[ks5[0]].get('g4') or g
        tag = re.match(r'^\[([^\]]+)\]', nm); tr = re.split(r'\s*-\s*', tag.group(1))[0].strip() if tag else None
        na = OrderedDict(id=g, st=st, c=c, r=r, ln=lnk, k='h', lb=nm, meta=f"Lv5 {len(ks5)} · Lv6 {len(k6)}", o=o)
        if tr: na['tr'] = tr
        live = [x for x in mem6 if TB[x]['t'] != 'X']
        seq = [TB[x].get('sub') for x in live if TB[x]['t'] == 'A']; sc = Counter(seq)
        kk = 'a' if nA and nA >= nN + nH + nO else ('h' if not nA and not nN else 'nh')
        lns = sorted(sc, key=lambda x: (-sc[x], seq.index(x)))[0] if kk == 'a' and sc else lnk
        parts = [f'{lab} {v}' for lab, v in (('Agent', nA), ('담당자 확인', nN), ('사람', nH), ('타 부문', nO), ('소멸', nX)) if v]
        nn = OrderedDict(id=g, st=st, c=c, r=r, ln=lns, k=kk, lb=nm, meta=' · '.join(parts), o=o)
        if tr: nn['tr'] = tr
        nn['mem'] = live
        out_a.append(na); out_n.append(nn)
        oA4[g] = OrderedDict(n=nm, kids=ks5, ty='업무', team=A5[ks5[0]]['team'], place='', ln=lnk)
    return out_a, out_n, E4

LAYOUT = {"4": {"colW": 300, "nodeW": 256, "rowH": 132, "nodeH": 104, "rowHA": 114, "nodeHA": 86, "pad": 14, "gap": 40, "bandH": 32},
          "5": {"colW": 200, "nodeW": 150, "rowH": 134, "nodeH": 100, "pad": 14, "gap": 40, "bandH": 32},
          "6": {"colW": 184, "nodeW": 138, "rowH": 130, "nodeH": 96, "pad": 14, "gap": 40, "bandH": 32}}
def ncols(nodes, nst):
    return {str(s): max([n['c'] for n in nodes if n['st'] == s], default=0) + 1 for s in range(1, nst + 1)}
def summary(asis, dz, TB, A5, mode):
    A6 = asis['A6']
    c5 = Counter()
    for k, a in A5.items():
        s = {('H' if TB[x]['t'] == 'O' else TB[x]['t']) for x in a['kids']} - {'X'}
        c5['X' if not s else 'A' if s == {'A'} else 'H' if s == {'H'} else 'N'] += 1
    c6 = Counter(TB[k]['t'] for k in A6)
    new = [k for k in TB if k not in A6 and TB[k]['t'] != 'M']
    cn = Counter(TB[k]['t'] for k in new)
    if mode == 'agent_only':   # 참조 방식: 신규 = Agent 신규만
        nNew = cn['A']; nN = c6['N']
    else:                      # 확정 방식: 신규 = Agent 업무 + 담당자 확인 (판정별 칸은 As-Is 행만)
        nNew = len(new); nN = c6['N']
    n5, n6 = len(A5), len(A6)
    t6 = n6 - c6['X'] + nNew
    return [
        dict(lv=5, text=f"Lv.5 (As-Is {n5}단계 → To-be {n5 - c5['X']}단계): AI 대체 ({c5['A']}), 담당자 확인 ({c5['N']}), 소멸 ({c5['X']}), 잔존 ({c5['H']})",
             tip="Lv.5 분류 기준 — AI 대체: 하위 Lv.6이 모두 Agent / 담당자 확인: Agent와 사람이 함께 수행 (Agent 결과를 사람이 확인·판단) / 잔존: 사람만 / 소멸: 하위 Lv.6이 모두 소멸",
             parts=[["AI 대체", c5['A'], "A"], ["담당자 확인", c5['N'], "N"], ["잔존", c5['H'], "H"], ["소멸", c5['X'], "X"]]),
        dict(lv=6, text=f"Lv.6 (As-Is {n6}단계 → To-be {t6}단계): AI 대체 ({c6['A']}), 담당자 확인 ({nN}), 소멸 ({c6['X']}), 잔존 ({c6['H']}), " + (f"타 부문 ({c6['O']}), " if c6['O'] else '') + f"신규 ({nNew})",
             tip=f"To-be {t6} = As-Is {n6} − 소멸 {c6['X']} + 신규 {nNew} ({'Agent 업무' if mode == 'agent_only' else f"Agent 업무 {cn['A']} · 담당자 확인 {cn['N']}"}). Orchestrator 표시는 단계 수에서 제외",
             parts=[["AI 대체", c6['A'], "A"], ["담당자 확인", nN, "N"], ["잔존", c6['H'], "H"]] + ([["타 부문", c6['O'], "O"]] if c6['O'] else []) + [["소멸", c6['X'], "X"], ["신규", nNew, "new"]])]
KO = {'asis': 'id st c r ln k lb meta ai pid ty chg vf o tr'.split(), 'ns': 'id st c r ln k lb tg meta pid mem vf subs of o tr'.split()}
def korder(n, sc):
    return {k: n[k] for k in KO[sc] if k in n}
def scenario_tags(asis, source=None, common=(), lanes=()):
    """시나리오 = 업무명 대괄호 태그 "[줄 - 갈래]" (source: lv4 = 엑셀 Lv.4 이름, lv5 = Lv.5 이름). common 태그는 공통 업무로"""
    A5 = asis['A5']
    src = source or ('lv4' if any(a.get('g4') for a in A5.values()) else 'lv5')
    def raw(a):
        m = re.match(r'^\[([^\]]+)\]', (a.get('g4') if src == 'lv4' else a.get('g3') if src == 'lv3' else a['n']) or '')   # lv3 = Lv.3 트랙 태그 (BX)
        if not m: return None
        l, sb = (re.split(r'\s*-\s*', m.group(1).strip(), maxsplit=1) + [''])[:2]
        return l.strip(), sb.strip()
    R = {k: raw(a) for k, a in A5.items()}
    heads = {t[0] for t in R.values() if t}
    def tag(t):
        if not t or t[0] in common: return None
        if '/' in t[0] and all(x in heads for x in t[0].split('/')): return None   # [촬영/비촬영-…] = 두 경로 공통
        return t
    t5 = {k: tag(t) for k, t in R.items()}
    st5 = {k5: i + 1 for i, s4 in enumerate(asis['A4'].values()) for k5 in s4['kids']}
    lines, subl, scen = [], [], OrderedDict()
    for k, t in t5.items():
        if not t: continue
        if t[0] not in lines: lines.append(t[0])
        if t[1] and t[1] not in subl: subl.append(t[1])
    for k5, t in t5.items():
        if not t: continue
        L = scen.setdefault(str(st5[k5]), [])
        if t[1] and dict(l=t[0], s=t[1]) not in L: L.append(dict(l=t[0], s=t[1]))
        if not t[1] and not any(x['l'] == t[0] for x in L): L.append(dict(l=t[0], s=''))
    # Lv.5 이름의 대괄호 태그 = 줄 안의 갈래 (예: [촬영] 줄 안의 [모델/성우 섭외])
    sub5 = []
    for k5, t in list(t5.items()):
        if not t or t[1]: continue
        m = re.match(r'^\[([^\]]+)\]', A5[k5]['n'] or '')
        orgs = [x for l in lanes for x in (l.get('name', ''), l.get('sub', '')) if x]
        if m and m.group(1).strip() != t[0] and not any(m.group(1).strip() in o for o in orgs):   # [제작]처럼 조직 이름 태그는 갈래가 아님
            t5[k5] = (t[0], m.group(1).strip()); sub5.append(m.group(1).strip())
            L = scen[str(st5[k5])]
            if dict(l=t[0], s=t5[k5][1]) not in L:
                i = max([j for j, x in enumerate(L) if x['l'] == t[0]], default=len(L) - 1); L.insert(i + 1, dict(l=t[0], s=t5[k5][1]))
    for k, L in scen.items():        # 줄만(공통) 항목: 그 줄의 첫 Lv.5가 줄만이면 남김, 갈래가 먼저 오면 뺌
        first = {}
        for k5 in [x for x, v in t5.items() if v and str(st5[x]) == k]:
            first.setdefault(t5[k5][0], t5[k5][1])
        scen[k] = [x for x in L if x['s'] or first.get(x['l']) == '' or not any(y['l'] == x['l'] and y['s'] for y in L)]
    subl += [x for x in dict.fromkeys(sub5) if x not in subl] and []
    return t5, lines, subl, scen, list(dict.fromkeys(sub5))
def apply_scenario(P, asis, dz):
    sc = dz.get('scenario')
    if not sc or sc.get('mode') in (None, 'off'): return P
    t5, lines, subl, scen, sub5 = scenario_tags(asis, sc.get('source'), set(sc.get('common', [])), dz.get('lanes', []))
    A6, TB = asis['A6'], dz['tb']
    def l5(nid):
        b = nid.split('~')[0]
        if b in A6: return A6[b]['l5'].split(' ')[0]
        if b in asis['A5']: return b
        return TB.get(b, {}).get('l5')
    for lv in ('5', '6'):
        for scr in ('asis', 'ns'):
            for n in P['views'][lv][scr]['nodes']:
                n.pop('tr', None); t = t5.get(l5(n['id']))
                if t: n['tr'] = t[0] + ('·' + t[1] if t[1] else '')
    P['lines'] = lines + ['']; P['sublines'] = subl + [''] + [x for x in sub5 if x not in subl]; P['scen'] = scen; P['paths'] = []; P['subl'] = []
    P['ui'] = dict(P['ui'], lineMode='lines', scenPick=False)     # 병렬박스만 지원 (시나리오 고르기는 제외)
    return P
def trace(asis, dz):
    """v38 As-Is → To-be 변경 추적 (상세 창 'As-Is 대비 변경'): 담당 전환·역할 전환·업무명 변경·흡수(소멸 → 흡수처)·통합(merge, 실린더 형식)·레인 이동(bon0)
    ② 재구성 설계는 ref(이어받은 As-Is 업무)로 '통합 원본'을 만든다."""
    A6, TB = asis['A6'], dz['tb']; lanes = dz.get('lanes', [])
    lane = {b: l['name'] for l in lanes for b in l.get('bon', [])}; lk = {l['k']: l['name'] for l in lanes}
    SN = {s: v['name'] for s, v in dz['subs'].items()}
    chg = {i: c for c in (dz.get('memo') or {}).get('changes', []) for i in c.get('ids', [])}
    out = {}
    for k, t in TB.items():
        if t['t'] == 'X': continue
        x = {}; cur = t.get('lb') or (A6[k]['n'] if k in A6 else '')
        src = [r for r in (t.get('ref') or []) if r in A6]
        if k in A6:
            fr = lane.get(A6[k]['bon'], A6[k]['bon']); x.update({'from': fr, 'old': A6[k]['n'], 'cur': cur})
            x['kind'] = {'A': '담당 전환 — 사람 수행에서 Agent 수행으로', 'N': '역할 전환 — 직접 작업에서 담당자 확인·결정으로', 'O': '타 부문 설계 대상', 'M': ''}.get(t['t'], '변경 없음 — 사람이 직접 수행')
            if t['t'] == 'A': x['to'] = SN.get(t.get('sub'), '')
            elif t['t'] in ('N', 'H'): x['to'] = fr
            if A6[k].get('bon0'): x['why'] = f"엑셀 담당본부 '{A6[k]['bon0']}'(공동 담당)을 '{fr}' 레인에 배치했습니다."
        elif src:
            x.update(kind='재구성 — As-Is 업무를 이어받은 To-be 업무', cur=cur, to=SN.get(t.get('sub'), '') or lk.get(t.get('lane'), ''),
                     src=[[r, A6[r]['n'], lane.get(A6[r]['bon'], A6[r]['bon'])] for r in src])
        else:
            x.update(kind='신규 — As-Is에 없던 업무', to=SN.get(t.get('sub'), '') or lk.get(t.get('lane'), ''))
            if k in chg: x['why'] = chg[k].get('desc', '')
        for m in t.get('merge') or []:                       # 실린더식 통합(①): 함께 합친 As-Is 업무
            if m in A6: x.setdefault('merged', []).append([m, A6[m]['n']])
        if t.get('merge_why'): x['why'] = t['merge_why']
        ab = [[xk, A6[xk]['n'], xt.get('why', '')] for xk, xt in TB.items() if xt['t'] == 'X' and xt.get('to') == k and xk in A6]
        if ab: x['abs'] = ab; x['kind'] = (x.get('kind') or '') + ' · As-Is 업무 흡수'
        if x: out[k] = x
    return out
def assemble(asis, dz, r):
    A6 = asis['A6']; TB = dz['tb']; nst = len(asis['A4'])
    st6 = {n['id']: n['st'] for n in r['ns6']['nodes']}
    TBo = OrderedDict()
    for k, t in TB.items():
        base = A6.get(k)
        TBo[k] = dict(t=t['t'], sub=t.get('sub'), note=t.get('note', ''), lb=t.get('lb') or (base['n'] if base else ''),
                      tg=t.get('tg', ''), ref=t.get('ref', []), st=st6[k],
                      l5=base['l5'].split(' ')[0] if base else t['l5'])
    subs = OrderedDict()
    for s, v in dz['subs'].items():
        tasks = [k for k in TB if TB[k].get('sub') == s]
        tasks = sorted(tasks, key=lambda k: list(dz['tb']).index(k) if k in dz['tb'] else 1e9)
        subs[s] = dict(id=s, band=v['band'], name=v['name'], desc=v['desc'], tasks=tasks,
                       stages=sorted({st6[k] for k in tasks}), d=v['d'], s=v['s'],
                       **{f: v[f] for f in ('dg', 'sp', 'of', 'og', 'wh') if v.get(f)})
    views = {}
    for lv in ('4', '5', '6'):
        views[lv] = {}
        for sc in ('asis', 'ns'):
            v = r[sc + lv]; views[lv][sc] = dict(nodes=[korder(n, sc) for n in v['nodes']], edges=v['edges'], ncols=ncols(v['nodes'], nst) if lv != '4' or any(n['id'].count('-') == 3 or n['id'] not in asis['A4'] for n in v['nodes']) else {str(s): 1 for s in range(1, nst + 1)})
    # 경로(병렬 줄): 업무명 대괄호 태그에서 자동, design.paths로 문구 보충
    pv = path_vocab(asis['A5']) or path_vocab({k: dict(n=v['n']) for k, v in A6.items()})
    over = {p['v']: p for p in dz.get('paths', [])}
    paths = [dict(v=v, **{k: x for k, x in over.get(v, {}).items() if k != 'v'}) for v in pv[:2]]
    if 'paths' in dz and not dz['paths']: paths = []      # 경로 필터를 쓰지 않는 부문
    subl = dz.get('subl')
    if subl is None:
        subl = []
        for n in r['ns6']['nodes']:
            for t in (n.get('tr') or '').split('·')[1:] + ([] if '·' in (n.get('tr') or '') else [n.get('tr') or '']):
                if t and t not in pv and t not in subl: subl.append(t)
        subl = subl[:2]
    result = OrderedDict(stages=r['stages'], lanes=[dict(k=l['k'], name=l['name'], sub=l['sub'], who=l.get('who', l['name']), **({'memo': l['memo']} if l.get('memo') else {})) for l in dz['lanes']],
        layout=LAYOUT, views=views, bands=dz['bands'], subs=subs, A6=r['A6'], A5=r['A5'], A4=r['A4'], TB=TBo, P5=r['P5'],
        text=dz['meta']['text'], start=dz['meta']['start'], summary=summary(asis, dz, TB, asis['A5'], dz.get('summary_mode', 'all')),
        story=dz['story'], sysinfo=dz['sysinfo'], dfmt=dz['dfmt'], outs=dz['outs'], when=dz['when'], whenHave=dz['whenHave'],
        form=dz['form'], outnew=dz['outnew'], tour=dz.get('tour', {}), paths=paths, subl=subl, ui=dz.get('ui', {}),
        desc=dz.get('desc', {}), ax=dz.get('ax') or dict(cat={}, tasks=[], src=''))
    if asis.get('source_html'):
        from source_asis import validate
        result['sourceAsis'] = validate(asis['source_html'], asis)
    return result
if __name__ == '__main__':
    _dz = json.load(open(sys.argv[2], encoding='utf-8')) if len(sys.argv) > 2 else {}
    if not (_dz.get('structure') or {}).get('confirmed'):
        print('주의 [구조] 확인받은 구조가 설계 파일에 없음 — 원천에 명시된 분기·환류 연결을 그대로 보존. 구조를 확인받아 structure.py save로 저장한 뒤 다시 생성')
    try:   # v33: 워딩 점검 — 업무명·이름표·문장·Agent 페이지 전체, 오류가 있으면 HTML을 만들지 않음 (모든 부문 공통)
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import style_check as _sc
        _A = json.load(open(sys.argv[1], encoding='utf-8')); _dz['_a6names'] = {k: a['n'] for k, a in _A['A6'].items()}
        _v = [x for x in _sc.name_check(_dz, _A) + _sc.nat_check(_dz) if x[0] == '오류'] + _sc.check(_dz); _dz.pop('_a6names', None)
        if _v:
            print(f'주의 [워딩] 점검 오류 {len(_v)}건 — HTML은 계속 생성. style_check.py design.json asis.json로 확인해 고친 뒤 다시 생성 (예: ' + ' / '.join(str(x[1]) + ' ' + str(x[2]) for x in _v[:3]) + ')')
    except SystemExit: raise
    except Exception as _e: print('경고 [워딩] 점검을 돌리지 못함:', _e)
    if not str((_dz.get('inputs') or {}).get('answer', '')).strip():
        print('주의 [자료] 첫 안내 메시지 답이 기록되어 있지 않음 — HTML은 계속 생성 (inputs.py save --answer로 기록)')
    _st = _dz.get('structure') or {}
    if not str(_st.get('answer', '')).strip():
        print('주의 [구조] 구조 확인 답이 기록되어 있지 않음 — HTML은 계속 생성 (structure.py save --answer로 기록)')
    import hashlib as _h
    _rows = sorted([k, str(a.get('pre', '')), str(a.get('post', '')), str(a.get('br', '')), str(a.get('rej', '')), str(a.get('rejr', ''))] for k, a in json.load(open(sys.argv[1], encoding='utf-8'))['A6'].items())
    if _st and _st.get('basis') != _h.sha1(json.dumps(_rows, ensure_ascii=False).encode('utf-8')).hexdigest()[:16]:
        print('주의 [구조] 엑셀의 선행·후행·분기·반려 칸이 구조 확인 때와 다름 — HTML은 계속 생성. structure.py로 다시 정리해 확인받은 뒤 다시 생성')
    asis = json.load(open(sys.argv[1])); dz = json.load(open(sys.argv[2]))
    res = compile_(asis, dz)
    json.dump(res, open(sys.argv[3], 'w'), ensure_ascii=False)
    if len(sys.argv) > 4:
        P = apply_scenario(assemble(asis, dz, res), asis, dz); P['trace'] = trace(asis, dz)
        json.dump(P, open(sys.argv[4], 'w'), ensure_ascii=False)
