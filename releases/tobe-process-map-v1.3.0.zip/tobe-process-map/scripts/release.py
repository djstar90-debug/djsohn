"""Build candidate HTML+XLSX from one validated design; certify after final QC.

python scripts/release.py build asis.json design.json output-directory
python scripts/qc_browser.py output-directory/map.html work/qc final
python scripts/qc_browser.py output-directory/map.html work/qc result
python scripts/release.py certify output-directory work/qc/final.json
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
import copy
import restructure
import check_design
import style_check
import build_html
import verify_input
import export_excel

ROOT=Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))

class ValidationError(ValueError):
    def __init__(self, report):
        self.report = report
        errors = [x['message'] for x in report['issues'] if x['severity'] == 'error']
        message = '\n'.join(errors[:8])
        if len(errors) > 8: message += f'\n... 추가 {len(errors)-8}건; 구조화된 diagnostics 참조'
        super().__init__(message or '검증 실패')


def _validate(asis, design):
    """Collect gate findings once. Internal synthesis may be reused within build only."""
    findings, phases, warnings, input_issues = [], {}, [], []
    synthesized = None
    def add(phase, severity, code, message):
        findings.append({'phase':phase,'severity':severity,'code':code,'message':str(message)})
    def failure(phase, exc):
        phases[phase] = 'failed'
        add(phase, 'error', 'INVALID_DATA', f'{phase}: {type(exc).__name__}: {exc}')
    caught = (ValueError, KeyError, TypeError, IndexError, AttributeError)
    if not isinstance(asis, dict) or not isinstance(design, dict):
        add('schema','error','INVALID_ROOT','asis/design는 JSON 객체여야 합니다.')
    elif design.get('mode') != 'restructure':
        add('schema','error','LEGACY_MODE','최종 배포에는 mode=restructure 필요; legacy 설계는 명시적으로 이관')
    if isinstance(asis, dict):
        try:
            input_issues = verify_input.validate(asis)
            conflicts = [i for i in input_issues if i['code']=='SOURCE_REFERENCE_CONFLICT']
            for item in input_issues:
                add('input',item['severity'],item['code'],item['message'])
            if asis.get('source_html'):
                from source_asis import validate as validate_source
                validate_source(asis['source_html'],asis)
                difference=asis['source_html'].get('scope_difference',{})
                if difference.get('excel_unmapped') or difference.get('html_unmapped'):
                    add('input','error','SOURCE_SCOPE_MISMATCH','As-Is HTML/Excel 범위 불일치: 원천 매핑을 해결한 뒤 배포')
            elif conflicts:
                for item in conflicts: add('input','error','UNRESOLVED_SOURCE_REFERENCE',item['message'])
            phases['input'] = 'completed'
        except caught as exc: failure('input', exc)
    if isinstance(asis,dict) and isinstance(design,dict):
        try:
            issues = restructure.check(asis,design)
            for severity,tag,message in issues:
                add('design','error' if severity=='오류' else 'warning',tag,f'{tag} {message}')
                if severity!='오류': warnings.append(f'{tag} {message}')
            phases['design'] = 'completed'
        except caught as exc: failure('design',exc)
        # A malformed graph cannot be safely synthesized; other independent findings remain available.
        if not any(x['severity']=='error' for x in findings):
            try:
                synthesized = restructure.synth(asis,copy.deepcopy(design))
                a,d = synthesized
                errs,warns,_ = check_design.run(a,copy.deepcopy(d))
                for message in errs: add('content','error','CONTENT',message)
                for message in warns: add('content','warning','CONTENT',message)
                warnings += warns
                phases['content'] = 'completed'
                style=style_check.check(copy.deepcopy(d))+[x for x in style_check.name_check(d,a) if x[0]=='오류']
                dd=copy.deepcopy(d); dd['_a6names']={k:v['n'] for k,v in a['A6'].items()}
                style += [x for x in style_check.nat_check(dd) if x[0]=='오류']
                for item in style: add('style','error','STYLE','[문구] '+str(item))
                phases['style']='completed'
            except caught as exc: failure('content_or_style',exc)
        else:
            phases['content']='skipped_invalid_prerequisite'; phases['style']='skipped_invalid_prerequisite'
    dispositions=design.get('qa_dispositions',{}) if isinstance(design,dict) else {}
    if not isinstance(dispositions,dict):
        add('review','error','INVALID_DISPOSITIONS','qa_dispositions는 경고별 검토 사유를 담은 객체여야 합니다.');dispositions={}
    for message in warnings:
        if not str(dispositions.get(message,'')).strip():
            add('review','error','UNDISPOSED_WARNING','[경고 검토 미완료] '+message)
    errors=sum(item['severity']=='error' for item in findings)
    report={'status':'failed' if errors else 'passed','issues':findings,'phases':phases,
            'counts':{'errors':errors,'warnings':sum(item['severity']=='warning' for item in findings)},
            'warnings':warnings,'input_issues':input_issues,'dispositions':dispositions}
    return report, synthesized


def validate_only(asis, design):
    """JSON-serializable gate report; does not compile or write output files."""
    return _validate(asis,design)[0]


def build(asis, design, dest):
    dest=Path(dest)
    if dest.exists() and any(dest.iterdir()): raise ValueError('출력 폴더가 비어 있지 않습니다. 새 버전 폴더를 사용하세요.')
    report, synthesized = _validate(asis,design)
    if report['status'] != 'passed': raise ValidationError(report)
    warnings=report['warnings']; input_issues=report['input_issues']; dispositions=report['dispositions']
    conflicts=[i for i in input_issues if i['code']=='SOURCE_REFERENCE_CONFLICT']
    pmd=restructure._build_validated(asis,design,synthesized=synthesized)
    html=build_html.build((ROOT/'assets/shell.html').read_text(),(ROOT/'assets/engine.js').read_text(),pmd,design)
    dest.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='pm-build-',dir=dest.parent) as tmp:
        work=Path(tmp)
        (work/'map.html').write_text(html,encoding='utf-8')
        verification=export_excel.write(asis,design,pmd,work/'map.xlsx',html=work/'map.html')
        for name,data in [('asis',asis),('design',design),('pmd',pmd)]:
            (work/(name+'.json')).write_bytes(export_excel.canonical(data))
        manifest={'version':'1.3.0','status':'candidate_requires_browser_qc',
                  'counts':{'asis_lv6':len(asis['A6']),'tobe_lv6':len(restructure.tasks(design))},
                  'warnings':warnings,'dispositions':dispositions,'input_issues':input_issues,
                  'validation':report,'excel_verification':verification,
                  'source_reference_policy':'validated original HTML graph takes precedence' if conflicts else 'no unresolved references',
                  'files':{p.name:sha(p) for p in sorted(work.iterdir())}}
        (work/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
        dest.mkdir(exist_ok=True)
        for file in work.iterdir(): os.replace(file,dest/file.name)
    return manifest

def certify(dest,qc_path):
    from qc_browser import failures, runner_fingerprint, PROFILE
    dest=Path(dest); m=read(dest/'manifest.json'); qc_bytes=Path(qc_path).read_bytes(); q=json.loads(qc_bytes)
    current_hashes={}
    for name,h in m['files'].items():
        current_hashes[name]=sha(dest/name)
        if current_hashes[name]!=h: raise ValueError(f'생성 후 파일 변경: {name}')
    if q.get('sha256')!=current_hashes.get('map.html') or q.get('part')!='final': raise ValueError('현재 HTML의 final QC가 아님')
    if m.get('version')=='1.3.0' and (q.get('runner_sha256')!=runner_fingerprint() or q.get('profile')!=PROFILE): raise ValueError('현재 검증기·브라우저 조건의 QC가 아님; 전체 QC 재실행 필요')
    if q.get('status')!='passed' or failures(q): raise ValueError('최종 브라우저 QC 실패: '+str(failures(q)))
    export_excel.verify(dest/'map.xlsx',dest/'map.html')
    m.update(status='passed',browser_qc_sha256=hashlib.sha256(qc_bytes).hexdigest(),browser_qc_summary=q['summary'])
    (dest/'browser-qc.json').write_bytes(qc_bytes)
    (dest/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
    return m

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__); sub=parser.add_subparsers(dest='cmd',required=True)
    b=sub.add_parser('build'); b.add_argument('asis'); b.add_argument('design'); b.add_argument('output')
    v=sub.add_parser('validate'); v.add_argument('asis'); v.add_argument('design')
    c=sub.add_parser('certify'); c.add_argument('output'); c.add_argument('qc')
    for command in (b,v,c): command.add_argument('--diagnostics',help='전체 구조화된 검증 결과 JSON 저장 경로')
    args=parser.parse_args()
    def save_diagnostics(value):
        if args.diagnostics:
            target=Path(args.diagnostics);target.parent.mkdir(parents=True,exist_ok=True)
            target.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    try:
        if args.cmd=='validate':
            result=validate_only(read(args.asis),read(args.design))
            save_diagnostics(result)
            print(json.dumps({'status':result['status'],'counts':result['counts'],'issues':result['issues'][:8]},ensure_ascii=False,indent=2))
            sys_exit=2 if result['status']!='passed' else 0
            raise SystemExit(sys_exit)
        result=build(read(args.asis),read(args.design),args.output) if args.cmd=='build' else certify(args.output,args.qc)
        save_diagnostics(result)
        print(json.dumps({'version':result['version'],'status':result['status'],'counts':result.get('counts',{})},ensure_ascii=False,indent=2))
    except (ValueError,KeyError,TypeError,IndexError,AttributeError) as exc:
        report=exc.report if isinstance(exc,ValidationError) else {'status':'failed','issues':[{'phase':args.cmd,'severity':'error','code':'BUILD_ERROR','message':str(exc)}]}
        save_diagnostics(report)
        parser.exit(2,'QA BLOCKED: '+str(exc)+'\n')
