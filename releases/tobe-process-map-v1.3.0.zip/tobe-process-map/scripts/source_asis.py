"""Preserve a supplied As-Is HTML as an immutable, source-rendered view.

capture HTML ASIS.json [--out OUT.json] stores exact UTF-8 source bytes, hashes,
DATA + saved-edit snapshot, and explicit Excel-ID correspondence. Never invents
an edge or merges nodes to make differently scoped sources appear equivalent.
verify ASIS.json validates the attachment and its Excel basis.
"""
import argparse, base64, copy, hashlib, json, re
from pathlib import Path


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':')).encode()).hexdigest()


def basis(asis):
    return digest({k: asis.get(k, {}) for k in ('A4', 'A5', 'A6')})


def snapshot(text):
    """Read JSON, never execute input JavaScript. Saved edits override base DATA."""
    match = re.search(r'\b(?:const|let|var)\s+DATA\s*=\s*', text)
    if not match:
        raise ValueError('As-Is HTML: supported JSON DATA assignment is missing; do not reconstruct silently')
    try:
        data, _ = json.JSONDecoder().raw_decode(text[match.end():])
    except (ValueError, TypeError) as exc:
        raise ValueError('As-Is HTML DATA must be a JSON object') from exc
    match = re.search(r'<script\b[^>]*\bid=["\']s04SavedEdits["\'][^>]*>(.*?)</script\s*>', text, re.S | re.I)
    if match:
        saved = json.loads(match.group(1))
        for key in ('lv3', 'lv4', 'lv5', 'lv6'):
            if key in saved:
                data[key] = saved[key]
        for key in ('orgs', 'stages'):
            if '__' + key in saved:
                data[key] = saved['__' + key]
    for level in ('lv4', 'lv5', 'lv6'):
        view = data.get(level)
        if not isinstance(view, dict) or not isinstance(view.get('nodes'), list) or not isinstance(view.get('edges'), list):
            raise ValueError(f'As-Is HTML: missing nodes/edges at {level}')
        ids = [n['id'] for n in view['nodes']]
        if len(set(ids)) != len(ids):
            raise ValueError(f'As-Is HTML: duplicate IDs at {level}')
        for edge in view['edges']:
            if len(edge) < 3 or edge[0] not in ids or edge[1] not in ids:
                raise ValueError(f'As-Is HTML: dangling/malformed edge at {level}: {edge[:2]}')
    return data


def correspondence(data, asis):
    """Source row AND task label first; ID+label only when source rows are absent."""
    a6 = asis['A6']; result = {}; unmatched = []
    for node in data['lv6']['nodes']:
        key = node['id']
        label = node.get('task') or node.get('label', '')
        candidates = [k for k, row in a6.items()
                      if row.get('row') in node.get('sourceRows', []) and row.get('n') == label]
        if not node.get('sourceRows') and key in a6 and a6[key].get('n') == label:
            candidates = [key]
        if len(candidates) == 1:
            result[key] = candidates[0]
        elif len(candidates) > 1:
            raise ValueError(f'As-Is HTML: ambiguous Excel correspondence for {key}')
        else:
            unmatched.append(key)
    if len(set(result.values())) != len(result):
        raise ValueError('As-Is HTML: multiple source nodes map to one Excel task; resolve explicitly')
    return result, {'html_unmapped': unmatched, 'excel_unmapped': sorted(set(a6) - set(result.values()))}


def capture(path, asis):
    raw = Path(path).read_bytes(); text = raw.decode('utf-8-sig')
    data = snapshot(text); mapping, difference = correspondence(data, asis)
    if not mapping:
        raise ValueError('As-Is HTML and Excel have no exact ID/row+label correspondence')
    return dict(schema='source-asis/v1', filename=Path(path).name,
                sha256=hashlib.sha256(raw).hexdigest(), bytes_base64=base64.b64encode(raw).decode(),
                data_sha256=digest(data), snapshot=data, mapping=mapping,
                scope_difference=difference, excel_basis=basis(asis))


def validate(payload, asis=None):
    if payload.get('schema') != 'source-asis/v1':
        raise ValueError('As-Is source schema missing or unsupported')
    raw = base64.b64decode(payload['bytes_base64'], validate=True)
    if hashlib.sha256(raw).hexdigest() != payload['sha256']:
        raise ValueError('As-Is HTML source hash mismatch')
    data = snapshot(raw.decode('utf-8-sig'))
    if digest(data) != payload['data_sha256'] or data != payload['snapshot']:
        raise ValueError('As-Is snapshot differs from embedded original HTML')
    if asis is not None:
        if basis(asis) != payload['excel_basis']:
            raise ValueError('Excel changed since As-Is source capture; recapture and review differences')
        mapping, difference = correspondence(data, asis)
        if mapping != payload['mapping'] or difference != payload['scope_difference']:
            raise ValueError('As-Is correspondence or scope difference was altered')
    return payload


def attach(asis, path):
    result = copy.deepcopy(asis)
    result['source_html'] = capture(path, asis)
    return result


def mapped_edges(payload):
    """Only genuinely matched endpoints enter Excel analytical topology."""
    validate(payload)
    mapping = payload['mapping']; kinds = {'std':'s', 'conditional':'b', 'cond':'b', 'rework':'r', 'parallel':'p', 'fork':'p', 'join':'s'}
    out = []
    for edge in payload['snapshot']['lv6']['edges']:
        if edge[0] in mapping and edge[1] in mapping:
            if edge[2] not in kinds:
                raise ValueError('Unsupported As-Is analytical edge type: ' + str(edge[2]))
            out.append([mapping[edge[0]], mapping[edge[1]], kinds[edge[2]], edge[3] if len(edge) > 3 else ''])
    return out


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    cap = sub.add_parser('capture'); cap.add_argument('html'); cap.add_argument('asis'); cap.add_argument('--out')
    ver = sub.add_parser('verify'); ver.add_argument('asis')
    args = parser.parse_args(); a = json.loads(Path(args.asis).read_text())
    if args.command == 'capture':
        a = attach(a, args.html)
        Path(args.out or args.asis).write_text(json.dumps(a, ensure_ascii=False, indent=1))
    source = validate(a['source_html'], a)
    print(json.dumps({'sha256':source['sha256'], 'mapped_tasks':len(source['mapping']),
                      'scope_difference':source['scope_difference']}, ensure_ascii=False))
