> **v1.2.0:** quality-contract.md의 design_contract/human_review가 추가 필수다. tobe_flow는 명시한다. 빈 흐름의 순차 자동 생성 및 오류 후 자동 보정 배포는 폐기됐다. 최종 HTML+Excel은 release.py를 사용한다. 아래 필드 설명과 재구성 원리는 유지된다.

# To-be 재설계 — 데이터 형식과 명령어 (사고 과정은 `redesign.md`)

항상 이 방식으로 만든다 (As-Is 행을 하나씩 그대로 옮기는 방식은 쓰지 않는다). 무엇을 어떻게 바꿀지는 `redesign.md`에서 다루고, 이 문서는 그 결과를 담는 데이터 형식과 명령어를 설명한다.

## 1. 담는 내용
| 항목 | To-be 재설계 |
|---|---|
| To-be 업무 | 새로 설계한 업무, 새 ID (`T6-…`) — 재설계한 흐름 순서대로 |
| To-be Lv.5 | 새로 정의 (`tb5`, `T5-…`) — 하나의 결과를 끝내는 업무 묶음. As-Is Lv.5의 이름·개수·순서를 따르지 않음. 소속 Lv.4(`l4`)를 지정 |
| As-Is와의 대응 관계 | 업무마다 `ref` = 이어받은 As-Is Lv.6, Lv.5마다 `from` = 원본 Lv.5 (마지막에 연결) |
| 업무별 정보 | 유형(A/N/H/O)·태그 + `io`(입력·산출물·시스템·형식·전달 대상) + `mode`(실행 방식) |
| 유지되지 않는 As-Is 업무 | X(흡수) + 흡수한 To-be 업무 + 사유 |
| Lv.4·단계 | 엑셀의 Lv.4와 단계 구분·이름 그대로 (통합·이름 변경 없음). 업무는 Lv.4 사이로 이동 가능 |

## 2. 진행 순서
첫 안내 메시지(자료 요청 A + As-Is 구조 확인 B)의 답변을 받고, 필요하면 구조를 재확인한 뒤에는 묻지 않고 바로 설계·제작한다. As-Is 구조 확인은 **As-Is의 분기·병행·반려**에 대한 확인이며, To-be 연결(`tobe_flow`)은 확인받은 As-Is 구조와 재설계 규칙(`redesign.md`)에 따라 Claude가 정한다.
제작 전에 아래 내용을 설계 파일과 작업 메모로 정리한다. 사용자에게 보여 주는 확인 단계가 아니며, 최종 보고의 근거로 쓴다:
1. 진단·변화 가설 5~8줄 (`thinking-process.md` ①~③) + 단계별 As-Is 흐름 → To-be 흐름 (`redesign.md` 5절)
2. 단계별 To-be Lv.5 목록: 이름, 원본 As-Is Lv.5 (통합은 `A+B →`, 분할은 `A → 1/2`), To-be 업무 수, 판정 분포
3. 흡수되는 As-Is 업무 전체 목록과 사유, 신규 To-be 업무(원본 없음)와 추가 이유
4. 실행 방식 분포 (예: 파일 기반 시범 68 · 사람 최종 확정 57 · 연동 전제 n)
5. Lv.4별 사람 개입 지점의 변화, Lv.4 안의 Lv.5 재편(R9)과 Lv.4 사이 이동(R4) — 내용으로 정리 (As-Is 대비 비율·개수 비교는 하지 않음)

## 3. 설계 파일 (design.json) — ②
```json
{"mode": "restructure",
 "tb5": {"T5-01": {"n": "To-be Lv.5 이름", "l4": "As-Is Lv.4 키", "st": 1, "from": ["As-Is Lv.5 ID"], "desc": "To-be Lv.5 설명 한두 문장", "note": ""}},
 "tb": {
   "T6-01-01": {"t": "A", "sub": "S1a", "lb": "업무명", "l5": "T5-01", "ref": ["As-Is Lv.6 ID", "…"], "role": "A-작성", "role_why": "RFP 요건을 기준 양식으로 정리하는 작성 업무",
                "io": {"inp": "…", "out": "요건표", "sys": "…", "fmt": "Excel 표", "to": "T6-01-02 (참여 여부 최종 결정)"}, "mode": "파일 기반 시범", "tg": ""},
   "T6-01-02": {"t": "N", "lane": "l0", "lb": "…", "l5": "T5-01", "ref": ["…"], "role": "H-최종", "role_why": "PT 참여 여부는 책임 있는 최종 결정", "mode": "사람 최종 확정", "tg": ""},
   "TB-G1": {"t": "M", "sub": "S0a", "lb": "① … → … Agent 호출", "anchor": "T6-01-02"},
   "As-Is ID": {"t": "X", "to": "T6-01-01", "why": "흡수 사유"}},
 "tobe_flow": [["T6-01-01", "T6-01-02", "s", ""], ["T6-01-02", "T6-02-01", "b", "조건 이름"]],
 "new_edges": [["T6-01-02", "TB-G1", "o", "확정"], ["TB-G1", "T6-02-01", "o", "호출"]]}
```
- `ref`: 해당 To-be 업무가 이어받은 As-Is Lv.6. As-Is 업무 하나를 여러 To-be 업무가 나누어 이어받아도 된다. **모든 As-Is Lv.6는 반드시 어떤 To-be 업무의 ref 또는 X(흡수) 중 하나에 들어 있어야 한다** (restructure.py check [원본 연결])
- `role`·`role_why`: 업무마다 역할 분류 코드와 업무 내용 기준의 판단 이유 (classification.md '역할 분류 코드'). 코드와 박스 유형(`t`)·배치(`sub`/`lane`)가 맞지 않으면 check 오류 [역할]·[배치]. Agent 박스(`t: A`)의 `tg`에는 사람 행위 태그를 쓰지 않는다 (사람의 확인·연락은 별도 박스)
- `io`: 입력(inp)·시스템(sys)·형식(fmt)은 비워 두면 ref 행들의 엑셀 값을 합쳐 쓴다. **Agent 업무는 `out`(산출물)과 `to`(전달 대상)를 반드시 적는다.** 사람의 의사결정 업무는 `inp`에 근거가 되는 산출물을 적는다 (redesign.md 4절). 세부 Agent 산출물 목록(`subs[].of`)은 업무별 `out`에서 자동으로 모인다
- `tb5[].l4`: To-be Lv.5의 소속 Lv.4 키 (`lv4_sheet.md`의 'Lv.4 키'). F1 양식은 단계 키와 같고, F2 양식은 Lv.4 묶음 이름(또는 ID)이다. 비우면 `from` 첫 Lv.5의 Lv.4를 따른다. **모든 As-Is Lv.4에 To-be Lv.5가 하나 이상 있어야 한다** (check [Lv.4 유지])
- Lv.4 사이로 업무를 옮길 때는 옮겨 갈 Lv.4의 To-be Lv.5에 업무를 두고 `ref`로 원래 As-Is 행을 연결한다. `stages_tobe`(단계 통합·이름 변경)는 쓰지 않는다 (check [Lv.4 유지] 오류)
- `asis_names`: skeleton이 기록하는 설계 시점의 As-Is 업무명. 엑셀 업무명이 바뀌면 check [변경행] 오류 — 그 행이 걸린 To-be 업무를 다시 설계
- `mode` 실행 방식 — 사람이 읽기 쉬운 짧은 표현: `사람 수행` · `사람 최종 확정` · `파일 기반 시범` · `연동 전제: ○○ 확보 후` · `수동 입력부터 시작` 등. 전제 조건이 있으면 해당 Agent의 선행 요건(`story[B].pre`)에도 같은 내용을 쓴다
- `tobe_flow`: 비워 두면 단계 안의 tb 순서대로 순차 연결되고, 단계 마지막 업무는 다음 단계 첫 업무로 연결된다. 병행·분기·반려가 있으면 반드시 직접 적는다 (유형: s 순차 · b 분기 · r 반려)
- `desc.T6`(To-be 업무 설명) · `desc.A6`(엑셀 As-Is 행 설명) · `tb5[].desc`(To-be Lv.5 설명) · `tour`의 ids는 모두 To-be ID 기준
- 레인·Agent 구조·서술 규칙은 `agent-and-story.md`, `writing-style.md` 참고

## 4. 제작
```bash
python scripts/restructure.py check  work/asis.json work/design.json            # 오류 0 (원본 연결·흡수·Lv.5·판정)
python scripts/restructure.py synth  work/asis.json work/design.json work/tobe/  # To-be 전용 asis_tobe.json·design_tobe.json 생성
python scripts/autofill.py fill      work/tobe/asis_tobe.json work/tobe/design_tobe.json work/tobe/design_tobe.json
python scripts/check_design.py       work/tobe/asis_tobe.json work/tobe/design_tobe.json   # To-be 점검
python scripts/style_check.py        work/tobe/design_tobe.json work/tobe/asis_tobe.json
python scripts/restructure.py absorb work/design.json work/tobe/design_tobe.json  # fill 결과를 설계 파일에 반영
python scripts/restructure.py build  work/asis.json work/design.json work/pmd.json
python scripts/build_html.py assets/shell.html assets/engine.js work/pmd.json /mnt/user-data/outputs/<파일명>.html work/design.json
```
- 빈칸을 채울 때는 `design.json`에 작성하고 synth부터 다시 실행한다 (design_tobe.json은 실행할 때마다 새로 생성됨)
- 화면 구성: As-Is 탭은 엑셀 그대로, To-be 탭은 재설계 결과 (통합된 단계 머리에는 'To-be에서 n단계로 통합' 표시). 상세 창의 'As-Is 대비 변경'에 이어받은 As-Is 업무, 실행 방식, 흡수 업무가 표시된다

## 5. 판단 기준
`redesign.md` 2절의 패턴 R1~R10과 3절의 '재설계가 부족하다는 신호'를 따른다. `classification.md`의 유형 판정 규칙은 To-be 업무 단위로 적용한다.

## 6. 재설계 정리 예시 (형식 참고용 — 내용은 해당 부문 엑셀 기준으로 작성, 최종 보고의 결과표·흐름 변화에 활용)
> **진단·변화 가설** (5~8줄) 
>
> **1단계 사업 기회 발굴 및 수주** — To-be Lv.5 9개 (As-Is 14개) · To-be 업무 38개 (As-Is 61행) · Agent 17 · 확인 12 · 사람 7 · Orchestrator 2
> | To-be Lv.5 | 원본 As-Is Lv.5 | To-be 업무 | 실행 방식 |
> |---|---|---|---|
> | [초청] RFP 접수 및 요건 구조화 | 1-1-1-1-1 | 3 (Agent 1 · 사람 2) | 파일 기반 시범 1 · 사람 수행 2 |
> | [초청] PT 참여 검토 및 결정 | 1-1-1-1-2 + 1-1-1-1-3 (통합) | 3 | 내부 데이터 확인 후 1 · 사람 최종 확정 2 |
>
> **흡수되는 As-Is 업무** — 「Go/No-Go 의견 정리」 → 「유관본부 가용성 확인 및 PT 참여 여부 결정」 (검토표 초안은 앞 단계 Agent가 작성하고, 최종 판단은 담당자가 함)
> **신규 To-be 업무** — 「광고주 브리프의 Agent 투입 및 분석 요청」 (업무 착수는 사람이 Agent에게 지시)
> **실행 방식 분포** — 파일 기반 시범 68 · 사람 최종 확정 57 · 사람 수행 40 · 연동 전제 34
- 단계마다 표 하나를 쓰고, 통합(+)과 분할(→ 1/2)은 원본 열에 표시한다. 흡수·신규 업무는 빠짐없이 적는다 (사유 한 줄)
- 묻지 않고 정한 사항은 5단계 보고의 '가정 사항'에 남긴다
