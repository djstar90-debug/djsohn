# 설계 요청 템플릿 · v1.2.0

As-Is Excel과 HTML을 읽고 SKILL.md 및 references/quality-contract.md에 따라 To-be HTML과 Excel을 생성한다.
Lv.4는 유지하고, 목표 산출물·사람 판단을 기준으로 Lv.5·Lv.6 구조를 재설계한다.
각 Agent 업무의 human_review, 별도 사람 노드, 승인·반려 연결과 design_contract.redesign 근거를 작성한다.
원본 HTML은 source_asis로 보존하며 좌표·화살표를 추측해 다시 그리지 않는다.
release.py 및 최종 QC를 통과한 HTML·Excel·manifest를 전달한다. 누락과 오류가 있으면 수정하고 재검증한다.
