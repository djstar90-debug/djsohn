# tobe-process-map v1.2.0

스킬 진입점: SKILL.md. Python 3.11+.

설치: `python -m pip install -r requirements.txt`
회귀: `python -m unittest discover -s tests -v`
브라우저: 시스템 Chromium 또는 `python -m playwright install chromium`.

정상 합성 설계는 tests/fixtures/valid-asis.json, valid-design.json에 있다.
실제 입력을 이 예제 데이터로 대체하지 않는다. assets/examples의 과거 도메인 예제는 legacy 참고용이다.

HTML+Excel 생성 및 검증 명령은 SKILL.md 4절, 변경 이유·검증 근거는 QA_QC_Report_v1.2.0.md를 참고한다.
