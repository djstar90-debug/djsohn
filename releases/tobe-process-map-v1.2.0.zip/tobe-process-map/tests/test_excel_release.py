import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from openpyxl import load_workbook
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import export_excel as E
import release
import restructure
import build_html
import prune

class ExportTests(unittest.TestCase):
    def setUp(self):
        root=Path(__file__).parent/'fixtures'
        self.a=json.loads((root/'valid-asis.json').read_text())
        self.d=json.loads((root/'valid-design.json').read_text())
        self.p=restructure.build(self.a,self.d)
        self.tmp=tempfile.TemporaryDirectory(); self.path=Path(self.tmp.name)/'map.xlsx'
    def tearDown(self): self.tmp.cleanup()
    def test_roundtrip_all_edges_and_design(self):
        E.write(self.a,self.d,self.p,self.path)
        self.assertEqual(E.restore(self.path),dict(asis=self.a,design=self.d,pmd=self.p))
        types={e[2] for e in self.p['views']['6']['ns']['edges']}
        self.assertTrue({'b','r'}.issubset(types))
    def test_nonlexical_source_order_survives(self):
        self.a['A6']=dict(reversed(list(self.a['A6'].items())))
        E.write(self.a,self.d,self.p,self.path)
        self.assertEqual(list(E.restore(self.path)['asis']['A6']),list(self.a['A6']))
    def test_excel_formula_text_stays_literal(self):
        self.d['tb'][next(iter(self.d['tb']))]['lb']='=HYPERLINK("https://example.com")'
        E.write(self.a,self.d,self.p,self.path)
        wb=load_workbook(self.path); self.assertEqual(wb['Process Map']['G2'].data_type,'s'); wb.close()
        E.verify(self.path)
    def test_visible_table_mutation_rejected(self):
        E.write(self.a,self.d,self.p,self.path)
        wb=load_workbook(self.path); wb['Edges']['E2']='WRONG'; wb.save(self.path); wb.close()
        with self.assertRaisesRegex(ValueError,'Edges'): E.restore(self.path)
    def test_payload_mutation_rejected(self):
        E.write(self.a,self.d,self.p,self.path)
        wb=load_workbook(self.path); wb['_Payload']['B2']='bad'; wb.save(self.path); wb.close()
        with self.assertRaisesRegex(ValueError,'SHA256'): E.restore(self.path)
    def test_oversize_cell_not_silently_truncated(self):
        self.d['tb'][next(iter(self.d['tb']))]['lb']='가'*32768
        with self.assertRaisesRegex(ValueError,'한도'): E.write(self.a,self.d,self.p,self.path)
    def test_html_mismatch_rejected(self):
        E.write(self.a,self.d,self.p,self.path)
        root=Path(__file__).resolve().parents[1]
        altered=copy.deepcopy(self.p); altered['text']['title']='changed'
        h=Path(self.tmp.name)/'map.html'
        h.write_text(build_html.build((root/'assets/shell.html').read_text(),(root/'assets/engine.js').read_text(),altered,self.d))
        with self.assertRaisesRegex(ValueError,'PMD'): E.verify(self.path,h)
    def test_release_without_qc_not_certified(self):
        dest=Path(self.tmp.name)/'release'
        manifest=release.build(self.a,self.d,dest)
        self.assertEqual(manifest['status'],'candidate_requires_browser_qc')
        fake=Path(self.tmp.name)/'qc.json'; fake.write_text(json.dumps({'part':'quick','sha256':release.sha(dest/'map.html')}))
        with self.assertRaisesRegex(ValueError,'final QC'): release.certify(dest,fake)
    def test_prune_missing_decision_keeps_original(self):
        d={'tb':{'1-1-1-1-1-1':{'t':'H'}}}; before=copy.deepcopy(d)
        with self.assertRaises(ValueError): prune.prune({'A6':{}},d,{})
        self.assertEqual(before,d)

if __name__=='__main__': unittest.main()
