"""QC must fail closed, reject stale reports and preserve safe HTML extraction."""
import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import htmlio
import qc_browser as qc


class HtmlIOTests(unittest.TestCase):
    def html(self, payload='{"name":"</script text"}'):
        return '<script id="pm-data">window.__PMD__ = ' + payload.replace('</script','<\\/script') + ';</script><script id="pm-engine">test();</script>'

    def test_roundtrip_unicode_escaped_closing_tag(self):
        source = self.html(json.dumps({'name': '한글 </script> & value'}, ensure_ascii=False))
        data, engine, prefix, middle, suffix = htmlio.split(source)
        self.assertEqual(data['name'], '한글 </script> & value')
        self.assertEqual(engine, 'test();')
        self.assertEqual(prefix + json.dumps(data, ensure_ascii=False).replace('</script','<\\/script') + ';' + middle + engine + suffix, source)

    def test_script_like_text_inside_json_is_not_a_marker(self):
        data, *_ = htmlio.split(self.html(json.dumps({'text':'<script id="pm-data">x</script>'})))
        self.assertEqual(data['text'], '<script id="pm-data">x</script>')

    def test_missing_duplicate_and_invalid_markers(self):
        for source in ['', '<script>window.__PMD__ = {};</script>', self.html() + '<script id="pm-data">{}</script>', self.html('{};alert(1)'), self.html('[]')]:
            with self.subTest(source=source[:70]), self.assertRaises(ValueError): htmlio.split(source)

    def test_attribute_spacing_and_quotes(self):
        data, *_ = htmlio.split(self.html('{}').replace('id="pm-data"', "type='text/javascript' id = 'pm-data'").replace('window.__PMD__ = ', ' window.__PMD__=\n'))
        self.assertEqual(data, {})


class QCStatusTests(unittest.TestCase):
    def clean(self):
        return {'part':'quick', 'screens':[{}], 'summary':{}, 'panels_checked':1, 'errors':[], 'panels_failed':[]}

    def test_every_blocking_metric_fails(self):
        for key in qc.BLOCKING:
            report = self.clean(); report['summary'][key] = 1
            with self.subTest(key=key): self.assertTrue(qc.failures(report))

    def test_heights_threshold_and_editorial_warning(self):
        report = self.clean(); report['summary'] = {'height_kinds_max':2,'heights_used':2,'text_style':3}
        self.assertFalse(qc.failures(report))
        report['summary']['heights_used'] = 3
        self.assertTrue(qc.failures(report))

    def test_zero_or_incomplete_checks_fail(self):
        report = self.clean(); report['screens']=[]
        self.assertTrue(qc.failures(report))
        report = self.clean(); report['panels_checked']=0
        self.assertTrue(qc.failures(report))
        report = self.clean(); report['expected_screens']=6
        self.assertTrue(qc.failures(report))

    def test_main_exception_is_error_report_and_exit_2(self):
        with tempfile.TemporaryDirectory() as directory:
            html = Path(directory)/'in.html'; html.write_text('<html/>')
            report = Path(directory)/'report.json'
            async def fail(*_): raise RuntimeError('simulated browser startup failure')
            with patch.object(qc, 'run', fail): self.assertEqual(qc.main([str(html),str(report),'quick']),2)
            saved=json.loads(report.read_text()); self.assertEqual(saved['status'],'error'); self.assertIn('simulated',saved['errors'][0])

    def fixture(self, directory):
        root=Path(directory); html=root/'map.html'; html.write_text('current HTML')
        run=root/'run'; run.mkdir()
        state={'html':str(html.resolve()),'sha256':qc.file_hash(html),'run_id':'current','run_dir':str(run),'start':qc.time.time(),'workers':{n:{'pid':123} for n,_,_ in qc.FINAL}}
        (root/'started.json').write_text(json.dumps(state))
        return root,html,run,state

    def test_changed_input_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root,html,run,state=self.fixture(directory); html.write_text('new HTML')
            with self.assertRaisesRegex(ValueError,'input differs'): qc.final_result(str(html),str(root))

    def test_mixed_result_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root,html,run,state=self.fixture(directory)
            (run/'asis.json').write_text(json.dumps({'run_id':'old','sha256':state['sha256']}))
            with self.assertRaisesRegex(ValueError,'Stale/mixed'): qc.final_result(str(html),str(root))

    def test_dead_worker_not_reported_as_pending(self):
        with tempfile.TemporaryDirectory() as directory:
            root,html,run,state=self.fixture(directory)
            with patch.object(qc,'process_alive',return_value=False), self.assertRaisesRegex(RuntimeError,'without a report'): qc.final_result(str(html),str(root))

    def test_live_worker_result_returns_immediately(self):
        with tempfile.TemporaryDirectory() as directory:
            root,html,run,state=self.fixture(directory)
            with patch.object(qc,'process_alive',return_value=True), patch.object(qc.time,'sleep',side_effect=AssertionError('must not block')):
                self.assertIsNone(qc.final_result(str(html),str(root)))


if __name__=='__main__': unittest.main()
