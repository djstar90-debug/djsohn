"""Canonical HTML/Excel bundle, with typed edges and lossless JSON recovery.

Usage: export_excel.py asis.json design.json pmd.json out.xlsx
       export_excel.py verify out.xlsx [out.html]
       export_excel.py restore out.xlsx destination/
The workbook is a review/export format, not a silent patch import. Edits must be
applied to design.json and regenerated; verify detects edited review tables.
"""
import base64
import gzip
import hashlib
import json
import sys
from pathlib import Path
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill

def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=False, separators=(',', ':')).encode('utf-8')

def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()

HEADERS = ['노드 ID', 'Lv.1', 'Lv.2', 'Lv.3', 'Lv.4', 'Lv.5', 'Lv.6',
           '노드 유형', '담당 조직', '세부 Agent', '역할', '선행', '후행',
           '인풋 데이터', '아웃풋', '활용 시스템', '인풋 데이터 형식',
           '실행 방식', 'As-Is 참조 ID', '_L5_ID', '사람 검토 필요',
           '사람 결정 노드', '통과 후행', '반려 후행', '판단 근거', '설명']

def tables(asis, design, pmd):
    tasks = {k:t for k,t in design['tb'].items() if t.get('t') in ('A','N','H','O')}
    lanes = {v['k']:v.get('name', v['k']) for v in design.get('lanes', [])}
    subs = {k:v.get('name', k) for k,v in design.get('subs', {}).items()}
    stages = list(asis['A4'].values())
    graph = pmd['views']['6']['ns']
    edges = graph['edges']
    out = {'Process Map': [HEADERS]}
    for k,t in tasks.items():
        group = design['tb5'][t['l5']]
        stage = stages[int(group.get('st',1))-1]
        source_groups=[asis['A5'][x] for x in group.get('from',[]) if x in asis['A5']]
        g4=group.get('l4')
        match=next((v for v in asis['A5'].values() if g4 and g4 in (v.get('g4id'),v.get('g4'),v.get('l4id'))),None)
        parent=match or (source_groups[0] if source_groups else {})
        lv4_name=parent.get('g4') or parent.get('l4') or stage['n']
        io = t.get('io', {})
        review = t.get('human_review', {})
        out['Process Map'].append([k, 'To-be', '', stage['n'], lv4_name, group['n'], t.get('lb',''),
            t['t'], lanes.get(t.get('lane'), ''), subs.get(t.get('sub'), ''), t.get('role',''),
            '; '.join(dict.fromkeys(e[0] for e in edges if e[1]==k)),
            '; '.join(dict.fromkeys(e[1] for e in edges if e[0]==k)),
            *[io.get(f,'') for f in ('inp','out','sys','fmt')], t.get('mode',''),
            '; '.join(t.get('ref',[])), t['l5'], review.get('required',''), review.get('decision_node',''),
            '; '.join(review.get('continue_to',[])), '; '.join(review.get('rework_to',[])),
            review.get('reason',t.get('role_why','')), design.get('desc',{}).get('T6',{}).get(k,'')])
    out['Edges'] = [['Level','View','From','To','Type','Label']]
    out['Layout'] = [['Level','View','ID','Lane','Stage','Column','Row','Label']]
    for lv,views in pmd['views'].items():
        for view,g in views.items():
            for e in g['edges']: out['Edges'].append([str(lv),view,*e])
            for n in g['nodes']:
                out['Layout'].append([str(lv),view,n['id'],n.get('ln',''),n.get('st',''),n.get('c',''),n.get('r',''),n.get('lb','')])
    out['As-Is Excel'] = [['ID','Lv.4','Lv.5','업무','담당팀','담당본부','선행','후행','분기','반려','원본 행']]
    for k,a in asis['A6'].items():
        out['As-Is Excel'].append([k,*[a.get(f,'') for f in ('l4','l5','n','team','bon','pre','post','br','rej','row')]])
    out['Traceability'] = [['As-Is ID','To-be ID','관계','근거']]
    for k,t in design['tb'].items():
        for src in t.get('ref',[]): out['Traceability'].append([src,k,'ref',t.get('role_why','')])
        if t.get('t')=='X': out['Traceability'].append([k,t.get('to',''),'삭제' if t.get('kind')=='삭제' else '흡수',t.get('why','')])
    out['Redesign'] = [['Scope','Kind','Source IDs','To-be IDs','Reason','Evidence']]
    for r in design.get('design_contract',{}).get('redesign',[]):
        out['Redesign'].append([r.get('scope',''),r.get('kind',''),'; '.join(r.get('source_ids',[])),
            '; '.join(r.get('tobe_ids',[])),r.get('reason',''),r.get('evidence','')])
    src = pmd.get('sourceAsis', {})
    out['Readme'] = [['항목','내용'],['버전','1.2.0'],['Excel 용도','검토·납품용. 편집 후 design.json에 반영하여 재생성. 원본 Excel과 동일 서식이 아님.'],
        ['연결 의미','s=순차, b=조건 분기, p=병렬, r/l=환류, o=Orchestrator. Edges 시트가 조건·유형을 보존.'],
        ['As-Is 표시','sourceAsis가 있으면 HTML 원본 탭이 기준. Layout/Edges의 asis는 Excel 재구성 참고 데이터.'],
        ['원본 HTML SHA256',src.get('sha256','미첨부')],['JSON SHA256',digest({'asis':asis,'design':design,'pmd':pmd})],
        ['복원','python scripts/export_excel.py restore output.xlsx work/restored']]
    return out

def normalized(rows):
    return [[json.dumps(v, ensure_ascii=False, sort_keys=True) if isinstance(v,(dict,list)) else ('' if v is None else v) for v in r] for r in rows]

def write(asis, design, pmd, output):
    payload = {'asis':asis,'design':design,'pmd':pmd}
    wb = Workbook(); wb.remove(wb.active)
    for name,rows in tables(asis,design,pmd).items():
        ws = wb.create_sheet(name)
        for row in normalized(rows):
            for value in row:
                if isinstance(value,str) and len(value)>32767: raise ValueError(f'{name}: Excel 셀 길이 한도 초과; 값을 줄이거나 별도 근거로 분리')
            ws.append(row)
            for cell in ws[ws.max_row]:
                if isinstance(cell.value,str): cell.data_type='s'  # preserve literal =,+,-,@; never formula
                cell.alignment=Alignment(vertical='top',wrap_text=True)
        ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
        for c in ws[1]: c.font=Font(bold=True,color='FFFFFF'); c.fill=PatternFill('solid',fgColor='B00020')
        for col in ws.columns: ws.column_dimensions[col[0].column_letter].width=26
    packed=base64.b64encode(gzip.compress(canonical(payload),mtime=0)).decode('ascii')
    ws=wb.create_sheet('_Payload'); ws.append(['schema','tobe-process-map/1.2.0']); ws.append(['sha256',digest(payload)])
    for i in range(0,len(packed),16000): ws.append([i//16000,packed[i:i+16000]])
    ws.sheet_state='hidden'
    wb.save(output)
    verify(output)

def restore(path):
    wb=load_workbook(path,read_only=True,data_only=False)
    try:
        rows=list(wb['_Payload'].values)
        if rows[0][1]!='tobe-process-map/1.2.0': raise ValueError('지원하지 않는 workbook payload schema')
        if [r[0] for r in rows[2:]]!=list(range(len(rows)-2)): raise ValueError('Payload chunk sequence mismatch')
        payload=json.loads(gzip.decompress(base64.b64decode(''.join(r[1] for r in rows[2:]),validate=True)))
        if digest(payload)!=rows[1][1]: raise ValueError('Workbook payload SHA256 mismatch')
        for name,expected in tables(**payload).items():
            actual=[list(r) for r in wb[name].values]
            # openpyxl returns empty strings as None, preserve bool/number types.
            clean=lambda rr:[[('' if v is None else v) for v in r] for r in rr]
            if clean(actual)!=clean(normalized(expected)): raise ValueError(f'{name}: 표시 표와 원본 JSON 불일치; 편집분을 설계에 반영한 뒤 재생성')
        return payload
    finally: wb.close()

def verify(path, html=None):
    payload=restore(path)
    if html:
        from htmlio import split
        from design_from_html import embedded
        text=Path(html).read_text(encoding='utf-8')
        if digest(split(text)[0])!=digest(payload['pmd']): raise ValueError('HTML/Excel PMD 불일치')
        if digest(embedded(text))!=digest(payload['design']): raise ValueError('HTML/Excel 설계 불일치')
    return payload

if __name__=='__main__':
    try:
        if sys.argv[1]=='verify': verify(sys.argv[2],sys.argv[3] if len(sys.argv)>3 else None); print('PASS: workbook tables, payload, HTML consistency')
        elif sys.argv[1]=='restore':
            p=restore(sys.argv[2]); dest=Path(sys.argv[3]); dest.mkdir(parents=True,exist_ok=True)
            for k,v in p.items():
                target=dest/(k+'.json')
                if target.exists(): raise ValueError(f'기존 파일 덮어쓰기 금지: {target}')
                target.write_bytes(canonical(v))
        else:
            values=[json.loads(Path(p).read_text(encoding='utf-8')) for p in sys.argv[1:4]]
            write(*values,sys.argv[4]); print('PASS:',sys.argv[4])
    except (ValueError,KeyError,IndexError,OSError) as e: print('ERROR:',e,file=sys.stderr); sys.exit(2)
