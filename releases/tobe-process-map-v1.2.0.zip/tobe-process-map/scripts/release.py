"""Build candidate HTML+XLSX from one validated design; certify after final QC.

python scripts/release.py build asis.json design.json output-directory
python scripts/qc_browser.py output-directory/map.html work/qc final
python scripts/qc_browser.py output-directory/map.html work/qc result
python scripts/release.py certify output-directory work/qc/final.json
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
import copy
import restructure
import check_design
import style_check
import build_html
import verify_input
import export_excel

ROOT=Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))

def build(asis, design, dest):
    dest=Path(dest)
    if dest.exists() and any(dest.iterdir()): raise ValueError('출력 폴더가 비어 있지 않습니다. 새 버전 폴더를 사용하세요.')
    if design.get('mode')!='restructure': raise ValueError('최종 배포에는 mode=restructure 필요; legacy 설계는 명시적으로 이관')
    input_issues=verify_input.validate(asis)
    blocking=[i for i in input_issues if i['severity']=='error']
    conflicts=[i for i in input_issues if i['code']=='SOURCE_REFERENCE_CONFLICT']
    if asis.get('source_html'):
        from source_asis import validate as validate_source
        validate_source(asis['source_html'],asis)
        difference=asis['source_html'].get('scope_difference',{})
        if difference.get('excel_unmapped') or difference.get('html_unmapped'):
            raise ValueError('As-Is HTML/Excel 범위 불일치: 원천 매핑을 해결한 뒤 배포')
    elif conflicts: blocking+=conflicts
    if blocking: raise ValueError('\n'.join(i['message'] for i in blocking))
    issues=restructure.check(asis,design)
    errors=[f'{tag} {msg}' for severity,tag,msg in issues if severity=='오류']
    warnings=[f'{tag} {msg}' for severity,tag,msg in issues if severity!='오류']
    if errors: raise ValueError('\n'.join(errors))
    a,d=restructure.synth(asis,copy.deepcopy(design))
    errs,warns,_=check_design.run(a,copy.deepcopy(d))
    errors+=errs; warnings+=warns
    style=style_check.check(copy.deepcopy(d))+[x for x in style_check.name_check(d,a) if x[0]=='오류']
    dd=copy.deepcopy(d); dd['_a6names']={k:v['n'] for k,v in a['A6'].items()}
    style += [x for x in style_check.nat_check(dd) if x[0]=='오류']
    errors += ['[문구] '+str(x) for x in style]
    # Warnings need an explicit content-specific disposition, not blanket approval.
    dispositions=design.get('qa_dispositions',{})
    pending=[w for w in warnings if not str(dispositions.get(w,'')).strip()]
    if pending: errors+=['[경고 검토 미완료] '+w for w in pending]
    if errors: raise ValueError('\n'.join(errors))
    pmd=restructure.build(asis,design)
    html=build_html.build((ROOT/'assets/shell.html').read_text(),(ROOT/'assets/engine.js').read_text(),pmd,design)
    dest.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='pm-build-',dir=dest.parent) as tmp:
        work=Path(tmp)
        (work/'map.html').write_text(html,encoding='utf-8')
        export_excel.write(asis,design,pmd,work/'map.xlsx')
        export_excel.verify(work/'map.xlsx',work/'map.html')
        for name,data in [('asis',asis),('design',design),('pmd',pmd)]:
            (work/(name+'.json')).write_bytes(export_excel.canonical(data))
        manifest={'version':'1.2.0','status':'candidate_requires_browser_qc',
                  'counts':{'asis_lv6':len(asis['A6']),'tobe_lv6':len(restructure.tasks(design))},
                  'warnings':warnings,'dispositions':dispositions,'input_issues':input_issues,
                  'source_reference_policy':'validated original HTML graph takes precedence' if conflicts else 'no unresolved references',
                  'files':{p.name:sha(p) for p in sorted(work.iterdir())}}
        (work/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
        dest.mkdir(exist_ok=True)
        for file in work.iterdir(): os.replace(file,dest/file.name)
    return manifest

def certify(dest,qc_path):
    from qc_browser import failures
    dest=Path(dest); m=read(dest/'manifest.json'); q=read(qc_path)
    for name,h in m['files'].items():
        if sha(dest/name)!=h: raise ValueError(f'생성 후 파일 변경: {name}')
    if q.get('sha256')!=sha(dest/'map.html') or q.get('part')!='final': raise ValueError('현재 HTML의 final QC가 아님')
    if q.get('status')!='passed' or failures(q): raise ValueError('최종 브라우저 QC 실패: '+str(failures(q)))
    export_excel.verify(dest/'map.xlsx',dest/'map.html')
    m.update(status='passed',browser_qc_sha256=sha(qc_path),browser_qc_summary=q['summary'])
    (dest/'browser-qc.json').write_bytes(Path(qc_path).read_bytes())
    (dest/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
    return m

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest='cmd',required=True)
    b=sub.add_parser('build'); b.add_argument('asis'); b.add_argument('design'); b.add_argument('output')
    c=sub.add_parser('certify'); c.add_argument('output'); c.add_argument('qc')
    args=p.parse_args()
    try:
        result=build(read(args.asis),read(args.design),args.output) if args.cmd=='build' else certify(args.output,args.qc)
        print(json.dumps(result,ensure_ascii=False,indent=2))
    except (ValueError,KeyError,TypeError,IndexError) as e: p.exit(2,'QA BLOCKED: '+str(e)+'\n')
