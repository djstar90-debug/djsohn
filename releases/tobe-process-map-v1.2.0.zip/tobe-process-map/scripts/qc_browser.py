"""브라우저 자동 점검
- 화면별 박스 수 = 데이터 노드 수 (단계 필터 반영)
- 박스 겹침 0
- 스크립트 오류 0
- 상세 창: 모든 To-be·As-Is Lv.6 박스에서 열림
- 연결선: 박스를 지나가는 선(양 끝 박스 제외), 같은 경로를 몇 px 간격으로 나란히 가는 선
사용: qc_browser.py out.html [report.json] [all|quick|asis|ns|panels]
     최종 점검(병렬, 백그라운드): qc_browser.py out.html 결과폴더 final  → 바로 돌아옴
                                  qc_browser.py out.html 결과폴더 result → 현재 상태를 즉시 확인하고 완료된 결과만 합침 (미완료 종료 코드 3)
점검 항목·기준은 모든 방식에서 같다. HTML은 읽기만 한다
"""
import re, asyncio, sys, json, os, time, subprocess, hashlib, uuid, shutil, base64
from pathlib import Path
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from playwright.async_api import async_playwright

SETTLE = r'''() => new Promise(res => {
  // 화면이 다 그려질 때까지: 박스 수·연결선 수·박스 위치가 연속 3프레임 같으면 끝 (최대 1.5초)
  const sig = () => { const b = document.querySelectorAll('#board .nd[data-id]'), e = document.querySelectorAll('#edges path');
    let s = b.length + ':' + e.length; for (let i = 0; i < b.length; i += 7) { const r = b[i].getBoundingClientRect(); s += ':' + Math.round(r.left) + ',' + Math.round(r.top); } return s; };
  let last = '', same = 0; const t0 = performance.now();
  const tick = () => { const s = sig(); same = (s === last) ? same + 1 : 0; last = s;
    if (same >= 3 || performance.now() - t0 > 1500) res(true); else requestAnimationFrame(tick); };
  requestAnimationFrame(tick); })'''
async def settle(pg):
    await pg.wait_for_timeout(60)
    await pg.evaluate(SETTLE)

JS_MEASURE = r"""
(opt) => {
  const R = el => { const r = el.getBoundingClientRect(); return {x:r.left, y:r.top, w:r.width, h:r.height}; };
  const boxes = [...document.querySelectorAll('#board .nd[data-id]')].filter(b => b.offsetParent !== null).map(b => ({id:b.dataset.id, ...R(b)}));
  const ov = [];
  for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
    const a = boxes[i], b = boxes[j];
    const ix = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x), iy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
    if (ix > 1 && iy > 1) ov.push([a.id, b.id]);
  }
  const paths = [...document.querySelectorAll('#edges path[data-a]')];
  const hits = [], segs = [];
  paths.forEach((p, pi) => {
    const L = p.getTotalLength(), m = p.getScreenCTM(); if (!m || !L) return;
    const pts = [];
    for (let s = 0; s <= L; s += 4) { const q = p.getPointAtLength(s); pts.push([q.x * m.a + q.y * m.c + m.e, q.x * m.b + q.y * m.d + m.f]); }
    const a = p.dataset.a, b = p.dataset.b;
    const crossed = new Set();
    boxes.forEach(bx => {
      if (bx.id === a || bx.id === b) return;
      const pad = 2;
      if (pts.some(([x, y]) => x > bx.x + pad && x < bx.x + bx.w - pad && y > bx.y + pad && y < bx.y + bx.h - pad)) crossed.add(bx.id);
    });
    crossed.forEach(id => hits.push([a, b, id]));
    for (let k = 1; k < pts.length; k++) segs.push({pi, x1:pts[k-1][0], y1:pts[k-1][1], x2:pts[k][0], y2:pts[k][1]});
  });
  // 나란히 가는 선: 서로 다른 선의 수평·수직 조각이 1~6px 간격으로 20px 이상 겹침
  const H = {}, V = {};
  segs.forEach(s => {
    if (Math.abs(s.y1 - s.y2) < 0.5) { const k = Math.round(s.y1); (H[k] = H[k] || []).push(s); }
    else if (Math.abs(s.x1 - s.x2) < 0.5) { const k = Math.round(s.x1); (V[k] = V[k] || []).push(s); }
  });
  const near = {};
  const scan = (M, horiz) => {
    const keys = Object.keys(M).map(Number).sort((a, b) => a - b);
    keys.forEach(k => { for (let d = 1; d <= 6; d++) { const o = M[k + d]; if (!o) continue;
      M[k].forEach(s => o.forEach(t => { if (s.pi === t.pi) return;
        const distance = Math.abs(horiz ? s.y1 - t.y1 : s.x1 - t.x1);
        if (distance < 1 || distance > 6) return;
        const a1 = horiz ? Math.min(s.x1, s.x2) : Math.min(s.y1, s.y2), a2 = horiz ? Math.max(s.x1, s.x2) : Math.max(s.y1, s.y2);
        const b1 = horiz ? Math.min(t.x1, t.x2) : Math.min(t.y1, t.y2), b2 = horiz ? Math.max(t.x1, t.x2) : Math.max(t.y1, t.y2);
        const lo = Math.max(a1, b1), hi = Math.min(a2, b2);
        if (hi > lo) { const key = Math.min(s.pi, t.pi) + '-' + Math.max(s.pi, t.pi) + '@' + (horiz ? 'h' : 'v') + k; (near[key] ||= []).push([lo, hi]); }
      })); } });
  };
  scan(H, true); scan(V, false);
  // Union projected intervals: counting unique rows misses a long parallel pair.
  const pairs = new Set(); Object.entries(near).forEach(([key, spans]) => {
    spans.sort((a,b) => a[0]-b[0]); let total=0, lo=spans[0][0], hi=spans[0][1];
    spans.slice(1).forEach(([a,b]) => { if(a<=hi+.1) hi=Math.max(hi,b); else {total+=hi-lo;lo=a;hi=b;} });
    total+=hi-lo; if(total>=20) pairs.add(key.split('@')[0]);
  });
  const par = [...pairs].map(k => k.split('-').map(i => paths[+i].dataset.a + '→' + paths[+i].dataset.b));
  return {boxes:boxes.length, ids:boxes.map(b => b.id), overlaps:ov, edge_box_hits:hits, parallel:par, edges:paths.length};
}
"""

JS_UI = """() => {
  // 비직교 꺾임: 연결선 조각 중 가로·세로가 아닌 것 / 곡선 모서리
  let diag = 0, curve = 0; document.querySelectorAll('#edges path.e').forEach(p => { const d = p.getAttribute('d') || ''; if (/[QCA]/.test(d)) curve++;
    const pts = (d.match(/-?\\d+\\.?\\d*,-?\\d+\\.?\\d*/g) || []).map(s => s.split(',').map(Number));
    for (let i = 1; i < pts.length; i++) if (Math.abs(pts[i][0] - pts[i-1][0]) > 0.6 && Math.abs(pts[i][1] - pts[i-1][1]) > 0.6) diag++; });
  // 글자 넘침: 글이 든 요소가 넘치는데 넘친 부분을 숨김(스크롤로 볼 수 있는 곳은 제외)
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }, clip = [];
  document.querySelectorAll('#stagehead *, #corner *, #labels *, #board .nd, #board .nd *').forEach(e => { if (!vis(e) || !e.textContent.trim()) return; const cs = getComputedStyle(e);
    const hx = /hidden|clip/.test(cs.overflowX) || cs.textOverflow === 'ellipsis', hy = /hidden|clip/.test(cs.overflowY) || (cs.webkitLineClamp && cs.webkitLineClamp !== 'none');   // 방향별로: 스크롤로 볼 수 있으면 잘림 아님
    if ((hx && e.scrollWidth > e.clientWidth + 1) || (hy && e.scrollHeight > e.clientHeight + 1)) clip.push((e.id || e.className || e.tagName) + ': ' + e.textContent.trim().slice(0, 24)); });
  // 첫 레인 가림: 맨 위로 스크롤했을 때 고정 머리줄 아래 끝 > 가장 위 박스 위 끝
  const w = document.querySelector('#wrap'), st0 = w.scrollTop; w.scrollTop = 0;
  const hb = document.querySelector('#stagehead').getBoundingClientRect().bottom, nb = Array.from(document.querySelectorAll('#board .nd')).filter(vis).map(n => n.getBoundingClientRect().top);
  const covered = nb.length && Math.min.apply(null, nb) < hb - 1 ? 1 : 0; w.scrollTop = st0;
  // 박스 높이 종류 (설명 메모 제외)
  const hs = new Set(Array.from(document.querySelectorAll('#board .nd')).filter(n => vis(n) && !/k-why|k-pt/.test(n.className)).map(n => Math.round(n.getBoundingClientRect().height)));
  /* v26 화살표: 서로 다른 화살표가 같은 선 위(1.5px 안)에서 10px 넘게 겹침 · 그중 점선·실선 · 꺾임점 공유 · 왼쪽이 아닌 곳으로 들어감 */
  const EP = Array.from(document.querySelectorAll('svg path[data-a]')).filter(p => /^M/.test(p.getAttribute('d') || '')).map(p => ({dash: /[0-9]/.test(getComputedStyle(p).strokeDasharray || ''), q: (p.getAttribute('d').match(/-?[0-9.]+/g) || []).map(Number).reduce((a, v, i, arr) => (i % 2 ? a : a.concat([[v, arr[i + 1]]])), [])})).filter(l => l.q.length >= 2);
  const SG = []; EP.forEach((l, k) => { for (let i = 0; i < l.q.length - 1; i++){ const a = l.q[i], b = l.q[i + 1], h = Math.abs(a[1] - b[1]) < .6, v = Math.abs(a[0] - b[0]) < .6; if (h === v) continue; SG.push({k, h, c: h ? a[1] : a[0], lo: Math.min(h ? a[0] : a[1], h ? b[0] : b[1]), hi: Math.max(h ? a[0] : a[1], h ? b[0] : b[1])}); } });
  SG.sort((x, y) => x.c - y.c); let eov = 0, emix = 0;
  for (let i = 0; i < SG.length; i++) for (let j = i + 1; j < SG.length && SG[j].c - SG[i].c < 1.5; j++){ const s = SG[i], t = SG[j]; if (s.k === t.k || s.h !== t.h || Math.min(s.hi, t.hi) - Math.max(s.lo, t.lo) < 10) continue; eov++; if (EP[s.k].dash !== EP[t.k].dash) emix++; }
  const BD = {}; EP.forEach((l, k) => l.q.slice(1, -1).forEach(p => { const key = Math.round(p[0]) + ',' + Math.round(p[1]); (BD[key] = BD[key] || new Set()).add(k); }));
  const notLeft = EP.filter(l => { const n = l.q.length, a = l.q[n - 2], b = l.q[n - 1]; return !(Math.abs(a[1] - b[1]) < .6 && b[0] > a[0]); }).length;
  return {nonorth:diag, curved:curve, clipped:clip.length, clip_ex:clip.slice(0, 3), head_cover:covered, height_kinds:hs.size, heights:Array.from(hs).sort((a, b) => a - b),
    edge_overlap:eov, edge_overlap_dash:emix, shared_bends:Object.values(BD).filter(s => s.size > 1).length, entry_not_left:notLeft, edges_n:EP.length};
}"""

@contextmanager
def serve_html(path):
    """Serve one local artifact; managed Chromium may disallow file:// URLs."""
    raw = Path(path).read_bytes()
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == '/favicon.ico':
                self.send_response(204); self.end_headers(); return
            if self.path != '/map.html':
                self.send_error(404); return
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers(); self.wfile.write(raw)
        def log_message(self, *_): pass
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True); thread.start()
    try: yield f'http://127.0.0.1:{server.server_port}/map.html'
    finally: server.shutdown(); server.server_close(); thread.join(timeout=2)


ONLY = [x for x in os.environ.get('QC_ONLY', '').split(',') if x]
async def run(path, part='all'):
    D = None
    rep = {'screens': [], 'errors': [], 'panels_failed': [], 'panels_checked': 0, 'source_checks': [], 'part': part}
    with serve_html(path) as local_url:
        async with async_playwright() as p:
            browser_path = os.environ.get('QC_CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser')
            b = await p.chromium.launch(**({'executable_path': browser_path} if browser_path else {}))
            pg = await b.new_page(viewport={'width': 1800, 'height': 1100})
            pg.set_default_timeout(10000)
            pg.on('pageerror', lambda e: rep['errors'].append(str(e)))
            pg.on('console', lambda m: rep['errors'].append('console: ' + m.text) if m.type == 'error' else None)
            await pg.add_init_script("document.addEventListener('DOMContentLoaded',()=>{const s=document.createElement('style');s.textContent='*,*::before,*::after{transition:none!important;animation:none!important}';document.head.appendChild(s);});")
            await pg.goto(local_url); await pg.wait_for_timeout(1200)
            D = await pg.evaluate('window.__PMD__')
            if not isinstance(D, dict) or not D.get('stages') or not D.get('views'):
                raise ValueError('Rendered HTML has no usable PMD stages/views')
            source_mode = bool(D.get('sourceAsis'))
            if source_mode and part in ('all', 'quick', 'asis', 'panels'):
                await check_source_frame(pg, D, rep)
            # Original As-Is uses its own renderer; never audit hidden regenerated nodes.
            if source_mode:
                await pg.click('[data-scr="ns"]')
            stages = [str(s['n']) for s in D['stages']]
            rep['expected_screens'] = sum(1 for screen in ('asis', 'ns') if part in ('all', 'quick', screen) and not (source_mode and screen == 'asis') for level in (4, 5, 6) for view in (('compact',) if part == 'quick' else ('compact', 'flow')) if not ONLY or f'{screen}{level}{view}' in ONLY) * (1 if part == 'quick' else 1 + len(stages))
            quick = part == 'quick'      # 빠른 점검: 한눈에 보기 · 전체 단계 6화면 + 상세 창 표본 (중간 확인용, 3~5분)
            for scr in [x for x in ('asis', 'ns') if part in ('all', 'quick', x)] if part != 'panels' else []:
                if source_mode and scr == 'asis': continue
                for lv in (4, 5, 6):
                    for vw in (('compact',) if quick else ('compact', 'flow')):
                        if ONLY and f'{scr}{lv}{vw}' not in ONLY: continue
                        for st in (['all'] if quick else ['all'] + stages):
                            await pg.click(f'[data-vw="{vw}"]')
                            sts = [int(x) for x in stages] if st == 'all' else [int(st)]
                            await pg.evaluate('([a, b, c]) => window.__PM3__.set(a, b, c)', [scr, lv, sts])
                            await settle(pg)
                            m = await pg.evaluate(JS_MEASURE, {}); u = await pg.evaluate(JS_UI)
                            exp = [n['id'] for n in D['views'][str(lv)][scr]['nodes'] if st == 'all' or str(n['st']) == st]
                            missing = sorted(set(exp) - set(m['ids'])); extra = sorted(set(m['ids']) - set(exp))
                            rep['screens'].append(dict(scr=scr, lv=lv, vw=vw, st=st, data=len(exp), shown=m['boxes'], missing=missing[:5], extra=extra[:5],
                                                       overlaps=len(m['overlaps']), ov_ex=m['overlaps'][:3], edge_box_hits=len(m['edge_box_hits']),
                                                       hit_ex=m['edge_box_hits'][:3], parallel=len(m['parallel']), par_ex=m['parallel'][:3], edges=m['edges'], **u))
            if part in ('asis', 'ns') or ONLY:
                await b.close(); return finish(rep)
            # 상세 창
            await pg.click('[data-vw="compact"]'); await pg.click('#stSeg [data-st="all"]')
            for scr in ('asis', 'ns'):
                if source_mode and scr == 'asis': continue
                await pg.click(f'[data-scr="{scr}"]'); await pg.click('[data-lv="6"]'); await pg.wait_for_timeout(300)
                ids_ui = {x['id'] for x in D['views']['6'][scr]['nodes'][::25]}
                for n in (D['views']['6'][scr]['nodes'][::12] if quick else D['views']['6'][scr]['nodes']):
                    ok = await pg.evaluate("""(id) => { try { window.__PM3__.showNode(id); } catch (e) { return 'ERR ' + e.message; }
                        const p = document.getElementById('panel'); return p && !p.hidden && p.textContent.trim().length > 20 ? 'ok' : 'empty'; }""", n['id'])
                    rep['panels_checked'] += 1
                    if ok != 'ok': rep['panels_failed'].append([scr, n['id'], ok])
                    elif n['id'] in ids_ui: rep.setdefault('ui_clip', []).extend([f'상세 창 {scr} {n["id"]}: ' + x for x in await pg.evaluate(JS_WIN, '#panel')])
                await pg.keyboard.press('Escape')
            # 흐름 따라가기 창: 단계마다 몇 걸음씩 넘기며 잘림 검사
            for st_ in range(1, len(D.get('stages', [])) + 1):
                await pg.click('[data-scr="ns"]'); await pg.click('#stSeg [data-st="%d"]' % st_); await pg.wait_for_timeout(300)
                if not await pg.evaluate("!!document.querySelector('#btnTour') && !document.querySelector('#btnTour').hidden"): break
                await pg.click('#btnTour'); await pg.wait_for_timeout(200)
                if await pg.locator('#tourStartDlg:not([hidden]) [data-tsd="first"]').count(): await pg.click('#tourStartDlg [data-tsd="first"]')   # v30 시작 창; await pg.wait_for_timeout(400)
                if await pg.locator('#scenask button').count(): await pg.locator('#scenask button').first.click(); await pg.wait_for_timeout(300)
                for _ in range(4 if quick else 12):
                    rep.setdefault('ui_clip', []).extend([f'흐름 따라가기 {st_}: ' + x for x in await pg.evaluate(JS_WIN, '#tourcap')])
                    rep['text_style'] = (rep.get('text_style') or []) + await pg.evaluate(JS_TEXT, '#tourcap .tc-d, #tourcap .tc-steps span, #tourcap p')
                    rep.setdefault('ui_clip', []).extend([f'흐름 따라가기 {st_}: 번호 넘침 ' + x for x in await pg.evaluate("Array.from(document.querySelectorAll('#tourcap .tc-steps li i')).filter(e => e.scrollWidth > e.clientWidth + 1 || e.getBoundingClientRect().height > 32).map(e => e.textContent.trim())")])
                    await pg.keyboard.press('ArrowRight'); await pg.wait_for_timeout(150)
                await pg.keyboard.press('Escape'); await pg.wait_for_timeout(200)
            await pg.click('#stSeg [data-st="all"]')
            # 흐름 따라가기: 걸음마다 강조 박스가 보이는 영역(머리줄 아래·설명창 위·레인 칸 오른쪽)에 들어오는지 (v25)
            if not quick:
                await pg.evaluate("window.scrollTo(0, 0)")
                for st_ in dict.fromkeys((1, len(D.get('stages', [])) or 1)):
                    await pg.click('[data-scr="ns"]'); await pg.click('#stSeg [data-st="%d"]' % st_); await pg.wait_for_timeout(400)
                    await pg.click('#btnTour'); await pg.wait_for_timeout(200)
                    if await pg.locator('#tourStartDlg:not([hidden]) [data-tsd="first"]').count(): await pg.click('#tourStartDlg [data-tsd="first"]')   # v30 시작 창; await pg.wait_for_timeout(600)
                    for i_ in range(5):
                        if await pg.locator('#scenask:not([hidden]) button').count(): await pg.locator('#scenask:not([hidden]) button').first.click(); await pg.wait_for_timeout(500)
                        await pg.wait_for_timeout(2600); v_ = await pg.evaluate(JS_TOURVIS)
                        if v_ != '보임': rep.setdefault('tour_hidden', []).append(f'{st_}단계 {i_ + 1}걸음: {v_}')
                        rep['tour_steps'] = rep.get('tour_steps', 0) + 1
                        count_text = await pg.locator('#tourcap .tc-count').text_content()
                        progress = re.search(r'전체\s*(\d+)/(\d+)', count_text or '')
                        if progress and int(progress.group(1)) >= int(progress.group(2)): break
                        await pg.keyboard.press('ArrowRight')
                    await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300)
                await pg.click('#stSeg [data-st="all"]')
            # v33 소멸 박스: 설명 박스가 바로 밑에 있고(Lv.6·Lv.5 × 한눈에·넓게), 누르면 상세 창이 열림
            if not quick:
                await pg.click('[data-scr="ns"]'); await pg.click('#stSeg [data-st="all"]'); await pg.wait_for_timeout(500)
                for lv_ in ('6', '5'):
                    for vw_ in ('compact', 'flow'):
                        await pg.click(f'#lvSeg [data-lv="{lv_}"]'); await pg.wait_for_timeout(300)
                        await pg.evaluate(f"document.querySelector('#vwSeg [data-vw=\"{vw_}\"]') && document.querySelector('#vwSeg [data-vw=\"{vw_}\"]').click()"); await pg.wait_for_timeout(900)
                        bad = await pg.evaluate(JS_GONE)
                        if bad: rep.setdefault('gone_bad', []).extend([f'Lv.{lv_} {vw_}: ' + x for x in bad])
                w_ = pg.locator('#board .nd.k-why').first
                if await w_.count():
                    await w_.scroll_into_view_if_needed(); await w_.click(); await pg.wait_for_timeout(500)
                    if not await pg.evaluate("(() => { const p = document.querySelector('#panel'); return !!(p && !p.hidden && /없어지는|흡수|삭제/.test(p.innerText)); })()"): rep.setdefault('gone_bad', []).append('설명 박스를 눌러도 상세 창에 소멸 설명이 없음')
                    await pg.keyboard.press('Escape')
                await pg.click('#lvSeg [data-lv="6"]'); await pg.evaluate("document.querySelector('#vwSeg [data-vw=\"compact\"]') && document.querySelector('#vwSeg [data-vw=\"compact\"]').click()"); await pg.wait_for_timeout(600)
                # v33 화면 글 검사: Claude가 쓴 글(Agent 박스·흐름 창·상세 페이지·구조도)에 구어 어휘·조사 짝 오류가 없는지 — 엑셀 원문 박스는 빼고
                rep['text_style'] = (rep.get('text_style') or []) + await pg.evaluate(JS_TEXT, '#board .nd.k-a, #board .nd.k-mk, #board .nd.k-why')
            # v36 연결선 이름표: 글이 상자 밖으로 넘치지 않고, 박스·다른 이름표와 2px 넘게 겹치지 않음 (넓게 보기 · As-Is·To-be · Lv.6·5·4)
            if not quick:
                for scr_ in ('asis', 'ns'):
                    if source_mode and scr_ == 'asis': continue
                    await pg.click(f'[data-scr="{scr_}"]'); await pg.wait_for_timeout(900)
                    for lv_ in ('6', '5', '4'):
                        await pg.click(f'#lvSeg [data-lv="{lv_}"]'); await pg.evaluate("document.querySelector(\"#vwSeg [data-vw='flow']\") && document.querySelector(\"#vwSeg [data-vw='flow']\").click()"); await pg.click('#stSeg [data-st="all"]'); await pg.wait_for_timeout(1000)
                        rep.setdefault('label_bad', []).extend([f'{scr_} Lv.{lv_}: ' + x for x in await pg.evaluate(JS_LAB, '#board')])
                await pg.evaluate("document.querySelector(\"#vwSeg [data-vw='compact']\") && document.querySelector(\"#vwSeg [data-vw='compact']\").click()"); await pg.click('[data-scr="ns"]'); await pg.click('#lvSeg [data-lv="6"]'); await pg.wait_for_timeout(700)
            # Agent 구조도·상세 페이지
            if await pg.evaluate("(() => { const b = document.querySelector('#btnAx'); return !!(b && !b.hidden); })()"):
                await pg.click('#btnAx'); await pg.wait_for_timeout(500)
                if not await pg.evaluate("(() => { const e = document.querySelector('#axw'); return e && !e.hidden && e.textContent.length > 100; })()"): rep['errors'].append('#axw 안 열림')
                await pg.keyboard.press('Escape'); await pg.wait_for_timeout(200)
            for btn in ('#btnMap', '#btnPage'):
                await pg.click(btn); await pg.wait_for_timeout(500)
                sel = '#amap' if btn == '#btnMap' else '#apage'
                vis = await pg.evaluate(f"(() => {{ const e = document.querySelector('{sel}'); return e && !e.hidden && e.textContent.length > 100; }})()")
                if not vis: rep['errors'].append(f'{sel} 안 열림')
                else:
                    pages = await pg.evaluate("Array.from(document.querySelectorAll('#apage .apn[data-page]')).map(e => e.dataset.page)") if sel == '#apage' else ['']
                    for pgid in pages:
                        if pgid: await pg.click(f'#apage .apn[data-page="{pgid}"]'); await pg.wait_for_timeout(250)
                        rep.setdefault('ui_clip', []).extend([f'{sel} {pgid}: ' + x for x in await pg.evaluate(JS_WIN, sel)])
                        rep['text_style'] = (rep.get('text_style') or []) + [f'{sel} {pgid}: ' + x for x in await pg.evaluate(JS_TEXT, '#apm' if sel == '#apage' else sel)]   # v33 Agent 페이지·구조도 글
                        if sel == '#apage': rep.setdefault('label_bad', []).extend([f'Agent 페이지 {pgid}: ' + x for x in await pg.evaluate(JS_LAB, '#apm')])   # v36
                await pg.keyboard.press('Escape'); await pg.wait_for_timeout(200)
            await b.close()
        return finish(rep)
JS_WIN = """(sel) => { const root = document.querySelector(sel); if (!root) return []; const out = [];
  root.querySelectorAll('*').forEach(e => { const r = e.getBoundingClientRect(); if (!r.width || !r.height || !e.textContent.trim() || e.children.length > 3) return; const cs = getComputedStyle(e);
    const hx = /hidden|clip/.test(cs.overflowX) || cs.textOverflow === 'ellipsis', hy = /hidden|clip/.test(cs.overflowY) || (cs.webkitLineClamp && cs.webkitLineClamp !== 'none');
    if ((hx && e.scrollWidth > e.clientWidth + 1) || (hy && e.scrollHeight > e.clientHeight + 1)) out.push('잘림 ' + e.textContent.trim().slice(0, 30));
    else if (e.children.length === 0 && /[가-힣A-Za-z0-9]…$/.test(e.textContent.trim())) out.push('말줄임 ' + e.textContent.trim().slice(-30)); });
  return Array.from(new Set(out)).slice(0, 8); }"""
JS_TOURVIS = """() => { const n = document.querySelector('#board .nd.hl') || document.querySelector('#board .tcard'); if (!n) return '박스 없음';
  const r = n.getBoundingClientRect(), w = document.querySelector('#wrap').getBoundingClientRect(), c = document.querySelector('#tourcap'), capTop = c && !c.hidden ? c.getBoundingClientRect().top : innerHeight;
  const hb = document.querySelector('#stagehead').getBoundingClientRect().bottom, lr = document.querySelector('#labels').getBoundingClientRect().right;
  const vt = Math.max(0, w.top, hb), vb = Math.min(innerHeight, w.bottom, capTop), vl = Math.max(0, w.left, lr), vr = Math.min(innerWidth, w.right);
  const ix = Math.max(0, Math.min(r.right, vr) - Math.max(r.left, vl)), iy = Math.max(0, Math.min(r.bottom, vb) - Math.max(r.top, vt));
  if ((ix * iy) / Math.max(1, r.width * r.height) >= 0.6) return '보임'; if (r.bottom <= 0 || r.top >= innerHeight) return '화면 밖'; if (r.bottom > capTop) return '설명창 뒤'; if (r.top < hb) return '머리줄 뒤'; return '일부만 보임'; }"""
JS_GONE = """() => { const B = Array.from(document.querySelectorAll('#board .nd')).filter(n => n.getBoundingClientRect().width > 0), R = n => n.getBoundingClientRect(), out = [];
  const why = {}; B.filter(n => n.classList.contains('k-why')).forEach(w => { why[(w.dataset.id || '').replace('~why', '')] = w; });
  B.filter(n => n.classList.contains('k-gone')).forEach(g => { const w = why[g.dataset.id]; if (!w){ out.push(g.dataset.id + ' 설명 박스 없음'); return; }
    const a = R(g), b = R(w), dy = b.top - a.bottom; if (Math.abs(a.left - b.left) > 4 || dy < -1 || dy > 40) out.push(g.dataset.id + ' 설명 박스가 바로 밑이 아님 (dx ' + Math.round(b.left - a.left) + ', dy ' + Math.round(dy) + ')');
    if (!/line-through/.test(getComputedStyle(g.querySelector('.lbl') || g).textDecorationLine)) out.push(g.dataset.id + ' 취소선 없음'); });
  return out.slice(0, 10); }"""
JS_TEXT = """(sel) => { const RX = [/(?<![가-힣])(빠진|찾아|만들어|만듭니다|만들고|겹치는지|모아서?|나눠서?|뽑아|뽑은|챙겨|살펴)(?![가-힣])/g, /에\\s*(비교|대조)/g, /(맞는지|드는지|있는지)\\s*(비교|대조)/g, /(을|를) (보고|보며) /g, /(이|가) 낸 /g];
  const Dd = window.__PMD__ || {}, norm = z => String(z || '').replace(/\\s+/g, ' ').trim();
  const XL = norm(Object.values(Dd.A6 || {}).map(a => (a.n || '') + ' ' + (a.pain || '') + ' ' + (a.inp || '') + ' ' + (a.out || '')).concat(Object.values(Dd.A5 || {}).map(a => a.n || '')).join(' '));   /* 엑셀 원문은 고치지 않으므로 뺌 */
  const out = [];
  Array.from(document.querySelectorAll(sel)).forEach(e => (e.innerText || '').split(/\\n+/).forEach(line => { const L = norm(line).replace(/^[·•\\-–\\d.)\\s]+/, ''); if (!L) return;
    RX.forEach(r => { r.lastIndex = 0; let m; while ((m = r.exec(L))){ const a = Math.max(0, m.index - 12), ctx = L.slice(a, m.index + m[0].length + 12).trim(), lw = L.slice(Math.max(0, m.index - 10), m.index + m[0].length).trim(), rw = L.slice(m.index, m.index + m[0].length + 10).trim(); if (XL.indexOf(lw) >= 0 || XL.indexOf(rw) >= 0 || XL.indexOf(L) >= 0) continue;   /* 앞뒤 몇 글자가 엑셀 원문에 그대로 있으면 원문 */ out.push(m[0] + ' — ' + ctx); } }); }));
  return Array.from(new Set(out)).slice(0, 10); }"""
JS_LAB = """(sel) => { const root = document.querySelector(sel); if (!root) return []; const out = [];
  const L = Array.from(root.querySelectorAll('.elab')).filter(e => e.offsetWidth > 0 && getComputedStyle(e).display !== 'none');
  const N = Array.from(root.querySelectorAll('.nd')).filter(n => n.offsetWidth > 0);
  const R = e => e.getBoundingClientRect(), ov = (a, b) => Math.min(a.right, b.right) - Math.max(a.left, b.left) > 2 && Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > 2;
  L.forEach((e, i) => { if (e.scrollWidth > e.clientWidth + 1 || e.scrollHeight > e.clientHeight + 2) out.push('글자 넘침: ' + e.textContent.slice(0, 30));
    const r = R(e); const hit = N.find(n => ov(R(n), r)); if (hit) out.push('박스와 겹침: ' + e.textContent.slice(0, 20) + ' ⟂ ' + hit.dataset.id);
    for (let j = i + 1; j < L.length; j++) if (ov(R(L[j]), r)) { out.push('이름표끼리 겹침: ' + e.textContent.slice(0, 20)); break; } });
  return Array.from(new Set(out)).slice(0, 12); }"""
def finish(rep):
    S = rep['screens']
    rep['summary'] = dict(screens=len(S), count_mismatch=sum(1 for s in S if s['missing'] or s['extra']),
                          overlaps=sum(s['overlaps'] for s in S), edge_box_hits=sum(s['edge_box_hits'] for s in S),
                          parallel=sum(s['parallel'] for s in S),
                          errors=len(rep['errors']), panels_failed=len(rep['panels_failed']),
                          nonorth=sum(s.get('nonorth', 0) + s.get('curved', 0) for s in S), clipped=sum(s.get('clipped', 0) for s in S),
                          head_cover=sum(s.get('head_cover', 0) for s in S), height_kinds_max=max([s.get('height_kinds', 0) for s in S] or [0]),
                          heights_used=max([len({h for s in S if s.get('lv') == 6 and s.get('vw') == v for h in s.get('heights', [])}) for v in {s.get('vw') for s in S}] or [0]), ui_clip=len(rep.get('ui_clip', [])), tour_hidden=len(rep.get('tour_hidden', [])), gone_bad=len(rep.get('gone_bad', [])), label_bad=len(set(rep.get('label_bad', []))), text_style=len(set(rep.get('text_style', []))), ui_text=len(rep.get('ui_text', [])),
                          edge_overlap_max=max([s.get('edge_overlap', 0) for s in S] or [0]), edge_overlap_dash_max=max([s.get('edge_overlap_dash', 0) for s in S] or [0]), shared_bends_max=max([s.get('shared_bends', 0) for s in S] or [0]),
                          entry_left_min=round(min([1 - s.get('entry_not_left', 0) / max(1, s.get('edges_n', 1)) for s in S if s.get('edges_n')] or [1]) * 100, 1))   # v26 화살표 점검 (화면마다 가장 나쁜 값)   # tour_hidden: 흐름 따라가기 중 강조 박스가 안 보인 걸음 (단계 첫·마지막 × 5걸음)   # heights_used: 같은 보기의 Lv.6 화면 전체에서 쓰인 박스 높이 수 (2면 어느 화면이든 같은 두 높이)
    return rep

# Zero-tolerance release blockers. Text style is a separate editorial warning;
# left-entry/shared-bend diagnostics are informational, as valid loops may use them.
BLOCKING = ('count_mismatch', 'overlaps', 'edge_box_hits', 'parallel', 'errors',
            'panels_failed', 'nonorth', 'clipped', 'head_cover', 'ui_clip',
            'tour_hidden', 'gone_bad', 'label_bad', 'ui_text', 'edge_overlap_max', 'edge_overlap_dash_max')


def failures(rep):
    summary = rep.get('summary', {})
    out = [f'{key}={summary.get(key)}' for key in BLOCKING if summary.get(key, 0)]
    for key in ('height_kinds_max', 'heights_used'):
        if summary.get(key, 0) > 2: out.append(f'{key}={summary[key]} > 2')
    part = rep.get('part', 'all')
    if 'expected_screens' in rep and len(rep.get('screens', [])) != rep['expected_screens']:
        out.append(f"Incomplete screens: {len(rep.get('screens', []))}/{rep['expected_screens']}")
    if part != 'panels' and not rep.get('screens') and not rep.get('source_checks'):
        out.append('No process-map screen was checked')
    if part in ('all', 'quick', 'panels', 'final') and rep.get('panels_checked', 0) == 0:
        out.append('No detail panel was checked')
    if rep.get('status') == 'error': out.append('QC runner failed')
    return out


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic_json(path, data):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name(target.name + '.' + uuid.uuid4().hex + '.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(temp, target)


def tagged(rep, html, part, run_id):
    rep.update(html=str(Path(html).resolve()), sha256=file_hash(html), part=part,
               run_id=run_id, only=list(ONLY), completed_at=time.time())
    rep['failures'] = failures(rep)
    rep['status'] = 'failed' if rep['failures'] else 'passed'
    return rep


FINAL = [('asis', 'asis', ''), ('ns45', 'ns', 'ns4compact,ns4flow,ns5compact,ns5flow'), ('ns6', 'ns', 'ns6compact,ns6flow'), ('panels', 'panels', '')]

def final_start(html, out):
    # A unique directory prevents old workers overwriting a newer run's files.
    root = Path(out); root.mkdir(parents=True, exist_ok=True)
    # A previous final report must not masquerade as completion of this run.
    (root / 'final.json').unlink(missing_ok=True)
    run_id = uuid.uuid4().hex; run_dir = root / run_id; run_dir.mkdir()
    state = dict(html=str(Path(html).resolve()), sha256=file_hash(html), start=time.time(),
                 run_id=run_id, run_dir=str(run_dir.resolve()), workers={})
    for name, part, only in FINAL:
        env = dict(os.environ, QC_ONLY=only, QC_RUN_ID=run_id)
        with open(run_dir / (name + '.log'), 'w') as log:
            worker = subprocess.Popen([sys.executable, os.path.abspath(__file__), state['html'], str(run_dir / (name + '.json')), part], env=env,
                                      stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        state['workers'][name] = dict(pid=worker.pid, part=part)
    atomic_json(root / 'started.json', state)
    print(f'최종 점검 시작: {run_id}; result 명령은 즉시 현재 상태를 반환합니다')


def process_alive(pid):
    try:
        os.kill(pid, 0)
        stat = Path(f'/proc/{pid}/stat')
        return not (stat.exists() and stat.read_text().split(') ', 1)[-1].startswith('Z'))
    except (ProcessLookupError, PermissionError):
        return False


def final_result(html, out, wait=0):
    # wait retained as compatibility argument; result is deliberately nonblocking.
    state = json.loads((Path(out) / 'started.json').read_text(encoding='utf-8'))
    if state['html'] != str(Path(html).resolve()) or state['sha256'] != file_hash(html):
        raise ValueError('QC input differs from the file used to start this run; start a new final run')
    run_dir = Path(state['run_dir']); reports = []; pending = []
    for name, part, only in FINAL:
        path = run_dir / (name + '.json')
        if not path.exists():
            if not process_alive(state['workers'][name]['pid']):
                raise RuntimeError(f'QC worker {name} exited without a report; see {run_dir / (name + ".log")}')
            if time.time() - state['start'] > 900:
                raise RuntimeError(f'QC run exceeded 900 seconds; inspect worker logs in {run_dir}')
            pending.append(name); continue
        report = json.loads(path.read_text(encoding='utf-8'))
        if report.get('run_id') != state['run_id'] or report.get('sha256') != state['sha256'] or report.get('html') != state['html'] or report.get('part') != part or report.get('only', []) != [x for x in only.split(',') if x]:
            raise ValueError(f'Stale/mixed QC result: {name}')
        reports.append(report)
    if pending:
        print('진행 중: ' + ', '.join(pending)); return None
    rep = dict(screens=[], errors=[], panels_failed=[], panels_checked=0, source_checks=[], part='final')
    for item in reports:
        for key in ('screens', 'errors', 'panels_failed', 'source_checks', 'ui_clip', 'tour_hidden', 'gone_bad', 'label_bad', 'text_style', 'ui_text'):
            rep.setdefault(key, []).extend(item.get(key, []))
        rep['panels_checked'] += item.get('panels_checked', 0)
        if item.get('status') != 'passed': rep['errors'].extend(item.get('failures', ['worker failed']))
    try:
        import ui_text_check
        from htmlio import split
        engine = split(Path(html).read_text(encoding='utf-8'))[1]
        rep['ui_text'] = [code + ' | ' + text for code, text in ui_text_check.lint(engine)]
    except Exception as exc:
        rep['errors'].append('UI text check failed: ' + str(exc))
    rep = tagged(finish(rep), html, 'final', state['run_id'])
    atomic_json(Path(out) / 'final.json', rep)
    print(json.dumps(rep['summary'], ensure_ascii=False))
    return rep


async def check_source_frame(pg, data, rep):
    """Check the actual source renderer; hidden reconstructed views do not count."""
    source = data['sourceAsis']
    raw = base64.b64decode(source['bytes_base64'], validate=True)
    if hashlib.sha256(raw).hexdigest() != source['sha256']:
        raise ValueError('Embedded source As-Is hash mismatch')
    await pg.click('[data-scr="asis"]')
    frame_el = pg.locator('#sourceAsisFrame')
    await frame_el.wait_for(state='visible')
    actual = await frame_el.get_attribute('srcdoc')
    if actual != raw.decode('utf-8-sig') and actual != raw.decode('utf-8'):
        raise ValueError('As-Is iframe document differs from preserved source HTML')
    frame = await (await frame_el.element_handle()).content_frame()
    await frame.wait_for_load_state('domcontentloaded')
    await frame.wait_for_timeout(500)
    controls = frame.locator('#levels [data-level]')
    levels = await controls.evaluate_all('(nodes) => nodes.map(n => n.dataset.level)')
    if not levels: levels = ['current']
    for level in levels:
        if level != 'current':
            await frame.locator(f'#levels [data-level="{level}"]').click()
            await frame.wait_for_timeout(150)
        count = await frame.locator('.node[data-id], .nd[data-id]').count()
        if count == 0:
            rep['errors'].append(f'Source As-Is Lv.{level}: no rendered process nodes')
        rep['source_checks'].append(dict(level=level, nodes=count, sha256=source['sha256'], renderer='original'))


def main(argv=None):
    args = sys.argv[1:] if argv is None else argv
    if not args:
        print('Usage: qc_browser.py map.html [report.json|directory] [all|quick|asis|ns|panels|final|result]', file=sys.stderr); return 2
    html = args[0]; out = args[1] if len(args) > 1 else None; part = args[2] if len(args) > 2 else 'all'
    run_id = os.environ.get('QC_RUN_ID') or uuid.uuid4().hex
    try:
        if part not in ('all', 'quick', 'asis', 'ns', 'panels', 'final', 'result'):
            raise ValueError('Unknown QC mode: ' + part)
        if part in ('final', 'result') and out is None: raise ValueError('Final QC requires a result directory')
        if part == 'final': final_start(html, out); return 0
        if part == 'result':
            rep = final_result(html, out)
            return 3 if rep is None else (2 if rep['failures'] else 0)
        initial_hash = file_hash(html)
        rep = asyncio.run(run(html, part))
        if file_hash(html) != initial_hash: rep['errors'].append('HTML changed while QC was running')
        rep = tagged(finish(rep), html, part, run_id)
    except Exception as exc:
        rep = dict(screens=[], errors=[f'{type(exc).__name__}: {exc}'], panels_failed=[], panels_checked=0, source_checks=[], status='error', part=part)
        rep = finish(rep)
        rep.update(html=str(Path(html).resolve()), sha256=file_hash(html) if Path(html).is_file() else None, run_id=run_id, completed_at=time.time())
        rep['failures'] = failures(rep)
        if part in ('final', 'result'):
            print(rep['errors'][0], file=sys.stderr); return 2
    if out: atomic_json(out, rep)
    print(json.dumps(rep['summary'], ensure_ascii=False))
    for failure in rep['failures'][:12]: print('FAIL:', failure)
    for error in rep.get('errors', [])[:5]: print('ERROR:', error)
    return 2 if rep['failures'] else 0


if __name__ == '__main__':
    sys.exit(main())
