"""설계 파일 점검 + 규칙 준수 점검 + 결과 보고용 수치
규칙 준수([규칙준수] 경고): 같은 업무 다른 판정 · 쌍 행 태그 차이 · 외부·고객 행 A · 결정 업무 A 무태그 · 게이트 미연결
사용: check_design.py asis.json design.json   (오류가 있으면 종료 코드 2)
오류: 빠진 행·엑셀에 없는 ID·판정 유형·세부 Agent·소멸 비고 형식·흡수 대상 실재·레인 누락·선 끝점·업무 없는 세부 Agent·서술 누락
"""
import sys, json, re
from collections import Counter
T_OK = {'A', 'N', 'H', 'X', 'O', 'M'}
EXT = re.compile(r'외부|외주|협력사|에이전시|프로덕션|스튜디오|광고주|고객')
DECIDE = ('확정', '결정', '승인', '선별', '판정', '셀렉', '압축')
def base_name(n):
    return re.sub(r'\s+', ' ', re.sub(r'\[[^\]]*\]', '', n or '')).strip()
def consistency(A6, TB, d):
    """규칙 준수 점검 — 정답 없이 결과 안의 모순을 찾는다 (경고: 판정을 바꿀지는 사람이 정함)"""
    out = []
    # ① 같은·거의 같은 업무명(대괄호 태그·띄어쓰기·조사 차이 무시)인데 판정이 다른 행
    import difflib
    key = lambda n: re.sub(r'(가|이|을|를|의)(?= )', '', base_name(n)).replace(' ', '')
    ks = list(A6); seen = set()
    for i, a in enumerate(ks):
        for b in ks[i + 1:]:
            ka, kb = key(A6[a]['n']), key(A6[b]['n'])
            if ka == kb or (min(len(ka), len(kb)) >= 8 and difflib.SequenceMatcher(None, ka, kb).ratio() >= 0.92):
                if TB[a]['t'] != TB[b]['t'] and (a, b) not in seen:
                    seen.add((a, b)); out.append(f'[규칙준수] 같은 업무 다른 판정 (의도된 예외면 무시): {a}={TB[a]["t"]} · {b}={TB[b]["t"]} "{base_name(A6[a]["n"])[:28]}"')
    # ② 쌍 행: 같은 Lv.5 안에서 대괄호 태그만 다르고 서술어가 같은 행 → 판정·태그를 맞춘다
    tagof = lambda n: (re.match(r'^\[([^\]]+)\]', n or '') or [None, None])[1]
    tail2 = lambda n: ' '.join(re.sub(r'\([^)]*\)', '', base_name(n)).split()[-2:])
    by5 = {}
    for k, a in A6.items():
        if tagof(a['n']): by5.setdefault((a['l5'].split(' ')[0], tail2(a['n'])), []).append(k)
    for g in by5.values():
        if len(g) < 2 or len({tagof(A6[k]['n']) for k in g}) < 2: continue
        if len({TB[k]['t'] for k in g}) > 1: out.append('[규칙준수] 쌍 행 판정 차이: ' + ', '.join(f'{k}={TB[k]["t"]}' for k in g))
        elif len({TB[k].get('tg', '') for k in g}) > 1: out.append('[규칙준수] 쌍 행 태그 차이: ' + ', '.join(f'{k}[{TB[k].get("tg", "")}]' for k in g))
    for k, a in A6.items():
        t = TB[k]; tail = ' '.join(re.sub(r'\([^)]*\)', '', base_name(a['n'])).split()[-2:])
        # ③ 외부·고객 담당 행이 Agent 대체 (자료 취합·백업·초안 준비 제외 — 외부에 연락·발송·요청하는 일은 사람 업무)
        if t['t'] == 'A' and EXT.search(a['team']) and not re.search(r'취합|백업|초안|준비|정리', t.get('lb', '')):
            out.append(f'[규칙준수] 외부·고객 담당 행이 A: {k} {a["team"][:14]} "{a["n"][:30]}"')
        # ④ 결정 서술어(또는 노드 유형 '승인')인데 A이면서 사람 태그가 없음
        if t['t'] == 'A' and not re.search(r'자동|1차|후보|초안', t.get('lb', '')) and (any(w in tail for w in DECIDE) or a.get('ty') == '승인'):
            out.append(f'[규칙준수] 결정 업무인데 A: {k} "{a["n"][:30]}" — 최종 판단은 별도 Lv.6 사람 박스(N)로 나눈다 (Agent 박스에 사람 태그를 붙이지 않음)')
        # ⑤ (v30 삭제) 'N 업무명에 (주체, 근거) 괄호' 요구 — 업무명에 괄호를 쓰지 않음 (writing-style.md 업무명)
        # ⑥ (v30 삭제) 'A 업무명이 원문 그대로' 경고 — 원문이 맞으면 그대로 둬도 됨
    # ⑦ 게이트(S0a) 신호가 다음으로 이어지지 않음
    outs = {e[0] for e in d.get('new_edges', []) if e[2] == 'o'}
    for k, t in TB.items():
        if t.get('t') == 'M' and t.get('sub', '').endswith('0a') and k not in outs:
            out.append(f'[규칙준수] 게이트 신호가 다음 Agent·담당자를 부르지 않음: {k}')
    return out
def patterns(asis, TB, d):
    """설계 패턴(design-patterns.md) 장치가 빠졌는지 · 틀 문장이 남았는지 — S04와 수를 맞추는 것이 아니라 장치 유무만 본다"""
    A6 = asis['A6']; out = []; nst = len(asis['A4'])
    st = lambda k: TB[k].get('st') if k not in A6 else list(asis['A4']).index(asis['A5'][A6[k]['l5'].split(' ')[0]]['l4id']) + 1
    new = {k: t for k, t in TB.items() if k not in A6}
    basis = re.sub(r'\(.*', '', d.get('ui', {}).get('orcBasis', '')).strip()
    s1 = [k for k in TB if st(k) == 1 and TB[k]['t'] != 'X']
    if not any(new[k]['t'] == 'N' for k in new if new[k].get('st') == 1):
        out.append('[설계패턴] P1 1단계에 사람 투입·기준 확정 N(신규)이 없음 — 요청을 Agent에 맡기는 지점, 기준을 확정하는 지점')
    if not any(re.search(r'조건|범위|기준|Fact Base', TB[k].get('lb') or '') and TB[k]['t'] in 'AN' for k in s1):
        out.append('[설계패턴] P1 1단계에 공통 기준 데이터 노드가 없음 — 뒤 단계가 대조할 조건 묶음 (예: 제작 조건/범위 정리)')
    if basis and not any(basis.split()[0] in (TB[k].get('lb') or '') for k in TB if TB[k]['t'] in 'AN'):
        out.append(f'[설계패턴] P1 Orchestrator 기준("{basis}")을 만드는 노드가 없음 — 이름이 문구에만 있음')
    for i in range(1, nst + 1):
        if not any(t['t'] == 'M' and not t.get('sub', '').endswith('0b') and t.get('st') == i for t in new.values()) and i < nst:
            out.append(f'[설계패턴] P4 {i}단계에 게이트(S0a) 신호가 없음')
    chg = [k for k, a in A6.items() if re.search(r'변경|수정 요청|Change|추가 비용|추가 요청|회차', a['n']) and TB[k]['t'] != 'O']
    if chg and not any(re.search(r'범위 확정|수정 확정|변경', t.get('lb', '') + t.get('tg', '')) and t['t'] in 'NM' for t in new.values()):
        out.append(f'[설계패턴] P3 변경·수정 행 {len(chg)}개가 있는데 변경 관리 장치(수정 범위 확정 N · 변경 확정 신호 M)가 없음')
    s0b = sum(1 for t in new.values() if t['t'] == 'M' and t.get('sub', '').endswith('0b'))
    if s0b < max(1, nst // 2): out.append(f'[설계패턴] P5 진행 현황(S0b) {s0b}개 — 상태가 바뀌는 단계마다 1개 안팎')
    for b in d['bands']:
        if not d['story'].get(b['id'], {}).get('hum', '').strip(): out.append(f'[설계패턴] P7 {b["id"]} 사람이 남는 지점(hum) 빈칸')
    # 틀 문장
    auto_t = [k for k, v in d.get('tour', {}).items() if v.get('_auto')]
    if auto_t: out.append(f'[서술] 흐름 따라가기 {len(auto_t)}개 단계가 자동 초안 그대로 — 의미 단위로 묶고 직접 쓰기 (writing-examples.md)')
    steps = [s_['d'] for v in d.get('tour', {}).values() for b in v.get('beats', []) for s_ in b['steps']]
    tpl = sum(1 for x in steps if re.search(r'업무를 맡습니다|업무를 직접 합니다|결정을 내립니다$|처리를 합니다$', x))
    if steps and tpl / len(steps) > 0.3: out.append(f'[서술] 흐름 따라가기 문장 {tpl}/{len(steps)}개가 틀 문장')
    w = sum(1 for x in d.get('when', {}).values() if re.search(r'」 업무에서$', x or ''))
    if w: out.append(f'[서술] when {w}개가 틀 문장 ("「업무」 업무에서") — 상황으로 쓰기')
    fa = sum(1 for s_ in d['story'].values() for x in s_.get('subs', {}).values() if x.get('_auto_f'))
    if fa: out.append(f'[서술] 세부 Agent 기능(f) {fa}곳이 업무명 복사 — 기능 문장으로 쓰기')
    return out
def v17checks(asis, TB, d):
    """박스별 설명(desc) · 데이터·시스템 3단계 · AX 과제 연결 형식 점검"""
    A6, A5, A4 = asis['A6'], asis['A5'], asis['A4']; out = []; ds = d.get('desc') or {}
    need = {'A4': [str(i) for i in range(1, len(A4) + 1)], 'T4': [str(i) for i in range(1, len(A4) + 1)], 'A5': list(A5), 'A6': list(A6),
            'T6': [k for k, t in TB.items() if t['t'] in ('A', 'N')], 'M6': [k for k, t in TB.items() if t['t'] == 'M']}
    for key, ids in need.items():
        miss = [i for i in ids if not (ds.get(key) or {}).get(i)]
        if miss: out.append(f'[설명] desc.{key} 빈칸 {len(miss)}개: ' + ', '.join(miss[:6]) + (' …' if len(miss) > 6 else ''))
    for key in ('A6', 'T6'):
        for k, v in (ds.get(key) or {}).items():
            lb = (TB.get(k, {}).get('lb') or A6.get(k, {}).get('n') or '').strip()
            if lb and v.strip().rstrip('.') == lb.rstrip('.'): out.append(f'[설명] desc.{key}.{k} 업무명을 그대로 옮김 — 무엇을 하는 일인지 풀어 쓰기')
    bad = []
    for sid, v in d['subs'].items():
        for x in v.get('d', []) + v.get('s', []):
            if len(x) < 3 or x[2] not in ('E', 'P', 'N'): bad.append(f'{sid}:{x[0][:14]}')
            elif x[2] == 'P' and not (len(x) > 4 and x[4]): out.append(f'[데이터] 준비중인데 괄호(어느 팀이 무엇을) 없음: {sid} {x[0][:20]}')
    if bad: out.append(f'[데이터] 상태(E/P/N) 없는 항목 {len(bad)}개 — autofill fill 다시 실행: ' + ', '.join(bad[:5]))
    if not any(len(x) > 2 and x[2] == 'P' for v in d['subs'].values() for x in v.get('d', []) + v.get('s', [])):
        out.append('[데이터] 준비중(P) 항목 0개 — 사내 준비 현황 자료를 받았는지 확인 (없으면 기존/신규만으로 보고에 남김)')
    ax = d.get('ax')
    if ax and ax.get('tasks'):
        for t in ax['tasks']:
            if t.get('lv') not in ('D', 'P', 'N'): out.append(f'[AX] 과제 {t.get("id")} 연결 정도(lv) 오류')
            elif t['lv'] in ('D', 'P') and not (t.get('ag') and t.get('st') and t.get('how')): out.append(f'[AX] 과제 {t["id"]} 연결 Agent·단계·실행 방법 빈칸')
            elif t['lv'] == 'N' and not t.get('how'): out.append(f'[AX] 과제 {t["id"]} 범위 밖 사유(how) 빈칸')
            for a in t.get('ag', []):
                if a not in d['subs']: out.append(f'[AX] 과제 {t["id"]} 없는 세부 Agent {a}')
    return out
def branches(asis, TB, d):
    """분기(시나리오)는 서로 잇지 않는다 — 설계가 만든 연결이 다른 시나리오 줄을 직접 잇거나, 신규 노드 하나가 여러 시나리오 시작점을 부르면 경고"""
    import sys, os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from compile import scenario_tags
    sc = d.get('scenario') or {}
    t5, lines, _, _, _ = scenario_tags(asis, sc.get('source'), set(sc.get('common', [])), d.get('lanes', []))
    out = []
    if d['bands'] and d['bands'][0]['id'] in (d.get('ui', {}).get('relBands') or []): out.append('[분기] 첫 큰 기능 Agent(Orchestrator)는 타 본부(relBands)가 될 수 없음')
    if not lines: return out
    A6 = asis['A6']
    def line(k):
        l5 = A6[k]['l5'].split(' ')[0] if k in A6 else TB.get(k, {}).get('l5')
        t = t5.get(l5); return t[0] if t else ''
    calls = {}
    for e in d.get('new_edges', []):
        la, lb = line(e[0]), line(e[1])
        if la and lb and la != lb: out.append(f'[분기] 서로 다른 분기를 직접 잇는 연결: {e[0]}({la}) → {e[1]}({lb})')
        if e[0] not in A6 and lb: calls.setdefault(e[0], set()).add(lb)
    for k, ls in calls.items():
        if len(ls) > 1: out.append(f'[분기] 신규 노드 {k}가 여러 분기({", ".join(sorted(ls))})를 함께 부름 — 분기마다 따로 두기')
    return out
OFFICE = re.compile(r'^(Excel|엑셀|PowerPoint|PPT|파워포인트|Word|워드|Keynote|한글|HWP|PDF)\b', re.I)
def lessons(asis, TB, d):
    """S04 대화 기록에서 나온 판단 기준 중 자동으로 확인할 수 있는 것 (references/s04-lessons.md)"""
    A6 = asis['A6']; out = []
    # [흐름주체] Agent·Orchestrator 박스만 가리키는 문장에 사람 주체 [59]
    for st, v in d.get('tour', {}).items():
        for b in v.get('beats', []):
            for stp in b['steps']:
                ks = [k for k in stp['ids'] if k in TB]
                if ks and stp.get('a') and all(TB[k]['t'] in ('A', 'M') for k in ks):
                    out.append(f'[흐름주체] {st}단계 "{b["t"]}": Agent가 하는 박스({ks[0]})를 사람({stp["a"]})이 하는 것으로 설명')
    # [시스템] 활용 시스템에 문서 도구 [28]
    for sid, v in d['subs'].items():
        bad = [y for g in v.get('sp', []) for y in g[1] if OFFICE.match(y)]   # 화면의 '무엇을 하려고 → 어떤 시스템으로' (s 목록의 문서 도구는 엔진이 걸러 표시)
        if bad: out.append(f'[시스템] {sid} 활용 시스템에 문서 도구: {", ".join(bad[:3])} — API로 연동하는 시스템만')
    # [노드번호] 화면 문장에 ID [21]
    idre = re.compile(r'\b(?:BR|CY|TB)-[A-Z0-9]+(?:-\d+)?\b|\b\d-\d-\d-\d-\d-\d\b')
    texts = [(f'tb.{k}', t.get('lb', '') + ' ' + t.get('note', '').split('」')[-1]) for k, t in TB.items()]
    texts += [(f'desc.{key}.{k}', v) for key, m in (d.get('desc') or {}).items() for k, v in m.items()]
    texts += [(f'tour.{st}', s_['d']) for st, v in d.get('tour', {}).items() for b in v.get('beats', []) for s_ in b['steps']]
    hit = [w for w, t in texts if idre.search(t or '')]
    if hit: out.append(f'[노드번호] 화면 문장에 노드 ID {len(hit)}곳: ' + ', '.join(hit[:5]))
    # [연결] 선이 하나도 없는 신규 박스 [49]
    ends = {x for e in d.get('new_edges', []) for x in e[:2]}
    lone = [k for k, t in TB.items() if k not in A6 and t['t'] != 'X' and k not in ends]
    if lone: out.append(f'[연결] 어디에도 연결되지 않은 신규 박스: {", ".join(lone[:6])}')
    # [고객접점] 신규 노드에 광고주·고객 접점 [9]
    cust = [k for k, t in TB.items() if k not in A6 and re.search(r'광고주 접점|고객 접점|광고주 화면', t.get('lb', ''))]
    if cust: out.append(f'[고객접점] 신규 고객 접점 노드: {", ".join(cust)} — 만들지 않는다')
    # [파일명] 굵은 이름에 날짜·파일명·버전 [85]
    fn = re.compile(r'\d{4}|\.pptx?|\.xlsx?|\.docx?|\bv\d')
    bad = sorted({x[0] for v in d['subs'].values() for x in v.get('d', []) + v.get('s', []) if fn.search(re.sub(r'\([^)]*\)', '', x[0]))})
    if bad: out.append(f'[파일명] 굵은 데이터·시스템 이름에 날짜·파일명: {", ".join(bad[:4])} — 세부는 괄호(하위)로')
    return out
REF_S04 = dict(X=0.047, N=0.012, A=0.035, edges=0.06)   # S04 제작 참고값 — 부문마다 당연히 다름 (목표 아님)
def memo_checks(asis, TB, d):
    """사고 과정 ①~⑤가 설계 파일에 있는지, 변화마다 진단 근거가 있는지. 규모는 참고값과 크게 다를 때만 이유 확인을 권함"""
    A6 = asis['A6']; out = []; m = d.get('memo') or {}
    if not m:
        out.append('[설계메모] memo 없음 — thinking-process.md ①~⑤(가치·진단·가설·단계별 변화·구조 판단)를 먼저 쓰고 판정은 그 결과로'); return out
    for f in ('value', 'diagnosis', 'hypotheses', 'changes', 'structure'):
        if not m.get(f): out.append(f'[설계메모] {f} 빈칸')
    dg = {x.get('id') for x in m.get('diagnosis', [])}
    covered = set()
    for c in m.get('changes', []):
        if c.get('why') not in dg: out.append(f'[설계메모] 변화 "{c.get("desc", "")[:24]}"의 이유(why)가 진단에 없음')
        covered.update(c.get('ids', []))
    need = [k for k in A6 if TB[k]['t'] == 'X'] + [k for k, t in TB.items() if k not in A6 and t['t'] in ('A', 'N')]
    miss = [k for k in need if k not in covered]
    if miss: out.append(f'[설계메모] 소멸·신규 {len(miss)}개가 어떤 변화(changes)에도 연결되지 않음: ' + ', '.join(miss[:6]) + (' …' if len(miss) > 6 else ''))
    n = len(A6) or 1; new = [k for k in TB if k not in A6]
    r = dict(X=sum(1 for k in A6 if TB[k]['t'] == 'X') / n, N=sum(1 for k in new if TB[k]['t'] == 'N') / n, A=sum(1 for k in new if TB[k]['t'] == 'A') / n)
    far = [f'{k} {r[k]*100:.0f}% (S04 {REF_S04[k]*100:.0f}%)' for k in r if r[k] > REF_S04[k] * 3 + 0.02]
    if False and far: out.append('[설계메모] 재설계 규모가 S04 참고값과 크게 다름 — 부문마다 다를 수 있으니 수치를 맞출 필요는 없고, 각 변화의 이유가 진단에 있는지만 다시 확인: ' + ' · '.join(far))
    return out
OFFICE_RX = __import__('re').compile(r'^(Excel|엑셀|PowerPoint|PPT|파워포인트|Word|워드|한글|HWP|Keynote)\b')
FILE_RX = __import__('re').compile(r'\.(pptx?|xlsx?|docx?|pdf)\b|\b\d{4}\b|\d{6}')
def v15checks(asis, TB, d):
    """AE v15 데이터 형식 [82·85·87·92·28] · 흐름 따라가기 주체 [59]"""
    out = []; A6 = asis['A6']
    for sid, v in d['subs'].items():
        items = v.get('d', [])
        if v.get('dg') is not None:
            ing = {x for g in v['dg'] for x in g[1]}
            miss = [x[0] for x in items if x[0] not in ing]
            if miss: out.append(f'[데이터 형식] {sid} 묶음(dg)에 없는 투입 데이터 {len(miss)}개: {miss[0][:20]}')
        nofmt = [x[0] for x in items if len(x) >= 5 and not (len(x) > 5 and x[5])]
        if items and len(items[0]) > 5 and nofmt: out.append(f'[데이터 형식] {sid} 형식(6번째 칸) 없는 투입 데이터 {len(nofmt)}개: {nofmt[0][:20]}')
        for x in items:
            nm = __import__('re').sub(r'\([^)]*\)', '', x[0])
            if FILE_RX.search(nm): out.append(f'[데이터 형식] {sid} 굵은 이름에 파일명·날짜: "{x[0][:30]}" — 세부는 괄호로'); break
        for g in v.get('sp', []) or []:
            if any(OFFICE_RX.match(t) for t in g[1]): out.append(f'[데이터 형식] {sid} 활용 시스템에 문서 도구: "{g[0]}" — API 연동 시스템만 [28]')
            if '검색' in g[0] and not g[1]: out.append(f'[데이터 형식] {sid} "{g[0]}"에 도구 없음 — 실제로 무엇으로 검색하는지 [87]')
    # 흐름 따라가기: Agent·Orchestrator 박스만 가리키는 문장을 사람이 하는 것처럼 쓰지 않는다
    lane_who = [l.get('who') or l['name'] for l in d['lanes']]
    for st, v in d.get('tour', {}).items():
        for b in v.get('beats', []):
            for s_ in b['steps']:
                ids = [i for i in s_['ids'] if i in TB]
                if ids and all(TB[i]['t'] in ('A', 'M') for i in ids):
                    txt = s_.get('d', '')
                    head = __import__('re').split(r'(?:가|이|는|은) ', txt, maxsplit=1)[0]
                    if s_.get('a') or (any(head.startswith(w) for w in lane_who if w) and 'Agent' not in head and 'Orchestrator' not in head):
                        out.append(f'[흐름 주체] {st}단계 "{txt[:28]}" — Agent가 하는 단계를 사람 주체로 설명 [59]')
    return out
GENERIC_ORG = {'팀', '본부', '부문', '파트', '담당팀', '담당 팀', '해당 팀', '각 팀', '관련 팀', '각 본부', '해당 본부', '전 본부', '본부별', '팀별', '부문별', '타 부문', '타 본부'}   # v22: '유관본부'·'전문본부'·'유관팀'은 일반 명사로 인정하지 않음 (원문 '유관 본부' 등으로)
ORG_RX = re.compile(r'[^\s,()「」\[\]·/:;"*→<>~+]*(?:팀|본부|부문|파트)(?![가-힣])')
def org_names(asis):
    """허용 조직명: 엑셀 담당본부·담당팀 원문, 그 조각('>' · ' / '), 엑셀 본문(업무명·작업 팀 등)에 원문으로 나오는 조직명"""
    full = set()
    for a in asis['A6'].values():
        for v in (a.get('bon'), a.get('team'), a.get('part')):
            if v: full.add(v.strip())
    full |= {re.sub(r'\s*\([^()]*(?:확인\s*필요|가설|미정|추정|TBD|tbd)[^()]*\)', '', v).strip() for v in list(full)}   # 메모를 뗀 이름도 원문
    pieces = set(full)
    for v in full:
        for x in re.split(r'\s*>\s*|\s+/\s+|\s*,\s*', v):
            if x.strip(): pieces.add(x.strip())
    text = set()
    for D in (asis['A6'], asis.get('A5', {}), asis.get('A4', {})):
        for a in D.values():
            for f, v in a.items():
                if isinstance(v, str) and f not in ('bon', 'team'): text.update(m.group(0) for m in ORG_RX.finditer(v))
    return full, pieces, text
def walk(o, path=''):
    if isinstance(o, str): yield path, o
    elif isinstance(o, dict):
        for k, v in o.items():
            if k in ('memo', 'hint', 'structure', 'form', 'src', 'team', 'bon'): continue
            yield from walk(v, f'{path}.{k}' if path else str(k))
    elif isinstance(o, list):
        for i, v in enumerate(o): yield from walk(v, f'{path}[{i}]')
ORIG_PATH = re.compile(r'(src_n|_names|\.pn\[|\.beats\[\d+\]\.t$|^subs\.[^.]+\.(s|d|dg|sp)\[|^bands\[\d+\]\.(s|d)\[|^meta\.text\.foot)')
def org_checks(asis, d):
    """[조직명] 축약·생략 의심 / [조직명 확인] 엑셀에 없는 조직명 — 레인·업무명·태그·설명·흐름 따라가기·Agent 서술 전체"""
    full, pieces, text = org_names(asis); out = []; seen = set()
    for l in d['lanes']:
        if l.get('bon') and l['name'] not in full: out.append(f"[조직명] 레인 이름이 엑셀 원문과 다름: '{l['name']}' (원문: {', '.join(l['bon'])})")
    longest = sorted(full, key=len, reverse=True)
    for path, txt in walk(d):
        if ORIG_PATH.search(path): continue   # 엑셀 원문을 그대로 담은 칸(판정 근거 업무명·Pain point·Lv.5 묶음 이름·시스템/데이터 이름·출처 표기)은 바꾸지 않으므로 점검하지 않음
        if path.startswith('lanes') and path.split('.')[-1] in ('name', 'short', 'who', 'sub'): t0 = txt
        t = re.sub(r'「[^」]*」', ' ', txt.replace('**', ''))   # 「」 안은 엑셀 업무명 원문 인용
        for f in longest: t = t.replace(f, ' ')     # 원문 조직명 전체는 미리 지움 (그 안의 조각을 잘못 잡지 않게)
        for m in ORG_RX.finditer(t):
            w = m.group(0).strip(' .')
            if not w or w in GENERIC_ORG or w in pieces: continue   # v22: 담당 열 원문(과 조각)만 인정 — 엑셀 본문에 나오는 호칭(예: 미디어팀)은 인정하지 않음
            if any(w.endswith(p) and len(p) >= 3 for p in pieces): continue   # 앞에 붙은 말 + 원문 (예: "광고주/제작본부")
            area = re.match(r'[A-Za-z_]+', path).group(0)
            if (w, area) in seen: continue
            seen.add((w, area))
            longer = sorted({p for p in pieces if p != w and (p.endswith(w) or (len(w) >= 3 and w in p))}, key=len)[:2]
            pv = re.search(r'([^\s,()「」]+\s)?$', t[:m.start()]).group(0); disp = (pv + w).strip()   # 보여 줄 때는 앞말까지 (예: 데이터 거버넌스팀)
            if not longer: longer = sorted({p for p in pieces if p != w and re.sub(r'(팀|본부|부문|파트)$', '', w)[:2] and re.sub(r'(팀|본부|부문|파트)$', '', w)[:2] in p}, key=len)[:2]
            if longer: out.append(f"[조직명] 축약·생략 의심: '{disp}' ({path}) — 엑셀 원문: {' / '.join(longer)}")
            else: out.append(f"[조직명 확인] 엑셀에 없는 조직명: '{disp}' ({path}) — 출처 원문 그대로인지 확인")
    return out
def quote_checks(asis, d):
    """[이름표] 「」로 인용한 업무명이 엑셀·To-be 업무명 중간에서 끊김 (글자 수로 자른 인용)"""
    names = {a['n'] for a in asis['A6'].values()} | {a['n'] for a in asis.get('A5', {}).values() if isinstance(a, dict) and a.get('n')}
    names |= {t.get('lb', '') for t in d.get('tb', {}).values() if t.get('lb')}
    names = {re.sub(r'^\[[^\]]+\]\s*', '', n) for n in names} | names
    out = []; seen = set()
    for path, txt in walk(d):
        for q in re.findall(r'「([^」]+)」', txt):
            if q in names or q in seen: continue
            JOSA = ('을', '를', '이', '가', '은', '는', '의', '에', '에서', '과', '와', '로', '으로', '도', '만')
            def cut(n):   # 어절 중간에서 끝났거나, 이음말(및·과·와·의·또는)로 끝나면 잘린 인용
                rest = n[len(q):]; w = re.match(r'\S*', rest).group(0)
                return not (rest[:1].isspace() and not re.search(r'(및|또는|과|와|의|및)$', q)) and w not in JOSA or bool(re.search(r'\s(및|또는)$', q))
            if any(n.startswith(q) and len(n) > len(q) and cut(n) for n in names):
                seen.add(q); full = next(n for n in names if n.startswith(q) and len(n) > len(q) and cut(n))
                out.append(f"[이름표] 업무명을 중간에서 자른 인용: 「{q}」 ← 「{full}」 ({path})")
    return out
ROLE_RX = re.compile(r'(?<![A-Za-z])(AE|CD|PM|AP)(?=가 |이 |는 |와 |의 |에게|·| 확인| 발송| 확정| 선택| 검수| 체결|\))')
def input_apply_checks(d, TB):
    """[자료반영] 받은 자료가 설계에 실제로 반영됐는지 · [자료충돌] 자료끼리 다른 점이 남았는지 (input-request.md 7·8절)"""
    I = d.get('inputs') or {}; out = []
    if not I: return out
    got = {x.get('kind', '') for x in I.get('received', [])} | {r.get('item', '') for r in I.get('requests', []) if r.get('status') == 'received'}
    has = lambda key: any(key in g for g in got)
    applied = I.get('applied') or {}
    note = lambda key: next((v for k, v in applied.items() if key in k), '')
    def need(key, ok, msg, label=None):
        if has(key) and not ok and not note(key): out.append(f'[자료반영] 받은 자료 「{label or key}」 반영 흔적 없음: {msg} — 반영하거나, 반영 결과(변경 없음 등)를 inputs.applied에 기록')
    P = sum(1 for s_ in d.get('subs', {}).values() for f in ('d', 's') for x in s_.get(f, []) if isinstance(x, list) and len(x) > 2 and x[2] == 'P')
    need('시스템', P > 0, '데이터·시스템 상태의 준비중(P) 0개', '시스템·데이터 준비 현황')
    need('AX 과제', bool((d.get('ax') or {}).get('tasks')), 'AX 과제(ax.tasks) 0개', 'AX 과제 목록')
    foot = (d.get('meta', {}).get('text', {}) or {}).get('foot', '')
    need('인터뷰', '인터뷰' in foot or any(x.get('src') for x in (d.get('memo') or {}).get('diagnosis', [])), '출처 표기·진단 근거(memo.diagnosis.src)에 인터뷰 없음', '현업 인터뷰·회의록')
    memo_l = [l['name'] for l in d.get('lanes', []) if l.get('memo')]
    org_ans = any(re.search(r'조직|팀|본부', q) for q in (I.get('answers') or {}))
    if (has('조직도') or org_ans) and memo_l and not note('조직'): out.append(f"[자료반영] 조직 정보를 받았는데 '확인 필요' 레인이 남음: {', '.join(memo_l)} — 정식 명칭을 레인 name에 넣고 memo를 지우거나, 정식 명칭이 없음을 inputs.applied에 기록")
    need('As-Is HTML', 'HTML' in str((d.get('structure') or {}).get('source', '')) or bool((d.get('structure') or {}).get('extra')), '확인한 구조의 출처에 As-Is HTML 없음 (structure.py에 HTML을 넣어 다시)', 'As-Is HTML')
    for k in sorted(got):   # 그 밖의 받은 자료: 반영 기록이 있어야 함
        if not k or re.search(r'As-Is 엑셀|참고 이미지|시스템|AX 과제|인터뷰|조직도|As-Is HTML|이전 To-be', k): continue
        if not note(k.split('·')[0].split(' ')[0]): out.append(f'[자료반영] 받은 자료 「{k}」 반영 기록 없음 — 어디에 어떻게 반영했는지(또는 반영할 것이 없었는지) inputs.applied에 기록')
    C = [c for c in I.get('conflicts', []) if not c.get('resolved')]
    if C: out.append(f"[자료충돌] 자료끼리 다른 점 {len(C)}개가 아직 정해지지 않음 (흐름 관련은 구조 확인 때 질문, 그 밖은 input-request.md 8절 기준으로 정해 resolved에 기록): " + ' · '.join(c.get('what', '')[:30] for c in C[:4]))
    return out
def people_checks(d):
    """[표기] 사람 주체 표기가 조직명(기본값)인데 직무명(AE·CD·PM·AP)을 사람 주체로 씀"""
    if d.get('people') != 'org': return []
    out = []; seen = set()
    for path, txt in walk(d):
        if path.startswith(('ax', 'meta')): continue
        for m in ROLE_RX.finditer(txt.replace('**', '')):
            key = (m.group(1), path.split('.')[0])
            if key in seen: continue
            seen.add(key); out.append(f"[표기] 직무명 '{m.group(1)}'을 사람 주체로 씀 — 사람 주체 표기는 조직명 원문 (사용자가 직무명을 요청하지 않음) ({path})")
    return out
def label_checks(d):
    """[이름표] 흐름 따라가기 이름표(v)가 업무명 중간에서 끊김"""
    out = []
    for st, v in (d.get('tour') or {}).items():
        for bt in v.get('beats', []):
            for sp in bt.get('steps', []):
                lab = sp.get('v', ''); m = re.search(r'\*\*(.+?)\*\*', sp.get('d', ''))
                if not lab: continue
                fulls = ([m.group(1)] if m else []) + [x for x in (sp.get('_names') or []) if x]
                for c in fulls:   # 이름표가 업무명 앞부분만이면 잘린 것 (남은 것이 괄호 설명뿐이면 괜찮음)
                    if c.startswith(lab) and len(lab) < len(c) and not re.match(r'\s*\(', c[len(lab):]):
                        out.append(f"[이름표] 업무명 앞부분에서 자른 이름표: '{lab}' ← '{c}' (tour {st})"); break
    return out

def run(asis, d):
    if d.get('mode') == 'restructure' and not asis.get('meta', {}).get('tobe'):
        from restructure import check
        from design_contract import metrics
        results = check(asis, d)
        return ([' '.join(x[1:]) for x in results if x[0] == '오류'],
                [' '.join(x[1:]) for x in results if x[0] != '오류'], metrics(asis, d))
    A6 = asis['A6']; TB = d['tb']; err, warn = [], []
    ROWID = re.compile(r'^\d+(?:-\d+){5}$'); DEL = [k for k in TB if k not in A6 and ROWID.match(k)]   # v29: 엑셀에서 없어진 행 (업데이트 때 이전 설계에 남은 것)
    if DEL:
        err.append(f"[삭제행] 새 엑셀에서 없어진 행 {len(DEL)}개가 설계에 남아 있음: {', '.join(DEL[:8])}{' …' if len(DEL) > 8 else ''} — 업무명 대조로 행마다 [정말 없어짐] / [다른 행으로 옮겨 감]을 정해 → prune.py로 정리")
        import copy as _cp; d = _cp.deepcopy(d); [d['tb'].pop(k) for k in DEL]; TB = d['tb']   # 나머지 점검은 이 행들을 빼고 (엉뚱한 '신규 노드' 오류가 나지 않게)
    if not d.get('bands') or not d.get('subs'): err.append('Agent 구조 없음 — 큰 기능 Agent(B0 Orchestrator 포함)·세부 Agent를 먼저 설계 (없으면 구조도·상세 페이지가 열리지 않음)')
    for k in A6:
        if k not in TB: err.append(f'판정 없음: {k}')
    for k, t in TB.items():
        if t.get('t') not in T_OK: err.append(f'판정 유형 오류: {k} {t.get("t")}')
        if t.get('t') in ('A', 'M') and t.get('sub') not in d['subs']: err.append(f'세부 Agent 없음: {k} {t.get("sub")}')
        if k not in A6:
            for f in ('st', 'l5', 'o', 'lb'):
                if f not in t: err.append(f'신규 노드 {k}: {f} 없음')
            if t.get('t') in ('N', 'H') and not t.get('lane'): err.append(f'신규 노드 {k}: 사람 레인(lane) 없음')
    labels = [t.get('lb') or A6.get(k, {}).get('n', '') for k, t in TB.items() if t.get('t') != 'X']
    for k, t in TB.items():
        if t.get('t') != 'X': continue
        if t.get('to'):   # v33 새 형식: 흡수 대상 번호 + 사유
            tt = TB.get(t['to'])
            if not tt and t['to'] not in A6: err.append(f"[소멸] {k}의 흡수 대상 {t['to']}이 없음")
            elif (tt or {}).get('t') == 'X': err.append(f"[소멸] {k}의 흡수 대상 {t['to']}도 소멸 박스 — 살아 있는 To-be 박스로")
            if not str(t.get('why', '')).strip(): err.append(f'[소멸] {k} 흡수 사유(why) 없음')
            continue
        if t.get('kind') == '삭제':
            if not str(t.get('why', '')).strip(): err.append(f'[소멸] {k} 삭제 사유(why) 없음')
            continue
        n = t.get('note', '')
        if not (n.startswith('흡수 →') or n.startswith('삭제 —')): err.append(f'소멸 비고 형식: {k} — to(흡수 대상 번호)+why, 또는 kind "삭제"+why로 (예전 형식은 "흡수 → 「대상」 사유")')
        tg = re.findall(r'「([^」]+)」', n)
        if n.startswith('흡수 →') and (not tg or not all(any(x == l or x in l for l in labels) for x in tg)): err.append(f'[소멸] {k} 설명이 지금 To-be 박스 이름을 가리키지 않음(옛 이름 등): {tg or n[:30]} — to(흡수 대상 번호)+why로 바꾸면 현재 이름이 자동으로 들어감')
    BYBON = any(l.get('bon') for l in d['lanes'])
    teams = {t for l in d['lanes'] for t in (l.get('bon') or l['team'])}
    for k, a in A6.items():
        key = (a.get('bon') or a['team']) if BYBON else a['team']
        if key not in teams: err.append(f'레인에 없는 {"담당본부" if BYBON else "담당팀"}: {key}'); teams.add(key)
    for st_, v_ in (d.get('tour') or {}).items():   # 이름표 점검용: 단계의 업무명
        for bt in v_.get('beats', []):
            for sp in bt.get('steps', []): sp['_names'] = [(TB.get(i) or {}).get('lb') or (A6.get(i) or {}).get('n', '') for i in sp.get('ids', [])]
    warn += org_checks(asis, d) + label_checks(d) + quote_checks(asis, d) + people_checks(d)
    inp = d.get('inputs') or {}   # [자료] 1단계(추가 자료 요청)를 거쳤는지
    if not inp: warn.append('[자료] 설계 파일에 자료 기록(inputs)이 없음 — 첫 안내 메시지를 거쳤는지 확인 (inputs.py save)')
    else:
        pend = [r.get('item', '') for r in inp.get('requests', []) if r.get('status') in (None, '', 'pending')]
        if pend: warn.append(f"[자료] 아직 받지 못한 자료 {len(pend)}개 (보고 '가정 사항'에 진행 방식 기록): " + ', '.join(pend[:5]))
        miss = [r.get('item', '') for r in inp.get('requests', []) if r.get('status') in ('none', 'pending') and not r.get('if_none')]
        if miss: warn.append('[자료] 없을 때 진행 방식(if_none)이 빈 요청: ' + ', '.join(miss[:5]))
    warn += input_apply_checks(d, TB)
    # v33 [싱크] Agent 이름을 바꾼 기록(agent_log)에 있는 예전 이름만 본다 — 바꾸지 않았으면 볼 것이 없음
    cur_names = {x['name'] for x in d.get('subs', {}).values()} | {b['name'] for b in d.get('bands', [])}
    olds = {e['old'] for e in d.get('agent_log', []) if e.get('old') and e['old'] not in cur_names}
    if olds:
        body = json.dumps({k: v for k, v in d.items() if k not in ('agent_log', 'structure', 'inputs', 'pruned', 'review')}, ensure_ascii=False)
        for o in sorted(olds):
            c = body.count(o)
            if c: err.append(f"[싱크] 바뀐 Agent의 예전 이름이 {c}곳에 남음: '{o}' — agent_edit.py로 바꾸면 문장까지 함께 바뀜")
    for st_, tv in (d.get('tour') or {}).items():   # 흐름 문장 주어 = 그 박스의 지금 Agent (지금 상태만 봄)
        for bt in tv.get('beats', []):
            for sp in bt.get('steps', []):
                ids = sp.get('ids') or []; t = TB.get(ids[0]) if ids else None
                if not t or t.get('t') != 'A' or t.get('sub') not in d.get('subs', {}): continue
                me = d['subs'][t['sub']]['name']; dd = (sp.get('d') or '').replace('**', '')
                other = next((n for n in cur_names | olds if n != me and dd.startswith(n)), None)
                if other and not dd.startswith(me): err.append(f"[싱크] {ids[0]} 흐름 문장 주어가 '{other}' — 이 박스의 지금 Agent는 '{me}'")
    for k, t in TB.items():   # v29: 신규 노드가 붙는 자리·참조가 지금 엑셀(또는 설계)에 있는지
        if k in A6: continue
        refs = [t.get('anchor'), (t.get('conn') or {}).get('splice')] + list(t.get('ref') or []) + list((t.get('conn') or {}).get('in') or []) + list((t.get('conn') or {}).get('out') or [])
        bad = [x for x in refs if isinstance(x, str) and x and x not in A6 and x not in TB]
        if bad: err.append(f"[연결] 신규 노드 {k}가 없는 행을 가리킴: {', '.join(bad)} — 붙을 자리(anchor·splice·ref)를 새 엑셀 행으로 다시 정하기 (prune.py '다시 정할 곳')")
    dz = d.get('desc') or {}
    for key, ids in (('A6', [k for k in A6]), ('T6', [k for k, t in TB.items() if t.get('t') in ('A', 'N', 'H', 'O')]), ('A5', list(asis.get('A5', {}))), ('A4', list(range(1, len(asis.get('A4', {})) + 1))), ('T4', list(range(1, len(asis.get('A4', {})) + 1))), ('M6', [k for k, t in TB.items() if t.get('t') == 'M'])):
        miss = [str(k) for k in ids if not (dz.get(key) or {}).get(str(k), '').strip()]
        if miss: err.append(f'[설명] 상세 창 설명 desc.{key} 빈칸 {len(miss)}개 (예: {", ".join(miss[:3])}) — Claude가 박스마다 직접 씀 (비우면 엔진 틀 문장이 나감)')
    empty = [f'{st_}.{bi}.{si}' for st_, v_ in (d.get('tour') or {}).items() for bi, bt in enumerate(v_.get('beats', [])) for si, sp in enumerate(bt.get('steps', [])) if not (sp.get('d') or '').strip() or not (sp.get('v') or '').strip()]
    if empty: err.append(f'[서술] 흐름 따라가기 문장·이름표 빈칸 {len(empty)}개 (예: {", ".join(empty[:3])}) — Claude가 박스마다 직접 씀')
    for k, t in TB.items():   # [변경행] 판정할 때의 원문 업무명과 지금 엑셀이 다르면 다시 판정
        if k in A6 and t.get('src_n') and t['src_n'] != A6[k]['n']: err.append(f"[변경행] {k} 판정 근거 업무명이 엑셀과 다름 — 다시 판정: '{t['src_n'][:30]}' → '{A6[k]['n'][:30]}'")
    nos = [k for k, t in TB.items() if k in A6 and t.get('t') and not t.get('src_n')]
    if nos: warn.append(f'[변경행] 판정 근거 업무명(src_n)이 없는 행 {len(nos)}개 — 이전 설계를 재사용했다면 design_from_html이 채움, 새로 판정했다면 autofill fill이 채움')
    for v_ in (d.get('tour') or {}).values():
        for bt in v_.get('beats', []):
            for sp in bt.get('steps', []): sp.pop('_names', None)
    ids = set(A6) | set(TB)
    for e in d.get('new_edges', []):
        for x in e[:2]:
            if x not in ids: err.append(f'선 끝점 없음: {e}')
    for s in d['subs']:
        if not any(t.get('sub') == s for t in TB.values()): err.append(f'업무 없는 세부 Agent: {s}')
    for b in d['bands']:
        if b['id'] not in d['story']: err.append(f'Agent 서술 없음: {b["id"]}')
        for f in ('p', 'intro', 'hum'):
            if not d['story'].get(b['id'], {}).get(f): warn.append(f'{b["id"]}.{f} 빈칸')
    if d['bands'] and d['bands'][0]['subs'][:2] != [d['bands'][0]['subs'][0], d['bands'][0]['subs'][1] if len(d['bands'][0]['subs']) > 1 else None]:
        pass
    if d['bands'] and not d['bands'][0]['name'].lower().find('orchestrator') >= 0: warn.append('첫 번째 큰 기능 Agent는 Orchestrator (세부: 단계 연계 S0a · 진행 현황 S0b)')
    for i, k in enumerate(asis['A4'], 1):
        tv = d.get('tour', {}).get(str(i), {})
        for f in ('now', 'chg', 'next'):
            if not tv.get(f): warn.append(f'흐름 따라가기 {i}단계 {f} 빈칸')
    warn += consistency(A6, TB, d)
    warn += patterns(asis, TB, d)
    warn += v17checks(asis, TB, d)
    warn += branches(asis, TB, d)
    warn += memo_checks(asis, TB, d)
    warn += v15checks(asis, TB, d)
    warn += lessons(asis, TB, d)
    c6 = Counter(TB[k]['t'] for k in A6); new = Counter(t['t'] for k, t in TB.items() if k not in A6)
    stats = dict(as_is=len(A6), 판정=dict(c6), 신규=dict(new), To_be=len(A6) - c6['X'] + new['A'] + new['N'] + new['H'],
                 A_사람태그=sum(1 for k in A6 if TB[k]['t'] == 'A' and TB[k].get('tg') and TB[k]['tg'] != 'Tool'),
                 A_Tool=sum(1 for k in A6 if TB[k].get('tg') == 'Tool'), 큰기능=len(d['bands']), 세부=len(d['subs']),
                 게이트=sum(1 for t in TB.values() if t['t'] == 'M' and not t.get('sub', '').endswith('0b')),
                 현황=sum(1 for t in TB.values() if t['t'] == 'M' and t.get('sub', '').endswith('0b')))
    return err, warn, stats
if __name__ == '__main__':
    err, warn, stats = run(json.load(open(sys.argv[1])), json.load(open(sys.argv[2])))
    for x in err: print('오류', x)
    for x in warn: print('확인', x)
    print(json.dumps(stats, ensure_ascii=False))
    sys.exit(2 if err else 0)
