# tobe-process-map v1.4.2 QC 보고서

**종합 판정: FAIL — 클라이언트 전달 전 핵심 결함 수정과 재검증 필요**

검증일: 2026-11-13 (KST). Critical 0건 / Major 14건 / Minor 4건, 중복 원인을 통합한 18건이다. 실제 첨부 입력에서 As-Is 연결 소실이 재현됐고, 보안 예외 2건과 실패를 정상 종료로 반환하는 QC 결함이 있어 CONDITIONAL PASS로 보지 않았다.

**원본 ZIP·67개 스킬 파일·입력 파일은 수정하지 않았다.** 초기 ZIP SHA256과 추출 파일별 SHA256을 보존하고 종료 시 원본 코드 변경0을 확인했다. 테스트 설계·예외 입력·하네스·HTML·로그·이 보고서만 별도 폴더에 작성했다. 수정된 스킬 ZIP을 만들거나 게시하지 않았다.

## 판정 기준과 테스트 범위

- Critical: 정상 사용에서 광범위한 복구 불가 손상·환경 침해 등 최상위 영향이 재현된 경우. 이번 시험에서는 확인하지 못했다.
- Major: 명시된 핵심 기능, 원천 정보의 정확성, 보안 또는 QC 판정 신뢰성을 훼손하는 재현 결함.
- Minor: 핵심 결과를 막지 않는 안내·편집 이력·측정 정확도 문제.
- P0: 클라이언트 전달 전에 가장 먼저 수정. P1: 실행·입력·지침의 신뢰성을 정리하고 재검증. P2: 경미한 동작·문서 개선. P3: 별도 제품 범위 제안.

첨부 Excel·HTML을 실제로 읽어 357개 업무를 대조하고 두 종류의 HTML을 생성했다. 전체 CRM 후보는 이전에 작성한 같은 부문 설계를 원천 행·업무명으로 정확히 매핑한 **진단 fixture**다. 새 데이터표 스키마와 맞지 않아 발생한 388개 검증 오류는 스킬 결함으로 세지 않았다. 별도로 같은 첨부 입력의 Brief 접수4개 업무를 현행 형식으로 작성해 생성8명령과 브라우저24화면을 실행했다. 이 대표 사례의 설계 오류는0이지만 확인6건·명칭 경고1건이 남아 있으므로 전체 CRM 최종 납품 PASS로 해석하면 안 된다.

관리형 환경은 Playwright 기본 브라우저가 없고 file:// 접근을 차단했다. 원본 명령의 실패를 기록한 다음, 원본 소스는 그대로 두고 **별도 테스트 하네스에서 시스템 Chromium과 동일 파일의 localhost HTTP 전송만 연결**했다. 검사 기준·렌더러를 고쳐 통과시키지 않았다. 설치 안내 누락과 환경 정책 차단을 구분했다.

검증 환경: Python3.12 / openpyxl3.1.5 / Playwright1.62.0 / Chromium156.0.8078.79 / Linux.

## 영역별 결과

| 영역 | 판정 범위 | 실제 확인 내용 |
| --- | --- | --- |
| 구조·파일 | 부분 통과 | ZIP74항목/실제67파일, YAML 유효, Python27개·JavaScript 구문, 활성 참조 파일 정상. 의존성/설치 명세 누락은 QC-13. |
| 원천 입력 | 부분 통과 / 보존 실패 | 첨부 HTML357업무↔Excel357행 전부 대응. Lv4/5/6 열34/123/357 및 레인11개 일치. Lv4 연결30→28 누락 확인. |
| 대표 정상 생성 | 생성·주요 화면 검사 통과, 납품 합격 아님 | 두 입력에서 Excel5–8행의 Brief 접수4업무를 현행 형식으로 새 작성. 생성8명령 exit0, 구조/설계 오류0, 문체위반0. 검토6건+명칭경고1건 보존. 브라우저24화면·상세창12회에서 주요 실패항목0. |
| 전체 CRM 생성 | 진단 HTML 생성·실행 | 357업무 전체와 기존205업무 To-Be 설계 fixture를 정확 대응해 생성. 구버전 데이터표 스키마 오류388은 스킬 결함으로 집계하지 않음. 60화면 검사 완료. |
| UI/UX | 기본 조작 통과 / 오탐1·Undo1 | 안정화 지도30상태(5크기×2탭×3레벨), Agent페이지55상태. JS예외0. 상세창·zoom·흐름 지정 시작/다음·제목/Agent 편집저장재열기 실행. |
| 오프라인 | 시험 범위 통과 | HTTP로 로드 후 offline=True; 6개 탭/레벨 조합, 로컬 다운로드와 저장본 재실행, 원천노드수/내장설계 보존. 외부HTTP요청0. file:// 직접 실행은 환경 정책으로 미검증. |
| 보안 | FAIL | 두 보안 예외 모두 원본 코드로 실제 생성·브라우저 실행 재현. 무해한 표식만 사용. |
| 자동 QC·예외 처리 | FAIL | 실패exit0, 다른HTML/검사0 결과수용, 종료된worker를진행중으로표시. 입력 편집·식별·연속제외 예외결함도 재현. |
| 다른 브라우저·플랫폼 | 미검증 | Firefox/WebKit 공식 다운로드403, 실제Safari/Edge 및 Claude전용SDK 실행환경 없음. Chromium156에서 검증. |

## 확인된 이슈

아래 파일 위치는 ZIP 내부 `tobe-process-map-ver1-4-2/` 기준이다. 재현 데이터·상세 로그는 함께 제공하는 QC 증거 자료에 있다. 테스트용 예외 입력은 별도 사본이며, 첨부 원본에 악성 값이나 편집 오류가 있었다고 주장하지 않는다.

| ID / 심각도 / 우선순위 | 이슈·발생 조건 | 재현 방법·관찰 결과 | 원인 | 수정 방안 | 관련 파일 위치 |
| --- | --- | --- | --- | --- | --- |
| QC-01 / Major / P0 | 원본 연결·연결별 정보 소실 — 첨부 Excel+HTML을 읽고 스킬 compile/restructure로 As-Is 탭을 생성; 복수 반려선이 있는 예외 입력 | asis_from_html.py 두 첨부 파일 → asis_layout.py → 생성 PMD의 views[4].asis.edges를 원본 DATA.lv4.edges와 ID 대응 후 비교; compare_graph.py로 재현; 원본 build 함수에 c→a/rework/승인 누락, c→b/rework/자료 부족 제공. 생성 A6[c]와 compile.py204–206의 edge 재구성 확인. → 원본 Lv.4 34개 박스/30개 연결이 생성 As-Is 34개/28개가 됨. [Monthly/Weekly] 수집·통합→모니터링·리포트와 [Daily] 수집·통합→모니터링·리포트 연결이 없음. Lv.5/6는 공동 진행 복제 정규화 후 연결 쌍 124/358개가 일치. 원본 edge 라벨 30/124/358개는 대응 출력에서 모두 빈 값. 단, 일반선 라벨 중 provenance 문구는 원본에서 상시 표시되지 않을 수 있으므로 라벨 건수는 데이터 보존 측정값임. 실제 Chromium As-Is Lv.4/4단계에서도 두 쌍의 양쪽 노드는 DOM에 있으나 연결 path는 각각 0개로 확인. 별도 통제 fixture에서는 서로 다른 반려 사유가 마지막 사유 하나로 덮였다(현재 CRM에는 반려선 없음). | HTML Lv.4/5 연결을 직접 보존하지 않고 Lv.6 post/pre에서 상향 재구성. edge별 타입·라벨을 노드 단위 문자열로 축약. asis_build에서 edge 사유를 대상별로 저장하지 않고 A6[A].rejr에 반복 대입. compile은 해당 단일 값을 모든 반려선에 재사용. | 각 레벨 원본 edge 배열(시작/끝/종류/조건·사유/사용자 편집)을 손실 없이 저장하고 As-Is는 해당 배열을 사용. 노드의 post/pre는 보조 인덱스로만 파생. 결과 연결·라벨을 원본과 자동 대조. 반려 사유도 연결별로 왕복 검사. | scripts/asis_from_html.py:83; scripts/asis_build.py:54; scripts/asis_build.py:59; scripts/compile.py:197; scripts/compile.py:204; scripts/compile.py:556; scripts/compile.py:570; scripts/compile.py:206 |
| QC-02 / Major / P0 | 저장 편집의 빈 배열·손상 데이터를 무시하고 이전 연결을 되살림 — As-Is HTML에 s04SavedEdits가 있고 사용자가 연결을 전부 삭제했거나 저장 JSON이 손상됨 | 첨부 HTML 사본에 <script id="s04SavedEdits" type="application/json">{"lv6":{"edges":[]}}</script> 추가 후 원본 asis_from_html.py 실행. 별도 사본은 JSON을 {broken-json로 둠. → 두 경우 모두 exit 0으로 asis.json 생성. empty edges의 기대 0개 대신 기존 358개 연결 유지. malformed 저장 정보도 경고 없이 무시. | if x.get("edges")/if x.get("nodes")는 빈 배열을 미지정처럼 처리; except Exception: pass는 손상된 편집 정보를 침묵 처리. | 키의 존재와 배열 형식을 별도로 검사해 빈 배열도 적용. 손상된 saved edits는 위치를 포함한 명시적 입력 오류로 중단하거나 복구 확인 후 처리. | scripts/asis_from_html.py:31; scripts/asis_from_html.py:38; scripts/asis_from_html.py:39; scripts/asis_from_html.py:40 |
| QC-03 / Major / P0 | 변경된 행 번호·중복 이름을 검증하지 않고 다른 업무 속성과 결합 — Excel 행 순서가 바뀌었지만 HTML sourceRows가 예전 번호이거나 sourceRows 없이 같은 계층·업무명 후보가 둘 이상 있음 | 첨부 HTML 사본의 처음 두 sourceRows(5,6)를 교환 후 두 원본 입력을 읽음. 별도 production match 함수 시험은 동일 L4/L5/L6 이름 후보 row5/999를 제공. → 행 번호 교환 사본에서도 357개 전부 정상 대응으로 보고. HTML 「광고주 CRM Brief 문서 접수」에 Excel6행 「캠페인 대상/기간/예산/일정 등 기본 요건 확인」 속성이 결합됨. 이름 중복 후보는 첫 행을 자동 선택하고 모호성을 보고하지 않음. 첨부 원본 자체에서는 357개 대응 모두 정상이며 이 이슈는 예외 입력에서 재현됨. | sourceRows 길이가1이면 업무명 불일치도 허용. l456/l56 후보는 유일성 검증 없이 rs[0] 선택. | 원천 workbook 지문·행 식별자와 계층을 함께 검증. HTML에서 이름만 편집한 정당한 사례는 구분하고, 원천 변경·복수 후보는 확정 대응 또는 명시적 불일치 보고를 요구. | scripts/asis_from_html.py:66; scripts/asis_from_html.py:68; scripts/asis_from_html.py:71; scripts/asis_from_html.py:72; scripts/asis_from_html.py:76 |
| QC-04 / Major / P1 | 연속된 미대응 HTML 업무를 제외하면 앞뒤 연결이 끊김 — 사용자가 --new exclude를 선택하고 제외할 업무가 2개 이상 연속됨 | a→x→y→b 그래프에서 Excel에 대응하는 a,b만 두고 원본 build(..., new_mode="exclude") 호출 → a,b 노드는 남지만 a→b 연결이 생성되지 않음. SKILL의 「제외(앞뒤 업무를 이어 흐름 유지)」에 불일치. | 제외 노드의 앞뒤 후보에서 제외 집합 전체를 먼저 필터링하므로 연속 경로가 사라짐. | 제외 노드 집합을 관통하는 경로를 추적해 남은 predecessor/successor를 연결하고 조건·환류 의미를 보존. 분기와 합류를 임의 완전 연결로 변형하지 않는 회귀검사 추가. | scripts/asis_from_html.py:85; scripts/asis_from_html.py:88; scripts/asis_from_html.py:89; SKILL.md:217 |
| QC-05 / Major / P0 | 설계·문구·브라우저 실패를 성공 종료로 반환 — 오류가 있는 설계·문구 또는 잘림·JavaScript 오류가 있는 HTML 검사 | 첨부 CRM 파생 As-Is+빈 설계로 restructure check; 문구 위반 fixture로 style_check; 실제 브라우저 error-probe 및 geometry-probe 실행 → 설계 오류391건·문구 위반5건에도 각각 exit0. 실제 브라우저 12화면에서 JS오류1·비직각12·잘림12여도 직접 CLI exit0. 최종 집계도 비직각·잘림을 실패 기준에서 제외. | restructure/style은 성공 종료 고정; qc_browser 직접 모드는 실패 종료 없음, result는 6개 지표만 판정. | 공통 실패 판정과 nonzero 종료를 모든 진입점에 적용하고 생성·최종 전달을 해당 결과에 묶는다. 높이 최대2종 등 항목별 정상 기준을 명시한다. | scripts/restructure.py:595; scripts/style_check.py:4; scripts/style_check.py:219; scripts/qc_browser.py:385; scripts/qc_browser.py:386; SKILL.md:338 |
| QC-06 / Major / P0 | 다른 HTML의 결과·검사 0건도 최종 집계가 수용 — result 폴더에 다른 HTML 또는 다른 검사 범위의 JSON이 들어간 경우 | 실제 clean As-Is report를 4개 파트 파일명으로 복사하고 다른 HTML로 result 호출; 별도로 0화면 report 4개 조립 → 두 경계 시험 모두 exit0. 같은 report를 반복 복사한 경우 화면48개로 집계; 실제 검사0건도 성공. 합성 report 경계 시험이며 고객 HTML 통과 결과로 사용하지 않았다. | HTML 해시·run ID·파트·필수 화면/패널 범위 검증 없이 JSON 파일 존재만 확인. | 현재 HTML SHA256, 실행ID, 파트, 검사환경·범위와 결과를 결합하고 불일치·누락·0coverage를 차단. | scripts/qc_browser.py:352; scripts/qc_browser.py:354; scripts/qc_browser.py:370 |
| QC-07 / Major / P1 | 이미 실패한 작업자를 진행 중으로 표시 — QC worker가 예외 종료해 결과 JSON을 쓰지 못한 경우 | PMD 없는 통제 HTML로 실제 worker4개 실행; 모두 exit1 뒤 final_result(wait=0) 조회 → worker 종료코드[1,1,1,1], 보고서0개인데 진행 중/다시 result 실행을 안내하며 exit3. 기본270초 대기는 코드로 확인했고 실제 소비하지 않았다. | 프로세스 상태·종료 원인을 기록하지 않아 JSON 부재를 실행 중으로 간주. | PID·종료코드·예외·시간 한도를 저장하고 진행/실패/시간초과를 분리해 실패 원인을 반환. | scripts/qc_browser.py:350; scripts/qc_browser.py:352; scripts/qc_browser.py:356; scripts/qc_browser.py:363 |
| QC-08 / Major / P0 | 대소문자 script 종료 태그로 데이터가 JavaScript 실행 — 제목·설명 등 인라인 JSON 값에 혼합 대소문자 종료 태그가 포함 | 첨부 자료 기반 PMD 사본의 title에 무해한 window 표식만 넣고 원본 build_html로 생성·실행 → 정상 대조군 표식 없음/JS오류0. 예외본은 표식1, 지도 초기화 실패, JS오류3. 원본 첨부 자체에 악성 값이 있었다는 뜻은 아니다. | 소문자 </script만 치환하지만 HTML 파서는 대소문자를 구분하지 않음. | 인라인 JSON의 <를 Unicode escape로 직렬화하거나 안전한 데이터 주입 방식 적용; 혼합 대소문자·특수문자 회귀검사. | scripts/build_html.py:5 |
| QC-09 / Major / P0 | 업무명 HTML 이벤트가 상세창에서 실행 — 업무명에 HTML 태그·이벤트 속성이 포함된 경우 | 같은 CRM PMD 사본의 업무명에 무해한 img/onerror 표식을 넣고 해당 상세창을 연다 → window 표식이 executed로 바뀌어 실행 확인. 엔진과 일반 JS오류 검사는 정상일 수 있음. 외부통신·정보유출 코드는 사용하지 않았다. | plain()이 문자열을 임시 div.innerHTML로 파싱하고 whatHTML이 원본 업무명을 전달. | 업무명은 textContent 등 일반 텍스트 경로로 처리. 편집용 제한 서식이 필요하면 별도 허용목록 정제. | assets/engine.js:176; assets/engine.js:1210 |
| QC-10 / Major / P1 | 오류가 남아도 전달하라는 지침과 QC0 기준 충돌 — HTML이 생성됐지만 설계 또는 화면 오류가 남은 경우 | SKILL:52의 자동 보정 뒤 HTML 전달 지침과 :64/:338의 모든 검사0 전달 기준을 비교 → 수정 실패 시 전달/중단에 대해 서로 반대 지침이 존재 | 생성 지속 정책과 최종 납품 허용 기준을 구분하지 않음 | 후보 생성은 허용하되 최종 전달은 명시적 fail-closed 기준으로 통일; 실패 상태와 미검증을 보고 | SKILL.md:52; SKILL.md:64; SKILL.md:331; SKILL.md:338 |
| QC-11 / Major / P1 | Lv.4·Lv.5 재설계 허용 범위 모순 — 같은 Lv.3 안에서 Lv.4를 통합하거나 To-Be Lv.5 이름/구성을 새로 설계할 때 | SKILL:12 한 문단 및 restructure:9,13과 :42 비교 → Lv.4 순서변경·통합·추가 허용과 이름·순서 유지/통합 금지가 공존. Lv.5 신규설계와 원문유지도 공존 | 새 Lv.4 계획 기능 도입 후 기존 설계 규칙 문장이 남음 | 현재 tobe_lv4 계약에 맞춰 Lv.4·Lv.5 규칙을 단일 정의로 정리하고 이전 정책 문구 삭제 | SKILL.md:12; SKILL.md:289; SKILL.md:307; references/restructure.md:9; references/restructure.md:13; references/restructure.md:42 |
| QC-12 / Major / P1 | 준비 경로와 후속 명령의 작업 경로 불일치 — 문서 명령을 cd <skill> 위치에서 순서대로 실행 | 준비는 /home/claude/work/asis.json 생성; 다음 skeleton·check는 <skill>/work/asis.json 읽음 → 두 경로는 다르며 작업 폴더 이동·심볼릭 링크·공통 WORK 설정이 없음. 압축 원본에는 work 폴더도 없음 | 절대 경로 예제와 상대 경로 예제 혼재 | 한 WORK 변수 또는 일관된 절대 경로를 선언하고 모든 명령·로그·출력에 적용 | SKILL.md:68; SKILL.md:70; SKILL.md:72; SKILL.md:106; SKILL.md:315 |
| QC-13 / Major / P1 | 의존성·브라우저 설치 조건 및 설치 지침 누락 — 필요 패키지/Playwright Chromium이 미설치된 새 실행 환경 | site-packages 없이 parse_excel.py ... report 또는 qc_browser.py ... quick 실행 → openpyxl/playwright ModuleNotFoundError 재현. ZIP에 requirements/pyproject/설치 안내 없음. 브라우저는 Playwright 기본 executable만 사용 | 개발 환경의 사전 설치 상태를 암묵적으로 전제 | 지원 Python과 의존성 명세, Chromium 설치·탐색 절차 및 사전검사 제공. Pillow/python-docx/pdftotext는 사용 기능별 선택 의존성 구분 | scripts/parse_excel.py:13; scripts/qc_browser.py:13; scripts/qc_browser.py:132; scripts/asis_layout.py:27; scripts/b_widget.py:69; scripts/inputs.py:45; scripts/inputs.py:49; SKILL.md:66 |
| QC-14 / Major / P1 | 원본 설계 수정 후 재생성을 생략하는 재시도 지침 — fill/check가 빈칸을 지적해 원본 design.json을 수정한 경우 | SKILL:330대로 design.json 수정 후 check부터 실행하면 :324 명령은 이전 work/tobe/design_tobe.json을 검사 → synth 실행 없이 원본 변경은 검사 대상에 반영되지 않음. 별도 참조문서는 synth부터 재실행하라고 지시 | 원본 설계와 파생 설계의 데이터 흐름을 재시도 안내에서 혼동 | 원본 수정→synth→fill→check를 하나의 명령으로 묶거나 정확한 최소 재시도 절차로 통일 | SKILL.md:324; SKILL.md:330; references/restructure.md:62 |
| QC-15 / Minor / P2 | 사용자 안내 버전 예시가 1.4.0으로 남음 — 작업 내용 없는 인사에 고정 소개 문구 사용 | name은 ver1-4-2인데 그대로 쓰라는 소개 예시는 ver1-4-0 → 설치 버전과 사용자에게 표시될 수 있는 버전 불일치 | 버전 문자열 중복 관리 | 소개 문구에서 name 기반 버전만 쓰거나 예시 갱신 | SKILL.md:2; SKILL.md:109; SKILL.md:112 |
| QC-16 / Minor / P2 | 공통 문구 사전의 기본 활성화 설명 불일치 — use_phrasebook을 지정하지 않고 fill 실행 | SKILL:291은 사전으로 먼저 채운다고 안내하지만 구현은 get(use_phrasebook, False) → 실제 기본값은 꺼짐; 자동 채움을 기대한 작업자는 빈칸이 남는 이유를 오인할 수 있음 | 사전 사용을 선택 기능으로 바꾼 뒤 오래된 작성 안내 잔존 | 선택 기능과 기본 OFF를 모든 작성 안내에 일치시키기 | SKILL.md:291; SKILL.md:408; scripts/autofill.py:451 |
| QC-17 / Minor / P2 | Agent 페이지의 배율 반올림을 글자 잘림으로 오탐 — 1800×1100에서 전체 CRM 진단 후보의 B7 Agent 페이지를 검사 | B7 #afsz와 내부 컨테이너 크기 및 실제 업무 라벨 경계를 대조 → clientWidth9096 / scrollWidth9100으로 잘림1건 보고. 실제 오른쪽 라벨 끝9052.99, 아래끝829.30은 영역9096×850 안이며 textOutside=[]; 텍스트 소실 미확인. | 외부 크기는 정밀 배율, 내부 transform은 소수3자리 배율을 써 4px 차이. JS_WIN이 컨테이너 초과를 텍스트 잘림으로 분류. | 동일 배율로 크기를 계산하고 컨테이너의 의도된 스크롤과 실제 텍스트 절단을 분리 판정. | assets/engine.js:1786; assets/engine.js:1787; assets/engine.js:1788; scripts/qc_browser.py:296 |
| QC-18 / Minor / P2 | 변경하지 않은 새 박스를 취소하는 데 Undo 두 번 필요 — 흐름도 편집에서 박스 추가 후 자동 포커스된 이름을 수정하지 않고 Undo | 정상 형식 소형 HTML의 박스추가1회→Undo1회→Undo1회 → 노드 수8→9→9→8. 첫 Undo는 무효 이력을 취소하고 두 번째에 추가가 취소됨. | 이름 blur 처리에서 실제 텍스트 변경 여부와 관계없이 Undo 이력 추가. | 텍스트가 실제로 바뀐 경우에만 이력을 저장하고 Add1회→Undo1회 원복을 회귀검사. | assets/engine.js:2005 |

## 오탐·진단 관찰을 구분한 항목

- **B7 잘림은 실제 텍스트 소실로 판정하지 않았다.** 컨테이너가4px 넘지만 업무 라벨은 영역 안에 있었다. QC-17은 검사 오탐과 반올림 문제다.
- 원본 fork/join이 내부 s로 바뀐 것만으로 화살표 색상 회귀라고 판단하지 않았다. Lv.4의 두 연결 누락은 데이터·DOM 양쪽에서 확인했다. 일반선 라벨 일부는 원본에서도 상시 보이지 않으므로 30/124/358건의 라벨 손실은 데이터 보존 측정값이다.
- 전체 CRM 진단 후보의 `fork_bad=1`은 구버전 설계의 새 레인 복제·배치와 연관된 관찰로 남겼다. 현행 소형 후보에서는0이며 독립된 엔진 결함으로 집계하지 않았다.
- 전체 검사의 console 오류1은 테스트 HTTP 전송의 favicon404였다. 제품 JavaScript 예외로 세지 않았다. 독립 오프라인 대조군 및 안정화 UI 시험에서 JS예외0을 확인했다.
- `edge_overlap_max`와 `shared_bends_max`만으로 실패를 선언하지 않았다. SKILL.md:415는 기본 선 합침을 명시한다. 정상 소형의4/1과 전체 진단의1650/102는 부가 측정값이며, 별도 UI 파손 증거 없이 결함 수에 넣지 않았다.

## 실행한 테스트

| 시험 | 시나리오 | 결과 | 증거 경로 |
| --- | --- | --- | --- |
| T01 | 실제 첨부 입력 파싱 | 357/357 대응, 미대응0 | audit-input/summary.json |
| T02 | 원천 배치/레인 대조 | 34/123/357개 열·Lv5/6 레인 일치 | audit-input/layout-data-comparison.json |
| T03 | 원천 연결/라벨 대조 | Lv4 두 연결 누락, 라벨 데이터 손실 | audit-input/graph-comparison.json |
| T04 | 저장 편집 빈 배열/손상 | 기존358연결로 되돌아감; 경고 없이 성공 | audit-input/input-probe-results.json |
| T05 | 오래된 행번호/중복 업무명 | 다른 행 속성 결합/첫 후보 자동 선택 | audit-input/input-probe-results.json |
| T06 | 연속 제외/복수 반려 사유 | 경로 단절/마지막 사유로 덮임(통제 fixture) | audit-input/input-probe-results.json |
| T07 | DATA 없는 HTML | exit1·산출물 미생성: 정상 차단 | audit-input/input-probe-results.json |
| T08 | 현행 정상 대표 생성 | 8명령 exit0, 주요 오류0; 검토 경고 보존 | generation/summary.json |
| T09 | 정상 대표 전체 브라우저 QC | 24화면·상세창12회, 주요 실패항목0 | generation/normal/browser-qc.json |
| T10 | 전체 CRM 진단 브라우저 QC | 60화면, 스크립트예외0; B7오탐1/fork경고1 별도 분리 | builtin-qc/all.json |
| T11 | 화면 크기별 지도/Agent 페이지 | 지도30상태·Agent55상태 JS예외0 | audit-ui/ui-summary.json |
| T12 | 탭·상세창·zoom·tour 지정 시작 | 정상 조작과 다음업무 이동 확인 | audit-ui/interaction-probe.json |
| T13 | 오프라인·편집본 저장/재열기 | 외부요청0·제목/노드/내장설계 보존 | audit-security/crm-offline/result.json |
| T14 | Agent 이름/설명 동기화·저장 | 상세/구조도/저장본 일치 | audit-security/feature-edit/summary.json |
| T15 | 박스 추가/Undo | 추가 성공, 취소에2회 필요 | audit-security/feature-edit/summary.json |
| T16 | script 종료 태그/업무명 이벤트 | 무해한 JS 표식 실행2건 | audit-security/crm-security/security-probe.json |
| T17 | 검사 오류와 종료코드 | 설계391·문구5·브라우저 오류에도exit0 | audit-gates/summary.json |
| T18 | 다른HTML/0검사 보고서 집계 | 잘못된 report도exit0(합성 경계시험) | audit-gates/aggregation-results.json |
| T19 | 실제worker4개 crash | 모두exit1 뒤 진행중exit3 | audit-gates/worker-crash-result.json |
| T20 | 연결선 추가·유형/라벨·저장·삭제·Undo | 6검사 통과/JS오류0, 실제 UI 사용 | audit-security/feature-edit/edge-summary.json |

전체 CRM 원본 QC는60화면, 정상 대표 QC는24화면을 순회했다. 별도 UI 크기 매트릭스는 1920×1080, 1366×768, 1280×720, 768×1024, 390×844에서 안정화한 지도30상태와 Agent상세55상태를 검사했다. 서로 중복되는 범위이므로 이 수치를 합산해 고유 화면 수로 주장하지 않는다. 일반 노드 패널, 흐름 지정 시작·다음 이동, Agent 이름/설명 편집 동기화, 편집본 저장·재열기도 실제 실행했다. 연결선은 실제 UI에서 추가→유형·이름표 변경→저장·오프라인 재열기→삭제→Undo 복원까지6검사를 통과했다.

## 수정 우선순위와 구조 개선

1. **P0 — 원천·보안·최종 판정:** QC-01~03, QC-05~06, QC-08~09. 레벨별 원본 edge를 손실 없이 보존하고 저장 편집·원천 대응을 검증한다. 사용자 데이터가 실행되는 두 경로를 차단한다. 오류 종료코드, 파일 해시, 실행ID, 검사 범위를 하나의 최종 판정에 묶는다.
2. **P1 — 예외·실행 절차:** QC-04, QC-07, QC-10~14. 연속 제외 연결과 작업자 crash 처리를 고치고, 단일 작업 경로·의존성 설치·원본→파생 설계 재생성 순서를 명시한다. 후보 생성과 최종 전달 기준을 분리하고 재설계 허용 범위를 통일한다.
3. **P2 — 안내·오탐·편집 이력:** QC-15~18. 버전/사전 기본값 문구를 정리하고, 실제 텍스트 잘림과 캔버스 반올림을 구분한다. 변경 없는 blur는 Undo 이력에 넣지 않는다.

구조적으로는 입력 정규화·설계 검증·컴파일·브라우저 검사·최종 판정을 한 실행 흐름으로 연결하는 것이 좋다. 단, 자동으로 오류를 무시하거나 입력 연결을 재해석해 성공시키면 안 된다. 이번 재현 사례를 회귀 테스트로 보존하고, sourceRows 변동·저장 편집 빈 배열·복수 반려·연속 제외·검사파일 바뀜·worker crash·특수문자·편집 저장 왕복을 필수 집합으로 둔다. 전체357업무의 현행 설계가 준비되면 독립된 사람 개입과 실질 재설계를 업무 담당자가 검토하고 전체 화면을 다시 검사해야 한다.

## 요구사항 밖 개선 제안

- 390px에서는 제목과 버전 배지가 겹치는 현상이 전체·소형 후보 모두에서 보였다(`assets/shell.html:746,749`). 모바일 조작 지원이 명시되어 있지 않아 현재 핵심 기능 실패에 합산하지 않았다. 모바일 지원 범위를 정하면 제목·배지 재배치와 지도 접근성을 P3로 개선한다.
- 이번 ZIP은 HTML 생성을 명시 출력으로 삼는다. 이전 대화의 Excel 출력 요구를 새 ZIP의 구현 요구에 자동으로 더하지 않았다. Excel/PNG/PDF 출력이 다시 필요하면 별도 요건·테스트로 확정한다.

## 미검증 범위와 사유

| 항목 | 사유 | 후속 검증 |
| --- | --- | --- |
| Firefox·WebKit·실제 Safari/Edge | Playwright Firefox/WebKit 공식 설치를 실제 시도했으나 네트워크 정책403 Domain forbidden. 실제 Safari/Edge는 해당 실행환경이 없음. | 각 브라우저에서 생성물·수정저장·한글·다운로드 경로 재검증 |
| file:// 직접 열기 | 관리형 Chromium의 ERR_BLOCKED_BY_ADMINISTRATOR. 같은 파일의 loopback HTTP 전송으로만 대체. | 파일 직접 열기가 허용된 환경에서 재검증 |
| Claude 전용 파일 전달/게시 SDK 및 실제 작업 횟수 | 일반 Chromium에는 window.claude가 없고 실제 Claude 실행 로그가 없음. | 클라이언트 Claude 환경에서 다운로드 및 작업 한도 실측 |
| 357업무 전체 신규 설계의 업무적 적합성 | 전체 렌더러 QC에는 기존 설계 fixture를 현재 입력에 정확 매핑. 현행 신규 작성은 대표4업무로 한정. | 전체 현행 설계의 재설계 근거·독립된 사람 판단·전체표 스키마·경고 검토 후 별도 승인 |
| 모든 편집 조합·모바일 기기·장시간 반복 | 대표 편집 경로를 실행했으며 가능한 모든 조합/기기/장기부하의 완전 탐색은 수행하지 않음. | 핵심 시나리오 회귀집합과 지원 기기 범위 확정 |

## 원본 식별·보존

| 파일 | bytes | SHA256 |
| --- | --- | --- |
| tobe-process-map-ver1.4.2.zip | 1304755 | 947eb0fd1fb32e1ee8e652f0b83f85ffd317683bfd8a726a1a9db22971b71728 |
| 261019-S13 CRM 마케팅-Summary Sheet-v4 Sent (1).xlsx | 202910 | 8f4be5eb4ad6ea90bd81a3a01f996b3ffe4c4a8619b2a5bf03b237e81778eb23 |
| 261019-S13 CRM 마케팅-HTML-v4 (1).html | 1332383 | 769af146ea9e91f2d5dc23fee80e0d762a8fd048fa870eb0fd0059315acdcbed |

초기 추출 파일 해시 목록은 `original-sha256.json`, 실행 종료 보존 확인은 `preservation.json`에 있다. QC 보고서의 FAIL은 현재 원본의 판정이며, 권고 수정은 적용하지 않았다.
