# v1.4.2 보안·오프라인·호환성 QC

검증일: 2026-11-13 (KST). 원본 ZIP·스킬 코드·첨부 입력 파일은 수정하지 않았다. 테스트 하네스와 예외 데이터·생성물은 audit-security 아래에만 작성했다.

## 확인된 이슈

| ID | 심각도 / 우선순위 | 발생 조건·재현 | 실제 결과 | 원인·위치 | 수정 권고 |
|---|---|---|---|---|---|
| SEC-01 | Major / P1 | 첨부 Excel+HTML을 사용한 CRM 생성 후보의 PMD 사본에서 text.title을 `QC </ScRiPt><ScRiPt>window.__QC_SCRIPT_MARKER__=1</ScRiPt><ScRiPt>`로 바꾸고 원본 build_html.build를 실행한 뒤 Chromium에서 연다. | 무해한 window 표식이 1로 설정돼 데이터에 들어 있던 JavaScript 실행을 확인. 지도 엔진은 초기화되지 않고 JavaScript 오류 3건 발생. 정상 대조군은 표식 없음·오류 0. | scripts/build_html.py:5에서 소문자 `</script`만 치환. HTML 파서는 script 종료 태그의 대소문자를 구분하지 않으므로 우회 가능. | 인라인 JSON의 모든 `<`를 `\u003c`로 직렬화하는 등 HTML script 컨텍스트에 안전한 방식 사용. 대·소·혼합 종료 태그, 특수문자, 실제 사용자 설명을 포함한 회귀검사 추가. |
| SEC-02 | Major / P1 | 같은 CRM PMD 사본의 업무명(lb)에 `img` 태그와 무해한 onerror 표식을 넣고 생성한다. As-Is 또는 To-Be의 해당 업무 상세창을 연다. | 상세창 열 때 `window.__QC_LABEL_MARKER__`가 `executed`로 바뀜. 엔진은 정상 실행하므로 일반 JavaScript 오류 점검만으로 감지되지 않음. 정상 대조군은 표식 없음. 외부 요청은 발생시키지 않았다. | assets/engine.js:176 `plain(h)`가 업무명을 임시 div.innerHTML로 해석. assets/engine.js:1210의 whatHTML이 미편집 원본 n.lb를 plain에 직접 전달. HTML을 '글자로 바꾸기' 위해 파싱하는 과정에서 이벤트 핸들러가 실행된다. | 원천 업무명은 일반 텍스트로 처리하고 innerHTML에 전달하지 않는다. 편집용 제한 서식과 일반 텍스트 경로를 구분하고, 필요한 rich text는 허용 태그·속성만 정제한다. 무해한 이벤트 핸들러를 포함한 업무명 클릭 회귀검사 추가. |

두 사례는 사용자가 첨부한 원본 데이터에 악성 내용이 있었다는 뜻이 아니다. 보안 예외 입력을 별도 사본에 넣은 결과이며, 본 테스트에서 외부 통신·파일 접근·정보 유출 코드를 사용하지 않았다. PMD 직렬화와 업무명 렌더링의 취약점을 확인한 것으로, 실제 팀 사용 중 공격 발생을 주장하지 않는다.

재현 명령:

```bash
PYTHONDONTWRITEBYTECODE=1 python audit-security/security_probe.py \
  --html generation/crm-diagnostic.html --out audit-security/crm-security
```

증거: `crm-security/security-probe.json`, 동일 폴더의 정상·예외 HTML 3개와 PNG. 하네스는 원본 `scripts/build_html.py`와 `assets/shell.html`, `assets/engine.js`를 그대로 읽는다. 별도 코드 수정으로 취약점을 만든 것이 아니다.

## 실행해 통과한 항목

첨부 두 파일을 반영한 `generation/crm-diagnostic.html`을 Chromium 156.0.8078.79의 로컬 HTTP에서 연 뒤 네트워크를 offline=True로 전환했다.

- As-Is/To-Be × Lv.4/5/6, 6개 조합에서 지도 표시 및 상세 화면 전환 실행.
- 일반 입력에서 JavaScript 오류 0건, 외부 HTTP(S) 요청 0건. 외부 script/stylesheet 요소 0건.
- UI의 문구 편집으로 제목을 변경한 뒤 '편집본 저장' 버튼을 실제로 눌러 HTML 다운로드 성공(2,469,501 bytes).
- 다운로드한 HTML을 offline=True 브라우저에서 다시 실행해 엔진 초기화, 변경 제목, 모든 레벨의 노드 수, 내장 pm-design 보존 확인. 다시 연 페이지 JavaScript 오류 0건.
- 화면 텍스트 편집·저장은 `references/editing.md:3,25,45`의 명시 기능에 해당한다. 이 결과만으로 전체 Agent 상세 표나 모든 흐름 편집 동작의 정확성을 보장하지는 않는다.

증거: `crm-offline/result.json`, `crm-offline/saved-edit.html`, 전후 PNG, `offline_download_probe.py`.

사용한 CRM 후보는 구버전 설계 fixture를 현재 첨부 자료에 정확 대응한 진단용 데이터이며, 후보의 새 스키마 점검 오류를 승인한 최종 업무 설계는 아니다. 오프라인·직렬화·저장 기능의 대조군으로 사용했고, 업무 설계 품질이나 상세 표의 데이터 적합성을 통과했다고 주장하지 않는다.

## 미검증·환경 한계

| 항목 | 수행·차단 사유 | 판정 범위 |
|---|---|---|
| Firefox | Playwright 공식 설치를 실제 실행했으나 cdn.playwright.dev와 playwright.download.prss.microsoft.com에서 403 Domain forbidden. 로그: ../browser-install.log | Firefox 호환성 미검증 |
| WebKit / Safari 계열 | WebKit 공식 설치도 별도로 실행했으나 같은 정책 차단. 로그: ../webkit-install.log. WebKit이 실행되더라도 실제 Safari 기기와 완전히 같다고 볼 수 없음 | WebKit·실제 Safari 호환성 미검증 |
| file:// 직접 열기 | 관리형 Chromium 정책이 ERR_BLOCKED_BY_ADMINISTRATOR로 차단. 원본 스킬 결함으로 분류하지 않음 | 로컬 HTTP 후 offline=True 및 set_content 재실행으로 오프라인 자립성을 확인했으나 실제 file:// 탐색은 미검증 |
| Claude 내 downloads/artifact SDK | 일반 Chromium에는 window.claude가 없어 해당 분기 미실행. 로컬 Blob 다운로드 분기만 실행 | Claude 내부 파일 전달/게시 SDK 분기 미검증 |

## 범위 밖 개선 제안

현재 v1.4.2는 편집본 HTML 다운로드를 명시한다. Excel·PNG·PDF 내보내기나 특정 모바일 기기의 완전한 조작 지원을 기존 버전의 요구사항만으로 강제하지 않았다. 그러한 기능은 별도 제품 요구사항이 정해졌을 때 추가 테스트해야 한다.

보안 수정 후 SEC-01/02를 먼저 재검증하고, 원본 입력의 정상 HTML·다운로드 편집본이 여전히 열리는지 함께 회귀검증할 것을 권고한다. 네트워크 접근이 허용되는 검증 환경에서 Firefox·WebKit을 추가 실행하고, 실제 Claude에서 다운로드 SDK 경로를 별도 점검해야 한다.
