# 정상 스키마 소형 CRM 편집 기능 QC

대상: `generation/normal/crm-diagnostic.html`. 첨부 원본 두 파일 기반의 정상 스키마 소형 설계이며 원본 코드·원본 HTML은 수정하지 않았다. Chromium에서 로드한 후 offline=True로 전환해 실행했다.

통과:
- Agent 상세 페이지에서 B1의 내용 편집을 켜고 S1a 이름·설명을 실제 contenteditable UI로 수정.
- 세부 Agent 데이터와 상세 페이지 문구, 구조도 이름과 설명 tooltip에 동일하게 반영.
- '편집본 저장'을 실제 클릭해 HTML 다운로드. 오프라인 재실행 시 변경한 이름·설명 보존. JavaScript 오류 0건.
- 흐름도 편집에서 박스 추가 성공(8→9개), 두 번째 Undo 후 원상 복원(8개).
- 흐름도 편집 UI에서 기존 두 박스 사이의 새 연결 추가 → 일반선을 반려선(r)으로 변경 → 이름표 변경 → 편집본 HTML 저장 → 오프라인 재열기에서 유형·이름표·연결 보존 → 연결 삭제 → Ctrl+Z로 복원까지 통과. JavaScript 오류 0건.

| ID | 등급·우선순위 | 발생 조건·재현 | 실제 결과 | 원인·위치 | 권고 |
|---|---|---|---|---|---|
| EDIT-01 | Minor / P2 | 흐름도 편집 → 박스 추가 1회 → 자동 선택된 새 업무명을 수정하지 않고 Undo 클릭 | 노드 수 8→9→첫 Undo 9→두 번째 Undo 8. 한 번의 추가를 취소하는 데 Undo 두 번 필요 | assets/engine.js:2005의 editText 완료 처리에서 실제 글자 변경 여부와 무관하게 blur 시 UNDO에 현재 상태를 추가 | 실제 이름이 변경된 경우에만 글자 편집 이력을 추가. Add 한 번과 이름 수정 없음에 대해 Undo 한 번으로 취소되는 회귀검사 추가 |

연결선 추가·종류·이름표 변경·저장·삭제·Undo는 추가 실행으로 검증을 완료했다. Claude SDK 저장 분기는 해당 런타임이 없어 미검증이다. 데이터 결손 때문에 발생한 Agent 패널 오류는 없었다.

재현: `PYTHONDONTWRITEBYTECODE=1 python audit-security/feature-edit/probe.py`. 증거: `summary.json`, 전후 화면 PNG, `agent-edited.html`.

연결선 재현: `PYTHONDONTWRITEBYTECODE=1 python audit-security/feature-edit/edge_probe.py`. 증거: `edge-summary.json`, `edge-edited.html`, 전후 PNG. 원본 코드와 생성 후보 HTML은 모두 그대로 두고 별도 편집본만 저장했다.
