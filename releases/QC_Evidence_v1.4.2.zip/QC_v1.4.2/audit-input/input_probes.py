"""QC-only exception inputs; no edits to skill or user sources."""
from pathlib import Path
import sys,json,copy,subprocess,collections,os
ROOT=Path('/workspace/qc-v142/original/tobe-process-map-ver1-4-2');OUT=Path('/workspace/qc-v142/audit-input');sys.path.insert(0,str(ROOT/'scripts'))
import asis_from_html as H
html=Path('/workspace/attachments/21def738-5e7a-4bcb-a138-28d6977426c1/261019-S13 CRM 마케팅-HTML-v4 (1).html')
xlsx=Path('/workspace/attachments/ab34d434-1175-4b70-8b03-e4820a81d686/261019-S13 CRM 마케팅-Summary Sheet-v4 Sent (1).xlsx')
text=html.read_text();start=text.index('{',text.index('const DATA'));original,end=json.JSONDecoder().raw_decode(text[start:]);R=H.read_excel(xlsx)
def emit(name,d=None,extra=''):
 p=OUT/(name+'.html');p.write_text(text[:start]+json.dumps(d or original,ensure_ascii=False)+text[start+end:]+extra);return p
def cli(name,p):
 o=OUT/(name+'.json');r=subprocess.run([sys.executable,str(ROOT/'scripts/asis_from_html.py'),str(p),str(xlsx),str(o)],capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 (OUT/(name+'.log')).write_text(r.stdout+r.stderr)
 return {'exit':r.returncode,'output_exists':o.exists(),'stdout':r.stdout},json.loads(o.read_text()) if o.exists() else None
results={}
pair,how,unused=H.match(original,R)
results['baseline']={'html_lv6':len(original['lv6']['nodes']),'excel_rows':len(R),'matched':len(pair),'unused':len(unused),'edge_counts':{lv:dict(collections.Counter(e[2] for e in original[lv]['edges'])) for lv in ['lv4','lv5','lv6']}}
# Updated Excel row order / stale HTML sourceRows must not silently exchange attributes.
d=copy.deepcopy(original);a,b=d['lv6']['nodes'][:2];a['sourceRows'],b['sourceRows']=b['sourceRows'],a['sourceRows'];p=emit('stale-source-rows',d)
r,generated=cli('stale-source-rows',p);m={x['html_id']:x for x in generated['A6'].values()}
r['mismatches']=[{'html_id':n['id'],'html_label':n['label'],'assigned_row':m[n['id']]['row'],'excel_label_at_assigned_row':R[m[n['id']]['row']]['lv6']} for n in d['lv6']['nodes'][:2]];results['stale_source_rows']=r
# User saved removal of every connection must survive import.
p=emit('saved-empty-edges',extra='<script id="s04SavedEdits" type="application/json">'+json.dumps({'lv6':{'edges':[]}})+'</script>')
r,_=cli('saved-empty-edges',p);r.update(expected_edges=0,actual_edges=len(H.read_html(p)['lv6']['edges']));results['saved_empty_edges']=r
# Invalid saved edits must be surfaced, not silently ignored.
p=emit('saved-malformed',extra='<script id="s04SavedEdits" type="application/json">{broken-json</script>')
r,_=cli('saved-malformed',p);r['actual_edges']=len(H.read_html(p)['lv6']['edges']);results['malformed_saved_edits']=r
# Missing required DATA is a control failure, should fail clearly.
p=OUT/'no-data.html';p.write_text('<!doctype html><p>No DATA</p>');r,_=cli('no-data',p);results['missing_DATA']=r
# Name match is ambiguous when sourceRows absent: full matching function silently chooses first.
n=copy.deepcopy(original['lv6']['nodes'][0]);n.pop('sourceRows',None)
x=copy.deepcopy(next(iter(R.values())));x2=copy.deepcopy(x);x2['row']=999;x2['sys']='DIFFERENT_SYSTEM'
small={'lv6':{'nodes':[n],'edges':[]}};amb_R=collections.OrderedDict([(x['row'],x),(999,x2)])
amb_pair,amb_how,amb_unused=H.match(small,amb_R)
results['ambiguous_name_match']={'candidate_rows':list(amb_R),'selected_row':amb_pair.get(n['id']),'method':amb_how.get(n['id']),'unused':amb_unused,'raises':False}
# Multiple consecutive unmatched boxes excluded: requested predecessor-successor reconnect disappears.
nodes=[]
for ident in ['a','x','y','b']:
 nodes.append({'id':ident,'label':ident,'hierarchy':{'l1':'Stage','l4':'Group','l5':'TaskGroup'}})
D={'lv6':{'nodes':nodes,'edges':[['a','x','std',''],['x','y','std',''],['y','b','std','']]}}
rr={1:{'row':1,'lv1':'Stage','lv2':'Domain'},2:{'row':2,'lv1':'Stage','lv2':'Domain'}}
a=H.build(D,rr,{'a':1,'b':2},'exclude');results['exclude_consecutive_nodes']={'expected_connection':['a','b'],'remaining_nodes':[x['html_id'] for x in a['A6'].values()],'actual_post':[x['post'] for x in a['A6'].values()]}
(OUT/'input-probe-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in results.items() if k!='baseline'},ensure_ascii=False,indent=2))
