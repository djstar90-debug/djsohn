# v1.4.2 구조·지침 QC

원본 ZIP·코드 수정 없이 정적 검증 및 독립 예외 입력의 CLI 실행을 수행했다. HTML 생성·브라우저 결과는 다른 QC 범위와 합쳐 판정해야 한다.

## 통과한 항목

- YAML frontmatter 정상(name/description 문자열), ZIP 루트 이름과 name 일치.
- Python 스크립트 27개 AST 문법 통과, engine.js Node 구문 검사 통과.
- 활성 지침에서 참조하는 scripts/references/assets 파일 누락 없음.
- 오래된 changelog에서만 현재 미포함 make_engine.py, s01_inputs.json을 언급한다. 현재 실행 경로의 오류로 분류하지 않았다.
- v1.4.2 자체의 명시 출력은 HTML이다. XLSX 출력 부재를 현 버전 기능 위반으로 분류하지 않았다.

## 발견 이슈

| ID | 등급 | 이슈·발생 조건 | 재현·확인 결과 | 원인·수정 방안 | 관련 위치 |
|---|---|---|---|---|---|
| STR-01 | Major | 설계·문구 검사 오류에도 성공 종료 — 잘못된 설계나 문구가 들어간 입력을 check CLI로 검사 | 첨부 CRM에서 생성한 asis.json과 empty-design.json으로 restructure.py check; bad-style-crm-design.json으로 style_check.py 실행; 원본 연결357/Lv.4구성34 오류391건에도 exit0; 문구 위반5건에도 exit0 | restructure check 및 style check가 sys.exit(0) 고정. style_check docstring의 위반 exit1 약속과도 불일치 → 검증 실패를 nonzero로 반환하고 생성 단계에서 필수 검증 결과를 강제. 사람이 보는 로그와 기계적 합격 판정을 분리 | scripts/restructure.py:595, scripts/style_check.py:4, scripts/style_check.py:219 |
| STR-02 | Major | 오류가 남아도 전달하라는 지침과 QC0 기준 충돌 — HTML이 생성됐지만 설계 또는 화면 오류가 남은 경우 | SKILL:52의 자동 보정 뒤 HTML 전달 지침과 :64/:338의 모든 검사0 전달 기준을 비교; 수정 실패 시 전달/중단에 대해 서로 반대 지침이 존재 | 생성 지속 정책과 최종 납품 허용 기준을 구분하지 않음 → 후보 생성은 허용하되 최종 전달은 명시적 fail-closed 기준으로 통일; 실패 상태와 미검증을 보고 | SKILL.md:52, SKILL.md:64, SKILL.md:331, SKILL.md:338 |
| STR-03 | Major | Lv.4·Lv.5 재설계 허용 범위 모순 — 같은 Lv.3 안에서 Lv.4를 통합하거나 To-Be Lv.5 이름/구성을 새로 설계할 때 | SKILL:12 한 문단 및 restructure:9,13과 :42 비교; Lv.4 순서변경·통합·추가 허용과 이름·순서 유지/통합 금지가 공존. Lv.5 신규설계와 원문유지도 공존 | 새 Lv.4 계획 기능 도입 후 기존 설계 규칙 문장이 남음 → 현재 tobe_lv4 계약에 맞춰 Lv.4·Lv.5 규칙을 단일 정의로 정리하고 이전 정책 문구 삭제 | SKILL.md:12, SKILL.md:289, SKILL.md:307, references/restructure.md:9, references/restructure.md:13, references/restructure.md:42 |
| STR-04 | Major | 준비 경로와 후속 명령의 작업 경로 불일치 — 문서 명령을 cd <skill> 위치에서 순서대로 실행 | 준비는 /home/claude/work/asis.json 생성; 다음 skeleton·check는 <skill>/work/asis.json 읽음; 두 경로는 다르며 작업 폴더 이동·심볼릭 링크·공통 WORK 설정이 없음. 압축 원본에는 work 폴더도 없음 | 절대 경로 예제와 상대 경로 예제 혼재 → 한 WORK 변수 또는 일관된 절대 경로를 선언하고 모든 명령·로그·출력에 적용 | SKILL.md:68, SKILL.md:70, SKILL.md:72, SKILL.md:106, SKILL.md:315 |
| STR-05 | Major | 의존성·브라우저 설치 조건 및 설치 지침 누락 — 필요 패키지/Playwright Chromium이 미설치된 새 실행 환경 | site-packages 없이 parse_excel.py ... report 또는 qc_browser.py ... quick 실행; openpyxl/playwright ModuleNotFoundError 재현. ZIP에 requirements/pyproject/설치 안내 없음. 브라우저는 Playwright 기본 executable만 사용 | 개발 환경의 사전 설치 상태를 암묵적으로 전제 → 지원 Python과 의존성 명세, Chromium 설치·탐색 절차 및 사전검사 제공. Pillow/python-docx/pdftotext는 사용 기능별 선택 의존성 구분 | scripts/parse_excel.py:13, scripts/qc_browser.py:13, scripts/qc_browser.py:132, scripts/asis_layout.py:27, scripts/b_widget.py:69, scripts/inputs.py:45, scripts/inputs.py:49, SKILL.md:66 |
| STR-06 | Major | 원본 설계 수정 후 재생성을 생략하는 재시도 지침 — fill/check가 빈칸을 지적해 원본 design.json을 수정한 경우 | SKILL:330대로 design.json 수정 후 check부터 실행하면 :324 명령은 이전 work/tobe/design_tobe.json을 검사; synth 실행 없이 원본 변경은 검사 대상에 반영되지 않음. 별도 참조문서는 synth부터 재실행하라고 지시 | 원본 설계와 파생 설계의 데이터 흐름을 재시도 안내에서 혼동 → 원본 수정→synth→fill→check를 하나의 명령으로 묶거나 정확한 최소 재시도 절차로 통일 | SKILL.md:324, SKILL.md:330, references/restructure.md:62 |
| STR-07 | Minor | 사용자 안내 버전 예시가 1.4.0으로 남음 — 작업 내용 없는 인사에 고정 소개 문구 사용 | name은 ver1-4-2인데 그대로 쓰라는 소개 예시는 ver1-4-0; 설치 버전과 사용자에게 표시될 수 있는 버전 불일치 | 버전 문자열 중복 관리 → 소개 문구에서 name 기반 버전만 쓰거나 예시 갱신 | SKILL.md:2, SKILL.md:109, SKILL.md:112 |
| STR-08 | Minor | 공통 문구 사전의 기본 활성화 설명 불일치 — use_phrasebook을 지정하지 않고 fill 실행 | SKILL:291은 사전으로 먼저 채운다고 안내하지만 구현은 get(use_phrasebook, False); 실제 기본값은 꺼짐; 자동 채움을 기대한 작업자는 빈칸이 남는 이유를 오인할 수 있음 | 사전 사용을 선택 기능으로 바꾼 뒤 오래된 작성 안내 잔존 → 선택 기능과 기본 OFF를 모든 작성 안내에 일치시키기 | SKILL.md:291, SKILL.md:408, scripts/autofill.py:451 |

## 검증 범위와 제한

- `crm-gate-exit-evidence.json`: 첨부 CRM Excel·HTML로 만든 asis.json 사용. 원본 누락357/Lv.4구성34 오류391건에도 restructure exit0, 문구 위반5건에도 style exit0 재현.
- `execution-evidence.json`: 모듈이 없는 환경은 Python -S로 site-packages를 제외해 재현했다. 현재 환경에 해당 패키지가 없다고 주장하는 결과는 아니다.
- 문서의 Python 호출 58개를 추출해 대상 스크립트 존재와 인자 소비 경로를 확인했다. 모든 58개 명령의 모든 입력 조합을 동적 실행한 것은 아니다.
- 이번 구조 검사에서는 HTML UI를 검증하지 않았다. 실제 HTML 생성·브라우저·QC 실행 결과는 주 작업의 통합 보고서에 합쳐야 한다.
- requirements/설치 절차와 함께 작은 정상 fixture 및 예외 입력의 자동 회귀검사 배포를 권고한다. 테스트 폴더가 없는 사실 자체는 기능 결함으로 분류하지 않았다.

## 우선순위

1. STR-01/02: 실패 판정과 최종 전달 정책을 먼저 일치시킨다.
2. STR-03/06: 설계 규칙과 재생성 경로를 통일해 출력 변동과 반복 작업을 줄인다.
3. STR-04/05: 재현 가능한 설치·실행 경로를 제공한다.
4. STR-07/08: 표시 버전과 선택 기능 설명을 정리한다.
