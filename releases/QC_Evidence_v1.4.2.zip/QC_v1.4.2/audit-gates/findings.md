# v1.4.2 자동 QC 신뢰성 검증

원본 스킬 코드는 수정하지 않았다. 아래 통제 HTML과 test harness는 모두 `audit-gates/`에 별도로 작성했다. 실행 환경의 기본 Chromium 패키지가 없고 시스템 Chromium은 `file://`을 차단하므로, 실제 브라우저 시험은 별도 transport harness에서 실행 경로를 `/usr/bin/chromium`, 입력 URL을 같은 파일의 localhost HTTP URL로만 바꿨다. 원본 `qc_browser.py`의 측정·요약·종료 코드는 그대로 `runpy`로 실행했다.

## 확인된 이슈

| ID | 심각도 / 우선순위 | 발생 조건과 재현 | 관찰 결과 | 원인 / 파일 위치 | 수정 권고 |
|---|---|---|---|---|---|
| G-01 | Major / P0 | `error-probe.html`(무해한 JS 오류 1개)을 `asis` 모드로 실행. `geometry-probe.html`의 실제 브라우저 측정 report 1개와 명시적으로 빈 report 3개를 final/result 집계 경계 시험에 사용 | 직접 실행: 12개 화면, `errors=1`, `nonorth=12`, `clipped=12`여도 종료 0. 집계 실행: `nonorth=12`, `clipped=12`여도 종료 0 | `scripts/qc_browser.py:385`은 6개 지표만 종료 판단에 사용. `:386–393`의 quick/all/asis/ns/panels 공통 직접 실행은 실패 종료 코드 자체가 없음. SKILL.md:338의 잘림·비직각·추가 UI 지표와 불일치 | 공통 실패 판정 함수를 두고 직접/최종 실행에 동일하게 적용. 숫자 필드 전체를 0으로 보는 대신 높이 최대 2종 등 각 기준을 명시적으로 판정 |
| G-02 | Major / P0 | 실제 `clean-browser.json`의 같은 As-Is report를 4개 part 파일로 복사하고, `started.json`과 다른 오류 HTML을 `result` 인수로 지정. 별도 0-coverage 실험은 4개 빈 report 사용 | 다른 HTML·다른 검사 범위인데도 `result` 종료 0, `errors=0`. 0개 화면을 검사한 report 묶음도 종료 0 | `scripts/qc_browser.py:352`에는 html 경로/시간만 기록. `:354–372`는 JSON 파일 존재만 확인하며 파일 해시·run ID·part·브라우저/검사 조건·화면 및 패널 coverage를 검증하지 않음 | 시작 시 HTML SHA256/run ID/검사 profile을 기록하고 각 worker 결과에 포함. 집계 시 현재 HTML·worker part·필수 화면/패널 수와 대조. HTML 변경 또는 report 대체 시 차단 |
| G-03 | Major / P1 | `__PMD__`가 없는 `crash-probe.html`로 실제 final worker 4개 실행. 4개가 모두 오류 종료한 뒤 `final_result(..., wait=0)` 조회 | worker 종료 코드 `[1,1,1,1]`, worker JSON 0개인데 `아직 진행 중 ... result를 다시 실행`, 종료 3. 종료된 작업을 계속 대기하도록 안내 | `scripts/qc_browser.py:350–352`는 PID/프로세스 핸들·종료 상태를 저장하지 않음. `:356–363`은 JSON 존재만 보고 누락을 진행 중으로 해석 | worker PID·returncode·실패 원인을 기록하고 crash/timeout을 terminal failure로 구분. 실패 worker를 지목하고 원인 수정 후 재시도하도록 안내 |

G-02는 의도적으로 잘못 조립한 report에 대한 **집계기 경계 시험**이다. 이 결과를 실제 고객 HTML의 통과 결과로 사용하지 않았다. G-03에서 기본 270초 대기를 실제로 소비하지 않았으며 `wait=0`은 공개 함수의 인수로 사용했다. 실제 worker 프로세스가 모두 오류 종료한 사실은 확인했다. 기본 대기 270초 및 반복 안내 동작은 원본 `final_result` 구현으로 확인된다.

## 실제 CRM 진단 후보 대조

입력: `/workspace/qc-v142/generation/crm-diagnostic.html` (현재 첨부 Excel·HTML로 구성한 전체 원천 + 이전 CRM 설계 exact remap 진단 후보; 신규 v1.4.2의 설계 검증 통과본은 아님).

원본 quick 측정은 6개 화면의 박스 누락·추가·겹침·비직각·map 글자 잘림 0을 기록했다. 상세 UI에는 `#apage B7` 잘림 1건과 `fork_bad` 1건이 있었다. CLI는 종료 0이었다. console 오류 1건은 HTTP test transport의 favicon 404이므로 제품 JavaScript 결함으로 집계하지 않는다. B7 잘림과 fork 경고는 root의 정상 schema 후보·화면 검증으로 원인을 확정해야 하며, 여기서는 진단 관찰만 보고한다.

## 증거와 재현 파일

- `transport_cli.py`: 브라우저 실행·URL만 조정하는 test harness. 원본 모듈의 `__main__` 실행.
- `error-probe.html`, `error-browser.json`, `error-browser-adapted.log`: 실제 Chromium 측정. 의도적 `QC_SENTINEL_SCRIPT_FAILURE` 1건.
- `geometry-probe.html`, `geometry-browser.json`, `geometry-browser.log`: 실제 Chromium 측정. 비직각·잘림 각 12, JS 오류 0.
- `clean-probe.html`, `clean-browser.json`, `clean-browser.log`: 집계 경계 시험의 실제 브라우저 측정 원천.
- `aggregation_probe.py`, `aggregation-results.json`, `ignored_geometry/`, `foreign_reports/`, `zero_coverage/`: 명시적인 합성 report 조립 경계 시험과 실제 원본 CLI 종료 코드.
- `crash_harness.py`, `worker-crash-result.json`, `worker-crash/*.log`: 실제 worker 4개의 오류 종료와 잘못된 진행 중 안내.
- `crm-quick.json`, `crm-quick.log`: 실제 전체 CRM 진단 후보 quick 측정.

재현 예: `PYTHONDONTWRITEBYTECODE=1 python audit-gates/transport_cli.py audit-gates/error-probe.html audit-gates/error-browser.json asis`. 절대 경로·localhost 서버 경로는 현재 QC 작업 폴더 기준이다. 브라우저 런타임이 정상 설치되고 file://이 허용되는 환경에서는 원본 qc_browser.py에 같은 HTML과 인수를 직접 전달하면 된다.
