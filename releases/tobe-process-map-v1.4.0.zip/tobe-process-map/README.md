# tobe-process-map v1.4.0

As-Is Excel(원본 HTML은 제공 시 반영) → To-be HTML·Excel·QA manifest. As-Is와 To-Be를 동일한 디자인·기능으로 표시하고, 원본 HTML의 배치·연결선 정보를 가져옵니다. 일괄 실행과 중단 지점 재개를 지원합니다.

스킬 진입점은 [SKILL.md](SKILL.md), 품질 기준은 [quality-contract.md](references/quality-contract.md), 설치·실행·재개는 [workflow.md](references/workflow.md)입니다. Python 3.11+와 Chromium이 필요합니다.

```bash
python -m pip install -r requirements.txt
python -m playwright install chromium
python scripts/pipeline.py prepare --excel input.xlsx --source-html input-asis.html --work work/crm-v1 --spec 3
# work/crm-v1/brief.md와 단계별 자료를 읽고 authoring.json 또는 design.json에 설계합니다.
python scripts/pipeline.py run --work work/crm-v1 --output outputs/crm-v1 --wait 90
```

run은 기계적 빈칸 보완, 생성, 모든 QC 묶음, 인증을 자동 작업자로 수행합니다. 호출 대기가 끝나도 작업자는 이어서 진행합니다. 실행 중에는 해당 세션을 기다리며, 상태가 필요하면 `pipeline.py status --work work/crm-v1`으로 확인합니다. 상태 조회가 작업을 진행시키는 방식이 아닙니다.

같은 설명을 한 번 작성하는 방법은 [authoring.md](references/authoring.md)를 따릅니다. 변경 전 설계는 보관하며, 후보와 최종 통과 결과를 구분합니다.

스킬 코드 변경 시 전체 회귀검사(일반 생성에서는 별도 실행하지 않음): `python -m unittest discover -s tests -v`. 스킬 자체 수정 시 기존 검사를 생략하지 않습니다. tests/fixtures는 형식 검증용이며 실제 입력을 대신하지 않습니다. 실행에 쓰이지 않는 과거 부문 예제·참고 HTML은 경량 패키지에서 제외했습니다. 코드가 검증하는 구조적 기준 외에 업무 설계의 타당성과 핵심 화면 검토가 필요합니다.
