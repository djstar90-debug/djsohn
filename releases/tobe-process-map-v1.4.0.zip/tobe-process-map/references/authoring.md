# 중복 없이 설계 작성하기

`authoring.json`은 선택 기능이다. 기존 `design.json`을 그대로 작성해도 된다. 이 형식은 같은 업무 설명을 상세 패널과 투어에 반복 작성하는 양을 줄인다. 설계 판단, 승인, 흐름, 경고 검토를 자동으로 만들어 주지는 않는다. 펼친 결과는 기존 정식 `design.json`이며, 동일한 검증·HTML·Excel 생성 경로를 사용한다.

## 가장 작은 변경: 기존 문장 참조

기존 설계 전체를 `design` 안에 넣고, 같은 문장만 참조한다. 참조는 이 `design` 내부의 JSON Pointer이며 외부 URL이나 파일을 읽지 않는다.

```json
{
  "schema": "tobe-authoring/v1",
  "design": {
    "desc": {"T6": {"T1": "분석 Agent가 자료를 대조하고 검토안을 작성한다."}},
    "tour": {"1": {"beats": [{"t": "분석", "steps": [
      {"ids": ["T1"], "v": "자료 분석", "d": {"$ref": "/desc/T6/T1"}, "a": ""}
    ]}]}}
  }
}
```

위 예시는 참조 문법만 보여 준다. 실제 파일에는 기존 `tb`, `tb5`, `tobe_flow`, `design_contract`, Agent 상세 등 나머지 설계 필드도 포함한다. 서로 다른 설명을 억지로 통일하지 않는다. `$ref` 객체에는 다른 키를 붙이지 않는다. ID 안의 `/`는 `~1`, `~`는 `~0`으로 표기한다. 존재하지 않는 참조와 순환 참조는 오류다.

## 새로 작성할 때: 업무 설명 한 번, 투어 순서는 명시

`tb.T1.narrative`에 쓴 설명은 `desc.T6.T1`로 이동한다. Orchestrator(`t: "M"`) 설명은 `desc.M6`로 이동한다. 이미 해당 설명이 있으면 서로 같아야 한다. `tour.<stage>.beats[].steps`에는 직접 정한 업무 ID 순서를 쓸 수 있다.

```json
"steps": ["T1", "T2", {"task": "T3", "v": "따로 정한 해설 제목"}]
```

각 ID는 그 업무의 `lb`, `desc.T6` 또는 `desc.M6`, 사람 업무의 실제 `lane.who`/`lane.name`을 재사용한다. `task` 객체의 `v`, `d`, `a`, `p` 등 명시한 값이 우선한다. 다수 업무를 묶는 투어 단계는 기존 `ids` 문법을 사용한다. 사람 담당 조직이 없으면 오류로 처리하며 임의로 Agent에게 맡기지 않는다. 업무 분리 여부·사람 승인 조건은 기존 설계 검증이 확인한다.

투어 순서는 반드시 작성자가 지정한다. `tb` 순서나 `tobe_flow`로 투어를 자동 생성하지 않는다. 반대로 투어 순서로 연결선을 생성하지도 않는다. 분기·병렬·조건·환류는 명시한 `tobe_flow`에 그대로 남는다.

## 사용

`pipeline.py` 작업 폴더의 `authoring.json`이 있으면 실행 시 정식 `design.json`으로 펼친다. 없으면 기존 방식으로 동작한다. 전체 설계나 HTML을 도구 응답에 출력하지 말고, 파일로 저장하고 짧은 요약만 확인한다.

기존 완성 설계를 의미 변경 없이 압축하려면:

```bash
python scripts/authoring.py pack work/design.json work/authoring.json
```

이 명령은 상세 설명과 **정확히 일치하는** 투어 설명·업무명을 참조로 바꾸고 왕복 일치를 검사한다. 다른 문장은 유지한다. 별도 파일로 펼쳐 검토하려면:

```bash
python scripts/authoring.py expand work/authoring.json work/expanded-design.json
```

여러 단계로 나눠 작성해야 할 경우에만 wrapper에 `"includes": ["authoring/stage-1.json", "authoring/stage-2.json"]`를 추가한다. 각 파일은 `{"tb": {...}, "tour": {"1": {...}}}`처럼 정식 설계 필드의 일부를 담은 객체다. 객체 키는 합치지만 서로 다른 기존 값·배열은 충돌 오류로 처리한다. 배열을 임의로 이어 붙여 흐름이나 투어 순서를 만들지 않는다. 공통 배열은 한 곳에서 완성해 작성한다. 중첩 includes, 상위 경로, 외부 경로는 허용하지 않는다. 여러 파일 작성 자체를 필수 단계로 만들지 않는다.

## 변경 보호와 검증 범위

펼치기 전 기존 `design.json`을 `design-history/<SHA256>.json`에 보관한다. `authoring-state.json`에는 작성 파일들의 해시와 생성본 해시를 기록한다. 작성 파일이 같으면 이미 펼친 설계를 다시 덮어쓰지 않는다. 생성된 `design.json`을 직접 고친 상태에서 작성 파일도 바뀌면 충돌을 보고한다. 이때 수동 변경을 작성 파일에 반영해 일치시킨 뒤 다시 실행한다. 원본 `authoring.json`을 변경 경로로 유지하면 이 충돌을 피할 수 있다.

`expand(document, asis=None)`은 원본을 변경하지 않는 순수 함수다. `materialize(work, asis=None)`은 생성·백업·변경 보호만 담당한다. 검증 통과를 선언하지 않는다. 같은 내용의 왕복 일치와 기존 품질 검사로 결과 보존을 확인하며, 작성량 감소를 응답 한 번 완료나 플랫폼 작업 한도 증가로 해석하지 않는다.
