# 실행과 재개 · v1.4.0

일반 생성 경로는 SKILL.md의 prepare → 설계 작성 → run이다. 입력·작업·출력 경로를 환경에 맞춘다. Claude의 파일 전달에는 `/mnt/user-data/outputs/<작업명>`을 사용하며, 다른 환경에서는 해당 환경의 출력 폴더를 사용한다.

## 준비

설치가 필요한 경우만 `python -m pip install -r requirements.txt`와 `python -m playwright install chromium`을 실행한다. 시스템 Chromium이 있으면 QC_CHROMIUM 설정을 사용할 수 있다.

```bash
python scripts/pipeline.py prepare --excel input.xlsx --source-html input-asis.html --work work/crm --spec 3
```

HTML은 제공된 경우 사용하며 미첨부 시 옵션을 생략한다. F2의 spec 3은 단계 기준 레벨, F1은 섹션 번호다. 준비 단계에서 입력 오류 전체를 `input-diagnostics.json`에 모은다. 오류 하나만 고쳐 재시도하는 대신 전체 원인을 검토한다. 원천 ID·연결·계층을 추측해 오류를 숨기지 않는다.

원천은 asis.json, 작성용 자료는 brief.md와 source-context/*.json에 있다. 패킷은 모든 업무 필드를 보존하고 반복 원문만 모았다. 전체 HTML의 바이트를 모델 문맥에 출력하지 않는다. 원본 업무 검토를 생략하는 기능이 아니다.

## 작성

references/authoring.md의 방식으로 한 번 작성한 설명을 여러 화면에서 참조한다. 기존 완성 design.json도 그대로 사용할 수 있다. 실제 구조와 판단 근거는 설계자가 작성하며, 전개기는 새 업무·연결·사람 결정을 추측하지 않는다.

run은 구조화된 작성 입력을 전개하고 필요한 기계적 빈칸을 보완한다. 기존 값은 보존한다. 변경·전개·백업 기록을 확인할 수 있다. 필수 설명이나 판단이 없으면 검증은 계속 실패한다. 자동 생성된 문장이 있다고 업무 설계 검토를 면제하지 않는다.

## 실행과 대기

```bash
python scripts/pipeline.py run --work work/crm --output /mnt/user-data/outputs/crm --wait 90
```

run은 별도 작업자가 생성·QC의 모든 묶음·인증을 끝까지 이어가도록 시작한다. 호출의 대기 시간과 실제 작업 수명은 다르다. 대기가 끝났다는 이유로 남은 QC가 멈추지 않는다. `--background`도 지원하지만 자동 진행을 위해 필수로 지정할 필요는 없다.

도구가 살아 있는 세션을 반환하면 해당 세션을 기다린다. 동일 work에 새 작업자를 반복 실행하지 않는다. 즉시 상태 확인이 필요할 때만 다음 명령을 사용한다.

```bash
python scripts/pipeline.py status --work work/crm
```

status는 관찰 명령이다. QC를 진행시키기 위해 status를 반복 호출할 필요가 없다. 작업자는 자체적으로 진행한다. 도구 대기 중 사용자에게 계속을 요구하지 않는다. 플랫폼의 실제 작업 한도나 환경 종료가 생기면 해당 제한과 저장된 상태를 정확히 설명한다.

| 상태 | 처리 |
|---|---|
| passed | 현재 입력의 HTML·Excel·manifest 실제 경로로 전달 |
| running | 살아 있는 작업자를 기다림; 새 빌드나 사용자 응답이 필요하다는 뜻이 아님 |
| requires_fix | 전체 진단의 원인을 묶어 수정한 뒤 run |
| inputs_changed / artifacts_changed | 변경 내역을 검토하고 최신 입력으로 재검증 |

후보는 출력 폴더의 revisions 하위에 생성된다. manifest passed 이전에는 후보이며, 다른 revision의 파일과 섞거나 임의로 최종본으로 표시하지 않는다. 이미 통과한 같은 파일을 보고만 하려고 다시 검수하지 않는다.

## 오류를 고칠 때

- 입력 오류: input-diagnostics.json에서 전체 행·종류·해결 방법을 읽는다. 자료가 부족하면 정확히 필요한 정보만 확인한다. 원천의 변경은 새 work에서 처리한다.
- 설계 오류: diagnostics.json의 관련 경로·ID를 묶어 수정한다. 전체 design.json을 반복 출력하거나 모든 설명을 재작성하지 않는다.
- 브라우저 오류: 실제 JavaScript 예외, 배치·잘림, 작업자 실행 실패를 구분한다. 화면·ID·stack·스크린샷을 사용한다.
- 일시적인 실행 문제만 고치고 파일이 같다면 `run --retry-qc`로 실패한 묶음을 명시적으로 재시도한다. 설계·HTML을 바꿨으면 새 전체 QC가 필요하다.
- 이미 실행된 작업이 중단됐으면 work와 결과 파일을 보존한다. 입력부터 다시 시작하거나 이전 설계를 덮어쓰지 않는다.

## 일반 생성과 스킬 개발 QA

일반 생성의 전체 산출물 검사는 run이 수행한다. 별도의 전체 단위 테스트, 반복 Excel verify, 수동 certify를 매번 추가하지 않는다. 스킬 코드 수정 QA에서는 전체 회귀 검사도 수행한다.

```bash
python -m unittest discover -s tests -v
```

기존 품질 기준을 낮추어 빨라졌다고 보고하지 않는다. 작업량 비교에는 모델이 읽고 쓴 자료, 설계 작성·오류 수정·대기·재개를 포함한다. 진입 명령 수만으로 실제 총 호출 수나 Claude의 계속 횟수가 줄었다고 단정하지 않는다.

## 이전 버전에서 이관

v1.3.1의 공통 As-Is/To-Be 엔진과 원천 배치 보존 기능은 그대로 유지한다. 기존 design.json을 보관하고 새 스킬에서 재검증한다. 새 work로 prepare할 경우 기존 설계를 옮겨 사용할 수 있다. 작성 입력을 구조화하려면 authoring.md의 pack 기능을 사용한다. 기존 출력 HTML은 스킬 ZIP 교체만으로 바뀌지 않는다.
