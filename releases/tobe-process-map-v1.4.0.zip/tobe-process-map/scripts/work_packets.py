"""Lossless, stage-sized source context for design authoring.

These are reading aids, not replacement inputs or an automatic To-be design.
Repeated long source text is stored once per packet; all task fields survive.
"""
from collections import Counter
import json
from pathlib import Path


def encode_rows(rows):
    columns = list(dict.fromkeys(k for row in rows.values() for k in row))
    counts = Counter(v for row in rows.values() for v in row.values() if isinstance(v, str) and len(v) >= 24)
    texts = list(dict.fromkeys(v for row in rows.values() for v in row.values()
                              if isinstance(v, str) and counts.get(v, 0) > 1))
    index = {v: i for i, v in enumerate(texts)}
    def cell(row, key):
        if key not in row: return {'$missing': True}
        value = row[key]
        if isinstance(value, str) and value in index: return {'$text': index[value]}
        if isinstance(value, dict): return {'$literal': value}
        return value
    return {'columns': columns, 'texts': texts,
            'rows': [[ident, *[cell(row, key) for key in columns]] for ident, row in rows.items()]}


def decode_rows(packet):
    result = {}
    for record in packet['rows']:
        row = {}
        if len(record) != len(packet['columns']) + 1: raise ValueError('Malformed source packet row')
        for key, value in zip(packet['columns'], record[1:]):
            if isinstance(value, dict):
                if '$missing' in value: continue
                if '$text' in value: value = packet['texts'][value['$text']]
                elif '$literal' in value: value = value['$literal']
            row[key] = value
        result[record[0]] = row
    return result


def packets(asis):
    a4, a5, a6 = (asis[k] for k in ('A4', 'A5', 'A6'))
    scope = {key: a5[row['l5'].split(' ')[0]]['l4id'] for key, row in a6.items()}
    flow = []
    if asis.get('source_html'):
        source = asis['source_html']
        mapping = source['mapping']
        for edge in source['snapshot']['lv6']['edges']:
            if edge[0] in mapping and edge[1] in mapping:
                flow.append([mapping[edge[0]], mapping[edge[1]], *edge[2:]])
    out = []
    for number, (key, stage) in enumerate(a4.items(), 1):
        rows = {k: v for k, v in a6.items() if scope[k] == key}
        packet = {'schema': 'source-context/v1', 'stage': number, 'stage_id': key,
                  'stage_name': stage.get('n', key),
                  'readme': 'rows의 첫 값은 ID, 나머지는 columns 순서. {$text:n}은 texts[n] 원문. 모든 원천 업무 필드를 포함하며 To-be 설계가 아님.',
                  'parents': {k: v for k, v in a5.items() if v['l4id'] == key},
                  'tasks': encode_rows(rows),
                  'source_html_edges': [e for e in flow if e[0] in rows or e[1] in rows]}
        if decode_rows(packet['tasks']) != rows: raise ValueError('Source packet roundtrip failed')
        out.append(packet)
    if sum(len(p['tasks']['rows']) for p in out) != len(a6):
        raise ValueError('Source packet coverage differs from input tasks')
    return out


def write_packets(asis, work):
    root = Path(work); folder = root / 'source-context'; folder.mkdir(parents=True, exist_ok=True)
    generated = packets(asis); paths = []
    brief = ['# 설계 작업 안내', '',
             f"원천 업무 {len(asis['A6'])}개 · Lv.5 {len(asis['A5'])}개 · 상위 단계 {len(asis['A4'])}개.",
             '원본 업무·판단·연결·Pain point를 아래 단계별 파일에서 읽는다. HTML 바이트가 포함된 전체 asis.json을 출력할 필요는 없다.',
             '공통으로 반복되는 긴 원문만 texts에 모았다. rows의 모든 칸과 참조 원문을 함께 검토한다.', '',
             '| 단계 | 이름 | 원천 업무 | 읽을 파일 |', '|---|---|---:|---|']
    for packet in generated:
        path = folder / ('stage-%02d.json' % packet['stage'])
        path.write_text(json.dumps(packet, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
        paths.append(str(path))
        brief.append(f"| {packet['stage']} | {packet['stage_name'].replace('|', '/').replace(chr(10), ' ')} | {len(packet['tasks']['rows'])} | source-context/{path.name} |")
    brief += ['', '같은 업무 설명은 한 번 작성하고 authoring.json의 참조로 상세창·흐름 안내에서 재사용한다.',
              '단계별로 자료를 읽고 여러 업무를 묶어 설계한다. 원천/설계 파일을 수정한 뒤에는 한 번의 run으로 모든 검사를 수행한다.',
              '검사 진행 중에는 살아 있는 실행 세션을 기다린다. 작업자가 남은 검사와 인증을 자동 수행하며, 사용자에게 계속 버튼을 요구하는 작업 단계는 없다.']
    (root / 'brief.md').write_text('\n'.join(brief) + '\n', encoding='utf-8')
    source_bytes = len(json.dumps({k: asis[k] for k in ('A4','A5','A6')}, ensure_ascii=False).encode())
    return {'brief': str(root/'brief.md'), 'packets': paths, 'tasks': len(asis['A6']),
            'source_data_bytes': source_bytes, 'packet_bytes': sum(Path(p).stat().st_size for p in paths)}
