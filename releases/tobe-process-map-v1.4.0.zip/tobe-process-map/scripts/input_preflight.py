"""Read-only, batched Excel input diagnostics before any design authoring.

This does not replace the canonical parser or repair source records. It reports
all independently detectable blockers together so an agent need not retry one
bad row at a time. HTML correspondence uses only existing exact source evidence.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re
import warnings
from zipfile import BadZipFile

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException
import parse_excel as parser


def inspect(excel, spec='3', source_html=None):
    report = {'status':'passed', 'phase':'input', 'issues':[], 'counts':{},
              'detail':{'file':Path(excel).name, 'spec':str(spec), 'format':None,
                        'recovered_ids':[], 'source_reference_policy':'unresolved references block Excel-only generation'}}
    issues = report['issues']; rows = []; wb = cached = None
    def add(code, message, severity='error', **evidence):
        issues.append(dict(severity=severity, code=code, message=message, **evidence))
    def finish():
        by_code = Counter(i['code'] for i in issues)
        report['counts'] = {'errors':sum(i['severity']=='error' for i in issues),
                            'warnings':sum(i['severity']=='warning' for i in issues),
                            'task_rows':len(rows), 'missing_ids':by_code['MISSING_ID'],
                            'recovered_ids':len(report['detail']['recovered_ids']),
                            'unresolved_references':by_code['SOURCE_REFERENCE_CONFLICT'],
                            'by_code':dict(by_code)}
        report['status'] = 'failed' if report['counts']['errors'] else 'passed'
        report['detail']['next_action'] = ('입력 진단 전체를 한 번에 검토하세요. 원본 ID·계층·연결을 임의 생성하거나 한 행씩 수정·재실행하지 않습니다. 정확한 원본 자료 또는 수정된 Excel이 필요합니다.'
                                          if report['status']=='failed' else '정규 파싱과 원천 검증을 진행합니다. 이 진단은 최종 설계/브라우저 QC를 대체하지 않습니다.')
        return report
    try:
        report['detail']['sha256'] = hashlib.sha256(Path(excel).read_bytes()).hexdigest()
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            wb = load_workbook(excel, data_only=False)
        if 'Process Map' not in wb.sheetnames:
            add('MISSING_SHEET', "필수 시트 'Process Map' 없음", sheets=wb.sheetnames)
            return finish()
        ws = wb['Process Map']
        # Collect every independent formula/error cell; never stop at the first.
        for row in ws:
            for cell in row:
                if cell.data_type == 'f':
                    if cached is None:
                        with warnings.catch_warnings():
                            warnings.simplefilter('ignore', UserWarning)
                            cached = load_workbook(excel, data_only=True)
                    value = cached['Process Map'][cell.coordinate]
                    if value.value is None or value.data_type == 'e':
                        add('FORMULA_CACHE_MISSING', f'Process Map!{cell.coordinate}: 계산값이 없는 수식; Excel에서 재계산·저장 필요', cell=cell.coordinate, row=cell.row)
                    else:
                        cell.value = value.value
                elif cell.data_type == 'e':
                    add('EXCEL_ERROR', f'Process Map!{cell.coordinate}: Excel 오류값 {cell.value}', cell=cell.coordinate, row=cell.row)
        try:
            fmt, hr, headers = parser.detect(ws)
        except parser.InputError as exc:
            add('UNSUPPORTED_FORMAT', str(exc)); return finish()
        report['detail']['format'] = fmt
        merged = {}
        for area in ws.merged_cells.ranges:
            value = ws.cell(area.min_row, area.min_col).value
            for r in range(area.min_row, area.max_row+1):
                for c in range(area.min_col, area.max_col+1): merged[r,c] = value
        def value(r,c):
            return '' if not c or c>=999 else parser.s(merged.get((r,c), ws.cell(r,c).value))
        if fmt == 'F2':
            try: stage_lv = int(spec)
            except (ValueError, TypeError): stage_lv = 0
            if stage_lv not in (3,4):
                add('INVALID_STAGE', 'F2 단계 레벨은 3 또는 4만 지원'); return finish()
            cols = parser.map_columns(headers)
            missing = sorted({'id','lv1','lv2','lv3','lv4','lv5','lv6'} - set(cols))
            if missing:
                add('MISSING_COLUMNS', 'F2 필수 열 없음: '+', '.join(missing), fields=missing); return finish()
            for r in range(hr+1, ws.max_row+1):
                item = {k:value(r,cols.get(k)) for k in ('id','lv1','lv2','lv3','lv4','lv5','lv6','l5id','pre','post','rej')}
                if item['id'] or item['lv6']: rows.append(dict(item,row=r))
        else:
            try: hr, cols, missing = parser.f1_columns(ws)
            except parser.InputError as exc:
                add('MISSING_COLUMNS', str(exc)); return finish()
            missing = sorted({'l1','l4','l5','l6','l4id','l5id','id'}.intersection(missing))
            if missing:
                add('MISSING_COLUMNS', 'F1 필수 열 없음: '+', '.join(missing), fields=missing); return finish()
            try: sections = [int(x) for x in re.split(r'[,+]',str(spec))]
            except (ValueError, TypeError): sections = []
            title_col = max(1, cols['l1']-1)
            starts = [r for r in range(1, ws.max_row+1) if re.match(r'^\d+\.',value(r,title_col)) and not value(r,cols['id'])]
            if starts:
                if not sections or len(sections)!=len(set(sections)) or any(x<1 or x>len(starts) for x in sections):
                    add('INVALID_SECTION', f'F1 섹션 범위 또는 중복 오류: {spec} (1~{len(starts)})'); return finish()
                wanted = [(n, range(starts[n-1]+1, starts[n] if n<len(starts) else ws.max_row+1)) for n in sections]
            else:
                # Canonical F1 parser treats a sheet without section headings as a single section.
                wanted = [(1, range(hr+1, ws.max_row+1))]
            for section, selected in wanted:
                for r in selected:
                    ident, name = value(r,cols['id']), value(r,cols['l6'])
                    if ident.startswith('Lv.'): continue
                    if ident or name:
                        item={k:value(r,cols.get(k)) for k in ('id','l4id','l5id','pre','post','rej')}
                        item.update({'lv'+str(n):value(r,cols.get('l'+str(n))) for n in range(1,7)})
                        rows.append(dict(item,row=r,section=section))
        if not rows:
            add('EMPTY_INPUT', 'Lv.6 업무가 없음'); return finish()
        source = None
        if source_html:
            try:
                from source_asis import snapshot
                source = snapshot(Path(source_html).read_text(encoding='utf-8-sig'))
            except (ValueError, TypeError, KeyError, OSError) as exc:
                add('SOURCE_HTML_INVALID', '원본 HTML 데이터 해석 실패: '+str(exc))
        source_matches = {}
        if source is not None:
            for item in rows:
                if fmt=='F2':
                    candidates=[n for n in source['lv6']['nodes'] if item['row'] in (n.get('sourceRows') or [])
                                and parser.normalized(n.get('task') or n.get('label')) == parser.normalized(item['lv6'])
                                and all(parser.normalized(n.get('hierarchy',{}).get('l'+str(lv))) == parser.normalized(item['lv'+str(lv)]) for lv in range(1,6))]
                else:
                    candidates=[n for n in source['lv6']['nodes'] if (n.get('task') or n.get('label','')) == item['lv6']
                                and (item['row'] in (n.get('sourceRows') or []) or (not n.get('sourceRows') and item['id']==n.get('id')))]
                if len(candidates)==1: source_matches[item['row']]=candidates[0]
                else: add('SOURCE_CORRESPONDENCE', f"행 {item['row']}: As-Is HTML에서 행·업무명·계층이 유일하게 일치하지 않음", row=item['row'], matches=len(candidates))
        effective={}; id_rows=defaultdict(list)
        for item in rows:
            r=item['row']; ident=item['id']; name=item['lv6']
            if not name: add('MISSING_NAME', f'행 {r}: 노드 ID {ident}의 Lv.6 업무명 없음', row=r, id=ident)
            if not ident and fmt=='F2' and r in source_matches:
                ident=str(source_matches[r].get('id') or '')
                if ident: report['detail']['recovered_ids'].append({'row':r,'id':ident,'method':'sourceRows+exact_name+hierarchy'})
            if not ident:
                add('MISSING_ID', f'행 {r}: Lv.6 업무 「{name}」의 ID 누락; 정확한 원본 대응 또는 수정된 Excel 필요', row=r, task=name)
            elif re.search(r'[,;\s]',ident):
                add('INVALID_ID', f'행 {r}: ID에 공백/구분자 사용 불가: {ident}', row=r, id=ident)
            else:
                effective[r]=ident;id_rows[ident].append(r)
            required = ('lv4','lv5','l4id','l5id') if fmt=='F1' else ('lv5','lv'+str(stage_lv))
            for field in required:
                if not item.get(field):add('MISSING_HIERARCHY', f'행 {r}: 필수 계층값 {field} 누락', row=r, field=field)
        for ident, found in id_rows.items():
            if len(found)>1: add('DUPLICATE_ID', f'Lv.6 ID 중복 {ident}: 행 '+', '.join(map(str,found)), rows=found, id=ident)
        group=lambda item,upto:tuple(parser.normalized(item['lv'+str(n)]) for n in range(1,upto+1))
        stage_for={};parent_for={}
        if fmt=='F2':
            for item in rows:
                r=item['row']
                if r not in effective:continue
                ident=effective[r];gstage=group(item,stage_lv);gparent=group(item,5)
                if source_html:
                    if r not in source_matches:continue
                    stage_for.setdefault(gstage,'STAGE-'+str(len(stage_for)+1))
                    parent=str(source_matches[r].get('parent') or '')
                    if not parent:add('SOURCE_PARENT_MISSING', f'행 {r}: 원본 HTML Lv.5 parent 없음', row=r)
                    elif parent_for.get(gparent) and parent_for[gparent]!=parent:
                        add('SOURCE_PARENT_CONFLICT', f'행 {r}: 원본 HTML 계층/parent 충돌', row=r)
                    else:parent_for[gparent]=parent
                elif re.fullmatch(r'\d+(?:-\d+){5}',ident):
                    stage_for.setdefault(gstage,'-'.join(ident.split('-')[:stage_lv]))
                    parent_for.setdefault(gparent,'-'.join(ident.split('-')[:5]))
                if item.get('l5id'):
                    if parent_for.get(gparent) and parent_for[gparent]!=item['l5id']:
                        add('PARENT_ID_CONFLICT', f'행 {r}: _L5_ID와 계층 ID 충돌', row=r)
                    parent_for[gparent]=item['l5id']
            for item in rows:
                stage_for.setdefault(group(item,stage_lv),'STAGE-'+str(item['row']))
                parent_for.setdefault(group(item,5),'L5-'+str(item['row']))
        named_stages=defaultdict(lambda:defaultdict(list));named_parents=defaultdict(lambda:defaultdict(list))
        for item in rows:
            if item['row'] not in effective:continue
            stage=stage_for[group(item,stage_lv)] if fmt=='F2' else item.get('l4id','')
            parent=parent_for[group(item,5)] if fmt=='F2' else item.get('l5id','')
            name=parser.normalized(item['lv'+str(stage_lv)]) if fmt=='F2' else item['lv4']
            if stage:named_stages[stage][name].append(item['row'])
            if parent:named_parents[parent][(item['lv5'],stage,item['lv4'] if fmt=='F2' else '')].append(item['row'])
        for ident, groups in named_stages.items():
            if len(groups)>1:add('STAGE_NAME_CONFLICT', f'단계 ID {ident}의 이름 충돌', id=ident, rows=sorted(r for found in groups.values() for r in found), names=list(groups))
        for ident, groups in named_parents.items():
            if len(groups)>1:add('PARENT_NAME_CONFLICT', f'Lv.5 ID {ident}의 부모/이름 충돌', id=ident, rows=sorted(r for found in groups.values() for r in found), groups=[list(x) for x in groups])
        if fmt=='F1':
            for field in ('l4id','l5id'):
                scopes=defaultdict(set);scope_rows=defaultdict(list)
                for item in rows:
                    if item.get(field):
                        scopes[item[field]].add(item.get('section',1));scope_rows[item[field]].append(item['row'])
                for ident, sections in scopes.items():
                    if len(sections)>1:
                        add('SCOPE_ID_COLLISION', f'{field} ID {ident}가 여러 선택 섹션에 중복; 정규 병합 불가', id=ident, field=field, rows=scope_rows[ident], sections=sorted(sections))
        known=set(effective.values())
        source_resolved = source is not None and len(source_matches)==len(rows)
        if source_resolved:report['detail']['source_reference_policy']='exact HTML correspondence available; captured source graph must pass canonical validation'
        for item in rows:
            for field in ('pre','post','rej'):
                for target in re.split(r'[,;\s]+',item[field]):
                    if target and target not in known:
                        add('SOURCE_REFERENCE_CONFLICT', f"행 {item['row']}: {field}가 원본에 없는 ID {target} 참조; 정확한 원본 연결 대조 필요", severity='warning' if source_resolved else 'error', row=item['row'], field=field, target=target)
        return finish()
    except (OSError, ValueError, KeyError, TypeError, BadZipFile, InvalidFileException) as exc:
        add('INPUT_READ_ERROR', str(exc)); return finish()
    finally:
        if cached is not None:cached.close()
        if wb is not None:wb.close()


def preview(report, limit=8):
    return {'status':report['status'], 'counts':report['counts'], 'issues':report['issues'][:max(0,min(8,int(limit)))]}


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('excel');ap.add_argument('--spec',default='3');ap.add_argument('--source-html');ap.add_argument('--out',required=True)
    args=ap.parse_args();result=inspect(args.excel,args.spec,args.source_html)
    dest=Path(args.out);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({**preview(result),'diagnostics':str(dest)},ensure_ascii=False,indent=2))
    raise SystemExit(2 if result['status']=='failed' else 0)
