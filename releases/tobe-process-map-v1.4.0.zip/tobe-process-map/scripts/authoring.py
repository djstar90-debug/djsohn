#!/usr/bin/env python3
"""Optional lossless authoring shorthand. No business decisions or flow inferred."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import tempfile

SCHEMA = 'tobe-authoring/v1'
STATE = 'authoring-state.json'


def _bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError(f'authoring: duplicate JSON key {key!r}')
        result[key] = value
    return result


def _read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=_pairs)


def _atomic(path, value, *, compact=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as f:
        f.write((json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8') if compact else _bytes(value))
        temporary = Path(f.name)
    try:
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def _escape(value):
    return str(value).replace('~', '~0').replace('/', '~1')


def _merge(base, fragment, path=''):
    """Objects merge; ordered lists/scalars must agree, never silently append."""
    if not isinstance(base, dict) or not isinstance(fragment, dict):
        raise ValueError(f'authoring: fragment must be an object at {path or "/"}')
    for key, value in fragment.items():
        here = path + '/' + _escape(key)
        if key not in base:
            base[key] = copy.deepcopy(value)
        elif isinstance(base[key], dict) and isinstance(value, dict):
            _merge(base[key], value, here)
        elif base[key] != value:
            raise ValueError(f'authoring: conflicting values at {here}')
    return base


def _load(path):
    path = Path(path).resolve()
    document = _read(path)
    hashes = {path.name: _sha(path.read_bytes())}
    if not isinstance(document, dict) or document.get('schema') != SCHEMA:
        raise ValueError(f'authoring: expected schema {SCHEMA}')
    design = copy.deepcopy(document.get('design', {}))
    if not isinstance(design, dict):
        raise ValueError('authoring: design must be an object')
    includes = document.get('includes', [])
    if not isinstance(includes, list):
        raise ValueError('authoring: includes must be a list of relative JSON paths')
    for name in includes:
        if not isinstance(name, str) or Path(name).is_absolute():
            raise ValueError('authoring: include paths must be relative')
        target = (path.parent / name).resolve()
        if not target.is_relative_to(path.parent) or target == path:
            raise ValueError(f'authoring: unsafe include path {name!r}')
        fragment = _read(target)
        if isinstance(fragment, dict) and ('includes' in fragment or 'schema' in fragment):
            raise ValueError('authoring: included files contain design objects, not nested wrappers')
        _merge(design, fragment)
        hashes[target.relative_to(path.parent).as_posix()] = _sha(target.read_bytes())
    return {'schema': SCHEMA, 'design': design}, hashes


def input_hashes(work):
    """Fingerprint every authoring input; never hashes generated design.json."""
    path = Path(work) / 'authoring.json'
    return _load(path)[1] if path.exists() else {}


def _resolve(design):
    cache, active = {}, set()

    def at(pointer):
        if not isinstance(pointer, str) or (pointer and not pointer.startswith('/')):
            raise ValueError('authoring: $ref must be an internal JSON Pointer')
        if pointer in cache:
            return copy.deepcopy(cache[pointer])
        if pointer in active:
            raise ValueError(f'authoring: circular $ref at {pointer or "/"}')
        active.add(pointer)
        value = design
        for raw in pointer.split('/')[1:]:
            # Reject malformed escapes rather than looking up an unintended key.
            import re
            if re.search(r'~(?![01])', raw):
                raise ValueError(f'authoring: invalid JSON Pointer {pointer}')
            key = raw.replace('~1', '/').replace('~0', '~')
            try:
                if isinstance(value, dict):
                    value = value[key]
                elif isinstance(value, list) and key.isdigit() and (key == '0' or not key.startswith('0')):
                    value = value[int(key)]
                else:
                    raise KeyError(key)
            except (KeyError, IndexError):
                raise ValueError(f'authoring: missing $ref target {pointer}') from None
        resolved = walk(value)
        active.remove(pointer)
        cache[pointer] = resolved
        return copy.deepcopy(resolved)

    def walk(value):
        if isinstance(value, dict):
            if '$ref' in value:
                if set(value) != {'$ref'}:
                    raise ValueError('authoring: $ref objects cannot contain other keys')
                return at(value['$ref'])
            return {key: walk(item) for key, item in value.items()}
        if isinstance(value, list):
            return [walk(item) for item in value]
        return copy.deepcopy(value)

    return walk(design)


def _tour_steps(design):
    for stage in design.get('tour', {}).values():
        if isinstance(stage, dict):
            for beat in stage.get('beats', []):
                if isinstance(beat, dict) and isinstance(beat.get('steps'), list):
                    yield beat['steps']


def expand(document, asis=None):
    """Pure expansion; source data is never used to invent design decisions."""
    if not isinstance(document, dict) or document.get('schema') != SCHEMA:
        raise ValueError(f'authoring: expected schema {SCHEMA}')
    if document.get('includes'):
        raise ValueError('authoring: load included files before calling expand')
    design = copy.deepcopy(document.get('design'))
    if not isinstance(design, dict):
        raise ValueError('authoring: design must be an object')
    for task_id, task in design.get('tb', {}).items():
        if not isinstance(task, dict) or 'narrative' not in task:
            continue
        narrative = task.pop('narrative')
        group = 'M6' if task.get('t') == 'M' else 'T6'
        descriptions = design.setdefault('desc', {}).setdefault(group, {})
        if task_id in descriptions and descriptions[task_id] != narrative:
            raise ValueError(f'authoring: narrative conflicts with /desc/{group}/{task_id}')
        descriptions[task_id] = narrative
    design = _resolve(design)
    for steps in _tour_steps(design):
        for index, step in enumerate(steps):
            if isinstance(step, str):
                task_id, overrides = step, {}
            elif isinstance(step, dict) and 'task' in step:
                task_id = step['task']
                overrides = {key: value for key, value in step.items() if key != 'task'}
                if 'ids' in overrides and overrides['ids'] != [task_id]:
                    raise ValueError('authoring: tour task shorthand cannot override ids with other tasks')
            else:
                continue
            if not isinstance(task_id, str):
                raise ValueError('authoring: tour task ID must be a string')
            task = design.get('tb', {}).get(task_id)
            if not isinstance(task, dict):
                raise ValueError(f'authoring: unknown tour task {task_id!r}')
            group = 'M6' if task.get('t') == 'M' else 'T6'
            label = overrides.get('v', task.get('lb'))
            detail = overrides.get('d', design.get('desc', {}).get(group, {}).get(task_id))
            if not isinstance(label, str) or not label.strip() or not isinstance(detail, str) or not detail.strip():
                raise ValueError(f'authoring: tour task {task_id} needs authored label and narrative')
            actor = overrides.get('a', '')
            if task.get('t') in ('N', 'H', 'O') and not actor:
                lane = next((lane for lane in design.get('lanes', []) if lane.get('k') == task.get('lane')), {})
                actor = lane.get('who') or lane.get('name')
                if not actor:
                    raise ValueError(f'authoring: human tour task {task_id} needs an authored lane or actor')
            expanded = {'ids': [task_id], 'v': label, 'd': detail, 'a': actor}
            expanded.update(overrides)
            steps[index] = expanded
    return design


def pack(design):
    """Replace only exact existing tour narrative/label duplicates; reversible."""
    compact = copy.deepcopy(design)
    for steps in _tour_steps(compact):
        for step in steps:
            if not isinstance(step, dict) or len(step.get('ids', [])) != 1:
                continue
            task_id = step['ids'][0]
            for group in ('T6', 'M6'):
                narrative = compact.get('desc', {}).get(group, {}).get(task_id)
                if isinstance(narrative, str) and narrative and step.get('d') == narrative:
                    step['d'] = {'$ref': f'/desc/{group}/{_escape(task_id)}'}
                    break
            label = compact.get('tb', {}).get(task_id, {}).get('lb')
            if isinstance(label, str) and label and step.get('v') == label:
                step['v'] = {'$ref': f'/tb/{_escape(task_id)}/lb'}
    result = {'schema': SCHEMA, 'design': compact}
    if expand(result) != design:
        raise ValueError('authoring: pack roundtrip did not preserve the canonical design')
    return result


def statistics(design, document):
    refs = []
    def visit(value):
        if isinstance(value, dict):
            if set(value) == {'$ref'}:
                refs.append(value['$ref'])
            for item in value.values():
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)
    visit(document['design'])
    size = lambda value: len(json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
    return {'canonical_bytes': size(design), 'authoring_bytes': size(document),
            'references': len(refs), 'tour_narrative_references': sum(x.startswith('/desc/') for x in refs),
            'exact_roundtrip': expand(document) == design}


def materialize(work, asis=None):
    """Write canonical design once, with backups and manual-edit protection."""
    work = Path(work)
    path = work / 'authoring.json'
    if not path.exists():
        return {'status': 'not_configured', 'safe_to_record_generated': False}
    document, hashes = _load(path)
    design_path, state_path = work / 'design.json', work / STATE
    state = _read(state_path) if state_path.exists() else {}
    current_hash = _sha(design_path.read_bytes()) if design_path.exists() else None
    unchanged = state.get('input_hashes') == hashes
    receipt_matches = current_hash == state.get('generated_design_sha256')
    if unchanged and current_hash:
        return {'status': 'unchanged', 'manual_changes_preserved': not receipt_matches,
                'safe_to_record_generated': receipt_matches, 'input_hashes': hashes}
    design = expand(document, asis)
    if state and current_hash and not receipt_matches:
        # Exact reconciliation is explicit evidence that the manual changes were
        # brought back into the authored source; never choose one divergent side.
        if _read(design_path) != design:
            raise ValueError('authoring: both authoring inputs and design.json changed; reconcile manual design edits into authoring.json before rebuilding')
        _atomic(state_path, {'schema': SCHEMA, 'input_hashes': hashes,
                            'materialized_design_sha256': current_hash,
                            'generated_design_sha256': current_hash})
        return {'status': 'reconciled', 'safe_to_record_generated': True, 'input_hashes': hashes}
    backup = None
    if current_hash:
        backup = work / 'design-history' / (current_hash + '.json')
        backup.parent.mkdir(parents=True, exist_ok=True)
        if not backup.exists():
            backup.write_bytes(design_path.read_bytes())
    _atomic(design_path, design)
    state = {'schema': SCHEMA, 'input_hashes': hashes,
             'materialized_design_sha256': _sha(design_path.read_bytes()),
             'generated_design_sha256': _sha(design_path.read_bytes())}
    _atomic(state_path, state)
    return {'status': 'materialized', 'safe_to_record_generated': True,
            'input_hashes': hashes, 'backup': str(backup) if backup else None}


def record_generated(work):
    """Record pipeline-owned deterministic enrichment; caller holds work lock."""
    work = Path(work)
    state_path = work / STATE
    if not state_path.exists():
        return False
    state = _read(state_path)
    if state.get('input_hashes') != input_hashes(work):
        raise ValueError('authoring: inputs changed during materialization')
    state['generated_design_sha256'] = _sha((work / 'design.json').read_bytes())
    _atomic(state_path, state)
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    for command in ('pack', 'expand'):
        p = sub.add_parser(command)
        p.add_argument('input', type=Path)
        p.add_argument('output', type=Path)
    p = sub.add_parser('materialize')
    p.add_argument('--work', type=Path, required=True)
    args = parser.parse_args()
    if args.command == 'pack':
        design = _read(args.input)
        document = pack(design)
        _atomic(args.output, document, compact=True)
        print(json.dumps(statistics(design, document), ensure_ascii=False))
    elif args.command == 'expand':
        document, _ = _load(args.input)
        _atomic(args.output, expand(document))
        print(json.dumps({'status': 'expanded', 'output': str(args.output)}, ensure_ascii=False))
    else:
        print(json.dumps(materialize(args.work), ensure_ascii=False))


if __name__ == '__main__':
    main()
