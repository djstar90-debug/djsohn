"""Operation-budget regressions: completion must not depend on another model call."""
import copy
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import pipeline as P
import qc_browser as Q
from test_pipeline import fake_report
FIX=ROOT/'tests/fixtures'


class AutomaticPreparation(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name);self.work=self.base/'work'
        P.prepare(self.work,asis_json=FIX/'valid-asis.json')
        (self.work/'design.json').write_bytes((FIX/'valid-design.json').read_bytes())
    def tearDown(self):self.tmp.cleanup()
    def test_missing_derived_arrays_are_filled_before_release_validation(self):
        d=P.read(self.work/'design.json')
        for sub in d['subs'].values():sub.pop('d');sub.pop('s')
        P.atomic(self.work/'design.json',d);before=(self.work/'design.json').read_bytes()
        with patch.object(Q,'final_wait',side_effect=fake_report):result=P.run(self.work,self.base/'out',0)
        self.assertEqual(result['status'],'passed')
        for sub in P.read(self.work/'design.json')['subs'].values():self.assertIn('d',sub);self.assertIn('s',sub)
        receipt=P.read(self.work/'preparation-report.json')
        self.assertEqual(Path(receipt['backup']).read_bytes(),before)
    def test_author_values_and_explicit_empty_arrays_are_not_replaced(self):
        d=P.read(self.work/'design.json');d['subs']['S1']['d']=[];d['subs']['S1'].pop('s')
        band=next(iter(d['story']));d['story'][band]['intro']='직접 작성한 설명입니다.'
        P.atomic(self.work/'design.json',d)
        P.prepare_design(self.work);after=P.read(self.work/'design.json')
        self.assertEqual(after['subs']['S1']['d'],[])
        self.assertEqual(after['story'][band]['intro'],d['story'][band]['intro'])
        self.assertEqual(after['tobe_flow'],d['tobe_flow']);self.assertEqual(after['new_edges'],d['new_edges'])
        self.assertEqual(after['tb'],d['tb'])
    def test_automatic_preparation_is_idempotent(self):
        P.prepare_design(self.work);before=(self.work/'design.json').read_bytes()
        report=P.read(self.work/'preparation-report.json')
        with patch('autofill.fill',side_effect=AssertionError('unneeded second fill')):
            self.assertEqual(P.prepare_design(self.work),report)
        self.assertEqual((self.work/'design.json').read_bytes(),before)
    def test_invalid_authored_value_is_not_repaired_to_pass(self):
        d=P.read(self.work/'design.json');d['subs']['S1']['d']='not an array'
        P.atomic(self.work/'design.json',d)
        with patch.object(Q,'final_wait',side_effect=AssertionError('must fail before browser')):
            result=P.run(self.work,self.base/'out',0)
        self.assertEqual(result['status'],'requires_fix')
        self.assertEqual(P.read(self.work/'design.json')['subs']['S1']['d'],'not an array')
    def test_diagnostics_group_shared_error_and_keep_all_locations(self):
        issues=[{'phase':'design','code':'SCHEMA','message':'subs.S'+str(i)+'.d — 배열이 필요합니다.'} for i in range(20)]
        report=P.compact({'status':'requires_fix','issues':issues},self.work)
        self.assertEqual(report['issue_count'],20);self.assertEqual(report['issue_group_count'],1)
        self.assertEqual(report['issue_groups'][0]['location_count'],20)
    def test_prepare_emits_lossless_source_packet_paths(self):
        state=P.status(self.work)
        self.assertTrue(Path(state['context']['brief']).is_file())
        self.assertEqual(state['context']['tasks'],4)
        self.assertTrue(all(Path(p).is_file() for p in state['context']['packets']))
    def test_authoring_materializes_then_prepares_without_rewriting_manual_values(self):
        import authoring
        d=P.read(self.work/'design.json')
        for sub in d['subs'].values():sub.pop('d');sub.pop('s')
        P.atomic(self.work/'authoring.json',authoring.pack(d))
        with patch.object(Q,'final_wait',side_effect=fake_report):result=P.run(self.work,self.base/'out',0)
        self.assertEqual(result['status'],'passed')
        current=P.read(self.work/'design.json');current['subs']['S1']['d']=['직접 작성한 데이터']
        P.atomic(self.work/'design.json',current)
        P.prepare_design(self.work)
        self.assertEqual(P.read(self.work/'design.json')['subs']['S1']['d'],['직접 작성한 데이터'])
        # Updated deterministic-generation receipt permits a later authoring edit
        # only until the canonical design has been manually changed.
        document=P.read(self.work/'authoring.json');document['design']['ds_memo']='changed'
        P.atomic(self.work/'authoring.json',document)
        with self.assertRaises(ValueError):P.prepare_design(self.work)
    def test_input_preflight_writes_all_blockers_before_parse_and_can_retry(self):
        work=self.base/'bad-input';source=self.base/'input.xlsx';source.write_bytes(b'fixture')
        issues=[{'severity':'error','code':'MISSING_ID','message':str(i),'row':i+1} for i in range(30)]
        report={'status':'failed','issues':issues,'counts':{'errors':30,'warnings':0}}
        with patch('input_preflight.inspect',return_value=report),patch('parse_excel.open_sheet',side_effect=AssertionError('blocked before parse')):
            result=P.prepare(work,excel=source)
        self.assertEqual(result['status'],'requires_fix')
        self.assertEqual(P.read(work/'input-diagnostics.json')['issues'],issues)
        self.assertFalse((work/P.STATE).exists())
        self.assertFalse((work/'design.json').exists())
        retry=P.compact(result,work)
        self.assertEqual(retry['next_action'],'fix_input_then_prepare')
        self.assertIn('원래 prepare 명령',retry['prepare_instruction'])
        self.assertNotIn('새 --work',retry['prepare_instruction'])
        self.assertNotIn('resume_command',retry)
    def test_changed_source_guides_new_prepare_instead_of_invalid_run_retry(self):
        for phase in ('input','input_changed','prepare_required'):
            with self.subTest(phase=phase):
                retry=P.compact({'status':'requires_fix','phase':phase},self.work)
                self.assertEqual(retry['next_action'],'fix_input_then_prepare')
                self.assertIn('원래 prepare 명령',retry['prepare_instruction'])
                self.assertIn('새 --work',retry['prepare_instruction'])
                self.assertNotIn('resume_command',retry)
    def test_repeated_launch_observes_worker_without_lock_or_rescheduling(self):
        P.atomic(self.work/'worker.json',{'pid':1234,'token':'active'})
        with patch.object(P,'worker_alive',return_value=True),patch.object(P,'lock',side_effect=AssertionError('active worker already owns lock')),patch.object(subprocess,'Popen',side_effect=AssertionError('must not duplicate worker')):
            result=P.background(self.work)
        self.assertEqual(result['worker']['pid'],1234)


class AutonomousCompletion(unittest.TestCase):
    def test_wait_zero_exits_but_worker_finishes_without_resume_or_status(self):
        # Snapshot isolates the worker from other development edits during tests.
        # The real Chromium/QC/Excel/certify path runs; no fake completion token.
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder);root=base/'skill'
            shutil.copytree(ROOT,root,ignore=shutil.ignore_patterns('__pycache__','qa','.git'))
            work=base/'work';out=base/'output'
            def invoke(*args):
                result=subprocess.run([sys.executable,str(root/'scripts/pipeline.py'),*args],cwd=root,text=True,capture_output=True,timeout=30)
                self.assertIn(result.returncode,(0,3),result.stderr+result.stdout)
                return json.loads(result.stdout)
            invoke('prepare','--asis-json',str(root/'tests/fixtures/valid-asis.json'),'--work',str(work))
            (work/'design.json').write_bytes((root/'tests/fixtures/valid-design.json').read_bytes())
            launched=invoke('run','--work',str(work),'--output',str(out),'--wait','0')
            self.assertEqual(launched['status'],'running');self.assertTrue(launched['automatic_completion'])
            self.assertNotIn('resume_command',launched)
            self.assertEqual(launched['next_action'],'wait_existing_worker')
            self.assertTrue(launched['worker_active'])
            deadline=time.monotonic()+45
            state=P.read(work/P.STATE)
            while state.get('status') in ('running','building') and time.monotonic()<deadline:
                time.sleep(.1)
                state=P.read(work/P.STATE)  # pure file read, no pipeline/QC APIs
            self.assertEqual(state.get('status'),'passed',(state,(work/'worker.log').read_text()[-1200:]))
            report=P.read(Path(state['candidate'])/'browser-qc.json')
            self.assertEqual(set(report['workers']),{'asis','ns45','ns6','panels'})
            self.assertTrue(all(x['status']=='passed' for x in report['workers'].values()))
            self.assertEqual(report['summary']['screens'],24)
            self.assertEqual(report['panels_checked'],7)
            self.assertTrue(all(Path(p).is_file() for p in state['deliverables'].values()))

if __name__=='__main__':unittest.main()
