import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import work_packets


class SourcePackets(unittest.TestCase):
    def test_lossless_including_empty_missing_and_reserved_objects(self):
        text = '반복되는 원천 설명과 자료를 변경하지 않고 보존합니다.'
        rows = {'a': {'n':'업무', 'inp':text, 'extra':{'$text':3}, 'none':None},
                'b': {'n':'다음 업무', 'inp':text, 'none':'', 'list':['원문',2]}}
        packet = work_packets.encode_rows(rows)
        self.assertEqual(work_packets.decode_rows(packet), rows)
        self.assertEqual(packet['texts'], [text])

    def test_all_tasks_and_fields_retained_without_raw_html(self):
        fixture = Path(__file__).parent / 'fixtures' / 'valid-asis.json'
        a = json.loads(fixture.read_text()); before = copy.deepcopy(a)
        with tempfile.TemporaryDirectory() as directory:
            report = work_packets.write_packets(a, directory)
            rebuilt = {}
            for path in report['packets']:
                p = json.loads(Path(path).read_text()); rebuilt.update(work_packets.decode_rows(p['tasks']))
                self.assertNotIn('bytes_base64', p)
            self.assertEqual(rebuilt, a['A6'])
            self.assertTrue(Path(report['brief']).is_file())
        self.assertEqual(a, before)

    def test_cross_stage_source_links_and_raw_types_retained(self):
        a = json.loads((Path(__file__).parent/'fixtures'/'valid-asis.json').read_text())
        ids = list(a['A6'])
        a['source_html'] = {'mapping': {'x':ids[0], 'y':ids[1]},
                            'snapshot': {'lv6': {'edges': [['x','y','conditional','승인 조건','원천 근거']]}}}
        p = work_packets.packets(a)[0]
        self.assertEqual(p['source_html_edges'], [[ids[0],ids[1],'conditional','승인 조건','원천 근거']])


if __name__ == '__main__': unittest.main()
