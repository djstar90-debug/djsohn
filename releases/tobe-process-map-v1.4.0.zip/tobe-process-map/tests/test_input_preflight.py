"""Batched input blockers reduce error-at-a-time retries without repairing data."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from openpyxl import Workbook
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import input_preflight as preflight
import parse_excel

HEADERS=['Lv.1','Lv.2','Lv.3','Lv.4','Lv.5','Lv.6','노드 ID','담당팀','선행','후행','_L5_ID','반려 시']


class InputPreflight(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def row(self,ident='1-1-1-1-1-1',name='자료 수집',group='조사',parent=''):
        return ['기획','마케팅','기획 단계','목표 설정',group,name,ident,'기획팀','','',parent,'']
    def workbook(self,rows,headers=HEADERS):
        wb=Workbook();ws=wb.active;ws.title='Process Map';ws.append(headers)
        for row in rows:ws.append(row)
        p=self.root/'input.xlsx';wb.save(p);wb.close();return p
    def source(self,rows):
        nodes=[dict(id='source-'+str(i),label=r[5],sourceRows=[i+2],hierarchy=dict(zip(['l1','l2','l3','l4','l5'],r[:5])),parent='source-group') for i,r in enumerate(rows)]
        d={'lv6':{'nodes':nodes,'edges':[]},'lv5':{'nodes':[],'edges':[]},'lv4':{'nodes':[],'edges':[]}}
        p=self.root/'source.html';p.write_text('<script>const DATA='+json.dumps(d,ensure_ascii=False)+';</script>');return p,d
    def codes(self,r):return r['counts']['by_code']

    def test_complete_excel_alone_passes_unchanged(self):
        rows=[self.row(),self.row('1-1-1-1-1-2','자료 검토')];rows[0][9]=rows[1][6]
        p=self.workbook(rows);before=hashlib.sha256(p.read_bytes()).hexdigest()
        report=preflight.inspect(p)
        self.assertEqual(report['status'],'passed');self.assertEqual(report['counts']['task_rows'],2)
        self.assertEqual(report['issues'],[])
        self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),before)
        self.assertEqual(len(parse_excel.build_f2(p)['A6']),2)
    def test_missing_ids_duplicate_and_references_reported_together(self):
        rows=[self.row('',name='첫 업무'),self.row('',name='둘째 업무'),self.row(),self.row(name='중복 업무')]
        rows[0][9]='unknown-a';rows[1][11]='unknown-b'
        r=preflight.inspect(self.workbook(rows))
        self.assertEqual(r['status'],'failed');self.assertEqual(self.codes(r)['MISSING_ID'],2)
        self.assertEqual(self.codes(r)['DUPLICATE_ID'],1);self.assertEqual(self.codes(r)['SOURCE_REFERENCE_CONFLICT'],2)
        self.assertEqual(r['counts']['task_rows'],4)
        self.assertEqual(sorted(i['row'] for i in r['issues'] if i['code']=='MISSING_ID'),[2,3])
    def test_preview_is_bounded_but_report_retains_all_rows(self):
        rows=[self.row('',name='업무 '+str(i)) for i in range(20)]
        r=preflight.inspect(self.workbook(rows));p=preflight.preview(r,limit=1000)
        self.assertEqual(len(p['issues']),8);self.assertEqual(r['counts']['missing_ids'],20)
        self.assertEqual(len(r['issues']),20)
    def test_exact_source_recovery_and_dangling_reference_warning(self):
        rows=[self.row('',name='자료 수집'),self.row('',name='자료 검토')];rows[0][9]='stale-id'
        p=self.workbook(rows);source,_=self.source(rows)
        r=preflight.inspect(p,source_html=source)
        self.assertEqual(r['status'],'passed');self.assertEqual(r['counts']['recovered_ids'],2)
        self.assertEqual(r['counts']['errors'],0);self.assertEqual(r['counts']['warnings'],1)
        self.assertEqual(len(parse_excel.build_f2(p,source_html=source)['A6']),2)
    def test_ambiguous_source_does_not_guess_or_discard_missing_id(self):
        rows=[self.row('')];p=self.workbook(rows);source,data=self.source(rows)
        data['lv6']['nodes'].append({**data['lv6']['nodes'][0],'id':'second-candidate'})
        source.write_text('<script>const DATA='+json.dumps(data)+';</script>')
        r=preflight.inspect(p,source_html=source)
        self.assertEqual(self.codes(r)['SOURCE_CORRESPONDENCE'],1);self.assertEqual(self.codes(r)['MISSING_ID'],1)
        self.assertEqual(r['detail']['recovered_ids'],[])
    def test_unmatched_html_does_not_exempt_dangling_refs(self):
        rows=[self.row()];rows[0][9]='unknown';p=self.workbook(rows);source,data=self.source(rows)
        data['lv6']['nodes'][0]['label']='다른 업무';source.write_text('<script>const DATA='+json.dumps(data)+';</script>')
        r=preflight.inspect(p,source_html=source)
        self.assertEqual(r['status'],'failed')
        self.assertEqual(next(x for x in r['issues'] if x['code']=='SOURCE_REFERENCE_CONFLICT')['severity'],'error')
    def test_hierarchy_conflicts_are_batched(self):
        rows=[self.row(),self.row('1-1-1-1-1-2',group='다른 묶음'),self.row('1-1-1-1-1-3','검수')]
        rows[2][2]='다른 단계'
        r=preflight.inspect(self.workbook(rows))
        self.assertIn('STAGE_NAME_CONFLICT',self.codes(r));self.assertIn('PARENT_NAME_CONFLICT',self.codes(r))
        with self.assertRaises(parse_excel.InputError):parse_excel.build_f2(self.root/'input.xlsx')
    def test_opaque_ids_with_explicit_parent_supported(self):
        rows=[self.row('T1',parent='P1'),self.row('T2','검토',parent='P1')]
        self.assertEqual(preflight.inspect(self.workbook(rows))['status'],'passed')
    def test_all_formula_cache_and_excel_error_cells_reported(self):
        rows=[self.row(),self.row('1-1-1-1-1-2')]
        rows[0][5]='="첫 업무"';rows[1][5]='="둘째 업무"';rows[1][7]='#REF!'
        r=preflight.inspect(self.workbook(rows))
        self.assertEqual(self.codes(r)['FORMULA_CACHE_MISSING'],2);self.assertEqual(self.codes(r)['EXCEL_ERROR'],1)
    def test_f1_missing_and_duplicate_ids_batched(self):
        headers=['Lv.1','Lv.2','Lv.3','Lv.4','Lv.5','Lv.6','Lv.4 노드 ID','Lv.5 노드 ID','Lv.6 노드 ID']
        row=['기획','마케팅','계획','목표','조사','자료 수집','L4','L5','T1']
        rows=[row,row,row[:-1]+['']]
        r=preflight.inspect(self.workbook(rows,headers),spec='1')
        self.assertEqual(self.codes(r)['DUPLICATE_ID'],1);self.assertEqual(self.codes(r)['MISSING_ID'],1)
    def test_f1_unselected_sections_do_not_block(self):
        headers=['섹션','Lv.1','Lv.2','Lv.3','Lv.4','Lv.5','Lv.6','Lv.4 노드 ID','Lv.5 노드 ID','Lv.6 노드 ID']
        rows=[['1. 정상'],['','기획','마케팅','계획','목표','조사','수집','L4','L5','T1'],['2. 오류'],['','기획','마케팅','계획','목표','조사','검토','L4B','L5B','']]
        p=self.workbook(rows,headers)
        self.assertEqual(preflight.inspect(p,spec='1')['status'],'passed')
        r=preflight.inspect(p,spec='1,2');self.assertEqual(r['counts']['missing_ids'],1)
    def test_invalid_headers_and_missing_sheet_are_structured(self):
        p=self.workbook([['wrong']],['unknown'])
        self.assertIn('UNSUPPORTED_FORMAT',self.codes(preflight.inspect(p)))
        wb=Workbook();wb.save(p);wb.close()
        self.assertIn('MISSING_SHEET',self.codes(preflight.inspect(p)))
    def test_unreadable_workbook_returns_structured_failure(self):
        p=self.root/'damaged.xlsx';p.write_text('not an Excel archive')
        r=preflight.inspect(p)
        self.assertEqual(r['status'],'failed');self.assertIn('INPUT_READ_ERROR',self.codes(r))
    def test_f1_duplicate_parent_ids_across_selected_sections_are_batched(self):
        headers=['섹션','Lv.1','Lv.2','Lv.3','Lv.4','Lv.5','Lv.6','Lv.4 노드 ID','Lv.5 노드 ID','Lv.6 노드 ID']
        rows=[['1. 첫 범위'],['','기획','마케팅','계획','목표','조사','수집','L4','L5','T1'],['2. 둘째 범위'],['','기획','마케팅','계획','목표','조사','검토','L4','L5','T2']]
        p=self.workbook(rows,headers);r=preflight.inspect(p,spec='1,2')
        self.assertEqual(self.codes(r)['SCOPE_ID_COLLISION'],2)
        with self.assertRaises(parse_excel.InputError):
            parse_excel.merge([parse_excel.build(p,1),parse_excel.build(p,2)])
    def test_cli_persists_complete_report_and_prints_only_preview(self):
        p=self.workbook([self.row('',name=str(i)+' 번째 업무') for i in range(12)])
        output=self.root/'diagnostics.json';script=Path(preflight.__file__)
        result=subprocess.run([sys.executable,str(script),str(p),'--out',str(output)],capture_output=True,text=True)
        self.assertEqual(result.returncode,2)
        self.assertEqual(len(json.loads(result.stdout)['issues']),8)
        self.assertEqual(len(json.loads(output.read_text())['issues']),12)


if __name__=='__main__':unittest.main()
