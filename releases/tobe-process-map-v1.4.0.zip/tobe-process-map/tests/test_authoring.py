import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import authoring as A
import restructure
import export_excel
import build_html

FIX = Path(__file__).parent / 'fixtures'


class AuthoringTests(unittest.TestCase):
    def setUp(self):
        self.design = json.loads((FIX / 'valid-design.json').read_text())
        self.asis = json.loads((FIX / 'valid-asis.json').read_text())
        self.tmp = tempfile.TemporaryDirectory()
        self.work = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name, data):
        path = self.work / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False))
        return path

    def document(self, design=None):
        return {'schema': A.SCHEMA, 'design': copy.deepcopy(self.design if design is None else design)}

    def steps(self, design):
        return design['tour']['1']['beats'][0]['steps']

    def test_pack_full_canonical_exact_and_nonmutating(self):
        before = copy.deepcopy(self.design)
        packed = A.pack(self.design)
        self.assertEqual(A.expand(packed), self.design)
        self.assertEqual(self.design, before)
        self.assertEqual(self.steps(packed['design'])[0]['v'], {'$ref': '/tb/T1/lb'})
        # Different authored narratives remain different; no generic replacement.
        self.assertEqual(self.steps(packed['design'])[0]['d'], self.steps(before)[0]['d'])

    def test_exact_narrative_reuse_removes_only_duplicate(self):
        for step in self.steps(self.design):
            step['d'] = self.design['desc']['T6'][step['ids'][0]]
        packed = A.pack(self.design)
        self.assertEqual(A.statistics(self.design, packed)['tour_narrative_references'], 3)
        self.assertEqual(A.expand(packed), self.design)

    def test_one_authored_narrative_expands_to_detail_and_explicit_tour(self):
        document = self.document()
        d = document['design']
        narratives = d['desc'].pop('T6')
        for task_id, narrative in narratives.items():
            d['tb'][task_id]['narrative'] = narrative
        d['tour']['1']['beats'][0]['steps'] = ['T3', 'T2', 'T1']
        before = copy.deepcopy(document)
        expanded = A.expand(document)
        self.assertEqual(document, before)
        self.assertEqual(expanded['desc']['T6'], narratives)
        self.assertNotIn('narrative', expanded['tb']['T1'])
        self.assertEqual([s['ids'] for s in self.steps(expanded)], [['T3'], ['T2'], ['T1']])
        self.assertEqual(self.steps(expanded)[1]['a'], 'CRM팀')
        self.assertEqual(self.steps(expanded)[0]['d'], narratives['T3'])
        self.assertEqual(expanded['tobe_flow'], self.design['tobe_flow'])
        self.assertEqual(expanded['design_contract'], self.design['design_contract'])
        self.assertEqual(expanded['tb'], self.design['tb'])

    def test_no_tour_or_flow_order_inferred(self):
        document = self.document()
        document['design'].pop('tour')
        document['design'].pop('tobe_flow')
        result = A.expand(document)
        self.assertNotIn('tour', result)
        self.assertNotIn('tobe_flow', result)

    def test_human_owner_cannot_be_invented(self):
        document = self.document()
        document['design']['lanes'] = []
        document['design']['tour']['1']['beats'][0]['steps'] = ['T2']
        with self.assertRaisesRegex(ValueError, 'authored lane or actor'):
            A.expand(document)
        document['design']['tour']['1']['beats'][0]['steps'] = [{'task': 'T2', 'a': '명시한 담당자'}]
        self.assertEqual(self.steps(A.expand(document))[0]['a'], '명시한 담당자')

    def test_shorthand_honors_authored_overrides(self):
        document = self.document()
        document['design']['tour']['1']['beats'][0]['steps'] = [
            {'task': 'T1', 'v': '다른 해설 제목', 'd': '모델이 따로 쓴 상세 설명', 'p': '원문 강조', 'a': '별도 주체'}]
        step = self.steps(A.expand(document))[0]
        self.assertEqual(step, {'ids': ['T1'], 'v': '다른 해설 제목', 'd': '모델이 따로 쓴 상세 설명', 'p': '원문 강조', 'a': '별도 주체'})

    def test_orchestrator_uses_m6(self):
        document = self.document()
        document['design']['tb']['M1'] = {'t': 'M', 'lb': '확정 신호 전달', 'narrative': 'Orchestrator가 확정 신호를 전달한다.'}
        document['design']['tour']['1']['beats'][0]['steps'] = ['M1']
        result = A.expand(document)
        self.assertEqual(result['desc']['M6']['M1'], self.steps(result)[0]['d'])
        self.assertNotIn('M1', result['desc']['T6'])

    def test_conflicting_narrative_fails(self):
        document = self.document()
        document['design']['tb']['T1']['narrative'] = '상충하는 새 설명'
        with self.assertRaisesRegex(ValueError, 'narrative conflicts'):
            A.expand(document)

    def test_missing_task_description_and_bad_override_fail(self):
        for shorthand, description in [(['unknown'], 'unknown tour task'), (['T1'], 'authored label and narrative'), ([{'task': 'T1', 'ids': ['T2']}], 'cannot override ids')]:
            with self.subTest(shorthand=shorthand):
                document = self.document()
                document['design']['tour']['1']['beats'][0]['steps'] = shorthand
                document['design']['desc']['T6'].pop('T1')
                with self.assertRaisesRegex(ValueError, description):
                    A.expand(document)

    def test_json_pointer_escaped_keys_and_array(self):
        document = self.document({'source': {'a/b~c': ['original']}, 'copy': {'$ref': '/source/a~1b~0c/0'}})
        self.assertEqual(A.expand(document)['copy'], 'original')

    def test_missing_circular_external_and_mixed_refs_fail(self):
        for design, message in [
                ({'x': {'$ref': '/missing'}}, 'missing'),
                ({'x': {'$ref': '/y'}, 'y': {'$ref': '/x'}}, 'circular'),
                ({'x': {'$ref': ''}}, 'circular'),
                ({'x': {'$ref': 'https://example.com'}}, 'internal JSON Pointer'),
                ({'x': {'$ref': '/x', 'extra': 1}}, 'other keys'),
                ({'x': {'$ref': '/bad~2key'}}, 'invalid JSON Pointer')]:
            with self.subTest(design=design):
                with self.assertRaisesRegex(ValueError, message):
                    A.expand(self.document(design))

    def test_reference_can_reuse_narrative_shorthand(self):
        document = self.document()
        document['design']['tb']['T1']['narrative'] = document['design']['desc']['T6'].pop('T1')
        self.steps(document['design'])[0]['d'] = {'$ref': '/desc/T6/T1'}
        expanded = A.expand(document)
        self.assertEqual(self.steps(expanded)[0]['d'], expanded['desc']['T6']['T1'])

    def test_stage_chunks_merge_objects_and_hash_all_inputs(self):
        self.write('authoring.json', {'schema': A.SCHEMA, 'design': {'tb': {}}, 'includes': ['chunks/a.json', 'chunks/b.json']})
        self.write('chunks/a.json', {'tb': {'A': {'lb': 'A'}}, 'tour': {'1': {'beats': []}}})
        self.write('chunks/b.json', {'tb': {'B': {'lb': 'B'}}, 'tour': {'2': {'beats': []}}})
        result = A.materialize(self.work)
        self.assertEqual(set(json.loads((self.work / 'design.json').read_text())['tb']), {'A', 'B'})
        self.assertEqual(set(result['input_hashes']), {'authoring.json', 'chunks/a.json', 'chunks/b.json'})
        before = A.input_hashes(self.work)
        self.write('chunks/b.json', {'tb': {'B': {'lb': 'new'}}})
        self.assertNotEqual(A.input_hashes(self.work), before)

    def test_chunks_do_not_silently_change_order_or_decisions(self):
        self.write('authoring.json', {'schema': A.SCHEMA, 'design': {'tobe_flow': [['T1', 'T2', 's', '']]}, 'includes': ['stage.json']})
        self.write('stage.json', {'tobe_flow': [['T2', 'T1', 's', '']]})
        with self.assertRaisesRegex(ValueError, 'conflicting values at /tobe_flow'):
            A.materialize(self.work)

    def test_unsafe_include_and_nested_wrappers_fail(self):
        for path in ['../outside.json', '/tmp/outside.json', 'authoring.json']:
            self.write('authoring.json', {'schema': A.SCHEMA, 'design': {}, 'includes': [path]})
            with self.assertRaises(ValueError):
                A.input_hashes(self.work)
        self.write('authoring.json', {'schema': A.SCHEMA, 'design': {}, 'includes': ['stage.json']})
        self.write('stage.json', self.document())
        with self.assertRaisesRegex(ValueError, 'not nested wrappers'):
            A.materialize(self.work)

    def test_duplicate_json_keys_fail(self):
        (self.work / 'authoring.json').write_text('{"schema":"tobe-authoring/v1","design":{"x":1,"x":2}}')
        with self.assertRaisesRegex(ValueError, 'duplicate JSON key'):
            A.input_hashes(self.work)

    def test_materialize_backs_up_manual_design_and_is_idempotent(self):
        original = self.write('design.json', {'before': 'preserved'}).read_bytes()
        self.write('authoring.json', A.pack(self.design))
        result = A.materialize(self.work)
        self.assertTrue(result['safe_to_record_generated'])
        self.assertEqual(Path(result['backup']).read_bytes(), original)
        first = (self.work / 'design.json').read_bytes()
        second = A.materialize(self.work)
        self.assertEqual(second['status'], 'unchanged')
        self.assertTrue(second['safe_to_record_generated'])
        self.assertEqual((self.work / 'design.json').read_bytes(), first)

    def test_manual_changes_preserved_then_conflicting_source_change_blocked(self):
        self.write('authoring.json', A.pack(self.design))
        A.materialize(self.work)
        self.design['meta']['text']['title'] = 'manual edit'
        manual = self.write('design.json', self.design).read_bytes()
        result = A.materialize(self.work)
        self.assertTrue(result['manual_changes_preserved'])
        self.assertFalse(result['safe_to_record_generated'])
        self.assertEqual((self.work / 'design.json').read_bytes(), manual)
        self.design['meta']['text']['title'] = 'separate source edit'
        self.write('authoring.json', A.pack(self.design))
        with self.assertRaisesRegex(ValueError, 'both authoring inputs and design.json changed'):
            A.materialize(self.work)
        self.assertEqual((self.work / 'design.json').read_bytes(), manual)

    def test_record_generated_allows_later_authoring_update(self):
        self.write('authoring.json', A.pack(self.design))
        A.materialize(self.work)
        enriched = copy.deepcopy(self.design)
        enriched['ui']['mechanical_default'] = True
        self.write('design.json', enriched)
        self.assertTrue(A.record_generated(self.work))
        self.assertTrue(A.materialize(self.work)['safe_to_record_generated'])
        self.design['meta']['text']['title'] = 'new authored title'
        self.write('authoring.json', A.pack(self.design))
        self.assertEqual(A.materialize(self.work)['status'], 'materialized')
        self.assertEqual(json.loads((self.work / 'design.json').read_text()), self.design)

    def test_explicitly_reconciled_manual_edit_can_be_adopted(self):
        self.write('authoring.json', A.pack(self.design))
        A.materialize(self.work)
        self.design['meta']['text']['title'] = 'manually edited and reconciled'
        manual = self.write('design.json', self.design).read_bytes()
        self.write('authoring.json', A.pack(self.design))
        result = A.materialize(self.work)
        self.assertEqual(result['status'], 'reconciled')
        self.assertTrue(result['safe_to_record_generated'])
        self.assertEqual((self.work / 'design.json').read_bytes(), manual)

    def test_missing_generated_design_can_be_rebuilt(self):
        self.write('authoring.json', A.pack(self.design))
        A.materialize(self.work)
        (self.work / 'design.json').unlink()
        self.assertEqual(A.materialize(self.work)['status'], 'materialized')

    def test_no_authoring_preserves_legacy_workflow(self):
        original = self.write('design.json', self.design).read_bytes()
        self.assertEqual(A.input_hashes(self.work), {})
        self.assertEqual(A.materialize(self.work)['status'], 'not_configured')
        self.assertFalse(A.record_generated(self.work))
        self.assertEqual((self.work / 'design.json').read_bytes(), original)

    def test_same_design_produces_same_pmd_and_excel_tables(self):
        expanded = A.expand(A.pack(self.design))
        original_pmd = restructure.build(self.asis, self.design)
        expanded_pmd = restructure.build(self.asis, expanded)
        self.assertEqual(expanded_pmd, original_pmd)
        self.assertEqual(export_excel.tables(self.asis, expanded, expanded_pmd),
                         export_excel.tables(self.asis, self.design, original_pmd))
        assets = Path(__file__).resolve().parents[1] / 'assets'
        shell, engine = (assets / 'shell.html').read_text(), (assets / 'engine.js').read_text()
        self.assertEqual(build_html.build(shell, engine, expanded_pmd, expanded),
                         build_html.build(shell, engine, original_pmd, self.design))


if __name__ == '__main__':
    unittest.main()
