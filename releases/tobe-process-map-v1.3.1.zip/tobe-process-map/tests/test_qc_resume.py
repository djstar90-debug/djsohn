"""Resume is valid only for complete passing parts of the exact QC input/profile."""
import json,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch,MagicMock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import qc_browser as qc

class ResumeTests(unittest.TestCase):
    def fixture(self,directory,failed=None):
        root=Path(directory);html=root/'input.html';html.write_text('unchanged artifact')
        run=root/'original';run.mkdir()
        state=dict(html=str(html.resolve()),sha256=qc.file_hash(html),runner_sha256=qc.runner_fingerprint(),profile=qc.PROFILE,root=str(root),run_dir=str(run),run_id='original',start=qc.time.time(),jobs=2,workers={})
        for name,part,only in qc.FINAL:
            state['workers'][name]=dict(pid=None,part=part,state='complete')
            report=dict(html=state['html'],sha256=state['sha256'],runner_sha256=state['runner_sha256'],profile=qc.PROFILE,run_id='original',part=part,only=[x for x in only.split(',') if x],status='failed' if name==failed else 'passed',screens=[] if part=='panels' else [{}],expected_screens=0 if part=='panels' else 1,panels_checked=1 if part=='panels' else 0,summary={'errors':1} if name==failed else {},errors=['synthetic'] if name==failed else [],completed_at=qc.time.time())
            (run/(name+'.json')).write_text(json.dumps(report))
        (root/'started.json').write_text(json.dumps(state))
        return root,html,state

    def test_completed_success_reuses_same_run_without_process(self):
        with tempfile.TemporaryDirectory() as d:
            root,html,state=self.fixture(d)
            with patch.object(qc.subprocess,'Popen') as launch:
                current=qc.final_start(html,root)
            self.assertEqual(current['run_id'],'original');launch.assert_not_called()

    def test_failed_result_does_not_retry_without_instruction(self):
        with tempfile.TemporaryDirectory() as d:
            root,html,state=self.fixture(d,'panels')
            with patch.object(qc.subprocess,'Popen') as launch:
                current=qc.final_start(html,root)
            self.assertEqual(current['run_id'],'original');launch.assert_not_called()

    def test_retry_one_part_retains_passed_parts_with_provenance(self):
        with tempfile.TemporaryDirectory() as d:
            root,html,state=self.fixture(d,'panels')
            with patch.object(qc.subprocess,'Popen',return_value=MagicMock(pid=1234)) as launch:
                current=qc.final_start(html,root,rerun_parts=['panels'])
            self.assertEqual(launch.call_count,1);self.assertNotEqual(current['run_id'],'original')
            for name in ('asis','ns45','ns6'):
                report=qc._load_report(current,name)
                self.assertEqual(report['run_id'],current['run_id']);self.assertEqual(report['reused_from']['run_id'],'original')
            self.assertEqual(current['workers']['panels']['state'],'running')

    def test_changed_input_never_reuses_passed_part(self):
        with tempfile.TemporaryDirectory() as d:
            root,html,state=self.fixture(d);html.write_text('changed artifact')
            with patch.object(qc.subprocess,'Popen',return_value=MagicMock(pid=1234)) as launch:
                current=qc.final_start(html,root)
            self.assertEqual(launch.call_count,2)
            self.assertEqual(sum(w['state']=='queued' for w in current['workers'].values()),2)
            self.assertFalse(any(w['state']=='reused' for w in current['workers'].values()))

    def test_changed_runner_never_reuses_passed_part(self):
        with tempfile.TemporaryDirectory() as d:
            root,html,state=self.fixture(d)
            with patch.object(qc,'runner_fingerprint',return_value='new-runner'),patch.object(qc.subprocess,'Popen',return_value=MagicMock(pid=1234)):
                current=qc.final_start(html,root)
            self.assertFalse(any(w['state']=='reused' for w in current['workers'].values()))

    def test_matching_active_run_resumes_without_duplicate_workers(self):
        with tempfile.TemporaryDirectory() as d:
            root,html,state=self.fixture(d)
            for name in ('ns6','panels'):
                (Path(state['run_dir'])/(name+'.json')).unlink();state['workers'][name].update(pid=123,state='running')
            (root/'started.json').write_text(json.dumps(state))
            with patch.object(qc,'process_alive',return_value=True),patch.object(qc.subprocess,'Popen') as launch:
                current=qc.final_start(html,root)
            self.assertEqual(current['run_id'],'original');launch.assert_not_called()

    def test_false_pass_with_incomplete_coverage_is_not_reusable(self):
        with tempfile.TemporaryDirectory() as d:
            root,html,state=self.fixture(d)
            report=qc._load_report(state,'asis');report['expected_screens']=99
            self.assertFalse(qc.reusable(report,state,'asis','asis',''))

    def test_errors_deduplicated_with_stack_and_locations(self):
        report={'errors':[]};qc.context(report,phase='agent',agent='B7',selector='#apage')
        qc.record_error(report,'example failure','Error\n at map.html:42:1')
        qc.context(report,phase='detail',node='T3');qc.record_error(report,'example failure','Error\n at map.html:42:1')
        self.assertEqual(len(report['errors']),1);item=report['diagnostics'][0]
        self.assertEqual(item['occurrences'],2);self.assertEqual(len(item['locations']),2);self.assertIn(':42:',item['stack'])

    def test_worker_failures_do_not_become_script_errors(self):
        report={'part':'final','screens':[{}],'panels_checked':1,'summary':{'errors':0},'worker_failures':['ns6: parallel=1']}
        self.assertEqual(report['summary']['errors'],0)
        self.assertTrue(qc.failures(report))
        self.assertIn('Worker ns6: parallel=1',qc.failures(report))

    def test_bounded_wait_returns_pending_with_resume_command(self):
        with tempfile.TemporaryDirectory() as d:
            root,html,state=self.fixture(d);(root/'status.json').write_text(json.dumps({'status':'pending','run_id':'original','pending':['panels']}))
            with patch.object(qc,'final_start',return_value=state),patch.object(qc,'final_result',return_value=None),patch.object(qc.time,'sleep',side_effect=AssertionError('zero budget must not sleep')):
                report=qc.final_wait(html,root,timeout=0)
            self.assertEqual(report['status'],'pending');self.assertIn('final-wait',report['resume_command'])

if __name__=='__main__':unittest.main()
