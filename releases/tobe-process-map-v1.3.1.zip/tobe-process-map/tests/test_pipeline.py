import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import pipeline as P
import qc_browser as Q

FIX=Path(__file__).parent/'fixtures'

def fake_report(html,out,**kwargs):
    report={'status':'passed','part':'final','sha256':P.file_hash(html),'run_id':'test',
            'runner_sha256':Q.runner_fingerprint(),'profile':Q.PROFILE,'summary':{'screens':1,'errors':0},'screens':[{}],'panels_checked':1,'failures':[]}
    P.atomic(Path(out)/'final.json',report)
    return report

class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.base=Path(self.tmp.name);self.work=self.base/'work';self.out=self.base/'outputs'
        P.prepare(self.work,asis_json=FIX/'valid-asis.json')
        (self.work/'design.json').write_bytes((FIX/'valid-design.json').read_bytes())
    def tearDown(self):self.tmp.cleanup()
    def test_prepare_resumes_without_overwriting_authored_design(self):
        before=(self.work/'design.json').read_bytes()
        P.prepare(self.work,asis_json=FIX/'valid-asis.json')
        self.assertEqual(before,(self.work/'design.json').read_bytes())
    def test_prepare_changed_input_is_blocked(self):
        src=self.base/'other.json';src.write_bytes((FIX/'valid-asis.json').read_bytes())
        with self.assertRaisesRegex(ValueError,'새 --work'):P.prepare(self.work,asis_json=src)
    def test_prepare_without_model_does_not_invent_design(self):
        w=self.base/'new';result=P.prepare(w,asis_json=FIX/'valid-asis.json')
        self.assertEqual(result['status'],'design_required');self.assertFalse(P.read(w/'design.json')['tb'])
    def test_build_and_certify_in_one_invocation(self):
        with patch.object(Q,'final_wait',side_effect=fake_report,create=True) as browser:
            result=P.run(self.work,self.out,0)
        self.assertEqual(result['status'],'passed');self.assertEqual(browser.call_count,1)
        for file in result['deliverables'].values():self.assertTrue(Path(file).is_relative_to(self.out));self.assertTrue(Path(file).is_file())
    def test_unchanged_pass_skips_build_and_browser(self):
        with patch.object(Q,'final_wait',side_effect=fake_report,create=True):P.run(self.work,self.out,0)
        import release
        with patch.object(release,'build',side_effect=AssertionError('unexpected rebuild')),patch.object(Q,'final_wait',side_effect=AssertionError('unexpected browser'),create=True):
            self.assertTrue(P.run(self.work,wait=0)['cache_hit'])
    def test_changed_design_invalidates_pass(self):
        with patch.object(Q,'final_wait',side_effect=fake_report,create=True):first=P.run(self.work,self.out,0)
        d=P.read(self.work/'design.json');d['meta']['text']['title']='변경된 예제';P.atomic(self.work/'design.json',d)
        self.assertEqual(P.status(self.work)['status'],'inputs_changed');self.assertNotIn('deliverables',P.status(self.work))
        with patch.object(Q,'final_wait',side_effect=fake_report,create=True) as browser:second=P.run(self.work,wait=0)
        self.assertEqual(browser.call_count,1);self.assertNotEqual(first['candidate'],second['candidate'])
    def test_candidate_exists_even_when_qc_pending(self):
        with patch.object(Q,'final_wait',return_value={'status':'pending'},create=True):result=P.run(self.work,self.out,0)
        self.assertEqual(result['status'],'running');self.assertTrue((Path(result['candidate'])/'map.xlsx').exists())
        self.assertNotIn('deliverables',result)
        import release
        with patch.object(release,'build',side_effect=AssertionError('unexpected rebuild')),patch.object(Q,'final_wait',side_effect=fake_report,create=True):
            self.assertEqual(P.run(self.work,wait=0)['status'],'passed')
    def test_qc_failure_preserves_candidate_and_diagnostics(self):
        failed={'status':'failed','summary':{'errors':6},'screens':[{}],'part':'final','panels_checked':1,'diagnostics':[{'message':'B7 clipped'}]}
        with patch.object(Q,'final_wait',return_value=failed,create=True):result=P.run(self.work,self.out,0)
        self.assertEqual(result['status'],'requires_fix');self.assertTrue(Path(result['candidate']).is_dir());self.assertNotIn('deliverables',result)
        self.assertEqual(P.read(self.work/'diagnostics.json')['phase'],'browser_qc')
    def test_changed_artifact_is_not_reused(self):
        with patch.object(Q,'final_wait',side_effect=fake_report,create=True):first=P.run(self.work,self.out,0)
        (Path(first['candidate'])/'map.html').write_text('tampered')
        self.assertEqual(P.status(self.work)['status'],'artifacts_changed')
        with patch.object(Q,'final_wait',side_effect=fake_report,create=True):second=P.run(self.work,wait=0)
        self.assertNotEqual(first['candidate'],second['candidate']);self.assertEqual(second['status'],'passed')
    def test_old_deliverables_hidden_after_artifact_failure(self):
        with patch.object(Q,'final_wait',side_effect=fake_report,create=True):first=P.run(self.work,self.out,0)
        (Path(first['candidate'])/'map.html').write_text('tampered')
        with patch('release.build',side_effect=ValueError('new build error')):result=P.run(self.work,wait=0)
        self.assertEqual(result['status'],'requires_fix');self.assertNotIn('deliverables',result)
        self.assertNotIn('deliverables',P.compact(result,self.work))
    def test_changed_certification_receipt_invalidates_cache(self):
        with patch.object(Q,'final_wait',side_effect=fake_report,create=True):first=P.run(self.work,self.out,0)
        (Path(first['candidate'])/'browser-qc.json').write_text('{}')
        self.assertEqual(P.status(self.work)['status'],'artifacts_changed')
    def test_browser_environment_change_invalidates_pipeline_cache(self):
        with patch.object(Q,'final_wait',side_effect=fake_report,create=True):P.run(self.work,self.out,0)
        with patch.object(Q,'runner_fingerprint',return_value='new-browser-version'):
            self.assertEqual(P.status(self.work)['status'],'inputs_changed')
    def test_source_changed_requires_new_preparation(self):
        src=self.base/'source.json';src.write_bytes((FIX/'valid-asis.json').read_bytes())
        w=self.base/'sourcework';P.prepare(w,asis_json=src)
        (w/'design.json').write_bytes((FIX/'valid-design.json').read_bytes())
        a=json.loads(src.read_text());a['meta']['title']='changed';src.write_text(json.dumps(a))
        result=P.run(w,self.base/'sourceout',0)
        self.assertEqual(result['status'],'requires_fix');self.assertEqual(result['phase'],'input_changed')
    def test_retry_qc_only_passes_failed_worker_names(self):
        with patch.object(Q,'final_wait',return_value={'status':'pending'},create=True):result=P.run(self.work,self.out,0)
        P.atomic(Path(result['candidate'])/'qc/final.json',{'repair':{'failed_parts':['panels']}})
        with patch.object(Q,'final_wait',side_effect=fake_report,create=True) as runner:result=P.run(self.work,wait=0,retry_qc=True)
        self.assertEqual(runner.call_args.kwargs['rerun_parts'],['panels']);self.assertEqual(result['status'],'passed')
    def test_worker_waits_for_parent_lock_release(self):
        import threading,time
        entered=threading.Event()
        def parent():
            with P.lock(self.work):entered.set();time.sleep(0.15)
        thread=threading.Thread(target=parent);thread.start();entered.wait()
        started=time.monotonic();P.wait_parent_lock(self.work,timeout=2)
        self.assertGreater(time.monotonic()-started,0.1);thread.join()
    def test_no_delivery_on_validation_failure(self):
        d=P.read(self.work/'design.json');d.pop('design_contract');P.atomic(self.work/'design.json',d)
        with patch.object(Q,'final_wait',side_effect=AssertionError('validation must precede browser'),create=True):result=P.run(self.work,self.out,0)
        self.assertEqual(result['status'],'requires_fix');self.assertEqual(result['phase'],'build');self.assertTrue((self.work/'diagnostics.json').exists())
    def test_output_relocation_cannot_overwrite_unrelated_files(self):
        with patch.object(Q,'final_wait',return_value={'status':'pending'},create=True):P.run(self.work,self.out,0)
        with self.assertRaisesRegex(ValueError,'기존'):P.run(self.work,self.base/'different',0)

if __name__=='__main__':unittest.main()
