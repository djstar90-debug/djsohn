"""Source-derived As-Is must use the visible shared UI and preserve its graph/layout."""
import copy,sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import qc_browser as qc

class SourceViewTests(unittest.TestCase):
    def fixture(self):
        nodes={'a':dict(x=10,y=10,w=40,h=20,stage=1,sourceId='source-a'),
               'b':dict(x=100,y=10,w=40,h=20,stage=1,sourceId='source-b'),
               'c':dict(x=100,y=80,w=40,h=20,stage=1,sourceId='source-c'),
               'p':dict(x=200,y=80,w=40,h=20,stage=2,sourceId='source-a-proxy')}
        edges=[dict(source='a',target='b',kind='fork',label='병행',points=[[50,20],[100,20]]),
               dict(source='a',target='c',kind='conditional',label='해당 시',points=[[50,20],[70,20],[70,90],[100,90]]),
               dict(source='c',target='a',kind='rework',label='반려',points=[[100,95],[5,95],[5,20],[10,20]])]
        level=dict(nodes=nodes,edges=edges)
        actual=dict(sourceLayout=True,transform=dict(sx=2,sy=2,ox=5,oy=7),
                    nodes=[dict(id=k,sourceId=v['sourceId'],x=v['x']*2+5,y=v['y']*2+7,w=v['w']*2,h=v['h']*2) for k,v in nodes.items()],
                    edges=[dict(source=e['source'],target=e['target'],sourceKind=e['kind'],label=e['label'],points=[[x*2+5,y*2+7] for x,y in e['points']]) for e in edges])
        return level,actual
    def test_parallel_conditional_loop_and_proxy_preserved(self):
        level,actual=self.fixture();self.assertEqual(qc.source_view_errors(level,actual,[1,2]),[])
    def test_stage_filter_keeps_only_visible_endpoints(self):
        level,actual=self.fixture();actual['nodes']=[n for n in actual['nodes'] if n['id']!='p']
        self.assertEqual(qc.source_view_errors(level,actual,[1]),[])
    def test_branch_dropped_is_not_a_passing_source_check(self):
        level,actual=self.fixture();actual['edges'].pop(1)
        self.assertTrue(any('edge set' in x for x in qc.source_view_errors(level,actual,[1,2])))
    def test_conditional_downgrade_detected(self):
        level,actual=self.fixture();actual['edges'][1]['sourceKind']='std'
        self.assertTrue(any('types' in x for x in qc.source_view_errors(level,actual,[1,2])))
    def test_arrow_label_edit_detected(self):
        level,actual=self.fixture();actual['edges'][1]['label']='순차'
        self.assertTrue(any('labels' in x for x in qc.source_view_errors(level,actual,[1,2])))
    def test_source_parallel_row_flattened_detected(self):
        level,actual=self.fixture();actual['nodes'][2]['y']=actual['nodes'][1]['y']
        self.assertTrue(any('position/size' in x for x in qc.source_view_errors(level,actual,[1,2])))
    def test_rerouted_arrow_detected_even_with_same_type(self):
        level,actual=self.fixture();actual['edges'][1]['points'][1][0]+=10
        self.assertTrue(any('route changed' in x for x in qc.source_view_errors(level,actual,[1,2])))
    def test_duplicate_edge_detected(self):
        level,actual=self.fixture();actual['edges'].append(copy.deepcopy(actual['edges'][0]))
        self.assertTrue(any('extra=' in x for x in qc.source_view_errors(level,actual,[1,2])))
    def test_non_affine_or_missing_source_layout_rejected(self):
        level,actual=self.fixture();actual['sourceLayout']=False;actual['transform']['sx']=-1
        self.assertGreaterEqual(len(qc.source_view_errors(level,actual,[1,2])),2)

    def test_visible_dash_change_is_detected(self):
        level,actual=self.fixture();level['edges'][1]['dash']='4 3';actual['edges'][1]['dash']='none'
        self.assertTrue(any('dash style' in x for x in qc.source_view_errors(level,actual,[1,2])))
    def test_visible_arrowhead_removal_is_detected(self):
        level,actual=self.fixture();level['edges'][1]['marker']='url(#arrow)';actual['edges'][1]['marker']=None
        self.assertTrue(any('arrowhead' in x for x in qc.source_view_errors(level,actual,[1,2])))
    def test_only_independently_captured_shared_route_is_inherited(self):
        level,actual=self.fixture()
        shared=[[50,20],[70,20]]
        for e in level['edges'][:2]:
            e['points']=shared+[[100,20]]
            e['segments']=[dict(hub='source-hub',points=shared)]
        for e in actual['edges'][:2]:e['points']=[[x*2+5,y*2+7] for x,y in shared+[[100,20]]]
        report=qc.inherited_hub_overlaps(level,actual)
        self.assertEqual(report['inherited_edge_overlap'],2)
        self.assertTrue(report['inherited_source_overlaps'][0]['source_span'])
        level['edges'][1]['points']=[[50,30],[70,30],[100,30]]
        self.assertEqual(qc.inherited_hub_overlaps(level,actual)['inherited_edge_overlap'],0)

    def test_visible_junction_presence_and_position_are_preserved(self):
        level,actual=self.fixture();level['edges'][0]['segments']=[dict(hub='junction-1',points=level['edges'][0]['points'])]
        level['junctions']=[dict(id='junction-1',x=70,y=20,r=4)]
        actual['junctions']=[dict(id='junction-1',x=145,y=47,r=4)]
        self.assertEqual(qc.source_view_errors(level,actual,[1,2]),[])
        actual['junctions'][0]['x']+=20
        self.assertTrue(any('junction dot position' in x for x in qc.source_view_errors(level,actual,[1,2])))
        actual['junctions']=[]
        self.assertTrue(any('junction dot set' in x for x in qc.source_view_errors(level,actual,[1,2])))

    def test_collinear_between_vertices_are_same_route(self):
        self.assertTrue(qc.same_route([[0,0],[5,0],[10,0],[10,10]],[[0,0],[10,0],[10,10]]))
        self.assertTrue(qc.same_route([[0,0],[0,0],[10,0]],[[0,0],[10,0]]))
    def test_reversal_or_bend_cannot_be_normalized_away(self):
        self.assertFalse(qc.same_route([[0,0],[15,0],[10,0]],[[0,0],[10,0]]))
        self.assertFalse(qc.same_route([[0,0],[5,4],[10,0]],[[0,0],[10,0]]))

    def test_source_visible_label_text_and_anchor_preserved(self):
        level,actual=self.fixture();level['labels']=[dict(source='a',target='b',text='병행',x=70,y=20)]
        actual['labels']=[dict(index='0',text='병행',x=145,y=47)]
        self.assertEqual(qc.source_view_errors(level,actual,[1,2]),[])
        actual['labels'][0]['x']+=10
        self.assertTrue(any('anchor changed' in x for x in qc.source_view_errors(level,actual,[1,2])))
        actual['labels'][0]['text']='순차'
        self.assertTrue(any('visible text changed' in x for x in qc.source_view_errors(level,actual,[1,2])))
    def test_invented_visible_label_is_rejected(self):
        level,actual=self.fixture();actual['labels']=[dict(index=None,text='원본에는 없던 라벨',x=50,y=50)]
        self.assertTrue(any('label set differs' in x for x in qc.source_view_errors(level,actual,[1,2])))

class SourceContractTests(unittest.TestCase):
    def fixture(self):
        node=dict(id='raw-a',task='원본 업무',label='원본 업무')
        raw=dict(nodes=[node],boxes={'raw-a':dict(x=1,y=2,w=50,h=25)},routes=[],edges=[])
        level=dict(nodes={'a':dict(sourceId='raw-a',x=1,y=2,w=50,h=25)},edges=[])
        return dict(sourceAsis=dict(sha256='source',geometry_sha256='geometry',geometry=dict(levels={lv:copy.deepcopy(raw) for lv in ('4','5','6')})),
                    sourceLayout=dict(schema='source-layout/v1',source_sha256='source',geometry_sha256='geometry',levels={lv:copy.deepcopy(level) for lv in ('4','5','6')}),
                    views={lv:{'asis':dict(nodes=[dict(id='a',lb='원본 업무')],edges=[])} for lv in ('4','5','6')})
    def test_projection_matches_independent_capture(self):self.assertEqual(qc.source_contract_errors(self.fixture()),[])
    def test_mutating_layout_and_view_together_does_not_hide_source_change(self):
        data=self.fixture();data['sourceLayout']['levels']['6']['nodes']['a']['x']=99
        self.assertTrue(any('geometry' in x for x in qc.source_contract_errors(data)))
    def test_extra_edge_is_rejected_against_independent_source_capture(self):
        data=self.fixture();data['views']['6']['asis']['edges']=[['a','a','r','추가된 환류']]
        self.assertTrue(any('edge graph' in x for x in qc.source_contract_errors(data)))
    def test_changed_source_label_rejected(self):
        data=self.fixture();data['views']['6']['asis']['nodes'][0]['lb']='대체 업무'
        self.assertTrue(any('label changed' in x for x in qc.source_contract_errors(data)))

class SharedUITests(unittest.TestCase):
    def fixture(self):
        state={'controls':{name:{'visible':True,'disabled':False,'style':['Arial','13px']} for name in qc.COMMON_CONTROLS},
               'board':True,'frame':False,'bodySource':False,'typography':['Arial','13px'],'boardStyle':['Arial']}
        return {'asis':copy.deepcopy(state),'ns':copy.deepcopy(state)}
    def test_same_shared_renderer_passes(self):self.assertEqual(qc.shared_ui_errors(self.fixture()),[])
    def test_original_html_iframe_is_explicitly_rejected(self):
        states=self.fixture();states['asis']['frame']=True
        self.assertTrue(any('iframe' in x for x in qc.shared_ui_errors(states)))
    def test_hidden_common_controls_are_rejected(self):
        states=self.fixture();states['asis']['controls']['lvSeg']['visible']=False
        self.assertTrue(any('#lvSeg' in x for x in qc.shared_ui_errors(states)))
    def test_different_typography_is_rejected(self):
        states=self.fixture();states['asis']['typography']=['serif','16px']
        self.assertTrue(any('typography' in x for x in qc.shared_ui_errors(states)))
    def test_source_checks_without_visible_screens_are_incomplete(self):
        report={'part':'asis','screens':[],'source_checks':[{'renderer':'original'}],'summary':{}}
        self.assertIn('No process-map screen was checked',qc.failures(report))

if __name__=='__main__':unittest.main()
