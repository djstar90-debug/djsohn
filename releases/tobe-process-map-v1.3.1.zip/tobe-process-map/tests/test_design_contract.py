import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import design_contract as C
import restructure as R
from autofill import skeleton


def fixture():
    ids = ['1-1-1-1-1-1','1-1-1-1-1-2','1-1-1-1-1-3','1-1-1-1-1-4']
    names = ['자료 수집','자료 대조','최종 승인','승인 결과 기록']
    A6 = {}
    for i,k in enumerate(ids):
        A6[k] = dict(n=names[i],l5='1-1-1-1-1 조사',l4='기획',team='CRM팀',bon='CRM팀',ai='',sys='',inp='원본 자료',fmt='표',out='자료',pain='취합 후 다시 대조하여 자료 전달이 반복됨',pre=ids[i-1] if i else '',post=ids[i+1] if i<3 else '',ty='업무',wt='',note='',br='',rejr='',rej='',row=i+5,hl=[])
    A5 = {'1-1-1-1-1':dict(n='조사',l4='기획',l4id='1-1-1-1',team='CRM팀',ty='업무',br='',rejr='',rej='',pre='',post='',kids=ids,pain=[],note=[],r=[5,6,7,8])}
    A4 = {'1-1-1-1':dict(n='기획',kids=list(A5),lv1='CRM',team='CRM팀',pre='',post='',ty='업무',br='',rej='',rejr='',r=[5,6,7,8])}
    a = dict(meta={},A6=A6,A5=A5,A4=A4)
    d = skeleton(a)
    d['meta']['text']['title']='계약 검증 예제'
    d['tb5']={'T5-1':dict(n='통합 분석과 승인',st=1,l4='1-1-1-1',**{'from':list(A5)},desc='자료 수집과 대조를 하나의 Agent 작업으로 통합')}
    d['bands']=[dict(id='B0',name='Orchestrator',desc='분석과 기록을 연결',subs=['S1','S2'])]
    d['subs']={s:dict(name=n,band='B0',desc=n,d=[],s=[]) for s,n in [('S1','분석 Agent'),('S2','기록 Agent')]}
    d['story']={'B0':dict(p='자료 전달 반복 감소',intro='통합 수집과 대조',hum='CRM팀이 분석 결과를 최종 승인한다.',imp=[['자료 전달 감소','수집과 대조를 하나의 Agent 업무로 통합한다.']],subs={
        'S1':{'f':[['자료 수집·대조',['T1']]],'pn':[['취합 후 반복 전달',ids[:2]]],'e':'자료 인계 없이 통합 분석 결과를 제공한다.'},
        'S2':{'f':[['승인 이력 기록',['T3']]],'pn':[['승인 결과 별도 기록',[ids[3]]]],'e':'확정된 결과를 일관되게 보관한다.'}})}
    d['desc']={'T6':{'T1':'분석 Agent가 자료를 수집하고 대조한다.','T2':'CRM팀이 분석 결과를 최종 승인한다.','T3':'기록 Agent가 승인 결과를 기록한다.'}}
    d['tb']={
      'T1':dict(t='A',lb='통합 수집 및 대조',l5='T5-1',ref=ids[:2],sub='S1',role='A-취합',role_why='수집과 대조를 단일 자료 처리로 통합',mode='파일 기반 시범',io={'inp':'원본 자료','out':'분석 결과','to':'T2'},human_review={'required':True,'reason':'분석 결과의 최종 채택은 담당 조직 판단','decision_node':'T2','continue_to':['T3'],'rework_to':['T1']}),
      'T2':dict(t='N',lb='분석 결과 최종 승인',l5='T5-1',ref=[ids[2]],lane='l0',role='H-최종',role_why='최종 채택 판단',mode='사람 판단',io={'inp':'분석 결과','out':'승인 결과'}),
      'T3':dict(t='A',lb='승인 결과 기록',l5='T5-1',ref=[ids[3]],sub='S2',role='A-관리',role_why='이미 결정된 결과 기록',mode='파일 기반 시범',io={'inp':'승인 결과','out':'승인 이력','to':'이력 보관함'},human_review={'required':False,'reason':'승인된 결과를 그대로 기록하는 결정 없는 작업'})}
    d['tobe_flow']=[['T1','T2','s',''],['T2','T3','b','승인'],['T2','T1','r','수정 필요']]
    d['design_contract']={'version':1,'redesign':[{'scope':'1-1-1-1','kind':'merge','source_ids':ids[:2],'tobe_ids':['T1'],'reason':'원본 자료의 반복 전달','evidence':'두 원본 작업을 T1 단일 자료 처리로 통합','constraint':''}]}
    d['inputs']={'received':[], 'answer':'합성 회귀검증 자료만 사용', 'requests':[]}
    d['desc']['A4']={'1':'자료를 순서대로 수집·대조하고 승인하여 기록한다.'}
    d['desc']['T4']={'1':'수집과 대조를 통합하고 별도 사람이 승인한 결과만 기록한다.'}
    d['desc']['A6']={k:row['n']+'을 수행한다.' for k,row in A6.items()}
    d['desc']['A5']={'1-1-1-1-1':'자료 수집과 대조·승인·기록을 순서대로 수행한다.'}
    d['tour']={'1':{'now':'자료 수집과 대조를 순서대로 진행한다.','chg':'Agent가 수집과 대조를 통합하고 CRM팀이 별도 승인한다.','next':'승인 결과를 기록한다.','beats':[{'t':'분석과 결정','steps':[
        {'ids':['T1'],'v':'통합 수집 및 대조','d':'분석 Agent가 원본 자료를 취합해 분석 결과를 작성한다.','a':''},
        {'ids':['T2'],'v':'분석 결과 최종 승인','d':'CRM팀이 분석 결과를 최종 승인하거나 수정 요청한다.','a':'CRM팀'},
        {'ids':['T3'],'v':'승인 결과 기록','d':'기록 Agent가 승인된 결과를 이력에 기록한다.','a':''}]}]}}
    for task in d['tb'].values(): task['src_n']=task['lb']
    d['qa_dispositions']={
        '[역할] T3 「승인 결과 기록」 — role A-관리이지만 업무명이 H-최종 성격으로 보임. 업무 내용을 다시 판단하고, 사람 일이 섞여 있으면 Lv.6 박스를 나눈다':'T3는 T2에서 이미 결정한 결과만 기록한다. 실제 사람 판단은 별도 N 노드 T2와 승인/반려 연결로 검증한다.',
        '[설계패턴] P1 1단계에 사람 투입·기준 확정 N(신규)이 없음 — 요청을 Agent에 맡기는 지점, 기준을 확정하는 지점':'합성 단일 단계 예제에서 이미 정의된 자료를 처리한다. T2가 실제 판단 지점이며 추가 착수 결재를 만들 이유가 없다.',
        '[설계패턴] P1 1단계에 공통 기준 데이터 노드가 없음 — 뒤 단계가 대조할 조건 묶음 (예: 제작 조건/범위 정리)':'단일 자료 처리 단계의 회귀검증 예제이며 복수 단계 공통 기준 업무를 가정하지 않는다.',
        '[설계패턴] P5 진행 현황(S0b) 0개 — 상태가 바뀌는 단계마다 1개 안팎':'세 업무뿐인 합성 검증 예제로 별도 현황 Agent를 도입하지 않는다.',
        '[데이터] 준비중(P) 항목 0개 — 사내 준비 현황 자료를 받았는지 확인 (없으면 기존/신규만으로 보고에 남김)':'합성 로컬 자료를 사용하는 회귀 예제이므로 준비 중인 외부 연동 데이터가 없다.',
        '[설계메모] memo 없음 — thinking-process.md ①~⑤(가치·진단·가설·단계별 변화·구조 판단)를 먼저 쓰고 판정은 그 결과로':'이 예제의 병목·설계 이유·변화는 design_contract.redesign에 원본 ID와 통합 ID로 명시되어 있다.'}
    return a,d

class ContractTests(unittest.TestCase):
    def test_good_merge_and_visible_gate(self):
        a,d=fixture(); self.assertEqual(C.validate(a,d),[]); self.assertFalse([x for x in R.check(a,d) if x[0]=='오류'])
    def test_build_good(self):
        a,d=fixture(); p=R.build(a,d)
        self.assertTrue(p['qualityGate']['passed'])
        self.assertEqual(p['views']['6']['ns']['edges'],d['tobe_flow'])
        self.assertEqual(next(n for n in p['views']['6']['ns']['nodes'] if n['id']=='T2')['ln'],'l0')
    def test_summary_uses_original_source_counts(self):
        a,d=fixture(); p=R.build(a,d)
        six=next(x for x in p['summary'] if x['lv']==6)
        self.assertEqual((six['asis_count'],six['tobe_count']),(4,3))
        self.assertIn('As-Is 4개 → To-be 3개',six['text'])
        self.assertEqual(sum(row[1] for row in six['parts']),3)
        self.assertEqual(six['parts'][1],['사람 확인·판단',1,'N'])
    def test_summary_lv5_uses_original_groups(self):
        a,d=fixture(); a['A5']['extra']={'n':'별도 원본 묶음'}
        five=R.redesign_summary(a,d)[0]
        self.assertEqual((five['asis_count'],five['tobe_count']),(2,1))
        self.assertEqual(sum(row[1] for row in five['parts']),1)
    def test_reject_owner_only_clone(self):
        a,d=fixture(); d['tb']={}
        for i,(k,v) in enumerate(a['A6'].items()):
            d['tb'][f'N{i}']=dict(t='A',lb='Agent '+v['n'],ref=[k],l5='T5-1',sub='S1',human_review={'required':False,'reason':'단순 변경'})
        d['tobe_flow']=[[f'N{i}',f'N{i+1}','s',''] for i in range(3)]
        d['design_contract']['redesign'][0].update(tobe_ids=['N0','N1'])
        self.assertTrue(any('1:1' in x[2] for x in C.validate(a,d)))
    def test_claim_without_actual_merge_fails(self):
        a,d=fixture(); d['tb']['T1']['ref']=d['tb']['T1']['ref'][:1]
        self.assertTrue(any('주장과 실제' in x[2] for x in C.validate(a,d)))
    def test_missing_review_declaration(self):
        a,d=fixture(); del d['tb']['T1']['human_review']
        self.assertTrue(any('human_review.required' in x[2] for x in C.validate(a,d)))
    def test_merged_human_action_fails(self):
        a,d=fixture(); d['tb']['T1']['lb']='자료 수집 및 담당자 확인'
        self.assertTrue(any('Agent 박스에' in x[2] for x in C.validate(a,d)))
    def test_approval_preparation_is_not_a_human_action(self):
        a,d=fixture(); d['tb']['T1']['lb']='최종 승인 요청서 초안 작성'
        self.assertFalse(any('Agent 박스에' in x[2] for x in C.validate(a,d)))
    def test_missing_handoff_and_rework(self):
        a,d=fixture(); d['tobe_flow']=d['tobe_flow'][1:2]
        issues=C.validate(a,d)
        self.assertTrue(any('넘기는 연결' in x[2] for x in issues)); self.assertTrue(any('재작업 연결' in x[2] for x in issues))
    def test_no_approval_bypass(self):
        a,d=fixture(); d['tobe_flow'].append(['T1','T3','s',''])
        self.assertTrue(any('우회' in x[2] for x in C.validate(a,d)))
    def test_orchestrator_cannot_bypass_human_gate(self):
        a,d=fixture(); d['tb']['M1']={'t':'M','sub':'S1'}
        d['new_edges']=[['T1','M1','o','호출'],['M1','T3','o','착수']]
        self.assertTrue(any('우회' in x[2] for x in C.validate(a,d)))
    def test_wrong_human_lane(self):
        a,d=fixture(); d['tb']['T2']['lane']='S1'
        self.assertTrue(any('[사람분리]'==x[1] for x in C.validate(a,d)))
    def test_build_blocks_without_contract(self):
        a,d=fixture(); del d['design_contract']
        with self.assertRaisesRegex(ValueError,'Release blocked'): R.build(a,d)
    def test_no_implicit_sequential_edges(self):
        a,d=fixture(); del d['tobe_flow']
        with self.assertRaises(ValueError): R.flow(d)
        self.assertTrue(any('tobe_flow' in x[2] for x in C.validate(a,d)))
    def test_retain_everything_not_redesign(self):
        a,d=fixture(); d['design_contract']['redesign'][0].update(kind='retain',constraint='계약상 순서')
        self.assertTrue(any('구조 변화 0건' in x[2] for x in C.validate(a,d)))
    def test_original_human_decision_cannot_disappear(self):
        a,d=fixture(); src=list(a['A6'])[0]; a['A6'][src]['n']='배포 대상 지역별 지사 확정'
        d['tb']['T1']['human_review']={'required':False,'reason':'목록 자동 작성'}
        self.assertTrue(any('원본 최종 확인' in x[2] for x in C.validate(a,d)))
    def test_duplicate_ref_not_fake_merge(self):
        a,d=fixture(); d['tb']['T4']=copy.deepcopy(d['tb']['T1']); d['tb']['T4']['ref']=d['tb']['T1']['ref'][:1]
        self.assertTrue(any('주장과 실제' in x[2] for x in C.validate(a,d)))
    def test_release_build_pair(self):
        import release
        a,d=fixture()
        with tempfile.TemporaryDirectory() as tmp:
            result=release.build(a,d,Path(tmp)/'release')
            self.assertEqual(result['counts'],{'asis_lv6':4,'tobe_lv6':3})
            self.assertTrue((Path(tmp)/'release'/'map.html').exists())
            self.assertTrue((Path(tmp)/'release'/'map.xlsx').exists())
    def test_missing_agent_story_blocked_before_browser(self):
        a,d=fixture(); del d['story']['B0']['imp']
        self.assertTrue(any(x[1]=='[Agent 상세]' for x in R.check(a,d)))
    def test_cli_returns_failure(self):
        a,d=fixture(); del d['design_contract']
        with tempfile.TemporaryDirectory() as tmp:
            ap,dp=Path(tmp)/'a.json',Path(tmp)/'d.json'; ap.write_text(json.dumps(a)); dp.write_text(json.dumps(d))
            r=subprocess.run([sys.executable,str(Path(R.__file__)),'check',str(ap),str(dp)],capture_output=True)
            self.assertEqual(r.returncode,2)

if __name__=='__main__': unittest.main()
