import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile

from openpyxl import Workbook
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import parse_excel as parser
import verify_input

HEADERS = ['Lv.1','Lv.2','Lv.3','Lv.4','Lv.5','Lv.6','노드 ID','담당팀','선행','후행','_L5_ID']

class InputTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name)
    def tearDown(self): self.tmp.cleanup()
    def workbook(self, rows):
        wb=Workbook(); ws=wb.active;ws.title='Process Map';ws.append(HEADERS)
        for row in rows: ws.append(row)
        p=self.root/'input.xlsx';wb.save(p);return p
    def row(self, ident='1-1-1-1-1-1', name='자료 수집', group='조사', parent=''):
        return ['기획','마케팅','기획 단계','목표 설정',group,name,ident,'기획팀','','',parent]
    def test_valid_numeric_input(self):
        out=parser.build_f2(self.workbook([self.row()]))
        self.assertEqual(list(out['A6']),['1-1-1-1-1-1']);self.assertEqual(verify_input.validate(out),[])
    def test_opaque_export_ids_with_explicit_parent(self):
        out=parser.build_f2(self.workbook([self.row('T6-01',parent='T5-01'),self.row('T6-02','자료 검토',parent='T5-01')]))
        self.assertEqual(list(out['A5']),['T5-01']);self.assertEqual(len(out['A6']),2)
    def test_duplicate_id_rejected(self):
        with self.assertRaisesRegex(parser.InputError,'중복'):
            parser.build_f2(self.workbook([self.row(),self.row(name='다른 업무')]))
    def test_named_row_missing_id_rejected(self):
        with self.assertRaisesRegex(parser.InputError,'ID 누락'):
            parser.build_f2(self.workbook([self.row('')]))
    def test_missing_id_exact_source_recovery(self):
        row=self.row('');p=self.workbook([row])
        node={'id':'original-task','label':row[5],'sourceRows':[2],'hierarchy':dict(zip(['l1','l2','l3','l4','l5'],row[:5])),'parent':'original-group'}
        html=self.root/'source.html';html.write_text('<script>const DATA='+json.dumps({'lv6':{'nodes':[node],'edges':[]},'lv5':{'nodes':[],'edges':[]},'lv4':{'nodes':[],'edges':[]}})+';</script>')
        out=parser.build_f2(p,source_html=html)
        self.assertIn('original-task',out['A6']);self.assertEqual(len(out['meta']['recovered_ids']),1)
        node['label']='업무 불일치';html.write_text('<script>const DATA='+json.dumps({'lv6':{'nodes':[node],'edges':[]},'lv5':{'nodes':[],'edges':[]},'lv4':{'nodes':[],'edges':[]}})+';</script>')
        with self.assertRaisesRegex(parser.InputError,'유일하게 일치'):
            parser.build_f2(p,source_html=html)
    def test_empty_input_rejected(self):
        with self.assertRaisesRegex(parser.InputError,'업무가 없음'): parser.build_f2(self.workbook([]))
    def test_formula_without_cache_rejected(self):
        row=self.row();row[5]='="자료 수집"'
        with self.assertRaisesRegex(parser.InputError,'계산값이 없는 수식'): parser.build_f2(self.workbook([row]))
    def test_formula_cached_value_used(self):
        row=self.row();row[5]='="자료 수집"';p=self.workbook([row])
        with zipfile.ZipFile(p) as z: files={n:z.read(n) for n in z.namelist()}
        xml=files['xl/worksheets/sheet1.xml'].decode()
        xml=xml.replace('<c r="F2"><f>', '<c r="F2" t="str"><f>').replace('</f><v></v>', '</f><v>자료 수집</v>')
        files['xl/worksheets/sheet1.xml']=xml.encode()
        with zipfile.ZipFile(p,'w') as z:
            for name,data in files.items():z.writestr(name,data)
        self.assertEqual(parser.build_f2(p)['A6']['1-1-1-1-1-1']['n'],'자료 수집')
    def test_merge_duplicate_any_level_rejected(self):
        one=parser.build_f2(self.workbook([self.row()]))
        for level in ('A4','A5','A6'):
            other=copy.deepcopy(one)
            for lv in ('A4','A5','A6'):
                if lv != level: other[lv]={k+'-copy':v for k,v in other[lv].items()}
            with self.assertRaisesRegex(parser.InputError,'ID 충돌'): parser.merge([one,other])
    def test_f1_duplicate_and_missing_id_rejected(self):
        wb=Workbook();ws=wb.active;ws.title='Process Map'
        ws.append(['Lv.1','Lv.2','Lv.3','Lv.4','Lv.5','Lv.6','Lv.4 노드 ID','Lv.5 노드 ID','Lv.6 노드 ID'])
        row=['기획','마케팅','계획','목표','조사','자료 수집','L4','L5','T1'];ws.append(row);ws.append(row)
        p=self.root/'f1.xlsx';wb.save(p)
        with self.assertRaisesRegex(parser.InputError,'중복'):parser.build(p)
        ws.cell(3,9).value=None;wb.save(p)
        with self.assertRaisesRegex(parser.InputError,'ID 누락'):parser.build(p)
    def test_stale_numeric_parent_names_rejected(self):
        row=self.row('1-1-1-1-1-2');row[2]='다른 단계'
        with self.assertRaisesRegex(parser.InputError,'이름 충돌'):
            parser.build_f2(self.workbook([self.row(),row]))
    def test_unknown_format_and_stage_rejected(self):
        wb=Workbook();ws=wb.active;ws.append(['unrelated']);
        with self.assertRaises(parser.InputError):parser.detect(ws)
        with self.assertRaises(parser.InputError):parser.build_f2(self.workbook([self.row()]),6)
    def test_dangling_reference_reported_not_deleted(self):
        row=self.row();row[9]='missing'
        out=parser.build_f2(self.workbook([row]));issues=verify_input.validate(out)
        self.assertEqual(out['A6'][row[6]]['post'],'missing')
        self.assertTrue(any(i['code']=='SOURCE_REFERENCE_CONFLICT' for i in issues))
        self.assertTrue(verify_input.require_resolved(out))

if __name__=='__main__':unittest.main()
