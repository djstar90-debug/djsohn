import base64, copy, importlib.util, json, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import source_asis as source
from build_html import build

class SourceFidelity(unittest.TestCase):
    def setUp(self):
        self.a = {'A4':{}, 'A5':{}, 'A6':{'a':{'n':'research','row':5},'b':{'n':'decision','row':6}}}
        nodes = [{'id':'a','task':'research','sourceRows':[5],'stage':0,'manualLane':'human','x':72},
                 {'id':'b','task':'decision','sourceRows':[6],'stage':0,'manualLane':'human','x':250}]
        self.data = {lv:{'nodes':copy.deepcopy(nodes),'edges':[['a','b','conditional','if approved'], ['b','a','rework','revise']]}
                     for lv in ('lv4','lv5','lv6')}
        self.temp = tempfile.TemporaryDirectory(); self.path = Path(self.temp.name)/'source.html'
        self.raw = ('<!DOCTYPE html>\n<script>const DATA='+json.dumps(self.data)+';</script>\n').encode()
        self.path.write_bytes(self.raw)
    def tearDown(self): self.temp.cleanup()
    def test_original_bytes_and_all_level_metadata(self):
        p=source.capture(self.path,self.a)
        self.assertEqual(base64.b64decode(p['bytes_base64']),self.raw)
        self.assertEqual(p['snapshot'],self.data)
        self.assertEqual(source.validate(p,self.a),p)
    def test_conditional_loop_and_label_not_downgraded(self):
        p=source.capture(self.path,self.a)
        self.assertEqual(source.mapped_edges(p),[['a','b','b','if approved'],['b','a','r','revise']])
    def test_parallel_and_join_snapshot_not_coerced(self):
        d=copy.deepcopy(self.data); d['lv6']['edges']=[['a','b','fork','parallel'],['b','a','join','merge']]
        self.path.write_text('<script>const DATA='+json.dumps(d)+';</script>')
        p=source.capture(self.path,self.a)
        self.assertEqual(p['snapshot']['lv6']['edges'],d['lv6']['edges'])
    def test_saved_edits_override_only_saved_levels(self):
        edited=copy.deepcopy(self.data['lv6']); edited['nodes'][0]['x']=400
        s=self.raw.decode()+"<script id='s04SavedEdits' type='application/json'>"+json.dumps({'lv6':edited})+'</script>'
        got=source.snapshot(s)
        self.assertEqual(got['lv6'],edited);self.assertEqual(got['lv5'],self.data['lv5'])
    def test_empty_edge_list_is_preserved(self):
        self.data['lv6']['edges']=[]
        self.path.write_text('<script>const DATA='+json.dumps(self.data)+';</script>')
        self.assertEqual(source.mapped_edges(source.capture(self.path,self.a)),[])
    def test_payload_tampering_rejected(self):
        p=source.capture(self.path,self.a);p['snapshot']['lv6']['edges'][0][2]='std'
        with self.assertRaises(ValueError):source.validate(p,self.a)
    def test_byte_tampering_rejected(self):
        p=source.capture(self.path,self.a);p['bytes_base64']=base64.b64encode(self.raw+b' ').decode()
        with self.assertRaises(ValueError):source.validate(p,self.a)
    def test_stale_excel_rejected(self):
        p=source.capture(self.path,self.a);self.a['A6']['b']['n']='different'
        with self.assertRaises(ValueError):source.validate(p,self.a)
    def test_scope_differences_are_explicit(self):
        self.a['A6']['c']={'n':'extra','row':7}
        p=source.capture(self.path,self.a)
        self.assertEqual(p['scope_difference']['excel_unmapped'],['c'])
    def test_builder_fail_closed(self):
        with self.assertRaises(ValueError):build('','',{},None)
    def test_builder_escapes_case_insensitive_script_termination(self):
        shell='<title>/*__TITLE__*/</title><script>window.__PMD__=/*__PMD__*/</script><script>/*__ENGINE__*/</script></body>'
        p={'text':{'title':'title'},'qualityGate':{'passed':True},'label':'</SCRIPT><script>alert(1)</script>'}
        got=build(shell,'void 0;',p)
        self.assertNotIn('</SCRIPT>',got)
        self.assertIn('\\u003c/SCRIPT\\u003e',got)
    def test_no_silent_unsupported_html_fallback(self):
        with self.assertRaises(ValueError):source.snapshot('<html>not a process map</html>')

if __name__=='__main__':unittest.main()
