"""Regression: source geometry and graph enter the shared renderer unchanged."""
import copy,json,sys,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import source_asis as source
import restructure
from build_html import build

class SharedSourceProjection(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixtures=ROOT/'tests'/'fixtures'
        cls.asis=json.loads((fixtures/'valid-asis.json').read_text())
        geometry=json.loads((fixtures/'source-reference-geometry.json').read_text())
        with patch.object(source,'capture_geometry',return_value=geometry):
            cls.asis=source.attach(cls.asis,fixtures/'source-reference.html')
        cls.pmd=restructure.build(cls.asis,json.loads((fixtures/'valid-design.json').read_text()))
    def setUp(self):self.p=copy.deepcopy(self.pmd)
    def test_normalized_reference_passes_independent_validation(self):
        self.assertEqual(source.validate_projection(self.p),self.p['sourceLayout'])
    def test_every_source_edge_kind_and_label_preserved(self):
        raw=self.asis['source_html']['snapshot']['lv6']['edges']
        routes=self.p['sourceLayout']['levels']['6']['edges']
        self.assertEqual([(e['kind'],e['label']) for e in routes],[(e[2],e[3]) for e in raw])
        self.assertEqual([e[2] for e in self.p['views']['6']['asis']['edges']],['p','p','s','b','r'])
    def test_parallel_nodes_keep_identical_source_x(self):
        g=self.p['sourceLayout']['levels']['6']['nodes'];ids=list(g)
        self.assertEqual(g[ids[1]]['x'],g[ids[2]]['x'])
        self.assertLess(g[ids[1]]['y'],g[ids[2]]['y'])
    def test_empty_upper_level_edges_remain_empty(self):
        for lv in ('4','5'):self.assertEqual(self.p['views'][lv]['asis']['edges'],[])
    def test_only_actual_visible_source_labels_are_displayed(self):
        g=self.p['sourceLayout']['levels']['6']
        self.assertEqual([x['text'] for x in g['labels']],['승인 시'])
        self.assertEqual([e['displayLabel'] for e in g['edges']],[False,False,False,True,False])
        self.assertTrue(all(e['label'] for e in g['edges']))
    def test_visible_source_label_tampering_is_rejected(self):
        self.p['sourceLayout']['levels']['6']['labels'][0]['text']='fabricated'
        with self.assertRaisesRegex(ValueError,'layout'):source.validate_projection(self.p)
    def test_source_conditional_and_return_dash_patterns_preserved(self):
        routes=self.p['sourceLayout']['levels']['6']['edges']
        self.assertEqual(routes[3]['dash'],'4 3');self.assertEqual(routes[4]['dash'],'6 4')
    def test_added_edge_is_rejected(self):
        e=self.p['views']['6']['asis']['edges'];e.append(list(e[0]))
        with self.assertRaisesRegex(ValueError,'nodes/edges'):source.validate_projection(self.p)
    def test_retyped_edge_is_rejected(self):
        self.p['views']['6']['asis']['edges'][0][2]='s'
        with self.assertRaisesRegex(ValueError,'nodes/edges'):source.validate_projection(self.p)
    def test_changed_label_is_rejected(self):
        self.p['views']['6']['asis']['nodes'][0]['lb']='fake'
        with self.assertRaisesRegex(ValueError,'nodes/edges'):source.validate_projection(self.p)
    def test_changed_node_position_is_rejected(self):
        next(iter(self.p['sourceLayout']['levels']['6']['nodes'].values()))['x']+=5
        with self.assertRaisesRegex(ValueError,'layout'):source.validate_projection(self.p)
    def test_changed_route_points_are_rejected(self):
        self.p['sourceLayout']['levels']['6']['edges'][0]['points'][0][0]+=5
        with self.assertRaisesRegex(ValueError,'layout'):source.validate_projection(self.p)
    def test_changed_visual_type_is_rejected(self):
        self.p['sourceLayout']['levels']['6']['edges'][0]['visualKind']='rework'
        with self.assertRaisesRegex(ValueError,'layout'):source.validate_projection(self.p)
    def test_browser_json_number_roundtrip_keeps_source_integrity(self):
        self.p=source.canonical_numbers(self.p)
        self.assertEqual(source.validate_projection(self.p),self.p['sourceLayout'])
    def test_semantic_duplicate_edge_multiplicity_cannot_be_dropped(self):
        data=copy.deepcopy(self.asis['source_html']['snapshot'])
        data['lv6']['edges'].append(list(data['lv6']['edges'][0]))
        with self.assertRaisesRegex(ValueError,'multiplicity'):
            source.validate_geometry(self.asis['source_html']['geometry'],data)
    def test_geometry_receipt_tampering_is_rejected(self):
        self.p['sourceAsis']['geometry']['levels']['6']['boxes'][next(iter(self.p['sourceAsis']['geometry']['levels']['6']['boxes']))]['x']+=3
        with self.assertRaisesRegex(ValueError,'geometry hash'):source.validate_projection(self.p)
    def test_legacy_capture_cannot_silently_render(self):
        a=copy.deepcopy(self.asis);a['source_html']['schema']='source-asis/v1'
        with self.assertRaisesRegex(ValueError,'legacy'):source.apply_to_pmd(self.p,a)
    def test_old_iframe_engine_is_rejected(self):
        shell=(ROOT/'assets'/'shell.html').read_text()
        with self.assertRaisesRegex(ValueError,'iframe'):build(shell,'function sourceAsisFrame(){} // sourceLayout',self.p)
    def test_shared_output_contains_no_source_ui(self):
        output=build((ROOT/'assets'/'shell.html').read_text(),(ROOT/'assets'/'engine.js').read_text(),self.p)
        self.assertNotIn('sourceAsisFrame',output)
        self.assertNotIn('<h1>원본 입력 전용 화면',output)
        self.assertIn('sourceLayout',output)
    def test_polyline_import_does_not_invent_bends(self):
        self.assertEqual(source.path_points('M0 1 H5 V9 L10 9'),[[0.,1.],[5.,1.],[5.,9.],[10.,9.]])
    def test_unsupported_curves_fail_instead_of_rerouting(self):
        with self.assertRaisesRegex(ValueError,'Unsupported'):source.path_points('M0 0 Q5 5 10 10')

if __name__=='__main__':unittest.main()
