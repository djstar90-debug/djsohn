"""Real SVG regression: parallel lines must not disappear in row deduplication."""
import asyncio
import shutil
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from qc_browser import JS_MEASURE
from playwright.async_api import async_playwright

@unittest.skipUnless(shutil.which('chromium'), 'System Chromium unavailable; run after Playwright setup')
class ParallelDetectionTest(unittest.TestCase):
    def test_parallel_interval_and_separated_line(self):
        async def check():
            async with async_playwright() as p:
                browser=await p.chromium.launch(executable_path=shutil.which('chromium'))
                page=await browser.new_page()
                for y,expected in ((14,1),(16.2,0),(10.8,0),(50,0)):
                    await page.set_content(f'<svg id="edges" width="300" height="100"><path data-a="a" data-b="b" d="M0,10 L100,10"/><path data-a="c" data-b="d" d="M0,{y} L100,{y}"/></svg>')
                    result=await page.evaluate(JS_MEASURE,{})
                    self.assertEqual(len(result['parallel']),expected)
                await browser.close()
        asyncio.run(check())

if __name__=='__main__': unittest.main()
