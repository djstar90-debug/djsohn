"""Source geometry/type review sheets must survive export and reject tampering."""
import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
from openpyxl import load_workbook
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import export_excel
import restructure
import source_asis


class SourceExport(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        fixture = Path(__file__).parent / 'fixtures'
        a = json.loads((fixture / 'valid-asis.json').read_text())
        cls.a = source_asis.attach(a, fixture / 'source-reference.html')
        cls.d = json.loads((fixture / 'valid-design.json').read_text())
        cls.p = restructure.build(cls.a, cls.d)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'map.xlsx'

    def tearDown(self):
        self.tmp.cleanup()

    def test_source_type_and_route_roundtrip(self):
        export_excel.write(self.a, self.d, self.p, self.path)
        restored = export_excel.restore(self.path)
        self.assertEqual(restored['pmd']['sourceLayout'], self.p['sourceLayout'])
        self.assertEqual(restored['asis']['source_html'], self.a['source_html'])
        wb = load_workbook(self.path, read_only=True)
        try:
            kinds = {row[3] for row in wb['As-Is Source Edges'].iter_rows(min_row=2, values_only=True)}
            self.assertEqual(kinds, {'fork', 'join', 'conditional', 'rework'})
            self.assertEqual(wb['As-Is Source Routes'].max_row - 1, 5)
            self.assertEqual(wb['As-Is Source Layout'].max_row - 1, 6)
        finally:
            wb.close()

    def test_review_type_or_route_edit_is_rejected(self):
        for sheet, cell, value in [('As-Is Source Edges', 'D2', 'std'), ('As-Is Source Routes', 'I2', 'rerouted')]:
            with self.subTest(sheet=sheet):
                export_excel.write(self.a, self.d, self.p, self.path)
                wb = load_workbook(self.path)
                wb[sheet][cell] = value
                wb.save(self.path)
                wb.close()
                with self.assertRaisesRegex(ValueError, sheet):
                    export_excel.restore(self.path)


if __name__ == '__main__':
    unittest.main()
