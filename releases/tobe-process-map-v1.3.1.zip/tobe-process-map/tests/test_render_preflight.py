"""Renderer contract regressions: invalid arrays stop before JS execution."""
import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from test_design_contract import fixture
import render_preflight as P
import restructure as R
import check_design


class RenderPreflightTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.asis,cls.design=fixture()
        cls.pmd=R.build(copy.deepcopy(cls.asis),copy.deepcopy(cls.design))
    def test_valid_design_and_compiled_page(self):
        self.assertEqual(P.validate_design(self.design,self.asis),[])
        self.assertEqual(P.validate_pmd(self.pmd),[])
    def test_valid_optional_third_improvement_reference_list(self):
        d=copy.deepcopy(self.design);d['story']['B0']['imp'][0].append(['T1'])
        self.assertEqual(P.validate_design(d,self.asis),[])
        self.assertFalse([x for x in R.check(self.asis,d) if x[0]=='오류'])
    def test_top_level_bad_type_reports_without_traceback(self):
        self.assertTrue(P.validate_design([]))
        self.assertTrue(check_design.run(self.asis,[])[0])
        self.assertTrue(R.check(self.asis,[]))
    def test_optional_third_reference_is_checked(self):
        d=copy.deepcopy(self.design);d['story']['B0']['imp'][0].append(['missing-task'])
        errors=P.validate_design(d,self.asis)
        self.assertTrue(any(e['path']=='story.B0.imp[0][2][0]' and e['code']=='RENDER_REFERENCE' for e in errors))
    def test_empty_optional_output_format_allowed(self):
        p=copy.deepcopy(self.pmd);p['subs']['S1']['of']=[['분석 결과',['']]]
        self.assertEqual(P.validate_pmd(p),[])
    def test_optional_grouping_absent_is_valid(self):
        p=copy.deepcopy(self.pmd)
        for sub in p['subs'].values():
            for field in ('dg','sp','og','wh'):sub.pop(field,None)
        self.assertEqual(P.validate_pmd(p),[])
    def test_missing_required_arrays_are_actionable(self):
        cases=[(['story','B0','imp'],None),(['story','B0','subs','S1','f'],None),
               (['story','B0','subs','S1','pn'],{}),(['subs','S1','d'],None),
               (['subs','S1','s'],'CRM'),(['tour','1','beats'],None),
               (['tour','1','beats',0,'steps'],None),(['tour','1','beats',0,'steps',0,'ids'],None)]
        for path,value in cases:
            with self.subTest(path=path):
                d=copy.deepcopy(self.design);obj=d
                for key in path[:-1]:obj=obj[key]
                obj[path[-1]]=value
                errors=P.validate_design(d,self.asis)
                self.assertTrue(errors)
                self.assertTrue(all('path' in e and e['message'] for e in errors))
                # Both public validation routes return diagnostics rather than traceback.
                self.assertTrue(R.check(self.asis,d))
                self.assertTrue(check_design.run(self.asis,d)[0])
    def test_optional_but_present_nested_format_must_be_array(self):
        d=copy.deepcopy(self.design);d['subs']['S1']['d']=[['원본',1,'E','','','문서']]
        self.assertTrue(any(e['path']=='subs.S1.d[0][5]' for e in P.validate_design(d,self.asis)))
    def test_invalid_group_member_array(self):
        p=copy.deepcopy(self.pmd);p['subs']['S1']['dg']=[['자료','원본']]
        self.assertTrue(any(e['path']=='subs.S1.dg[0][1]' for e in P.validate_pmd(p)))
    def test_orphan_sub_agent_and_missing_task(self):
        p=copy.deepcopy(self.pmd);p['subs']['S1']['band']='B7';p['subs']['S1']['tasks']=['unknown']
        errors=P.validate_pmd(p)
        self.assertTrue(any(e['path']=='subs.S1.band' for e in errors))
        self.assertTrue(any(e['path']=='subs.S1.tasks[0]' for e in errors))
    def test_compiled_task_missing_agent_reference(self):
        p=copy.deepcopy(self.pmd);p['TB']['T1']['sub']='missing-agent'
        self.assertTrue(any(e['path']=='TB.T1.sub' for e in P.validate_pmd(p)))
    def test_bad_reference_types_never_raise_unhashable_exception(self):
        for path in [('subs','S1','band'),('TB','T1','sub'),('TB','T1','l5'),('stages',0,'id'),('views','6','ns','nodes',0,'ln')]:
            with self.subTest(path=path):
                p=copy.deepcopy(self.pmd);obj=p
                for key in path[:-1]:obj=obj[key]
                obj[path[-1]]=['wrong-type']
                self.assertTrue(P.validate_pmd(p))
    def test_tour_missing_step_task_blocks(self):
        d=copy.deepcopy(self.design);d['tour']['1']['beats'][0]['steps'][0]['ids']=['unknown']
        self.assertTrue(any(e['path']=='tour.1.beats[0].steps[0].ids[0]' for e in P.validate_design(d,self.asis)))
    def test_compiled_geometry_array_shape(self):
        p=copy.deepcopy(self.pmd);p['views']['6']['ns']['nodes']=None
        self.assertTrue(any(e['path']=='views.6.ns.nodes' for e in P.validate_pmd(p)))
    def test_summary_parts_and_layout_numeric_shape(self):
        p=copy.deepcopy(self.pmd);p['summary'][0]['parts']='invalid';p['layout']['6']['nodeW']=float('nan')
        paths={e['path'] for e in P.validate_pmd(p)}
        self.assertIn('summary[0].parts',paths);self.assertIn('layout.6.nodeW',paths)
    def test_validation_never_mutates_source(self):
        p=copy.deepcopy(self.pmd);p['story']['B0']['imp']=None;before=copy.deepcopy(p)
        self.assertTrue(P.validate_pmd(p));self.assertEqual(p,before)
    def test_private_validated_build_equivalent_to_public_build(self):
        a,d=fixture();expected=R.build(copy.deepcopy(a),copy.deepcopy(d))
        synth=R.synth(copy.deepcopy(a),copy.deepcopy(d));before=copy.deepcopy(synth)
        actual=R._build_validated(copy.deepcopy(a),copy.deepcopy(d),synthesized=synth)
        self.assertEqual(expected,actual);self.assertEqual(before,synth)
    def test_cli_invalid_returns_structured_errors_and_exit_two(self):
        d=copy.deepcopy(self.design);d['tour']['1']['beats']=None
        with tempfile.TemporaryDirectory() as tmp:
            file=Path(tmp)/'design.json';file.write_text(json.dumps(d))
            run=subprocess.run([sys.executable,P.__file__,'design',str(file)],capture_output=True,text=True)
            self.assertEqual(run.returncode,2)
            report=json.loads(run.stdout);self.assertFalse(report['passed']);self.assertTrue(report['errors'])

if __name__=='__main__':unittest.main()
