"""Browser evidence for synthetic failures, independent of unavailable user logs."""
import asyncio,json,os,shutil,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'));sys.path.insert(0,str(ROOT/'tests'))
import qc_browser as qc
from playwright.async_api import async_playwright

@unittest.skipUnless(shutil.which('chromium'),'System Chromium unavailable')
class DiagnosticBrowserTests(unittest.TestCase):
    def test_real_error_records_stack_context_and_screenshot(self):
        from test_design_contract import fixture
        import restructure,build_html
        asis,design=fixture();data=restructure.build(asis,design)
        html=build_html.build((ROOT/'assets/shell.html').read_text(),(ROOT/'assets/engine.js').read_text(),data,design)
        html=html.replace('</body>',"<script>setTimeout(()=>{throw new Error('synthetic regression error')},100)</script></body>")
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'sample.html';path.write_text(html)
            out=Path(folder)/'result.json'
            with patch.dict(os.environ,{'QC_ARTIFACTS_DIR':str(Path(folder)/'screenshots')}):
                code=qc.main([str(path),str(out),'quick'])
            self.assertEqual(code,2);report=json.loads(out.read_text())
            errors=[item for item in report['diagnostics'] if item['message']=='synthetic regression error']
            self.assertEqual(len(errors),1);item=errors[0]
            self.assertIn('map.html:',item['stack']);self.assertTrue(item['locations']);self.assertTrue(Path(item['screenshots'][0]).is_file())
            self.assertEqual(len(report['screens']),6)

    def test_clipping_diagnostic_identifies_agent_and_actual_selector(self):
        async def check(folder):
            async with async_playwright() as p:
                browser=await p.chromium.launch(executable_path=shutil.which('chromium'));page=await browser.new_page()
                await page.set_content('<section id="apage"><div style="width:12px;height:12px;overflow:hidden">long text clipped here</div></section>')
                messages=await page.evaluate(qc.JS_WIN,'#apage');self.assertTrue(messages);self.assertIn('div:nth-child(1)',messages[0])
                report={'errors':[]};qc.context(report,phase='agent',agent='B7',selector='#apage')
                await qc.capture_issue(page,report,'clip',messages,'#apage')
                item=report['diagnostics'][0];self.assertEqual(item['locations'][0]['agent'],'B7');self.assertTrue(Path(item['screenshots'][0]).is_file())
                await browser.close()
        with tempfile.TemporaryDirectory() as folder,patch.dict(os.environ,{'QC_ARTIFACTS_DIR':folder}):asyncio.run(check(folder))

if __name__=='__main__':unittest.main()
