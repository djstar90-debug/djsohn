# design.json 형식 (legacy 참고)

> v1.2.0: 이 문서의 행별 대체 예제는 마이그레이션 참고용이다. 신규 설계는 restructure.md + quality-contract.md를 따른다. Agent tg에 사람 확인을 넣은 예제는 현행 금지이며 독립된 사람 Lv.6 노드가 필요하다.

현재 검증 예시: `tests/fixtures/valid-design.json`. 과거 부문 대형 예제는 클라이언트 패키지에서 제외했다.
처음 작성할 때는 `autofill.py skeleton`으로 초안을 만들어 채운 뒤, `autofill.py fill`로 기계적인 항목을 자동으로 채운다.

```jsonc
{
  "meta": {"text": {"title": "…To-be Process map", "eyebrow": "S01 · AX PI · Account Management",
                    "ver": "As-Is 원본 · To-be 가설 · 팀 검토용", "crumb": "Lv.1 … › 단계 = Lv.3 6개 · 원본: 파일명 (Process Map 시트)",
                    "foot": "근거: … (출처·가정 명시)"},
           "start": {"scr": "asis", "lv": 5}},
  "lanes": [{"k": "l0", "name": "비즈니스 1, 3부문 > 비즈니스 본부", "bon": ["비즈니스 1, 3부문 > 비즈니스 본부"], "sub": "", "team": ["비즈니스 본부 > 비즈니스팀"],
             "short": "비즈니스 1, 3부문 > 비즈니스 본부", "who": "비즈니스 1, 3부문 > 비즈니스 본부"}],   // 레인은 담당본부 원문 하나당 하나 (bon이 있으면 행은 담당본부 기준으로 레인에 배치). name은 원문 그대로 쓰고 화면에서 '>' 기준으로 줄바꿈. who는 문장 속 주체로, 조직명 원문을 쓰고 직무명은 사용자가 요청했을 때만 사용
  "structure": {"parallel": [{"from": "ID", "to": ["ID", "ID"]}], "branch": [{"from": "ID", "to": {"조건": "ID"}}], "join": [{"to": "ID", "from": ["ID", "ID"]}], "rework": [], "confirmed": true},   // 사용자에게 확인받은 As-Is 구조 (structure.py save가 기록) — compile [구조] 경고의 기준
      // team에는 엑셀의 담당팀 문자열을 빠짐없이 넣는다. short는 Lv.4 '참여' 표시용, who는 흐름 따라가기·상세 창에 표시되는 주체 이름
  "tb": {
    "BR-001-02": {"t": "A", "sub": "S1a", "lb": "OT Brief 초안 작성", "tg": "AE 확인"},
    "BR-005-03": {"t": "N", "lb": "컨셉 후보 압축 (CD 판단)"},
    "BR-001-01": {"t": "H"},                                   // 원문 유지
    "BR-003-01": {"t": "X", "note": "흡수 → 리브리핑의 「브랜드·제품·경쟁 팩트 시트」 (AP·CD 중복 조사 통합)"},
    "1-1-1-3-3-1": {"t": "O", "tg": "AP 전략 To-be"},
    // 신규 노드는 ID를 TB-…로 쓴다 (autofill fill이 anchor·conn을 보고 st·l5·o·연결선을 채움)
    "TB-01": {"t": "A", "sub": "S1b", "lb": "제작 방식·난이도 판정 (…)", "tg": "① 판정", "ref": ["BR-007-02"],
              "anchor": "BR-002-04", "conn": {"splice": "BR-002-04"}},        // anchor 뒤에 끼워 넣음
    "TB-00": {"t": "N", "lane": "cd", "lb": "OT 브리프를 Agent에 투입·분석 요청 (CD)", "anchor": "BR-001-01", "conn": {"in": ["BR-001-01"], "out": ["TB-00A"]}},
    "TB-G1": {"t": "M", "sub": "S0a", "lb": "① 제작 조건 확정 → 조사·참고자료 Agent 호출", "anchor": "TB-03"},   // M은 anchor → M → anchor의 후행 순으로 연결 (신호선 자동 생성)
    "TB-S1": {"t": "M", "sub": "S0b", "lb": "진행 현황 생성 (조건·일정·담당)", "anchor": "TB-03"}
  },
  "new_edges": [],          // fill이 채움. 직접 쓸 때는 [from, to, 's'|'b'|'o', 라벨]
  "bands": [{"id": "B0", "name": "제작 Orchestrator", "desc": "…", "subs": ["S0a", "S0b"]}],   // 첫 번째 항목은 Orchestrator
  "subs": {"S1a": {"band": "B1", "name": "Brief 정리 Agent", "desc": "…",
                   "new_data": [["과거 유사 캠페인 브리프 이력", "DB·이력"]], "new_sys": ["메일·회의록 수집 연동"],
                   "have_data": [], "have_sys": []}},        // have_*는 Orchestrator처럼 As-Is 행을 대체하지 않는 세부 Agent에만 사용
  "story": {"B1": {"intro": "…하는 Agent", "p": "서술형 2문장", "pb": ["개조식 3~4개"],
                   "imp": [["앞당김", "서술형 1문장. As-Is에서는 …", ["BR-001-05", "TB-01"]]],
                   "hum": "사람이 남는 지점 — …(주체).",
                   "subs": {"S1a": {"e": "기대 변화 서술형 1문장"}}}},   // f·pn은 fill이 초안 작성
  "stage_gate": {"BR-L4-01": "착수 · ① 제작 조건 확정"},       // 단계 ID → 단계 머리말 3행
  "tour": {"1": {"now": "지금은 …", "chg": "Agent가 …", "next": "… 2단계로"}},   // beats는 fill이 생성
  "outs": {"S1a": [["정리된 브리프·쟁점·미확정 요건 목록", "문서 (PPT·PDF·Word)"]]},
  "when": {"과거 유사 캠페인 브리프 이력": "1단계 브리프를 구조화할 때"},     // 신규 데이터·시스템마다 작성
  "whenHave": {"메일·메신저": "담당자에게 다음 작업을 알릴 때"},             // Orchestrator의 have_* 항목
  "sysinfo": {"워크플로 엔진": "게이트 통과 이벤트, 다음 작업 호출"},         // 시스템별 주고받는 정보
  "paths": [],              // 경로 필터. 생략하면 업무명 대괄호 태그에서 자동 생성(최대 2개), []이면 사용 안 함, [{"v":"촬영","title":"…","legend":"…"}]
  "subl": [],               // 경로 안의 갈래(예: 영상/이미지). 생략하면 자동 생성
  "scenario": {"mode": "lines", "common": ["정산"], "source": "lv4"},   // 선택 항목: off(기본)/lines(병렬박스). source를 생략하면 Lv.4 태그가 있을 때 lv4, 없으면 lv5
  "summary_mode": "all",    // 신규 = Agent 업무 + 담당자 확인 (확정된 방식)
  "parallel_tags": true,    // 1:1로 이어진 연속 행이 대괄호 태그만 다르면 병렬로 묶음
  "pos_fix": {"5": {"BR-021": {"r": 1}}},   // 선택 항목: 위치를 수동으로 지정할 예외
  "ui": {"srcShort": "S04", "src": "Process Map", "orcName": "제작 단계 연계 Agent", "orcBasis": "제작 조건(산출물·일정·비용·회차)",
         "s0bSee": "AE·CD·PM이 같은 현황을 봅니다.", "file": "일반제작_As-Is_To-be_프로세스맵", "tagEg": "CD 확인",
         "sysHint": "…", "sublLegend": "", "lv4": "Lv.4", "lv4btn": "Lv.4", "otName": "타 부문", "adv": "광고주 접점"}
}
```

## ID 규칙
- 상위 기능 Agent는 `B0`~`Bn`, 세부 Agent는 `S0a`… (B0 = Orchestrator, S0a = 단계 연계·호출, S0b = 진행 현황 — 엔진이 이 ID로 구분함)
- 신규 노드: `TB-01`(A), `TB-00`(N), `TB-G1`(M·S0a), `TB-S1`(M·S0b)
- 단계 키: tour·stage_gate는 단계 번호 문자열 또는 단계 ID (parse 결과의 A4 순서)

## 추가 형식 (신규 노드·게이트·흐름 따라가기)
**데이터·시스템 항목 (subs.d / subs.s, bands.d / bands.s)** — 5개 항목
`[이름, 보유 여부(1/0), 상태, 근거 메모, 준비 중 괄호 문구]`
- 상태: `E` 기존(현재 사용 중) · `P` 준비 중(사내 다른 팀이 준비) · `N` 신규 구축 필요
- 근거 메모: 기존 항목이라도 변경 예정이나 제약이 있으면 적는다 (예: "Knox Drive로 전환 준비중", "기밀 데이터 사용 불가"). 신규 항목은 "To-be Agent가 만드는 데이터 — Agent 구축과 함께 생김" / "계약서 양식 변경 필요 (PM·법무)" / 구축이 필요한 이유를 적는다
- 준비 중 괄호 문구: 화면에서 이름 뒤에 붙는 짧은 문구로, "어느 팀이 무엇을 준비 중인지"를 쓴다 (예: "디지털X부문 AI사업전략팀이 DAM 자산 AI 검색 준비중"). 일정 같은 긴 설명은 근거 메모에 쓴다
- 설계 파일에 `subs.X.pend: [[이름, 근거 메모, 괄호 문구]]`로 준비 중 항목을, `ds_memo: {이름: 메모}`로 기존 항목 메모를 적으면 autofill이 5개 항목으로 채운다

**박스별 설명 (desc)** — 상세 창의 "이 박스는" 문장
`{"A4": {"1": "…단계입니다."}, "T4": {"1": "To-be에서는 …"}, "A5": {Lv.5 ID: …}, "A6": {As-Is Lv.6 ID: …}, "T6": {To-be에서 역할이 바뀐 박스 ID(A·N·신규): …}, "M6": {Orchestrator ID: …}}`
- 작성 범위: A4·T4는 모든 단계, A5·A6는 전체, T6은 A·N·신규 A/N 전체(사람·소멸 박스는 쓰지 않음 — 사람은 A6, 소멸은 note가 표시됨), M6는 모든 신호

**AX 과제 연결 (ax)** — 과제 원자료가 있을 때만 작성 (`references/ax-mapping.md`)
`{"src": "원자료 이름", "cat": {코드: 이름}, "tasks": [{"id", "top", "org", "lab", "name", "bg", "pain", "chg", "kpi", "slides", "lv": "D|P|N", "st": [단계], "ag": [세부 Agent], "how", "cat", "dup": [과제 id], "score"}], "cols": (선택) AX 표의 열 구성}`
- 없으면 AX 버튼이 표시되지 않는다
- `use_phrasebook`: false면 공통 문구 사전을 쓰지 않는다 (S04 예시처럼 사용자가 확정한 문구를 그대로 유지할 때)

## 기본 형식 (AE 기준)
- `ui.relBands`: 타 본부 Agent의 상위 기능 ID 목록 (예: ["B10","B11"]) — Agent 구조도에서 제외되고, 흐름 따라가기와 흐름 번호에서도 건너뛴다 (지도에는 그대로 표시). 이름은 "○○ Agent (AP본부)" 형식
- `ui.subBox`: 병렬박스 안에서 따로 묶을 갈래 이름 (예: 초청, 콜드콜, 단독 PT, 계약 연장)
- `ui.amxEn`: Agent 구조도의 단계 머리에 표시할 영문명 (예: Pitch, Produce, Execute …), `ui.axDom`: AX 창에 표시할 부문 이름
- 세부 Agent 투입 데이터 `d`: `[이름, 보유 여부, 상태 E/P/N, 근거 메모, 준비 주체, [형식…]]` (6개 항목)
- 세부 Agent `dg`: 투입 데이터 묶음 `[[묶음 이름, [항목 이름…]]]` — 상위는 "무엇이 필요한가", 형식은 각 항목의 6번째 값
- 세부 Agent `sp`: 활용 시스템 `[[용도, [시스템…]]]` — 용도 → 시스템 순
- 세부 Agent `of`: 산출물 `[[산출물, [형식…]]]`, `og`: 산출물 묶음 `[[묶음, [산출물…]]]`
- 굵은 글씨의 상위 항목명에는 파일명·날짜를 쓰지 않는다. 세부 내용은 괄호로 쓰면 화면에서 하위 항목으로 표시된다 (엔진의 cleanNm)

## 설계 메모 (memo) — 사고 과정 ①~⑤ (`thinking-process.md`)
```jsonc
"memo": {
  "value": "합의된 조건 안에서 원하는 품질의 소재를 제때 만드는 것",
  "kpi": ["리드타임", "수정 회차", "제작 원가"],
  "moments": [["제작 조건 확정", ["BR-002-04"]], ["최종안 확정", ["BR-015-03"]]],
  "diagnosis": [{"id": "D1", "type": "기준 늦음", "desc": "견적·제작 방식이 4단계 PPM 이후에 정해짐", "ids": ["BR-007-02", "BR-022-01"]}],
                                                  // type 값: 정보 흩어짐 · 기준 늦음 · 사후 확인 · 반복 · 대기
  "hypotheses": ["조사·정리 비용이 낮아져 1단계에서 조건을 확정할 수 있다"],
  "unchanged": ["OT 대면·과제 재정의", "Art Direction", "현장 OK/NG"],
  "changes": [{"st": 1, "kind": "앞당김", "desc": "제작 조건/범위를 1단계에서 확정", "why": "D1", "ids": ["TB-02", "TB-03"]}],
                                                  // kind 값: 앞당김 · 게이트 · 병렬 · 소멸 · 신규 · 역할
  "structure": {"stages": "7단계 유지 — 의사결정 단위가 그대로", "client": "접점 수 변화 없음, 들고 가는 자료가 빨라짐", "orgs": "AP·제작 고유 업무는 각 본부 To-be"},
  "roles": [["CD", "작성 → 조건 확정·창작 판단에 집중"]]
}
```
- 소멸(X) 노드와 신규 노드는 모두 `changes` 항목 중 하나의 `ids`에 들어 있어야 하고, 그 항목의 `why`는 `diagnosis`의 id여야 한다 (check_design [설계메모])
- type·kind 값은 위 목록의 표현을 그대로 쓴다

## 받은 자료 기록 (inputs) — 첫 안내 메시지
```json
"inputs": {
  "received": [{"file": "…xlsx", "kind": "As-Is 엑셀"}, {"file": "…html", "kind": "As-Is HTML"}],
  "requests": [{"item": "시스템·데이터 상세 자료", "pri": "추가", "why": "엑셀 시스템 46종 중 10종 이름·접근 방식 '확인 필요'", "if_none": "모두 기존으로 두고 가정에 남김", "status": "received|none|pending"}],
  "questions": [{"q": "3-1-1-5-1-2 실제 수행 조직은?", "why": "담당 '이벤트 운영 담당팀(가설)'", "if_none": "엑셀 원문 + '확인 필요'"}],
  "answers": {"3-1-1-5-1-2 실제 수행 조직은?": "…"},
  "assumptions": ["시스템 준비 현황 없음 → 기존/신규만"],
  "none_needed": false
}
```
- `inputs.py`가 만든 `work/inputs.json`에 Claude가 requests와 questions를 작성하고, 답변을 받으면 status·answers·assumptions를 채운 뒤 `inputs.py save`로 설계 파일에 옮긴다
- `"applied": {"자료 종류": "어디에 무엇을 반영했는지 (반영하지 않았으면 이유)"}` · `"conflicts": [{"what", "where", "excel", "src", "other", "ask_in": "0.5|기타", "resolved"}]` · 업데이트 작업이면 `"carried"`(이전 요청 상태)와 `"prev_received"`도 기록

## 소멸·업무명 관련 형식
- 소멸(X) 행: `{"t": "X", "to": "흡수한 박스 번호", "why": "사유"}` 또는 `{"t": "X", "kind": "삭제", "why": "사유"}` — 화면에 표시되는 문구(note)는 compile이 만든다 (references/gone-display.md)
- `agent_log`: `[{"op": "rename|merge|role|add", "id", "old", "new", "at"}]` — agent_edit.py와 design_from_html이 기록하고, check_design [싱크]가 사용한다
- 흐름 따라가기 `steps[].v`: 기본값은 해당 박스의 업무명 (줄일 때는 업무명에 있는 단어만, 같은 순서로, 같은 동작으로 끝나게)
