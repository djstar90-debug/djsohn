# 컴파일·QC · v1.3.1

기본 제작 명령과 최종 배포는 SKILL.md과 quality-contract.md를 따른다.

- parse_excel: 업무행 누락·중복·수식 캐시·원본 행 대응 검증.
- source_asis: 원본 HTML의 DATA·저장 편집·배치·선 경로·행 대응·해시 및 공통 As-Is 뷰 일치 검증.
- restructure.check/build: 구조 설계 계약, 분리된 사람 개입, 명시적 연결, 역할·레인·산출물. 오류 시 exit 2, 자동 보정으로 최종 납품하지 않음.
- build_html: 유효 qualityGate가 필요. 잘못된 template, source hash, 닫는 script 태그 데이터 주입을 검사.
- export_excel: 실제 XLSX 생성·재개방, 표시 표와 payload, HTML PMD/설계 일치 검증.
- qc_browser: 시스템 Chromium 또는 Playwright, quick 및 final 오류 종료. 현재 HTML SHA256/run_id에 묶인 결과만 결합. 결과 파일이 없거나 worker 실패면 통과 불가.
- release.certify: 최종 QC와 현재 파일 해시를 확인한 뒤 manifest passed.

빠른 검사도 실패 시 exit 2. 최종 result는 기다리는 동안 exit 3; 이후 다시 호출한다. 이전/다른 HTML의 결과를 재활용하지 않는다. final의 모든 4개 묶음 완료가 필요하다.

필수 실패 항목: 누락/추가/겹침, 노드 통과선·평행선 충돌, 스크립트·패널 오류, 비직각선, 글자 넘침, 헤더 가림, 높이 규격, 흐름 가림, 소멸 설명, 라벨 충돌. 문체 경고는 별도 리뷰하며 구조 오류와 혼동하지 않는다.

직접 확인: To-be Lv.6, 사람 승인과 반려선, Agent 페이지, 흐름 따라가기, 원본 As-Is의 병렬·분기·환류. 현재 실행 환경에서 접근한 브라우저만 검증했다고 보고한다. As-Is의 공통 조작부·실제 표시 노드·연결선·상세창을 검사한다. iframe이 열리는지만 확인해 통과시키지 않는다.
