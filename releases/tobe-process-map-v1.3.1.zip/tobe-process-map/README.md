# tobe-process-map v1.3.1

As-Is Excel·HTML → To-be HTML·Excel·QA manifest. As-Is와 To-Be를 동일한 디자인·기능으로 표시하고, 원본 HTML의 배치·연결선 정보를 가져옵니다. 일괄 실행과 중단 지점 재개를 지원합니다.

스킬 진입점은 [SKILL.md](SKILL.md), 품질 기준은 [quality-contract.md](references/quality-contract.md), 설치·실행·재개는 [workflow.md](references/workflow.md)입니다. Python 3.11+와 Chromium이 필요합니다.

```bash
python -m pip install -r requirements.txt
python -m playwright install chromium
python scripts/pipeline.py prepare --excel input.xlsx --source-html input-asis.html --work work/crm-v1 --spec 3
# work/crm-v1/design.json에 실제 업무를 설계합니다.
python scripts/pipeline.py run --work work/crm-v1 --output outputs/crm-v1 --wait 50
python scripts/pipeline.py status --work work/crm-v1
```

구조 설계 후 선택적 필드 보완은 `pipeline.py enrich --work work/crm-v1`을 사용합니다. 변경 전 설계는 design-history에 보관됩니다. 긴 QC는 run에 `--background`를 붙여 최대 900초 동안 작업자가 진행하도록 할 수 있습니다.

진행 중이거나 수정 후 재개할 때는 `python scripts/pipeline.py run --work work/crm-v1 --wait 50`을 실행합니다. 같은 작업을 처음부터 만들 필요가 없습니다. 후보와 최종 통과 파일은 구분하며, 최종 경로는 status 결과에서 확인합니다.

전체 회귀검사: `python -m unittest discover -s tests -v`. 스킬 자체 수정 시 기존 검사를 생략하지 않습니다. tests/fixtures는 형식 검증용이며 실제 입력을 대신하지 않습니다. 실행에 쓰이지 않는 과거 부문 예제·참고 HTML은 경량 패키지에서 제외했습니다. 코드가 검증하는 구조적 기준 외에 업무 설계의 타당성과 핵심 화면 검토가 필요합니다.
