"""0.5단계 구조 확인 — As-Is의 순차·병행·분기·합류·환류를 정리해 대화창에서 확인받고, 확인한 구조를 설계 파일에 저장

  python scripts/structure.py work/asis.json [As-Is.html] work/structure      → work/structure.md (대화창에 보여 줄 정리) + work/structure.json
  python scripts/structure.py save work/structure.json work/design.json [role|org] --answer "사용자 답 원문"   → 확인받은 뒤 설계 파일에 저장 (답이 없으면 저장하지 않음, compile이 [구조]에 씀)
                                                                       role = 직무명 사용(AE·CD·PM·AP) / org = 조직명만 (check_design [표기])

읽는 곳
- 엑셀(asis.json): 후행·분기 조건(조건→ID)·반려 시 복귀 ID·노드 유형
- As-Is HTML(있으면): 저장된 연결선(일반 std · 조건 분기 conditional · 반려/재작업 rework, 조건·사유 글)과 묶음(대괄호 시나리오).
  사람이 HTML에서 고친 연결이 있을 수 있으므로 HTML을 우선하고, 엑셀과 다른 연결은 '엑셀과 다른 점'으로 따로 보여 준다.
판단
- 분기 = 한 업무 뒤가 여럿이고 조건이 붙음 (조건에 따라 하나로 감)
- 병행 = 한 업무 뒤가 여럿이고 조건이 없음 (동시에 진행)
- 합류 = 앞 업무가 여럿 (반려선 제외)
- 반려·환류 = 되돌아가는 선 (반려 시 복귀 ID · rework)
"""
import json, re, sys
from collections import OrderedDict, defaultdict

IDP = r'(?:[A-Z]{1,4}-\d+|\d+(?:-\d+)+)'   # BX-0001 꼴(이번 엑셀)과 1-2-3-4-5-6 꼴
def ids(s): return [x for x in re.split(r'[,;\s]+', s or '') if re.match('^' + IDP + '$', x)]

PARNOTE = {}   # 분기인데 '…이면 병렬 진행' 메모가 붙은 곳 → 구조 확인 때 해당 줄에 질문
def from_excel(A6):
    E = []
    for k, a in A6.items():
        cond = {}; brt = (a.get('br') or '').strip()
        par = bool(re.match(r'(병렬|동시)\s*진행\s*[:：]', brt))   # v35: '병렬 진행: A → x / B → y' = 병행
        for line in re.split(r'\n|\s+/\s+', re.sub(r'^(병렬|동시)\s*진행\s*[:：]\s*', '', brt)):   # v35: 줄바꿈뿐 아니라 ' / '로 나눈 조건도 (붙은 '/'는 글자)
            m = re.match(r'\s*(.+?)\s*(?:→|->)\s*(' + IDP + ')', line)
            if m: cond[m.group(2)] = m.group(1)
        if re.search(r'(병렬|동시)\s*진행', brt) and not par: PARNOTE[k] = re.search(r'[(（][^()（）]*(병렬|동시)\s*진행[^()（）]*[)）]', brt).group(0) if re.search(r'[(（][^()（）]*(병렬|동시)\s*진행[^()（）]*[)）]', brt) else '병렬 진행 언급'
        for b in ids(a.get('post')):
            if b in A6: E.append((k, b, ('std' if par else ('cond' if b in cond else 'std')), '' if par else cond.get(b, '')))
        for b in ids(a.get('rej')):
            if b in A6: E.append((k, b, 'rework', a.get('rejr', '')))
    return E

def from_html(path, A6):
    from source_asis import snapshot, correspondence
    data = snapshot(open(path, encoding='utf-8-sig').read())
    mapping, difference = correspondence(data, {'A6': A6})
    if not mapping: raise ValueError('As-Is HTML and Excel have no exact correspondence')
    kind = {'std':'std', 'conditional':'cond', 'cond':'cond', 'rework':'rework', 'parallel':'std', 'fork':'std', 'join':'std'}
    E = []
    for e in data['lv6']['edges']:
        if e[0] not in mapping or e[1] not in mapping: continue
        if e[2] not in kind: raise ValueError('Unknown As-Is edge type: ' + str(e[2]))
        E.append((mapping[e[0]], mapping[e[1]], kind[e[2]], e[3] if len(e) > 3 else ''))
    groups = [(g.get('label', ''), len(g.get('members', []))) for g in data['lv6'].get('v34Groups', [])]
    return E, groups

def basis_of(asis):
    """구조 확인의 기준 지문: 엑셀 행마다 선행·후행·분기 조건·반려 칸 — 바뀌면 구조를 다시 확인받아야 함"""
    import hashlib
    rows = sorted([k, str(a.get('pre', '')), str(a.get('post', '')), str(a.get('br', '')), str(a.get('rej', '')), str(a.get('rejr', ''))] for k, a in asis['A6'].items())
    return hashlib.sha1(json.dumps(rows, ensure_ascii=False).encode('utf-8')).hexdigest()[:16]

def analyze(asis, html=None):
    A6, A5, A4 = asis['A6'], asis['A5'], asis['A4']
    st_of = {k: list(A4).index(A5[a['l5'].split(' ')[0]]['l4id']) + 1 for k, a in A6.items()}
    EX = from_excel(A6); src = '엑셀'; groups = []; diff = []
    if html:
        EH, groups = from_html(html, A6)
        if EH is not None:
            src = 'As-Is HTML (엑셀과 비교)'
            kx = {(a, b): t for a, b, t, _ in EX}; kh = {(a, b): t for a, b, t, _ in EH}; lab = {(a, b): l for a, b, _, l in EH}
            res_extra = [[a, b, {'cond': 'b', 'rework': 'r'}.get(t, 's'), lab.get((a, b), '')] for (a, b), t in kh.items() if (a, b) not in kx]
            for e in kh:
                if e not in kx: diff.append(f'HTML에만 있는 연결: {e[0]} → {e[1]} ({kh[e]})')
                elif kh[e] != kx[e]: diff.append(f'종류가 다름: {e[0]} → {e[1]} (엑셀 {kx[e]} · HTML {kh[e]})')
            for e in kx:
                if e not in kh: diff.append(f'엑셀에만 있는 연결: {e[0]} → {e[1]} ({kx[e]})')
            EX = EH
    out = defaultdict(list); inn = defaultdict(list)
    for a, b, t, lab in EX:
        if t == 'rework': continue
        out[a].append((b, t, lab)); inn[b].append(a)
    res = dict(source=src, parallel=[], branch=[], join=[], rework=[], groups=groups, diff=diff, extra=locals().get('res_extra', []), basis=basis_of(asis))
    for a, L in out.items():
        if len(L) < 2: continue
        if all(t == 'cond' for _, t, _ in L): res['branch'].append(dict(st=st_of[a], frm=a, to=OrderedDict((lab or b, b) for b, _, lab in L)))
        elif not any(t == 'cond' for _, t, _ in L): res['parallel'].append(dict(st=st_of[a], frm=a, to=[b for b, _, _ in L]))
        else: res['branch'].append(dict(st=st_of[a], frm=a, to=OrderedDict((lab or f'(조건 없음) {b}', b) for b, _, lab in L), mixed=1))
    for b, P in inn.items():
        if len(P) >= 2: res['join'].append(dict(st=st_of[b], to=b, frm=P))
    for a, b, t, lab in EX:
        if t == 'rework': res['rework'].append(dict(st=st_of[a], frm=a, to=b, why=lab))
    res['source_edges'] = [[a,b,{'cond':'b','rework':'r'}.get(t,'s'),lab] for a,b,t,lab in EX]
    res['st_of'] = st_of; res['edges'] = len(EX); res['stages'] = [(i + 1, A4[k]['n']) for i, k in enumerate(A4)]
    return res, A6

ROLES, ORGS = [], []
COND_RX = re.compile(r'필요\s*시|필요한 경우|경우에|(?:이벤트|시)\s*한정|\(\s*[^)]*한정\s*\)|(발생|변경|가능|요청|해당|누락|실패)\s*시(?![가-힣])')   # v35: '…변경 시'·'…발생 시'도
def md(res, A6):
    global ROLES, ORGS   # v35: 사람 주체 표기 질문 — 그 부문 엑셀의 담당 칸에서 (괄호 안 직무명 / 괄호 밖 조직명)
    tm = sorted({a.get('team', '') for a in A6.values() if a.get('team')})
    ROLES = [m.group(1) for t in tm for m in [re.search(r'\(([^()]+)\)\s*$', t)] if m][:6]
    ORGS = [re.sub(r'\s*\([^()]*\)\s*$', '', t) for t in tm][:6]
    """구조 정리 근거 문서 — 한눈에 표 → 단계별 표(번호) → 확인이 필요한 지점 (첫 안내 메시지 B는 이를 Lv.5 기준으로 다시 정리)"""
    nm = lambda k: f"{k} {A6[k]['n']}" if k in A6 else k
    st_name = {}
    for i, x in enumerate(res.get('stages', [])):
        k, v = (x[0], x[1]) if isinstance(x, (list, tuple)) else (i + 1, x); st_name[int(k)] = re.sub(r'^\d+\.\s*', '', str(v))
    cond = [dict(st=None, id=k, n=a['n'] + (f" (조건: {re.split(r'\n', a.get('br',''))[0]})" if a.get('ty') == '조건부' and a.get('br') else '')) for k, a in A6.items() if COND_RX.search(a['n']) or a.get('ty') == '조건부']
    for c in cond:
        c['st'] = next((b['st'] for b in res['branch'] if b['frm'] == c['id']), None) or res['st_of'][c['id']]
    res['conditional'] = [dict(st=c['st'], id=c['id']) for c in cond]
    no = {}; tag = lambda kind, x: no.setdefault((kind, id(x)), f"{kind}{sum(1 for k in no if k[0] == kind) + 1}")
    L = ['## As-Is 구조 정리 — 분기/병행·조건부 진행·환류/복귀 (근거 자료 · Lv.6 기준)', '',
         f"기준: **{res['source']}** · 연결 {res['edges']}개" + (f" · 엑셀과 다른 점 {len(res.get('diff', []))}개 (맨 아래)" if res.get('diff') else ''), '',
         '### 한눈에', '', '| 종류 | 뜻 | 개수 |', '|---|---|---|',
         f"| ◇ 분기 (B) | 조건에 따라 한쪽으로만 감 | {len(res['branch'])} |",
         f"| ⇉ 병행 (P) | 동시에 함께 진행 | {len(res['parallel'])} |",
         f"| ⇢ 합류 (J) | 여러 갈래가 한 업무로 모임 | {len(res['join'])} |",
         f"| ↺ 반려·환류 (R) | 앞 업무로 되돌아감 | {len(res['rework'])} |",
         f"| ⚑ 조건부 업무 (C) | 경우에 따라서만 하는 업무 ('필요 시' 등) | {len(cond)} |", '']
    ask = []
    for st in sorted({x['st'] for x in res['branch'] + res['parallel'] + res['join'] + res['rework']} | {c['st'] for c in cond}):
        L.append(f"### {st}단계 · {st_name.get(st, '')}".rstrip(' ·')); L.append('')
        B = [b for b in res['branch'] if b['st'] == st]
        if B:
            L += ['**◇ 분기**', '', '| 번호 | 갈라지는 업무 | 조건 → 다음 업무 |', '|---|---|---|']
            for b in B:
                t = tag('B', b); L.append(f"| {t} | {nm(b['frm'])} | " + '<br>'.join(f"{c} → {nm(v)}" for c, v in b['to'].items()) + ' |')
                if b['frm'] in PARNOTE: ask.append(f"**{t}** {nm(b['frm'])}: 엑셀에 '{PARNOTE[b['frm']]}'라고 적혀 있습니다 → [조건에 따라 한쪽으로만 (분기)] / [조건에 따라 동시 진행도 함 (분기로 두고 상세 창에 표시)]")
                if b.get('mixed'):
                    nc = [v for c, v in b['to'].items() if c.startswith('(조건 없음)')]
                    if not nc: nc = [x for x in re.findall(IDP, str(A6.get(b['frm'], {}).get('post', ''))) if x not in b['to'].values()]   # 분기 갈래 밖의 후행
                    ask.append(f"**{t}** {nm(b['frm'])} 다음에 조건 없는 갈래({', '.join(nm(v) for v in nc)})가 섞여 있습니다 → [그 밖의 경우(조건에 해당하지 않으면 이쪽)] / [조건 갈래와 동시 진행]" if nc else f"**{t}** {nm(b['frm'])}: 조건 갈래 밖에도 이어지는 업무가 있는지 확인해 주세요 (엑셀 후행 칸과 분기 조건이 맞지 않음)")
            L.append('')
        P_ = [x for x in res['parallel'] if x['st'] == st]
        if P_:
            L += ['**⇉ 병행**', '', '| 번호 | 앞 업무 | 동시에 진행하는 업무 |', '|---|---|---|']
            for x in P_: L.append(f"| {tag('P', x)} | {nm(x['frm'])} | " + '<br>'.join(nm(v) for v in x['to']) + ' |')
            L.append('')
        J = [x for x in res['join'] if x['st'] == st]
        if J:
            L += ['**⇢ 합류**', '', '| 번호 | 모이는 업무 | 들어오는 업무 |', '|---|---|---|']
            for x in J: L.append(f"| {tag('J', x)} | {nm(x['to'])} | " + '<br>'.join(nm(v) for v in x['frm']) + ' |')
            L.append('')
        R = [x for x in res['rework'] if x['st'] == st]
        if R:
            L += ['**↺ 반려·환류**', '', '| 번호 | 되돌리는 업무 | 사유 | 돌아가는 업무 |', '|---|---|---|---|']
            for x in R: L.append(f"| {tag('R', x)} | {nm(x['frm'])} | {x.get('why') or '(사유 없음 — 알려 주세요)'} | {nm(x['to'])} |")
            L.append('')
        C = [c for c in cond if c['st'] == st]
        if C:
            L += ['**⚑ 조건부 업무**', '', '| 번호 | 업무 |', '|---|---|']
            for c in C: L.append(f"| {tag('C', c)} | {nm(c['id'])} |")
            L.append('')
    if res.get('diff'):
        L += ['### 엑셀과 다른 점', ''] + [f"- {d}" for d in res['diff']] + ['']
        ask.append('엑셀과 다른 점: [As-Is HTML대로] / [엑셀대로] / 곳마다 다름')
    L += ['### 확인이 필요한 지점 (B에서 해당 줄 끝에 짧게 질문)', ''] + ([f"{i + 1}. {a}" for i, a in enumerate(ask)] or ['- 없음'])
    return '\n'.join(L) + '\n'

if __name__ == '__main__':
    if sys.argv[1] == 'save':
        args = sys.argv[1:]; ANSWER = ''
        if '--answer' in args: k = args.index('--answer'); ANSWER = (args[k + 1] if k + 1 < len(args) else '').strip(); args = args[:k] + args[k + 2:]; sys.argv = [sys.argv[0]] + args
        if not ANSWER:   # v1.1.5: 멈추지 않고 저장 — 답이 없다는 사실을 기록
            print('자료 근거 구조 저장 — 사용자 확인 기록 없음')
        st = json.load(open(sys.argv[2], encoding='utf-8')); d = json.load(open(sys.argv[3], encoding='utf-8'))
        if not st.get('basis'): print('주의 [구조] 구조 정리에 기준 지문(basis)이 없음 — 그대로 저장 (structure.py로 다시 정리하면 채워짐)')
        d['structure'] = dict(parallel=[dict(**{'from': x['frm']}, to=x['to']) for x in st['parallel']],
                              branch=[dict(**{'from': x['frm']}, to=x['to']) for x in st['branch']],
                              join=[dict(to=x['to'], **{'from': x['frm']}) for x in st['join']],
                              rework=[dict(**{'from': x['frm']}, to=x['to'], why=x['why']) for x in st['rework']],
                              source_edges=st.get('source_edges', []), extra=st.get('extra', []), source=st.get('source', ''), basis=st.get('basis', ''), answer=ANSWER, confirmed=bool(ANSWER), source_verified=bool(st.get('source_edges') is not None))   # extra = As-Is HTML에만 있는 연결 (사람이 고친 연결) → compile이 지도에 넣음
        d['people'] = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4] in ('role', 'org') else d.get('people') or 'org'   # 기본 = 조직명 원문 (사용자가 직무명을 요청했을 때만 role)
  # 사람 주체 표기: role(직무명 사용) / org(조직명만)
        json.dump(d, open(sys.argv[3], 'w', encoding='utf-8'), ensure_ascii=False, indent=1); print('설계 파일에 확인한 구조 저장:', sys.argv[3], '· 사람 주체 표기:', d.get('people', '(미정)')); sys.exit(0)
    asis = json.load(open(sys.argv[1], encoding='utf-8'))
    html = sys.argv[2] if len(sys.argv) > 3 else None; out = sys.argv[-1]
    res, A6 = analyze(asis, html)
    open(out + '.md', 'w', encoding='utf-8').write(md(res, A6)); json.dump(res, open(out + '.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f"분기 {len(res['branch'])} · 병행 {len(res['parallel'])} · 합류 {len(res['join'])} · 반려·환류 {len(res['rework'])} · 경로 묶음 {len(res['groups'])} · 엑셀과 다른 점 {len(res['diff'])}")
    print('→', out + '.md', '(첫 안내 메시지 B 작성 근거 — Lv.5 기준으로 다시 정리해 보여 주고, 확인받은 뒤 save)')
