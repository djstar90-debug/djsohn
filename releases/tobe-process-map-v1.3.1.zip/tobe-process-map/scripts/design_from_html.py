"""참조(또는 이전 버전) HTML → design.json  (판단 층만 꺼냄)"""
import sys, json, re
sys.path.insert(0, __file__.rsplit('/',1)[0])
from htmlio import split
def embedded(html):
    """이 스킬로 만든 HTML: 압축해 넣어 둔 설계 파일을 그대로 꺼낸다"""
    import gzip, base64
    m = re.search(r'<script type="application/gzip\+base64" id="pm-design">([^<]+)</script>', html)
    return json.loads(gzip.decompress(base64.b64decode(m.group(1))).decode('utf-8')) if m else None
def extract(html):
    e = embedded(html)
    if e is not None: return e
    D, engine, *_ = split(html)
    A6 = D['A6']; ns6 = {n['id']: n for n in D['views']['6']['ns']['nodes']}
    lane_of_team = {}
    for k, a in A6.items():
        lane_of_team.setdefault(a['team'], D['views']['6']['asis']['nodes'] and next(n['ln'] for n in D['views']['6']['asis']['nodes'] if n['id']==k))
    lanes = [dict(l, team=[t for t,v in lane_of_team.items() if v==l['k']]) for l in D['lanes']]
    tb = {}
    for k, t in D['TB'].items():
        e = {x: t[x] for x in ('t','sub','lb','tg','note','ref') if t.get(x) not in (None, '', [])}
        if k not in A6:
            n = ns6[k]
            e.update(st=t['st'], l5=t['l5'], o=n['o'])
            if not t.get('sub'): e['lane'] = n['ln']
        tb[k] = e
    new_edges = [e for e in D['views']['6']['ns']['edges'] if not (e[0] in A6 and e[1] in A6)]
    # 엔진 안 STORY(흐름 따라가기) 상수
    m = re.search(r'const STORY = (\{.*?\n\});', engine, re.S)
    tour_js = m.group(1) if m else None
    design = dict(
        meta=dict(text=D['text'], start=D['start']),
        lanes=lanes,
        tb=tb, new_edges=new_edges,
        bands=D['bands'], subs=D['subs'], story=D['story'],
        stage_gate={s['id']: s['gate'] for s in D['stages']},
        outs=D['outs'], outnew=D['outnew'], when=D['when'], whenHave=D['whenHave'],
        sysinfo=D['sysinfo'], dfmt=D['dfmt'], form=D['form'],
        tour_js=tour_js, desc=D.get('desc', {}), ax=D.get('ax'))
    return design
def embedded(html):
    """이 스킬로 만든 HTML에 압축해 넣어 둔 설계 파일을 꺼낸다 (없으면 None)"""
    import gzip, base64
    m = re.search(r'<script type="application/gzip\+base64" id="pm-design">([^<]+)</script>', html)
    return json.loads(gzip.decompress(base64.b64decode(m.group(1))).decode('utf-8')) if m else None
def edits(html):
    """편집본(결과 HTML 안에서 고친 것)의 편집 기록을 꺼내 종류별로 정리한다 — 설계 파일에는 들어 있지 않으므로 업데이트 때 따로 확인
    기록 위치: window.__BAKED__ = {text, ed, story, ag, nm} (references/editing.md)"""
    m = re.search(r'/\*BAKED\*/(.*?)/\*/BAKED\*/', html, re.S)
    if not m: return None
    try: B = json.loads(m.group(1))
    except Exception: return None
    T = B.get('text') or {}; ED = B.get('ed') or {}; AG = B.get('ag') or {}; NM = B.get('nm') or {}
    memo_off = [k[3:] for k in T if k.startswith('LM|')]   # v26: HTML에서 지운 '확인 필요' 표시 (레인 키)
    out = dict(
        names={k: v[0] for k, v in NM.items() if isinstance(v, list) and v},                                  # 이름 바꾸기: 종류|ID → 새 이름
        table={sid: sorted(v.keys()) for sid, v in (AG.get('subs') or {}).items()},                           # 세부 Agent 표 편집: 바꾼 칸
        table_story=sorted((AG.get('story') or {}).keys()),
        panel_text={k: v[1] for k, v in T.items() if k.startswith('P|') and isinstance(v, list)},             # 상세 창 글자 (그 화면 그 박스)
        page_text={k: v for k, v in T.items() if k.startswith('G|')},
        page_rows=sorted(k for k in T if k.startswith(('GR|', 'GX|'))),                                      # 지운 행·항목 (GR = 세부 Agent 상세 표 행, GX = 그 밖의 데이터 항목)                                                # 지운 상세 표 행 (GR|큰기능|세부|표:행)                                          # Agent 상세 페이지 글자 (G|큰기능|세부|원래 글자, '' = 지움)
        map_text={k: v for k, v in T.items() if k.startswith(('AMX|', 'BD|'))},
        band_text={k: v for k, v in T.items() if k.startswith(('IN|', 'PB|'))},                                # 큰 기능 Agent '이 Agent는'(IN) · 한눈에 보기 맨 위 '무엇을 하나'(PB, JSON 목록)                                # 구조도 설명 줄 (BD = 큰 기능 Agent 설명 원본)
        box_labels={k: v for k, v in T.items() if not k.startswith(('P|', 'AMX|', 'BD|', 'G|')) and k.count('|') == 2},  # 그 화면 박스 이름만 바꾼 것
        header_text={k: v for k, v in T.items() if '|' not in k},                                             # 머리글 문구(✎ 문구 편집)
        flow={scr: {x: len(e[x]) for x in ('mv', 'kd', 'tg', 'cd', 'del', 'add', 'ea', 'ed', 'em') if e.get(x)} for scr, e in ED.items() if any(e.get(x) for x in ('mv', 'kd', 'tg', 'cd', 'del', 'add', 'ea', 'ed', 'em'))},
        tour_text=sorted((B.get('story') or {}).keys()))
    return {k: v for k, v in out.items() if v}
if __name__ == '__main__':
    html = open(sys.argv[1], encoding='utf-8').read()
    E = edits(html)
    if E:   # 편집본: 설계 파일만으로는 화면에서 고친 내용이 사라지므로 목록을 남기고 알린다
        ep = sys.argv[2].rsplit('.', 1)[0] + '_edits.json'; json.dump(E, open(ep, 'w'), ensure_ascii=False, indent=1)
        print('편집 기록 있음 →', ep, {k: len(v) for k, v in E.items()}, '— 설계에 옮길 것은 옮기고(이름·표 편집), 나머지는 보고에 남긴다')
    d = embedded(html)
    try:   # v33: HTML 안에서 바꾼 Agent·레인 이름을 설계에도 반영 (다음 HTML에도 유지 — a·b·c 싱크)
        import importlib.util as _iu, os as _os
        _sp = _iu.spec_from_file_location('agent_edit', _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'agent_edit.py')); _ae = _iu.module_from_spec(_sp); _sp.loader.exec_module(_ae)
        _B = json.loads(re.search(r'/\*BAKED\*/(.*?)/\*/BAKED\*/', html, re.S).group(1) or '{}')
        for _k, _h in ((_B.get('nm') or {}).items()):
            if not isinstance(_h, list) or not _h or not d: continue
            _kind, _id = _k.split('|', 1)
            if _kind == 'ag' and _ae._obj(d, _id) and _ae._obj(d, _id)['name'] != _h[0]: print('Agent 이름 반영:', _ae._obj(d, _id)['name'], '→', _h[0], '·', _ae.rename(d, _id, _h[0]), '곳')
            elif _kind == 'ln':
                for _l in d.get('lanes', []):
                    if _l.get('k') == _id and _l.get('name') != _h[0]: _old = _l['name']; _ae.walk_replace(d, _old, _h[0]); _l['name'] = _h[0]; print('레인 이름 반영:', _old, '→', _h[0])
            elif _kind == 't6' and _id in d.get('tb', {}) and d['tb'][_id].get('lb') != _h[0]: d['tb'][_id]['lb'] = _h[0]; print('업무명 반영:', _id)
    except Exception as _e: print('경고: HTML에서 바꾼 이름을 설계에 반영하지 못함 —', _e)
    try:   # v26: 편집본에서 지운 '확인 필요' 표시를 설계 파일 레인 memo에도 반영
        Bk = json.loads(re.search(r'/\*BAKED\*/(.*?)/\*/BAKED\*/', html, re.S).group(1) or '{}')
        for k in [k[3:] for k in (Bk.get('text') or {}) if k.startswith('LM|')]:
            for l in (d or {}).get('lanes', []):
                if l.get('k') == k and l.get('memo'): l['memo'] = ''; print('확인 필요 표시 지움 반영:', l['name'])
    except Exception: pass
    try:   # 이전 HTML에 든 As-Is 업무명 = 그때 판정의 근거 → 새 엑셀과 다르면 check_design [변경행]
        P = json.loads(re.search(r'window\.__PMD__ = (\{.*?\});?\s*</script>', html, re.S).group(1)); A6o = P.get('A6') or {}
        if d:
            for k, t in d.get('tb', {}).items():
                if k in A6o and not t.get('src_n') and A6o[k].get('n'): t['src_n'] = A6o[k]['n']
    except Exception: pass
    if d is not None:
        json.dump(d, open(sys.argv[2], 'w'), ensure_ascii=False, indent=1); print('내장 설계 파일 복원'); sys.exit()
    d = extract(html)   # 이전 버전(설계 파일 없는 HTML): 화면 데이터에서 판단 층을 역추적
    json.dump(d, open(sys.argv[2], 'w'), ensure_ascii=False, indent=1)
    print({k: (len(v) if hasattr(v,'__len__') else v) for k, v in d.items()})
