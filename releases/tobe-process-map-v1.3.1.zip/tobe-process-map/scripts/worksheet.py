"""작성용 시트 — 문장을 쓸 때 필요한 정보를 단계별 한 표로 (여러 파일을 찾아보지 않게)
  sheet asis.json design.json out_dir [단계]   단계별 시트(md)와 빈칸만 담은 작성 틀(json)
  merge design.json filled.json               작성 틀에 쓴 문장을 설계 파일에 합침 (빈 값은 건너뜀)

시트 한 줄 = 박스 하나: ID · 담당 · As-Is 업무명 · 판정 · To-be 업무명 · 세부 Agent · 태그 · 앞 → 뒤 · Pain 요약 · 이미 쓴 설명
작성 틀(fill_N.json): {"desc": {"A4","T4","A5","A6","T6","M6"}, "tour": {단계: {"now","chg","next"}}} 중 빈칸만
경로만 다른 같은 업무는 대표 행에만 ★ — 나머지는 autofill fill이 채우므로 틀에서 뺌
"""
import sys, os, json, re
from collections import OrderedDict

def short(s, n=40):
    s = re.sub(r'\s+', ' ', s or '').strip()
    return s if len(s) <= n else s[:n - 1] + '…'

def sheet(asis, d, out, only=None):
    A6, A5, A4 = asis['A6'], asis['A5'], asis['A4']; TB = d['tb']; S = d['subs']; ds = d.get('desc') or {}
    BYBON = any(l.get('bon') for l in d['lanes']); lane = {t: l['name'] for l in d['lanes'] for t in (l.get('bon') or l['team'])}
    lkey = (lambda a: a.get('bon') or a['team']) if BYBON else (lambda a: a['team'])
    base = lambda n: re.sub(r'\s+', ' ', re.sub(r'\[[^\]]*\]', '', n or '')).strip()
    rep, seen = {}, {}
    for k, a in A6.items():
        key = (base(a['n']), TB[k]['t'], TB[k].get('sub'))
        if key in seen: rep[k] = seen[key]
        else: seen[key] = k
    name = lambda k: (TB.get(k, {}).get('lb') or A6.get(k, {}).get('n') or k)
    who = lambda k: (S[TB[k]['sub']]['name'] if TB[k].get('sub') in S else lane.get(lkey(A6[k]), '') if k in A6 else next((l['name'] for l in d['lanes'] if l['k'] == TB[k].get('lane')), ''))
    os.makedirs(out, exist_ok=True); files = []
    for si, (sk, s4) in enumerate(A4.items(), 1):
        if only and si != only: continue
        L = [f'# {si}단계 {s4["n"]}', '', f'- As-Is 단계 설명(A4): {ds.get("A4", {}).get(str(si), "(빈칸)")}', f'- To-be 단계 설명(T4): {ds.get("T4", {}).get(str(si), "(빈칸)")}', '']
        fill = {'desc': {x: {} for x in ('A4', 'T4', 'A5', 'A6', 'T6', 'M6')}, 'tour': {}}
        if not ds.get('A4', {}).get(str(si)): fill['desc']['A4'][str(si)] = ''
        if not ds.get('T4', {}).get(str(si)): fill['desc']['T4'][str(si)] = ''
        tv = d.get('tour', {}).get(str(si), {})
        miss_t = {f: '' for f in ('now', 'chg', 'next') if not tv.get(f)}
        if miss_t: fill['tour'][str(si)] = miss_t
        for k5 in s4['kids']:
            L.append(f'## {k5} {A5[k5]["n"]}  — Lv.5 설명(A5): {ds.get("A5", {}).get(k5, "(빈칸)")}')
            if not ds.get('A5', {}).get(k5): fill['desc']['A5'][k5] = ''
            L.append('| ID | 담당 | As-Is 업무명 | 판정 | To-be 업무명 | 세부 Agent / 레인 | 태그 | 앞 → 뒤 | Pain 요약 | 설명 A6 / T6 |')
            L.append('|---|---|---|---|---|---|---|---|---|---|')
            rows = list(A5[k5]['kids']) + [k for k, t in TB.items() if k not in A6 and t.get('l5') == k5]
            for k in rows:
                t = TB[k]; a = A6.get(k, {})
                pre = ', '.join(short(name(x), 16) for x in (a.get('pre', '') or '').split(', ') if x)[:40]
                post = ', '.join(short(name(x), 16) for x in (a.get('post', '') or '').split(', ') if x)[:40]
                pain = short(next((x for x in (a.get('pain', '') or '').split('\n') if x.strip()), ''), 36)
                rmark = f'= {rep[k]}' if k in rep else ('★' if any(v == k for v in rep.values()) else '')
                a6, t6 = ds.get('A6', {}).get(k, ''), (ds.get('M6', {}) if t['t'] == 'M' else ds.get('T6', {})).get(k, '')
                L.append(f'| {k}{" " + rmark if rmark else ""} | {short(a.get("team", "") or "신규", 14)} | {short(a.get("n", "—"), 34)} | {t["t"]} | {short(t.get("lb") or "", 34)} | {short(who(k), 18)} | {t.get("tg", "")} | {pre} → {post} | {pain} | {short(a6, 24) or "·"} / {short(t6, 24) or "·"} |')
                if k in rep: continue          # 경로 반복 — fill이 채움
                if k in A6 and not a6: fill['desc']['A6'][k] = ''
                if t['t'] in ('A', 'N') and not t6: fill['desc']['T6'][k] = ''
                if t['t'] == 'M' and not t6: fill['desc']['M6'][k] = ''
            L.append('')
        p = os.path.join(out, f'sheet_{si}.md'); open(p, 'w', encoding='utf-8').write('\n'.join(L))
        fill['desc'] = {x: v for x, v in fill['desc'].items() if v}
        q = os.path.join(out, f'fill_{si}.json'); json.dump(fill, open(q, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        n = sum(len(v) for v in fill['desc'].values()) + sum(len(v) for v in fill['tour'].values())
        files.append((si, p, q, n))
    return files

def merge(dp, fp):
    d = json.load(open(dp, encoding='utf-8')); f = json.load(open(fp, encoding='utf-8')); n = 0
    for key, m in f.get('desc', {}).items():
        for k, v in m.items():
            if v and v.strip(): d.setdefault('desc', {}).setdefault(key, {})[k] = v.strip(); n += 1
    for st, m in f.get('tour', {}).items():
        for k, v in m.items():
            if v and v.strip(): d.setdefault('tour', {}).setdefault(st, {})[k] = v.strip(); n += 1
    json.dump(d, open(dp, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    return n

if __name__ == '__main__':
    if sys.argv[1] == 'sheet':
        asis = json.load(open(sys.argv[2])); d = json.load(open(sys.argv[3]))
        for si, p, q, n in sheet(asis, d, sys.argv[4], int(sys.argv[5]) if len(sys.argv) > 5 else None):
            print(f'{si}단계: 시트 {p} · 작성 틀 {q} (빈칸 {n}개)')
    else:
        print('합친 문장', merge(sys.argv[2], sys.argv[3]))
