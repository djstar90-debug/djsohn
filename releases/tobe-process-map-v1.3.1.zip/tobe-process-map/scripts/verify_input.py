"""Lossless input checks. Dangling source references are recorded, never silently deleted.

Use validate(asis) for structured issues or: verify_input.py asis.json.
Source HTML may resolve Excel topology conflicts; unresolved conflicts block standalone release.
"""
import json
import re
import sys


def validate(data):
    issues = []
    def add(severity, code, message): issues.append(dict(severity=severity, code=code, message=message))
    for level in ('A4', 'A5', 'A6'):
        records = data.get(level)
        if not isinstance(records, dict) or not records:
            add('error', 'EMPTY_LEVEL', f'{level}: 업무가 없거나 형식이 잘못됨'); continue
        for ident, record in records.items():
            if not ident or not record.get('n'):
                add('error', 'MISSING_REQUIRED', f'{level}/{ident}: ID/업무명 누락')
            for field in ('pre', 'post', 'rej'):
                for target in re.split(r'[,;\s]+', str(record.get(field, ''))):
                    if target and target not in records:
                        add('warning', 'SOURCE_REFERENCE_CONFLICT', f'{level}/{ident}.{field}: 원본에 없는 ID {target}; 원본 HTML과 대조 필요')
    a4, a5, a6 = (data.get(k) or {} for k in ('A4', 'A5', 'A6'))
    for ident, record in a6.items():
        parent = record.get('l5', '').split(' ')[0]
        if parent not in a5:
            add('error', 'MISSING_PARENT', f'A6/{ident}: Lv.5 부모 {parent} 없음')
        elif ident not in a5[parent].get('kids', []):
            add('error', 'CHILD_MISMATCH', f'A6/{ident}: Lv.5 children 누락')
    for level, records, children in (('A4', a4, a5), ('A5', a5, a6)):
        for ident, record in records.items():
            kids = record.get('kids', [])
            if len(kids) != len(set(kids)):
                add('error', 'DUPLICATE_CHILD', f'{level}/{ident}: children 중복')
            for child in kids:
                if child not in children: add('error', 'MISSING_CHILD', f'{level}/{ident}: 자식 {child} 없음')
    for ident, record in a5.items():
        if record.get('l4id') not in a4: add('error', 'MISSING_PARENT', f'A5/{ident}: 단계 부모 없음')
    return issues


def require_resolved(data):
    """Release gate; HTML source synchronization can resolve source-reference warnings."""
    issues = validate(data)
    return [x for x in issues if x['severity'] == 'error' or x['code'] == 'SOURCE_REFERENCE_CONFLICT']


if __name__ == '__main__':
    result = validate(json.load(open(sys.argv[1], encoding='utf-8')))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    sys.exit(2 if any(x['severity'] == 'error' for x in result) else 0)
