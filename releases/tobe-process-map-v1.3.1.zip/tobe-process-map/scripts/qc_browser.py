"""브라우저 자동 점검
- 화면별 박스 수 = 데이터 노드 수 (단계 필터 반영)
- 박스 겹침 0
- 스크립트 오류 0
- 상세 창: 모든 To-be·As-Is Lv.6 박스에서 열림
- 연결선: 박스를 지나가는 선(양 끝 박스 제외), 같은 경로를 몇 px 간격으로 나란히 가는 선
사용: qc_browser.py out.html [report.json] [all|quick|asis|ns|panels]
     최종 점검(병렬, 백그라운드): qc_browser.py out.html 결과폴더 final  → 바로 돌아옴
                                  qc_browser.py out.html 결과폴더 result → 현재 상태를 즉시 확인하고 완료된 결과만 합침 (미완료 종료 코드 3)
점검 항목·기준은 모든 방식에서 같다. HTML은 읽기만 한다
"""
import re, asyncio, sys, json, os, time, subprocess, hashlib, uuid, shutil, traceback, shlex
from pathlib import Path
from importlib.metadata import version as package_version
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread
from playwright.async_api import async_playwright

# Observe existing rendering timers rather than guessing with fixed sleeps. This
# preserves their delays/callbacks; it only tracks short pending UI callbacks.
INIT_QC = r"""(() => {
 const pending=new Set(), nativeSet=window.setTimeout.bind(window), nativeClear=window.clearTimeout.bind(window);
 window.__QC_PENDING__=pending;
 window.setTimeout=(fn,delay,...args)=>{if(typeof fn!=='function'||Number(delay)>1000)return nativeSet(fn,delay,...args);
  let id; id=nativeSet((...xs)=>{pending.delete(id);return fn(...xs)},delay,...args);pending.add(id);return id;};
 window.clearTimeout=id=>{pending.delete(id);return nativeClear(id)};
 document.addEventListener('DOMContentLoaded',()=>{const style=document.createElement('style');style.textContent='*,*::before,*::after{transition:none!important;animation:none!important}';document.head.appendChild(style)});
})()"""
SETTLE = r'''() => new Promise(resolve => {
 const start=performance.now();let previous='',same=0;
 const frame=()=>{const nodes=[...document.querySelectorAll('#board .nd[data-id]')],edges=[...document.querySelectorAll('#edges path')];
  const signature=nodes.map(n=>{const r=n.getBoundingClientRect();return n.dataset.id+':'+r.x.toFixed(1)+','+r.y.toFixed(1)+','+r.width.toFixed(1)+','+r.height.toFixed(1)}).join('|')+'#'+edges.map(e=>e.getAttribute('d')).join('|');
  same=signature===previous?same+1:0;previous=signature;
  if(same>=3&&!(window.__QC_PENDING__&&window.__QC_PENDING__.size))return resolve(true);
  if(performance.now()-start>4500)return resolve(false);requestAnimationFrame(frame);};requestAnimationFrame(frame);
})'''
async def settle(pg):
    if not await pg.evaluate(SETTLE):
        raise RuntimeError('Render did not settle in 4500ms; pending UI timers or geometry changes')


def context(rep, **values):
    rep['_context'] = values


def record_error(rep, message, stack='', kind='javascript'):
    normalized = re.sub(r'http://127\.0\.0\.1:\d+', 'local-artifact', stack or message)
    key = hashlib.sha256((kind + message + normalized).encode()).hexdigest()[:16]
    diagnostics = rep.setdefault('diagnostics', [])
    item = next((x for x in diagnostics if x['key'] == key), None)
    location = dict(rep.get('_context', {}))
    if item is None:
        item = dict(key=key, kind=kind, message=message, stack=stack, occurrences=0, locations=[], screenshots=[])
        diagnostics.append(item); rep['errors'].append(message)
    item['occurrences'] += 1
    if location not in item['locations']: item['locations'].append(location)
    return item


async def capture_issue(pg, rep, kind, messages, selector):
    if not messages: return
    location = dict(rep.get('_context', {}))
    key = hashlib.sha256(json.dumps([kind, location, selector], sort_keys=True).encode()).hexdigest()[:16]
    diagnostics = rep.setdefault('diagnostics', [])
    if any(x.get('key') == key for x in diagnostics): return
    item = dict(key=key, kind=kind, message='; '.join(map(str, messages)), stack='', occurrences=1,
                locations=[dict(location, selector=selector)], screenshots=[])
    diagnostics.append(item)
    await screenshot_issue(pg, item)


async def screenshot_issue(pg, item):
    directory = os.environ.get('QC_ARTIFACTS_DIR')
    if not directory or item.get('screenshots'): return
    target = Path(directory) / (item['key'] + '.png'); target.parent.mkdir(parents=True, exist_ok=True)
    try:
        await pg.screenshot(path=str(target), timeout=5000)
        item.setdefault('screenshots', []).append(str(target.resolve()))
    except Exception as exc: item['screenshot_error'] = str(exc)


async def capture_errors(pg, rep):
    for item in rep.get('diagnostics', []):
        if item['kind'] in ('javascript', 'console', 'runner', 'panel') and not item.get('screenshots'):
            await screenshot_issue(pg, item)


async def select_view(pg, rep, scr, lv, vw, stages, stage_label='all'):
    context(rep, phase='map', scr=scr, lv=lv, vw=vw, stage=stage_label)
    await pg.click(f'[data-vw="{vw}"]')
    await pg.evaluate('([a,b,c])=>window.__PM3__.set(a,b,c)', [scr,lv,stages])
    await settle(pg)


async def tour_open(pg, rep, stage):
    context(rep, phase='tour', scr='ns', stage=stage)
    await pg.click('[data-scr="ns"]'); await pg.click(f'#stSeg [data-st="{stage}"]'); await settle(pg)
    if not await pg.evaluate("!!document.querySelector('#btnTour') && !document.querySelector('#btnTour').hidden"): return False
    await pg.click('#btnTour')
    if await pg.locator('#tourStartDlg:not([hidden]) [data-tsd="first"]').count(): await pg.click('#tourStartDlg [data-tsd="first"]')
    if await pg.locator('#scenask:not([hidden]) button').count(): await pg.locator('#scenask:not([hidden]) button').first.click()
    await settle(pg)
    return True


async def tour_last(pg):
    text = await pg.locator('#tourcap .tc-count').text_content()
    match = re.search(r'전체\s*(\d+)/(\d+)', text or '')
    return bool(match and int(match.group(1)) >= int(match.group(2)))

JS_MEASURE = r"""
(opt) => {
  const R = el => { const r = el.getBoundingClientRect(); return {x:r.left, y:r.top, w:r.width, h:r.height}; };
  const boxes = [...document.querySelectorAll('#board .nd[data-id]')].filter(b => b.offsetParent !== null).map(b => ({id:b.dataset.id, ...R(b)}));
  const ov = [];
  for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
    const a = boxes[i], b = boxes[j];
    const ix = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x), iy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
    if (ix > 1 && iy > 1) ov.push([a.id, b.id]);
  }
  const paths = [...document.querySelectorAll('#edges path[data-a]')];
  const hits = [], segs = [];
  paths.forEach((p, pi) => {
    const L = p.getTotalLength(), m = p.getScreenCTM(); if (!m || !L) return;
    const pts = [];
    for (let s = 0; s <= L; s += 4) { const q = p.getPointAtLength(s); pts.push([q.x * m.a + q.y * m.c + m.e, q.x * m.b + q.y * m.d + m.f]); }
    const a = p.dataset.a, b = p.dataset.b;
    const crossed = new Set();
    boxes.forEach(bx => {
      if (bx.id === a || bx.id === b) return;
      const pad = 2;
      if (pts.some(([x, y]) => x > bx.x + pad && x < bx.x + bx.w - pad && y > bx.y + pad && y < bx.y + bx.h - pad)) crossed.add(bx.id);
    });
    crossed.forEach(id => hits.push([a, b, id]));
    for (let k = 1; k < pts.length; k++) segs.push({pi, x1:pts[k-1][0], y1:pts[k-1][1], x2:pts[k][0], y2:pts[k][1]});
  });
  // 나란히 가는 선: 서로 다른 선의 수평·수직 조각이 1~6px 간격으로 20px 이상 겹침
  const H = {}, V = {};
  segs.forEach(s => {
    if (Math.abs(s.y1 - s.y2) < 0.5) { const k = Math.round(s.y1); (H[k] = H[k] || []).push(s); }
    else if (Math.abs(s.x1 - s.x2) < 0.5) { const k = Math.round(s.x1); (V[k] = V[k] || []).push(s); }
  });
  const near = {};
  const scan = (M, horiz) => {
    const keys = Object.keys(M).map(Number).sort((a, b) => a - b);
    keys.forEach(k => { for (let d = 1; d <= 6; d++) { const o = M[k + d]; if (!o) continue;
      M[k].forEach(s => o.forEach(t => { if (s.pi === t.pi) return;
        const distance = Math.abs(horiz ? s.y1 - t.y1 : s.x1 - t.x1);
        if (distance < 1 || distance > 6) return;
        const a1 = horiz ? Math.min(s.x1, s.x2) : Math.min(s.y1, s.y2), a2 = horiz ? Math.max(s.x1, s.x2) : Math.max(s.y1, s.y2);
        const b1 = horiz ? Math.min(t.x1, t.x2) : Math.min(t.y1, t.y2), b2 = horiz ? Math.max(t.x1, t.x2) : Math.max(t.y1, t.y2);
        const lo = Math.max(a1, b1), hi = Math.min(a2, b2);
        if (hi > lo) { const key = Math.min(s.pi, t.pi) + '-' + Math.max(s.pi, t.pi) + '@' + (horiz ? 'h' : 'v') + k; (near[key] ||= []).push([lo, hi]); }
      })); } });
  };
  scan(H, true); scan(V, false);
  // Union projected intervals: counting unique rows misses a long parallel pair.
  const pairs = new Set(); Object.entries(near).forEach(([key, spans]) => {
    spans.sort((a,b) => a[0]-b[0]); let total=0, lo=spans[0][0], hi=spans[0][1];
    spans.slice(1).forEach(([a,b]) => { if(a<=hi+.1) hi=Math.max(hi,b); else {total+=hi-lo;lo=a;hi=b;} });
    total+=hi-lo; if(total>=20) pairs.add(key.split('@')[0]);
  });
  const par = [...pairs].map(k => k.split('-').map(i => paths[+i].dataset.a + '→' + paths[+i].dataset.b));
  return {boxes:boxes.length, ids:boxes.map(b => b.id), overlaps:ov, edge_box_hits:hits, parallel:par, edges:paths.length};
}
"""

JS_UI = """() => {
  // 비직교 꺾임: 연결선 조각 중 가로·세로가 아닌 것 / 곡선 모서리
  let diag = 0, curve = 0; document.querySelectorAll('#edges path.e').forEach(p => { const d = p.getAttribute('d') || ''; if (/[QCA]/.test(d)) curve++;
    const pts = (d.match(/-?\\d+\\.?\\d*,-?\\d+\\.?\\d*/g) || []).map(s => s.split(',').map(Number));
    for (let i = 1; i < pts.length; i++) if (Math.abs(pts[i][0] - pts[i-1][0]) > 0.6 && Math.abs(pts[i][1] - pts[i-1][1]) > 0.6) diag++; });
  // 글자 넘침: 글이 든 요소가 넘치는데 넘친 부분을 숨김(스크롤로 볼 수 있는 곳은 제외)
  const vis = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; }, clip = [];
  document.querySelectorAll('#stagehead *, #corner *, #labels *, #board .nd, #board .nd *').forEach(e => { if (!vis(e) || !e.textContent.trim()) return; const cs = getComputedStyle(e);
    const hx = /hidden|clip/.test(cs.overflowX) || cs.textOverflow === 'ellipsis', hy = /hidden|clip/.test(cs.overflowY) || (cs.webkitLineClamp && cs.webkitLineClamp !== 'none');   // 방향별로: 스크롤로 볼 수 있으면 잘림 아님
    if ((hx && e.scrollWidth > e.clientWidth + 1) || (hy && e.scrollHeight > e.clientHeight + 1)) clip.push((e.id || e.className || e.tagName) + ': ' + e.textContent.trim().slice(0, 24)); });
  // Text may escape a dark heading with overflow:visible and become unreadable on the white board.
  document.querySelectorAll('#stagehead .cv.r1').forEach(e => { if (!vis(e)) return; const parent=e.getBoundingClientRect();
    [...e.children].filter(c=>c.tagName==='SPAN'&&vis(c)&&c.textContent.trim()).forEach(c=>{const r=c.getBoundingClientRect();
      if(r.top<parent.top-1||r.bottom>parent.bottom+1)clip.push('stage heading outside header: '+c.textContent.trim().slice(0,40));}); });
  // 첫 레인 가림: 맨 위로 스크롤했을 때 고정 머리줄 아래 끝 > 가장 위 박스 위 끝
  const w = document.querySelector('#wrap'), st0 = w.scrollTop; w.scrollTop = 0;
  const hb = document.querySelector('#stagehead').getBoundingClientRect().bottom, nb = Array.from(document.querySelectorAll('#board .nd')).filter(vis).map(n => n.getBoundingClientRect().top);
  const covered = nb.length && Math.min.apply(null, nb) < hb - 1 ? 1 : 0; w.scrollTop = st0;
  // 박스 높이 종류 (설명 메모 제외)
  const hs = new Set(Array.from(document.querySelectorAll('#board .nd')).filter(n => vis(n) && !/k-why|k-pt/.test(n.className)).map(n => Math.round(n.getBoundingClientRect().height)));
  /* v26 화살표: 서로 다른 화살표가 같은 선 위(1.5px 안)에서 10px 넘게 겹침 · 그중 점선·실선 · 꺾임점 공유 · 왼쪽이 아닌 곳으로 들어감 */
  const EP = Array.from(document.querySelectorAll('svg path[data-a]')).filter(p => /^M/.test(p.getAttribute('d') || '')).map(p => ({dash: /[0-9]/.test(getComputedStyle(p).strokeDasharray || ''), q: (p.getAttribute('d').match(/-?[0-9.]+/g) || []).map(Number).reduce((a, v, i, arr) => (i % 2 ? a : a.concat([[v, arr[i + 1]]])), [])})).filter(l => l.q.length >= 2);
  const SG = []; EP.forEach((l, k) => { for (let i = 0; i < l.q.length - 1; i++){ const a = l.q[i], b = l.q[i + 1], h = Math.abs(a[1] - b[1]) < .6, v = Math.abs(a[0] - b[0]) < .6; if (h === v) continue; SG.push({k, h, c: h ? a[1] : a[0], lo: Math.min(h ? a[0] : a[1], h ? b[0] : b[1]), hi: Math.max(h ? a[0] : a[1], h ? b[0] : b[1])}); } });
  SG.sort((x, y) => x.c - y.c); let eov = 0, emix = 0;
  for (let i = 0; i < SG.length; i++) for (let j = i + 1; j < SG.length && SG[j].c - SG[i].c < 1.5; j++){ const s = SG[i], t = SG[j]; if (s.k === t.k || s.h !== t.h || Math.min(s.hi, t.hi) - Math.max(s.lo, t.lo) < 10) continue; eov++; if (EP[s.k].dash !== EP[t.k].dash) emix++; }
  const BD = {}; EP.forEach((l, k) => l.q.slice(1, -1).forEach(p => { const key = Math.round(p[0]) + ',' + Math.round(p[1]); (BD[key] = BD[key] || new Set()).add(k); }));
  const notLeft = EP.filter(l => { const n = l.q.length, a = l.q[n - 2], b = l.q[n - 1]; return !(Math.abs(a[1] - b[1]) < .6 && b[0] > a[0]); }).length;
  return {nonorth:diag, curved:curve, clipped:clip.length, clip_ex:clip.slice(0, 3), head_cover:covered, height_kinds:hs.size, heights:Array.from(hs).sort((a, b) => a - b),
    edge_overlap:eov, edge_overlap_dash:emix, shared_bends:Object.values(BD).filter(s => s.size > 1).length, entry_not_left:notLeft, edges_n:EP.length};
}"""

@contextmanager
def serve_html(path):
    """Serve one local artifact; managed Chromium may disallow file:// URLs."""
    raw = Path(path).read_bytes()
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == '/favicon.ico':
                self.send_response(204); self.end_headers(); return
            if self.path != '/map.html':
                self.send_error(404); return
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers(); self.wfile.write(raw)
        def log_message(self, *_): pass
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True); thread.start()
    try: yield f'http://127.0.0.1:{server.server_port}/map.html'
    finally: server.shutdown(); server.server_close(); thread.join(timeout=2)


ONLY = [x for x in os.environ.get('QC_ONLY', '').split(',') if x]
async def run(path, part='all'):
    rep = {'screens': [], 'errors': [], 'panels_failed': [], 'panels_checked': 0, 'source_checks': [], 'source_failures': [], 'shared_ui': [], 'part': part, 'diagnostics': []}
    started = time.monotonic()
    with serve_html(path) as local_url:
        async with async_playwright() as p:
            browser_path = os.environ.get('QC_CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser')
            browser = await p.chromium.launch(**({'executable_path': browser_path} if browser_path else {}))
            pg = await browser.new_page(viewport=PROFILE['viewport'])
            pg.set_default_timeout(10000)
            context(rep, phase='load')
            pg.on('pageerror', lambda error: record_error(rep, str(error), getattr(error, 'stack', '')))
            pg.on('console', lambda msg: record_error(rep, 'console: '+msg.text, json.dumps(msg.location), 'console') if msg.type == 'error' else None)
            await pg.add_init_script(INIT_QC)
            try:
                await pg.goto(local_url)
                await pg.wait_for_function('!!window.__PM3__ && !!window.__PMD__')
                await pg.evaluate('document.fonts.ready')
                await settle(pg)
                # Expected data comes from the immutable artifact, not mutable runtime state.
                # JS roundtrips also collapse 1.0 to 1, invalidating exact source hashes.
                from htmlio import split
                data = split(Path(path).read_text(encoding='utf-8'))[0]
                if not isinstance(data, dict) or not data.get('stages') or not data.get('views'):
                    raise ValueError('Rendered HTML has no usable PMD stages/views')
                source_mode = bool(data.get('sourceAsis'))
                if part in ('all','quick','asis'):
                    await check_shared_ui(pg, data, rep)
                    if source_mode:
                        context(rep, phase='source-asis')
                        await check_source_contract(pg, data, rep)
                stages = [str(stage['n']) for stage in data['stages']]
                quick = part == 'quick'
                rep['expected_screens'] = sum(1 for scr in ('asis','ns') if part in ('all','quick',scr) for lv in (4,5,6) for vw in (('compact',) if quick else ('compact','flow')) if not ONLY or f'{scr}{lv}{vw}' in ONLY) * (1 if quick else 1+len(stages))
                for scr in ('asis','ns'):
                    if part not in ('all','quick',scr): continue
                    for lv in (4,5,6):
                        for vw in (('compact',) if quick else ('compact','flow')):
                            if ONLY and f'{scr}{lv}{vw}' not in ONLY: continue
                            for st in (['all'] if quick else ['all']+stages):
                                chosen = [int(x) for x in stages] if st=='all' else [int(st)]
                                await select_view(pg, rep, scr, lv, vw, chosen, st)
                                measured = await pg.evaluate(JS_MEASURE, {}); ui = await pg.evaluate(JS_UI)
                                expected = [n['id'] for n in data['views'][str(lv)][scr]['nodes'] if st=='all' or str(n['st'])==st]
                                missing=sorted(set(expected)-set(measured['ids'])); extra=sorted(set(measured['ids'])-set(expected))
                                screen=dict(scr=scr,lv=lv,vw=vw,st=st,data=len(expected),shown=measured['boxes'],missing=missing[:5],extra=extra[:5],overlaps=len(measured['overlaps']),ov_ex=measured['overlaps'][:3],edge_box_hits=len(measured['edge_box_hits']),hit_ex=measured['edge_box_hits'][:3],parallel=len(measured['parallel']),par_ex=measured['parallel'][:3],edges=measured['edges'],**ui)
                                rep['screens'].append(screen)
                                if source_mode and scr=='asis':
                                    screen.update(await check_source_view(pg, data, rep, lv, vw, chosen))
                                problems=[f'{key}: {screen[key]}' for key in ('missing','extra','overlaps','edge_box_hits','parallel','nonorth','curved','clipped','head_cover','edge_overlap') if screen.get(key)]
                                await capture_issue(pg,rep,'map',problems,'#board, #edges')
                                # Reuse this exact rendered view for checks formerly repeated in panels.
                                if not quick and st=='all' and vw=='flow':
                                    bad=await pg.evaluate(JS_LAB,'#board');rep.setdefault('label_bad',[]).extend([f'{scr} Lv.{lv}: '+x for x in bad]);await capture_issue(pg,rep,'edge-label',bad,'#board .elab')
                                if not quick and st=='all' and scr=='ns' and lv in (5,6):
                                    bad=await pg.evaluate(JS_GONE);rep.setdefault('gone_bad',[]).extend([f'Lv.{lv} {vw}: '+x for x in bad]);await capture_issue(pg,rep,'gone',bad,'#board .k-gone, #board .k-why')
                                if not quick and st=='all' and scr=='ns' and lv==6 and vw=='compact':
                                    rep.setdefault('text_style',[]).extend(await pg.evaluate(JS_TEXT,'#board .nd.k-a, #board .nd.k-mk, #board .nd.k-why'))
                                await capture_errors(pg,rep)
                if part not in ('asis','ns') and not ONLY:
                    await pg.click('[data-vw="compact"]');await pg.click('#stSeg [data-st="all"]')
                    for scr in ('asis','ns'):
                        await pg.click(f'[data-scr="{scr}"]');await pg.click('[data-lv="6"]');await settle(pg)
                        ui_ids={node['id'] for node in data['views']['6'][scr]['nodes'][::25]}
                        for node in (data['views']['6'][scr]['nodes'][::12] if quick else data['views']['6'][scr]['nodes']):
                            context(rep,phase='detail',scr=scr,node=node['id'],selector='#panel')
                            okay=await pg.evaluate("""id=>{try{window.__PM3__.showNode(id)}catch(e){return 'ERR '+e.stack};const p=document.getElementById('panel');return p&&!p.hidden&&p.textContent.trim().length>20?'ok':'empty'}""",node['id'])
                            rep['panels_checked']+=1
                            if okay!='ok':rep['panels_failed'].append([scr,node['id'],okay]);await capture_issue(pg,rep,'detail',[okay],'#panel')
                            elif node['id'] in ui_ids:
                                bad=await pg.evaluate(JS_WIN,'#panel');rep.setdefault('ui_clip',[]).extend([f'상세 창 {scr} {node["id"]}: '+x for x in bad]);await capture_issue(pg,rep,'clip',bad,'#panel')
                            await capture_errors(pg,rep)
                        await pg.keyboard.press('Escape')
                    # One tour walk checks text + visibility together, preserving the
                    # former 12 text steps/stage and first/last 5 visibility steps.
                    visible_stages={int(stages[0]),int(stages[-1])}
                    for st in map(int,stages):
                        if not await tour_open(pg,rep,st):break
                        for step in range(4 if quick else 12):
                            context(rep,phase='tour',scr='ns',stage=st,step=step+1,selector='#tourcap')
                            bad=await pg.evaluate(JS_WIN,'#tourcap')
                            bad+=['번호 넘침 '+x for x in await pg.evaluate("[...document.querySelectorAll('#tourcap .tc-steps li i')].filter(e=>e.scrollWidth>e.clientWidth+1||e.getBoundingClientRect().height>32).map(e=>e.textContent.trim())")]
                            rep.setdefault('ui_clip',[]).extend([f'흐름 따라가기 {st}: '+x for x in bad]);await capture_issue(pg,rep,'clip',bad,'#tourcap')
                            rep.setdefault('text_style',[]).extend(await pg.evaluate(JS_TEXT,'#tourcap .tc-d, #tourcap .tc-steps span, #tourcap p'))
                            if not quick and st in visible_stages and step<5:
                                visible=await pg.evaluate(JS_TOURVIS);rep['tour_steps']=rep.get('tour_steps',0)+1
                                if visible!='보임':rep.setdefault('tour_hidden',[]).append(f'{st}단계 {step+1}걸음: {visible}');await capture_issue(pg,rep,'tour-visibility',[visible],'#board .nd.hl, #board .tcard')
                            await capture_errors(pg,rep)
                            if await tour_last(pg):break
                            await pg.keyboard.press('ArrowRight')
                            if await pg.locator('#scenask:not([hidden]) button').count():await pg.locator('#scenask:not([hidden]) button').first.click()
                            await settle(pg)
                        await pg.keyboard.press('Escape')
                    await select_view(pg,rep,'ns',6,'compact',[int(x) for x in stages])
                    if not quick:
                        why=pg.locator('#board .nd.k-why').first
                        if await why.count():
                            await why.scroll_into_view_if_needed();await why.click();await settle(pg)
                            okay=await pg.evaluate("()=>{const p=document.querySelector('#panel');return !!(p&&!p.hidden&&/없어지는|흡수|삭제/.test(p.innerText))}")
                            if not okay:rep.setdefault('gone_bad',[]).append('설명 박스를 눌러도 상세 창에 소멸 설명이 없음');await capture_issue(pg,rep,'gone-detail',['소멸 설명 없음'],'#panel')
                            await pg.keyboard.press('Escape')
                    if await pg.evaluate("()=>{const b=document.querySelector('#btnAx');return !!(b&&!b.hidden)}"):
                        context(rep,phase='ax',selector='#axw');await pg.click('#btnAx');await settle(pg)
                        if not await pg.evaluate("()=>{const e=document.querySelector('#axw');return e&&!e.hidden&&e.textContent.length>100}"):record_error(rep,'#axw 안 열림',kind='panel')
                        await capture_errors(pg,rep);await pg.keyboard.press('Escape')
                    for button,selector in (('#btnMap','#amap'),('#btnPage','#apage')):
                        context(rep,phase='agent',selector=selector);await pg.click(button);await settle(pg)
                        if not await pg.evaluate("selector=>{const e=document.querySelector(selector);return e&&!e.hidden&&e.textContent.length>100}",selector):record_error(rep,f'{selector} 안 열림',kind='panel')
                        else:
                            pages=await pg.evaluate("[...document.querySelectorAll('#apage .apn[data-page]')].map(e=>e.dataset.page)") if selector=='#apage' else ['']
                            for agent in pages:
                                context(rep,phase='agent',agent=agent,selector=selector)
                                if agent:await pg.click(f'#apage .apn[data-page="{agent}"]');await settle(pg)
                                bad=await pg.evaluate(JS_WIN,selector);rep.setdefault('ui_clip',[]).extend([f'{selector} {agent}: '+x for x in bad]);await capture_issue(pg,rep,'clip',bad,selector)
                                rep.setdefault('text_style',[]).extend([f'{selector} {agent}: '+x for x in await pg.evaluate(JS_TEXT,'#apm' if selector=='#apage' else selector)])
                                if selector=='#apage':
                                    bad=await pg.evaluate(JS_LAB,'#apm');rep.setdefault('label_bad',[]).extend([f'Agent 페이지 {agent}: '+x for x in bad]);await capture_issue(pg,rep,'edge-label',bad,'#apm .elab')
                                await capture_errors(pg,rep)
                        await pg.keyboard.press('Escape')
                await capture_errors(pg,rep)
            except Exception as exc:
                rep['status']='error';item=record_error(rep,f'{type(exc).__name__}: {exc}',traceback.format_exc(),'runner');await screenshot_issue(pg,item)
            finally:
                await browser.close()
    rep.pop('_context',None);rep['duration_seconds']=round(time.monotonic()-started,3)
    return finish(rep)

JS_WIN = """(sel) => { const root = document.querySelector(sel); if (!root) return []; const out = [];
  const css = element => { const path=[]; let node=element; while(node && node!==root){ if(node.id){path.unshift('#'+CSS.escape(node.id));break;} path.unshift(node.tagName.toLowerCase()+':nth-child('+([...node.parentElement.children].indexOf(node)+1)+')');node=node.parentElement;} return sel+' '+path.join(' > '); };
  root.querySelectorAll('*').forEach(e => { const r = e.getBoundingClientRect(); if (!r.width || !r.height || !e.textContent.trim() || e.children.length > 3) return; const cs = getComputedStyle(e);
    const hx = /hidden|clip/.test(cs.overflowX) || cs.textOverflow === 'ellipsis', hy = /hidden|clip/.test(cs.overflowY) || (cs.webkitLineClamp && cs.webkitLineClamp !== 'none');
    if ((hx && e.scrollWidth > e.clientWidth + 1) || (hy && e.scrollHeight > e.clientHeight + 1)) out.push('잘림 [' + css(e) + '] ' + e.textContent.trim().slice(0, 30));
    else if (e.children.length === 0 && /[가-힣A-Za-z0-9]…$/.test(e.textContent.trim())) out.push('말줄임 [' + css(e) + '] ' + e.textContent.trim().slice(-30)); });
  return Array.from(new Set(out)).slice(0, 8); }"""
JS_TOURVIS = """() => { const n = document.querySelector('#board .nd.hl') || document.querySelector('#board .tcard'); if (!n) return '박스 없음';
  const r = n.getBoundingClientRect(), w = document.querySelector('#wrap').getBoundingClientRect(), c = document.querySelector('#tourcap'), capTop = c && !c.hidden ? c.getBoundingClientRect().top : innerHeight;
  const hb = document.querySelector('#stagehead').getBoundingClientRect().bottom, lr = document.querySelector('#labels').getBoundingClientRect().right;
  const vt = Math.max(0, w.top, hb), vb = Math.min(innerHeight, w.bottom, capTop), vl = Math.max(0, w.left, lr), vr = Math.min(innerWidth, w.right);
  const ix = Math.max(0, Math.min(r.right, vr) - Math.max(r.left, vl)), iy = Math.max(0, Math.min(r.bottom, vb) - Math.max(r.top, vt));
  if ((ix * iy) / Math.max(1, r.width * r.height) >= 0.6) return '보임'; if (r.bottom <= 0 || r.top >= innerHeight) return '화면 밖'; if (r.bottom > capTop) return '설명창 뒤'; if (r.top < hb) return '머리줄 뒤'; return '일부만 보임'; }"""
JS_GONE = """() => { const B = Array.from(document.querySelectorAll('#board .nd')).filter(n => n.getBoundingClientRect().width > 0), R = n => n.getBoundingClientRect(), out = [];
  const why = {}; B.filter(n => n.classList.contains('k-why')).forEach(w => { why[(w.dataset.id || '').replace('~why', '')] = w; });
  B.filter(n => n.classList.contains('k-gone')).forEach(g => { const w = why[g.dataset.id]; if (!w){ out.push(g.dataset.id + ' 설명 박스 없음'); return; }
    const a = R(g), b = R(w), dy = b.top - a.bottom; if (Math.abs(a.left - b.left) > 4 || dy < -1 || dy > 40) out.push(g.dataset.id + ' 설명 박스가 바로 밑이 아님 (dx ' + Math.round(b.left - a.left) + ', dy ' + Math.round(dy) + ')');
    if (!/line-through/.test(getComputedStyle(g.querySelector('.lbl') || g).textDecorationLine)) out.push(g.dataset.id + ' 취소선 없음'); });
  return out.slice(0, 10); }"""
JS_TEXT = """(sel) => { const RX = [/(?<![가-힣])(빠진|찾아|만들어|만듭니다|만들고|겹치는지|모아서?|나눠서?|뽑아|뽑은|챙겨|살펴)(?![가-힣])/g, /에\\s*(비교|대조)/g, /(맞는지|드는지|있는지)\\s*(비교|대조)/g, /(을|를) (보고|보며) /g, /(이|가) 낸 /g];
  const Dd = window.__PMD__ || {}, norm = z => String(z || '').replace(/\\s+/g, ' ').trim();
  const XL = norm(Object.values(Dd.A6 || {}).map(a => (a.n || '') + ' ' + (a.pain || '') + ' ' + (a.inp || '') + ' ' + (a.out || '')).concat(Object.values(Dd.A5 || {}).map(a => a.n || '')).join(' '));   /* 엑셀 원문은 고치지 않으므로 뺌 */
  const out = [];
  Array.from(document.querySelectorAll(sel)).forEach(e => (e.innerText || '').split(/\\n+/).forEach(line => { const L = norm(line).replace(/^[·•\\-–\\d.)\\s]+/, ''); if (!L) return;
    RX.forEach(r => { r.lastIndex = 0; let m; while ((m = r.exec(L))){ const a = Math.max(0, m.index - 12), ctx = L.slice(a, m.index + m[0].length + 12).trim(), lw = L.slice(Math.max(0, m.index - 10), m.index + m[0].length).trim(), rw = L.slice(m.index, m.index + m[0].length + 10).trim(); if (XL.indexOf(lw) >= 0 || XL.indexOf(rw) >= 0 || XL.indexOf(L) >= 0) continue;   /* 앞뒤 몇 글자가 엑셀 원문에 그대로 있으면 원문 */ out.push(m[0] + ' — ' + ctx); } }); }));
  return Array.from(new Set(out)).slice(0, 10); }"""
JS_LAB = """(sel) => { const root = document.querySelector(sel); if (!root) return []; const out = [];
  const L = Array.from(root.querySelectorAll('.elab')).filter(e => e.offsetWidth > 0 && getComputedStyle(e).display !== 'none');
  const N = Array.from(root.querySelectorAll('.nd')).filter(n => n.offsetWidth > 0);
  const R = e => e.getBoundingClientRect(), ov = (a, b) => Math.min(a.right, b.right) - Math.max(a.left, b.left) > 2 && Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > 2;
  L.forEach((e, i) => { if (e.scrollWidth > e.clientWidth + 1 || e.scrollHeight > e.clientHeight + 2) out.push('글자 넘침: ' + e.textContent.slice(0, 30));
    const r = R(e); const hit = N.find(n => ov(R(n), r)); if (hit) out.push('박스와 겹침: ' + e.textContent.slice(0, 20) + ' ⟂ ' + hit.dataset.id);
    for (let j = i + 1; j < L.length; j++) if (ov(R(L[j]), r)) { out.push('이름표끼리 겹침: ' + e.textContent.slice(0, 20)); break; } });
  return Array.from(new Set(out)).slice(0, 12); }"""
def finish(rep):
    S = rep['screens']
    rep['summary'] = dict(screens=len(S), count_mismatch=sum(1 for s in S if s['missing'] or s['extra']),
                          overlaps=sum(s['overlaps'] for s in S), edge_box_hits=sum(s['edge_box_hits'] for s in S),
                          parallel=sum(s['parallel'] for s in S),
                          errors=len(rep['errors']), panels_failed=len(rep['panels_failed']),
                          source_fidelity=len(rep.get('source_failures',[])), shared_ui=len(rep.get('shared_ui',[])),
                          nonorth=sum(s.get('nonorth', 0) + s.get('curved', 0) for s in S), clipped=sum(s.get('clipped', 0) for s in S),
                          head_cover=sum(s.get('head_cover', 0) for s in S), height_kinds_max=max([s.get('height_kinds', 0) for s in S] or [0]),
                          heights_used=max([len({h for s in S if s.get('lv') == 6 and s.get('vw') == v for h in s.get('heights', [])}) for v in {s.get('vw') for s in S}] or [0]), ui_clip=len(rep.get('ui_clip', [])), tour_hidden=len(rep.get('tour_hidden', [])), gone_bad=len(rep.get('gone_bad', [])), label_bad=len(set(rep.get('label_bad', []))), text_style=len(set(rep.get('text_style', []))), ui_text=len(rep.get('ui_text', [])),
                          edge_overlap_max=max([max(0,s.get('edge_overlap',0)-s.get('inherited_edge_overlap',0)) for s in S] or [0]), edge_overlap_dash_max=max([max(0,s.get('edge_overlap_dash',0)-s.get('inherited_edge_overlap_dash',0)) for s in S] or [0]), source_inherited_edge_overlap_max=max([s.get('inherited_edge_overlap',0) for s in S] or [0]), shared_bends_max=max([s.get('shared_bends', 0) for s in S] or [0]),
                          entry_left_min=round(min([1 - s.get('entry_not_left', 0) / max(1, s.get('edges_n', 1)) for s in S if s.get('edges_n')] or [1]) * 100, 1))   # v26 화살표 점검 (화면마다 가장 나쁜 값)   # tour_hidden: 흐름 따라가기 중 강조 박스가 안 보인 걸음 (단계 첫·마지막 × 5걸음)   # heights_used: 같은 보기의 Lv.6 화면 전체에서 쓰인 박스 높이 수 (2면 어느 화면이든 같은 두 높이)
    return rep

# Zero-tolerance release blockers. Text style is a separate editorial warning;
# left-entry/shared-bend diagnostics are informational, as valid loops may use them.
BLOCKING = ('count_mismatch', 'overlaps', 'edge_box_hits', 'parallel', 'errors',
            'panels_failed', 'nonorth', 'clipped', 'head_cover', 'ui_clip',
            'tour_hidden', 'gone_bad', 'label_bad', 'ui_text', 'edge_overlap_max', 'edge_overlap_dash_max',
            'source_fidelity', 'shared_ui')


def failures(rep):
    summary = rep.get('summary', {})
    out = [f'{key}={summary.get(key)}' for key in BLOCKING if summary.get(key, 0)]
    for key in ('height_kinds_max', 'heights_used'):
        if summary.get(key, 0) > 2: out.append(f'{key}={summary[key]} > 2')
    part = rep.get('part', 'all')
    if 'expected_screens' in rep and len(rep.get('screens', [])) != rep['expected_screens']:
        out.append(f"Incomplete screens: {len(rep.get('screens', []))}/{rep['expected_screens']}")
    if part != 'panels' and not rep.get('screens'):
        out.append('No process-map screen was checked')
    if part in ('all', 'quick', 'panels', 'final') and rep.get('panels_checked', 0) == 0:
        out.append('No detail panel was checked')
    if rep.get('status') == 'error': out.append('QC runner failed')
    out.extend('Worker '+message for message in rep.get('worker_failures', []))
    return out


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic_json(path, data):
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name(target.name + '.' + uuid.uuid4().hex + '.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
    os.replace(temp, target)


def tagged(rep, html, part, run_id):
    rep.update(html=str(Path(html).resolve()), sha256=file_hash(html), part=part,
               run_id=run_id, only=list(ONLY), completed_at=time.time(), runner_sha256=runner_fingerprint(), profile=PROFILE, browser=browser_identity())
    rep['failures'] = failures(rep)
    rep['status'] = 'failed' if rep['failures'] else 'passed'
    return rep


PROFILE = {'suite': 'full-v1.3.1-shared-asis', 'viewport': {'width':1800,'height':1100},
           'map_levels':[4,5,6], 'views':['compact','flow'], 'detail_sampling':'all',
           'label_and_gone_checks':'map-workers', 'source_fidelity':'visible-shared-renderer', 'tour_text_steps':12, 'tour_visible_steps':5}
FINAL = [('asis', 'asis', ''), ('ns45', 'ns', 'ns4compact,ns4flow,ns5compact,ns5flow'), ('ns6', 'ns', 'ns6compact,ns6flow'), ('panels', 'panels', '')]


_BROWSER_ID_CACHE = {}

def browser_identity():
    browser=os.environ.get('QC_CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser')
    if not browser:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p: browser=p.chromium.executable_path
    path=Path(browser)
    signature=(str(path.resolve()),path.stat().st_size,path.stat().st_mtime_ns) if path.is_file() else (str(path),None,None)
    if signature not in _BROWSER_ID_CACHE:
        result=subprocess.run([str(path),'--version'],capture_output=True,text=True,timeout=5,check=True)
        _BROWSER_ID_CACHE[signature]=dict(executable=str(path.resolve()),version=result.stdout.strip(),playwright=package_version('playwright'),binary_stat=list(signature[1:]))
    return _BROWSER_ID_CACHE[signature]


def runner_fingerprint():
    hasher=hashlib.sha256()
    for name in ('qc_browser.py','htmlio.py','ui_text_check.py','source_asis.py'):
        source=Path(__file__).resolve().parent/name
        hasher.update(name.encode());hasher.update(source.read_bytes())
    hasher.update(json.dumps([PROFILE,sys.version,browser_identity()],sort_keys=True).encode())
    return hasher.hexdigest()


def state_matches(state, html):
    return state.get('html')==str(Path(html).resolve()) and state.get('sha256')==file_hash(html) and state.get('runner_sha256')==runner_fingerprint() and state.get('profile')==PROFILE


def report_matches(report,state,name,part,only):
    return report.get('run_id')==state.get('run_id') and report.get('html')==state['html'] and report.get('sha256')==state['sha256'] and report.get('runner_sha256')==state.get('runner_sha256') and report.get('profile')==state.get('profile') and report.get('part')==part and report.get('only',[])==[x for x in only.split(',') if x]


def reusable(report,state,name,part,only):
    return report_matches(report,state,name,part,only) and report.get('status')=='passed' and not failures(report) and 'expected_screens' in report and report.get('profile')==PROFILE


def _load_report(state,name):
    path=Path(state['run_dir'])/(name+'.json')
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else None


def _start_queued(state):
    active=sum(1 for name,worker in state['workers'].items() if worker.get('pid') and not (Path(state['run_dir'])/(name+'.json')).exists() and process_alive(worker['pid']))
    for name,part,only in FINAL:
        worker=state['workers'][name]
        if worker.get('state')!='queued' or active>=state['jobs']:continue
        run_dir=Path(state['run_dir'])
        env=dict(os.environ,QC_ONLY=only,QC_RUN_ID=state['run_id'],QC_ARTIFACTS_DIR=str(run_dir/'diagnostics'/name))
        with open(run_dir/(name+'.log'),'w') as log:
            process=subprocess.Popen([sys.executable,os.path.abspath(__file__),state['html'],str(run_dir/(name+'.json')),part],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        worker.update(pid=process.pid,state='running');active+=1
    atomic_json(Path(state['root'])/'started.json',state)


def final_start(html,out,resume=True,rerun_parts=None,jobs=2):
    """Start/resume full coverage; only complete, exact-input passed parts cache.

    An active matching run is resumed without launching duplicate workers.
    Retry starts a new provenance record and copies only verified passed parts.
    """
    root=Path(out);root.mkdir(parents=True,exist_ok=True);previous=None
    path=root/'started.json'
    if path.exists():previous=json.loads(path.read_text(encoding='utf-8'))
    requested=set(rerun_parts or [])
    if not requested.issubset({name for name,_,_ in FINAL}):raise ValueError('Unknown retry parts: '+','.join(sorted(requested)))
    if resume and previous and state_matches(previous,html):
        pending=[name for name,worker in previous['workers'].items() if not (Path(previous['run_dir'])/(name+'.json')).exists() and (worker.get('state')=='queued' or (worker.get('pid') and process_alive(worker['pid'])))]
        if pending:
            if requested:raise RuntimeError('Current QC is still running; resume it before requesting a retry')
            _start_queued(previous);return previous
        reports={name:_load_report(previous,name) for name,_,_ in FINAL}
        if not requested and all(reports[name] and report_matches(reports[name],previous,name,part,only) for name,part,only in FINAL):return previous
    (root/'final.json').unlink(missing_ok=True)
    run_id=uuid.uuid4().hex;run_dir=root/run_id;run_dir.mkdir()
    state=dict(html=str(Path(html).resolve()),sha256=file_hash(html),runner_sha256=runner_fingerprint(),profile=PROFILE,start=time.time(),
               run_id=run_id,run_dir=str(run_dir.resolve()),root=str(root.resolve()),jobs=max(1,min(4,int(jobs))),workers={})
    for name,part,only in FINAL:
        item=_load_report(previous,name) if resume and previous and state_matches(previous,html) else None
        if name not in requested and item and reusable(item,previous,name,part,only):
            copy=dict(item);copy.update(run_id=run_id,reused_from=dict(run_id=item['run_id'],completed_at=item.get('completed_at')))
            atomic_json(run_dir/(name+'.json'),copy);state['workers'][name]=dict(pid=None,part=part,state='reused',reused_from=item['run_id'])
        else:state['workers'][name]=dict(pid=None,part=part,state='queued')
    atomic_json(root/'started.json',state);_start_queued(state)
    return state


def process_alive(pid):
    if not pid:return False
    try:
        os.kill(pid,0);stat=Path(f'/proc/{pid}/stat')
        return not (stat.exists() and stat.read_text().split(') ',1)[-1].startswith('Z'))
    except (ProcessLookupError,PermissionError):return False


def diagnostic_plan(reports,html,out):
    grouped={};failed_parts=[]
    for name,item in reports:
        if item.get('status')!='passed':failed_parts.append(name)
        for diagnostic in item.get('diagnostics',[]):
            key=diagnostic['key'];entry=grouped.setdefault(key,{**diagnostic,'parts':[]})
            if name not in entry['parts']:entry['parts'].append(name)
    command=' '.join(shlex.quote(str(x)) for x in [sys.executable,Path(__file__).resolve(),html,out,'retry'])
    return dict(failed_parts=failed_parts,diagnostics=list(grouped.values()),
                rerun_command=command if failed_parts else None,
                instruction='Fix the cited node/Agent/selector; after changing HTML run final-wait for full coverage. retry reuses passed parts only when HTML and runner hashes still match.')


def final_result(html,out,wait=0,quiet=False):
    """Nonblocking status/aggregation. final_wait owns bounded internal polling."""
    state=json.loads((Path(out)/'started.json').read_text(encoding='utf-8'))
    if state['html']!=str(Path(html).resolve()) or state['sha256']!=file_hash(html):
        raise ValueError('QC input differs from the file used to start this run; start a new final run')
    if state.get('runner_sha256')!=runner_fingerprint() or state.get('profile')!=PROFILE:
        raise ValueError('QC runner/profile changed; start a new final run')
    _start_queued(state)
    run_dir=Path(state['run_dir']);reports=[];pending=[]
    for name,part,only in FINAL:
        item=_load_report(state,name)
        if item is None:
            worker=state['workers'][name]
            if worker.get('state')=='queued':pending.append(name);continue
            if not process_alive(worker.get('pid')):raise RuntimeError(f'QC worker {name} exited without a report; see {run_dir/(name+".log")}')
            if time.time()-state['start']>900:raise RuntimeError(f'QC run exceeded 900 seconds; inspect worker logs in {run_dir}')
            pending.append(name);continue
        if not report_matches(item,state,name,part,only):raise ValueError(f'Stale/mixed QC result: {name}')
        reports.append((name,item))
    if pending:
        atomic_json(Path(out)/'status.json',dict(status='pending',run_id=state['run_id'],sha256=state['sha256'],pending=pending,completed=[name for name,_ in reports],jobs=state['jobs']))
        if not quiet:print('진행 중: '+', '.join(pending))
        return None
    rep=dict(screens=[],errors=[],worker_failures=[],panels_failed=[],panels_checked=0,source_checks=[],source_failures=[],shared_ui=[],part='final',diagnostics=[])
    for name,item in reports:
        for key in ('screens','errors','panels_failed','source_checks','source_failures','shared_ui','ui_clip','tour_hidden','gone_bad','label_bad','text_style','ui_text','diagnostics'):
            rep.setdefault(key,[]).extend(item.get(key,[]))
        rep['panels_checked']+=item.get('panels_checked',0)
        if item.get('status')!='passed':rep['worker_failures'].extend(name+': '+failure for failure in item.get('failures',['worker failed']))
    rep['errors']=list(dict.fromkeys(rep['errors']))
    try:
        import ui_text_check
        from htmlio import split
        rep['ui_text']=[code+' | '+text for code,text in ui_text_check.lint(split(Path(html).read_text(encoding='utf-8'))[1])]
    except Exception as exc:rep['errors'].append('UI text check failed: '+str(exc))
    rep=tagged(finish(rep),html,'final',state['run_id'])
    rep['workers']={name:dict(status=item['status'],screens=len(item['screens']),reused_from=item.get('reused_from')) for name,item in reports}
    rep['wall_seconds']=round(time.time()-state['start'],3)
    rep['repair']=diagnostic_plan(reports,html,out)
    atomic_json(Path(out)/'final.json',rep);atomic_json(Path(out)/'repair.json',rep['repair'])
    if not quiet:print(json.dumps(rep['summary'],ensure_ascii=False))
    return rep


def final_wait(html,out,timeout=50,resume=True,rerun_parts=None,jobs=2):
    """One bounded orchestration call. Never consumes a passing subset as final."""
    deadline=time.monotonic()+max(0,min(float(timeout),50))
    state=final_start(html,out,resume=resume,rerun_parts=rerun_parts,jobs=jobs)
    while True:
        result=final_result(html,out,quiet=True)
        if result is not None:return result
        if time.monotonic()>=deadline:
            pending=json.loads((Path(out)/'status.json').read_text(encoding='utf-8'))
            pending['resume_command']=' '.join(shlex.quote(str(x)) for x in [sys.executable,Path(__file__).resolve(),html,out,'final-wait'])
            return pending
        time.sleep(min(.25,max(0,deadline-time.monotonic())))


COMMON_CONTROLS = ('scrSeg','lvSeg','stSeg','vwSeg','zOut','zv','zIn','zFit',
                   'btnPresent','btnFlow','btnEdit','btnExport')
JS_SHARED_UI = r'''(ids) => {
 const visible=e=>!!(e&&e.getBoundingClientRect().width&&e.getBoundingClientRect().height&&getComputedStyle(e).visibility!=='hidden');
 const style=e=>{if(!e)return null;const s=getComputedStyle(e);return ['fontFamily','fontSize','fontWeight','borderRadius','borderStyle','borderWidth','padding'].map(k=>s[k]);};
 return {controls:Object.fromEntries(ids.map(id=>{const e=document.getElementById(id);return [id,{visible:visible(e),disabled:!!(e&&e.disabled),style:style(e)}]})),
   board:visible(document.getElementById('board')),frame:!!document.querySelector('#sourceAsisFrame, #sourceAsisPanel, iframe[srcdoc]'),
   bodySource:document.body.classList.contains('source-asis'),
   typography:style(document.querySelector('#board .nd .lbl')),
   boardStyle:style(document.getElementById('board'))};
}'''


def shared_ui_errors(states):
    """Compare shared chrome, allowing semantic node colours/content to differ."""
    errors=[]
    for scr,state in states.items():
        if state.get('frame') or state.get('bodySource'):
            errors.append(scr+': source HTML/iframe presentation is forbidden; use the shared process-map renderer')
        if not state.get('board'):errors.append(scr+': shared #board is not visible')
        for name in COMMON_CONTROLS:
            control=state.get('controls',{}).get(name,{})
            if not control.get('visible') or control.get('disabled'):
                errors.append(scr+': common control #'+name+' is hidden, missing or disabled')
    if 'asis' in states and 'ns' in states:
        a,b=states['asis'],states['ns']
        for name in COMMON_CONTROLS:
            if a.get('controls',{}).get(name,{}).get('style')!=b.get('controls',{}).get(name,{}).get('style'):
                errors.append('As-Is/To-be control style differs: #'+name)
        for key in ('typography','boardStyle'):
            if a.get(key) is not None and b.get(key) is not None and a.get(key)!=b.get(key):
                errors.append('As-Is/To-be shared '+key+' differs')
    return errors


async def check_shared_ui(pg, data, rep):
    if await pg.locator('#sourceAsisFrame, #sourceAsisPanel, iframe[srcdoc]').count():
        rep['shared_ui'].append('Source HTML/iframe presentation is forbidden; use the shared process-map renderer')
        return
    states={};stages=[s['n'] for s in data['stages']]
    for scr in ('asis','ns'):
        await select_view(pg,rep,scr,6,'compact',stages)
        states[scr]=await pg.evaluate(JS_SHARED_UI,COMMON_CONTROLS)
        # Exercise reversible shared controls. Restore their state before map QC.
        context(rep,phase='shared-ui',scr=scr)
        zoom=await pg.evaluate('window.__PM3__.S.zoom')
        await pg.click('#zIn');await settle(pg)
        if await pg.evaluate('window.__PM3__.S.zoom')<=zoom:
            rep['shared_ui'].append(scr+': zoom-in control did not change scale')
        await pg.click('#zOut');await settle(pg)
        for button,field in (('#btnEdit','edit'),('#btnFlow','fedit')):
            await pg.click(button);await settle(pg)
            if not await pg.evaluate('(field)=>!!window.__PM3__.S[field]',field):
                rep['shared_ui'].append(scr+': '+button+' did not activate shared editing')
            await pg.click(button);await settle(pg)
        await pg.click('#btnPresent');await settle(pg)
        if not await pg.evaluate("document.body.classList.contains('present')"):
            rep['shared_ui'].append(scr+': presentation mode did not open')
        await pg.click('#btnExitPresent');await settle(pg)
    rep['shared_ui'].extend(shared_ui_errors(states))
    await capture_issue(pg,rep,'shared-ui',rep['shared_ui'],'#controls, #stageWrap')


JS_SOURCE_VISIBLE = r'''() => {
 const api=window.__PM3__,m=api.M(), vis=e=>!!(e.getBoundingClientRect().width&&e.getBoundingClientRect().height);
 return {sourceLayout:!!m.sourceLayout,transform:m.sourceTransform||null,
   labels:[...document.querySelectorAll('#board .elab')].filter(vis).map(e=>({index:e.dataset.sourceLabelIndex??null,text:e.textContent.trim(),x:parseFloat(e.style.left),y:parseFloat(e.style.top)})),
   junctions:[...document.querySelectorAll('#edges circle[data-source-junction]')].map(e=>({id:e.dataset.sourceJunction,x:Number(e.getAttribute('cx')),y:Number(e.getAttribute('cy')),r:Number(e.getAttribute('r'))})),
   nodes:[...document.querySelectorAll('#board .nd[data-id]')].filter(vis).map(e=>({id:e.dataset.id,sourceId:e.dataset.sourceId||'',x:e.offsetLeft,y:e.offsetTop,w:e.offsetWidth,h:e.offsetHeight})),
   edges:[...document.querySelectorAll('#edges path[data-a]')].map(e=>({source:e.dataset.a,target:e.dataset.b,kind:e.dataset.kind||'',sourceKind:e.dataset.sourceKind||'',sourceStyle:e.dataset.sourceStyle||'',label:e.dataset.label||'',
      points:((e.getAttribute('d')||'').match(/-?[0-9.]+/g)||[]).map(Number).reduce((a,v,i,arr)=>i%2?a:a.concat([[v,arr[i+1]]]),[]),
      path:e.getAttribute('d')||'',index:e.dataset.edgeIndex,dash:getComputedStyle(e).strokeDasharray,marker:e.getAttribute('marker-end'),
      segments:[...document.querySelectorAll('#edges path.source-segment')].filter(q=>q.dataset.edgeIndex===e.dataset.edgeIndex).map(q=>({
       visualKind:q.dataset.sourceStyle||'',dash:getComputedStyle(q).strokeDasharray,marker:q.getAttribute('marker-end'),
       points:((q.getAttribute('d')||'').match(/-?[0-9.]+/g)||[]).map(Number).reduce((a,v,i,arr)=>i%2?a:a.concat([[v,arr[i+1]]]),[])
      }))}))};
}'''


def dash_pattern(value):
    return [round(float(n),3) for n in re.findall(r'-?[0-9]+(?:\.[0-9]+)?',str(value or ''))]


def canonical_route(points, tolerance=.11):
    """Remove duplicate/between-collinear vertices; preserve bends and reversals."""
    out=[]
    for point in points:
        point=list(point)
        if out and all(abs(a-b)<=tolerance for a,b in zip(out[-1],point)):continue
        out.append(point)
        while len(out)>=3:
            a,b,c=out[-3:]
            horizontal=abs(a[1]-b[1])<=tolerance and abs(b[1]-c[1])<=tolerance
            vertical=abs(a[0]-b[0])<=tolerance and abs(b[0]-c[0])<=tolerance
            between=all(min(a[k],c[k])-tolerance<=b[k]<=max(a[k],c[k])+tolerance for k in (0,1))
            if (horizontal or vertical) and between:out.pop(-2)
            else:break
    return out


def same_route(expected, actual, tolerance=1.1):
    expected=canonical_route(expected);actual=canonical_route(actual)
    return len(expected)==len(actual) and all(abs(a-b)<=tolerance for p,q in zip(expected,actual) for a,b in zip(p,q))


def source_view_errors(level, actual, stages):
    """Verify the visible DOM against imported visual geometry, including proxies."""
    from collections import Counter
    errors=[];chosen=set(map(int,stages));transform=actual.get('transform') or {}
    if not actual.get('sourceLayout'):errors.append('shared renderer is not using imported As-Is geometry')
    if not all(isinstance(transform.get(k),(int,float)) for k in ('sx','sy','ox','oy')) or transform.get('sx',0)<=0 or transform.get('sy',0)<=0:
        return errors+['missing/invalid positive source transform']
    sx,sy,ox,oy=(transform[k] for k in ('sx','sy','ox','oy'))
    expected={k:n for k,n in level.get('nodes',{}).items() if int(n['stage']) in chosen}
    rendered={n['id']:n for n in actual.get('nodes',[])}
    if Counter(n['id'] for n in actual.get('nodes',[]))!=Counter(expected.keys()):
        errors.append('visible source nodes differ: missing='+str(sorted(set(expected)-set(rendered)))+' extra='+str(sorted(set(rendered)-set(expected))))
    for key,node in expected.items():
        if key not in rendered:continue
        got=rendered[key];want={'x':node['x']*sx+ox,'y':node['y']*sy+oy,'w':node['w']*sx,'h':node['h']*sy}
        bad={k:[want[k],got.get(k)] for k in want if not isinstance(got.get(k),(int,float)) or abs(want[k]-got[k])>1.1}
        if bad:errors.append(key+': source position/size changed '+json.dumps(bad))
        if got.get('sourceId')!=node.get('sourceId',''):errors.append(key+': sourceId metadata differs')
    expected_edges=[e for e in level.get('edges',[]) if e['source'] in expected and e['target'] in expected]
    def signature(e,rendered=False):
        return (e['source'],e['target'],e.get('sourceKind' if rendered else 'kind',''),e.get('label',''))
    wanted=Counter(signature(e) for e in expected_edges);got=Counter(signature(e,True) for e in actual.get('edges',[]))
    if wanted!=got:errors.append('visible source edge set/types/labels differ: missing='+str(list((wanted-got).elements()))+' extra='+str(list((got-wanted).elements())))
    pool={}
    for edge in actual.get('edges',[]):pool.setdefault(signature(edge,True),[]).append(edge)
    for edge in expected_edges:
        matches=pool.get(signature(edge),[])
        if not matches:continue
        found=matches.pop(0);wanted_points=[[x*sx+ox,y*sy+oy] for x,y in edge.get('points',[])]
        got_points=found.get('points',[])
        if not same_route(wanted_points,got_points):
            errors.append(edge['source']+'→'+edge['target']+': source arrow route changed')
        if edge.get('visualKind') is not None and found.get('sourceStyle')!=edge['visualKind']:
            errors.append(edge['source']+'→'+edge['target']+': source arrow style changed')
        segments=edge.get('segments',[])
        visual_expected=segments if len(segments)>1 else [edge]
        visual_actual=found.get('segments',[]) if len(segments)>1 else [found]
        if len(visual_actual)!=len(visual_expected):
            errors.append(edge['source']+'→'+edge['target']+': visible source segment count changed')
        for index,(wanted_seg,got_seg) in enumerate(zip(visual_expected,visual_actual)):
            if 'dash' in wanted_seg and dash_pattern(wanted_seg['dash'])!=dash_pattern(got_seg.get('dash')):
                errors.append(edge['source']+'→'+edge['target']+f': segment {index} dash style changed')
            if 'marker' in wanted_seg and bool(wanted_seg['marker'] and wanted_seg['marker']!='none')!=bool(got_seg.get('marker') and got_seg['marker']!='none'):
                errors.append(edge['source']+'→'+edge['target']+f': segment {index} arrowhead changed')
            if len(segments)>1:
                expected_points=[[x*sx+ox,y*sy+oy] for x,y in wanted_seg['points']]
                actual_points=got_seg.get('points',[])
                if not same_route(expected_points,actual_points):
                    errors.append(edge['source']+'→'+edge['target']+f': segment {index} visible route changed')
    hubs={p['hub'] for e in expected_edges for p in e.get('segments',[]) if p.get('hub')}
    expected_junctions={j['id']:j for j in level.get('junctions',[]) if j['id'] in hubs}
    actual_junctions={j['id']:j for j in actual.get('junctions',[])}
    if Counter(j['id'] for j in actual.get('junctions',[]))!=Counter(expected_junctions.keys()):
        errors.append('visible source junction dot set changed')
    for key,j in expected_junctions.items():
        got=actual_junctions.get(key,{})
        if any(not isinstance(got.get(k),(int,float)) or abs(got[k]-want)>1.1 for k,want in [('x',j['x']*sx+ox),('y',j['y']*sy+oy),('r',j['r'])]):
            errors.append(key+': source junction dot position/size changed')
    expected_labels={str(i):label for i,label in enumerate(level.get('labels',[])) if label['source'] in expected and label['target'] in expected}
    actual_labels={str(label.get('index')):label for label in actual.get('labels',[])}
    if Counter(str(label.get('index')) for label in actual.get('labels',[]))!=Counter(expected_labels.keys()):
        errors.append('visible source arrow label set differs (invented, hidden or duplicated labels)')
    for key,label in expected_labels.items():
        got=actual_labels.get(key,{})
        if got.get('text')!=label['text']:errors.append('source label '+key+': visible text changed')
        if any(not isinstance(got.get(k),(int,float)) or abs(got[k]-want)>1.1 for k,want in [('x',label['x']*sx+ox),('y',label['y']*sy+oy)]):
            errors.append('source label '+key+': source anchor changed')
    return errors


def source_contract_errors(data):
    """Cross-check adapted data against the independently captured source projection."""
    from collections import Counter
    from source_asis import EDGE_KINDS
    errors=[];source=data.get('sourceAsis',{});layout=data.get('sourceLayout',{})
    if layout.get('schema')!='source-layout/v1':
        return ['As-Is source requires source-layout/v1 shared geometry; iframe substitution is forbidden']
    geometry=source.get('geometry',{})
    if layout.get('source_sha256')!=source.get('sha256') or layout.get('geometry_sha256')!=source.get('geometry_sha256'):
        errors.append('source-layout provenance differs from captured source')
    for lv in ('4','5','6'):
        captured=geometry.get('levels',{}).get(lv,{});level=layout.get('levels',{}).get(lv,{})
        nodes=level.get('nodes',{});routes=level.get('edges',[]);view=data.get('views',{}).get(lv,{}).get('asis',{})
        projected=view.get('nodes',[]);ids={n['id']:n for n in projected}
        source_nodes={n['id']:n for n in captured.get('nodes',[])}
        mapping={n.get('sourceId'):k for k,n in nodes.items()}
        if not nodes or Counter(n.get('sourceId') for n in nodes.values())!=Counter(source_nodes.keys()):
            errors.append('Lv.'+lv+': source display node/proxy coverage differs')
        if Counter(n['id'] for n in projected)!=Counter(nodes.keys()):errors.append('Lv.'+lv+': As-Is view/source-layout nodes differ')
        for key,node in nodes.items():
            sid=node.get('sourceId');box=captured.get('boxes',{}).get(sid,{})
            if any(node.get(k)!=box.get(k) for k in ('x','y','w','h')):errors.append('Lv.'+lv+' '+key+': source geometry was changed during adaptation')
            label=source_nodes.get(sid,{}).get('task') or source_nodes.get(sid,{}).get('label','')
            if ids.get(key,{}).get('lb')!=label:errors.append('Lv.'+lv+' '+key+': source node label changed')
        expected_routes=[]
        for route in captured.get('routes',[]):
            expected=dict(route,source=mapping.get(route['source']),target=mapping.get(route['target']),sourceFrom=route['source'],sourceTo=route['target'])
            expected_routes.append(expected)
        if routes!=expected_routes:errors.append('Lv.'+lv+': source arrow routes/styles/types/labels were changed during adaptation')
        expected_edges=[[mapping.get(e[0]),mapping.get(e[1]),EDGE_KINDS.get(e[2]),e[3] if len(e)>3 else ''] for e in captured.get('edges',[])]
        if view.get('edges')!=expected_edges:errors.append('Lv.'+lv+': source edge graph changed during adaptation')
    return errors


async def check_source_contract(pg, data, rep):
    import source_asis
    source_asis.validate_projection(data)
    bad=source_contract_errors(data)
    rep['source_failures'].extend(bad)
    await capture_issue(pg,rep,'source-contract',bad,'#board, #edges')
    if bad:raise ValueError('Invalid shared As-Is projection: '+'; '.join(bad[:3]))
    rep['source_checks'].append(dict(renderer='shared',sha256=data['sourceAsis']['sha256'],levels=[4,5,6]))


def inherited_hub_overlaps(level, actual):
    """Account only exact overlaps independently present in captured source routes.

    All raw observations remain in screens. Each inherited span records its two
    original source routes and mapped baseline, rather than exempting a whole view.
    The caller invokes this only after all source fidelity checks have passed.
    """
    sx,sy,ox,oy=(actual['transform'][k] for k in ('sx','sy','ox','oy'))
    def segs(points):
        out=[]
        for a,b in zip(points,points[1:]):
            h=abs(a[1]-b[1])<.6;v=abs(a[0]-b[0])<.6
            if h==v:continue
            out.append(dict(h=h,c=a[1] if h else a[0],lo=min(a[0],b[0]) if h else min(a[1],b[1]),hi=max(a[0],b[0]) if h else max(a[1],b[1])))
        return out
    routes={}
    for e in level['edges']:routes.setdefault((e['source'],e['target'],e['kind'],e.get('label','')),[]).append(e)
    matched=[]
    for edge in actual['edges']:
        pool=routes.get((edge['source'],edge['target'],edge['sourceKind'],edge.get('label','')),[])
        matched.append(pool.pop(0) if pool else None)
    baseline={}
    for i,a in enumerate(matched):
        if not a:continue
        for j,b in enumerate(matched[i+1:],i+1):
            if not b:continue
            for x in segs(canonical_route(a['points'])):
                for y in segs(canonical_route(b['points'])):
                    lo,hi=max(x['lo'],y['lo']),min(x['hi'],y['hi'])
                    if x['h']!=y['h'] or abs(x['c']-y['c'])>.11 or hi-lo<=.11:continue
                    horizontal=x['h'];scale=sx if horizontal else sy;offset=ox if horizontal else oy
                    baseline.setdefault((i,j),[]).append(dict(h=horizontal,c=x['c']*(sy if horizontal else sx)+(oy if horizontal else ox),lo=lo*scale+offset,hi=hi*scale+offset,source_span=[lo,hi],source_line=x['c']))
    geometry=[]
    for index,edge in enumerate(actual['edges']):
        for segment in segs(edge['points']):geometry.append(dict(segment,index=index,dash=bool(dash_pattern(edge.get('dash')))))
    count=mixed=0;evidence=[]
    geometry.sort(key=lambda x:x['c'])
    for index,a in enumerate(geometry):
        for b in geometry[index+1:]:
            if b['c']-a['c']>=1.5:break
            if a['index']==b['index'] or a['h']!=b['h']:continue
            lo,hi=max(a['lo'],b['lo']),min(a['hi'],b['hi'])
            if hi-lo<10:continue
            pair=tuple(sorted((a['index'],b['index'])))
            found=next((span for span in baseline.get(pair,[]) if span['h']==a['h'] and abs(span['c']-a['c'])<=.11 and abs(span['c']-b['c'])<=.11 and span['lo']<=lo+.11 and span['hi']>=hi-.11),None)
            if found:
                count+=1;mixed+=a['dash']!=b['dash'];source_edges=[matched[i] for i in pair]
                evidence.append(dict(edges=list(pair),source_edges=[[e.get('sourceFrom',e['source']),e.get('sourceTo',e['target'])] for e in source_edges],
                                     axis='h' if a['h'] else 'v',span=[lo,hi],source_span=found['source_span'],source_line=found['source_line'],
                                     hubs=sorted({p['hub'] for e in source_edges for p in e.get('segments',[]) if p.get('hub')})))
    return dict(inherited_edge_overlap=count,inherited_edge_overlap_dash=mixed,inherited_source_overlaps=evidence)


async def check_source_view(pg, data, rep, lv, vw, stages):
    actual=await pg.evaluate(JS_SOURCE_VISIBLE)
    bad=source_view_errors(data['sourceLayout']['levels'][str(lv)],actual,stages)
    rep['source_failures'].extend([f'Lv.{lv} {vw} stages {stages}: '+message for message in bad])
    await capture_issue(pg,rep,'source-fidelity',bad,'#board .nd, #edges path[data-a]')
    return inherited_hub_overlaps(data['sourceLayout']['levels'][str(lv)],actual) if not bad else {}


def main(argv=None):
    args = sys.argv[1:] if argv is None else argv
    if not args:
        print('Usage: qc_browser.py map.html [report.json|directory] [all|quick|asis|ns|panels|final|result|final-wait|retry]', file=sys.stderr); return 2
    html = args[0]; out = args[1] if len(args) > 1 else None; part = args[2] if len(args) > 2 else 'all'
    run_id = os.environ.get('QC_RUN_ID') or uuid.uuid4().hex
    try:
        if part not in ('all', 'quick', 'asis', 'ns', 'panels', 'final', 'result', 'final-wait', 'retry'):
            raise ValueError('Unknown QC mode: ' + part)
        if part in ('final', 'result', 'final-wait', 'retry') and out is None: raise ValueError('Final QC requires a result directory')
        if part == 'final':
            state=final_start(html,out,jobs=int(os.environ.get('QC_JOBS','2')));print(json.dumps({'status':'started','run_id':state['run_id'],'jobs':state['jobs']}));return 0
        if part in ('final-wait','retry'):
            retry_parts=None
            if part=='retry' and (Path(out)/'started.json').exists():
                old=json.loads((Path(out)/'started.json').read_text());retry_parts=[name for name,_,_ in FINAL if (_load_report(old,name) or {}).get('status')!='passed']
            rep=final_wait(html,out,timeout=float(os.environ.get('QC_WAIT_SECONDS','50')),jobs=int(os.environ.get('QC_JOBS','2')),rerun_parts=retry_parts)
            print(json.dumps({k:rep.get(k) for k in ('status','run_id','summary','pending','repair','resume_command') if k in rep},ensure_ascii=False))
            return 3 if rep['status']=='pending' else (0 if rep['status']=='passed' else 2)
        if part == 'result':
            rep = final_result(html, out)
            return 3 if rep is None else (2 if rep['failures'] else 0)
        initial_hash = file_hash(html)
        rep = asyncio.run(run(html, part))
        if file_hash(html) != initial_hash: rep['errors'].append('HTML changed while QC was running')
        rep = tagged(finish(rep), html, part, run_id)
    except Exception as exc:
        rep = dict(screens=[], errors=[f'{type(exc).__name__}: {exc}'], panels_failed=[], panels_checked=0, source_checks=[], status='error', part=part)
        rep = finish(rep)
        rep.update(html=str(Path(html).resolve()), sha256=file_hash(html) if Path(html).is_file() else None, run_id=run_id, completed_at=time.time(), only=list(ONLY), runner_sha256=runner_fingerprint(), profile=PROFILE)
        rep['failures'] = failures(rep)
        if part in ('final', 'result', 'final-wait', 'retry'):
            print(rep['errors'][0], file=sys.stderr); return 2
    if out: atomic_json(out, rep)
    print(json.dumps(rep['summary'], ensure_ascii=False))
    for failure in rep['failures'][:12]: print('FAIL:', failure)
    for error in rep.get('errors', [])[:5]: print('ERROR:', error)
    return 2 if rep['failures'] else 0


if __name__ == '__main__':
    sys.exit(main())
