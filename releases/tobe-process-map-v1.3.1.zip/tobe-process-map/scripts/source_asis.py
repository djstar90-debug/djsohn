"""Capture As-Is data and reference geometry for the shared renderer.

capture HTML ASIS.json [--out OUT.json] stores exact UTF-8 source bytes, hashes,
DATA + saved-edit snapshot, and explicit Excel-ID correspondence. Never invents
an edge or merges nodes to make differently scoped sources appear equivalent.
verify ASIS.json validates the attachment and its Excel basis.
"""
import argparse, base64, copy, hashlib, json, re, math, os, shutil
from pathlib import Path
from collections import Counter


def canonical_numbers(value):
    # JSON.stringify uses 1 for 1.0; preserve hashes through offline save/export.
    if isinstance(value,float) and math.isfinite(value) and value.is_integer():return int(value)
    if isinstance(value,dict):return {k:canonical_numbers(v) for k,v in value.items()}
    if isinstance(value,list):return [canonical_numbers(v) for v in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(canonical_numbers(value), ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'),allow_nan=False).encode()).hexdigest()


def basis(asis):
    return digest({k: asis.get(k, {}) for k in ('A4', 'A5', 'A6')})


def snapshot(text):
    """Read JSON, never execute input JavaScript. Saved edits override base DATA."""
    match = re.search(r'\b(?:const|let|var)\s+DATA\s*=\s*', text)
    if not match:
        raise ValueError('As-Is HTML: supported JSON DATA assignment is missing; do not reconstruct silently')
    try:
        data, _ = json.JSONDecoder().raw_decode(text[match.end():])
    except (ValueError, TypeError) as exc:
        raise ValueError('As-Is HTML DATA must be a JSON object') from exc
    match = re.search(r'<script\b[^>]*\bid=["\']s04SavedEdits["\'][^>]*>(.*?)</script\s*>', text, re.S | re.I)
    if match:
        saved = json.loads(match.group(1))
        for key in ('lv3', 'lv4', 'lv5', 'lv6'):
            if key in saved:
                data[key] = saved[key]
        for key in ('orgs', 'stages'):
            if '__' + key in saved:
                data[key] = saved['__' + key]
        if '__lanes' in saved: data['splitLanes'] = saved['__lanes']
    for level in ('lv4', 'lv5', 'lv6'):
        view = data.get(level)
        if not isinstance(view, dict) or not isinstance(view.get('nodes'), list) or not isinstance(view.get('edges'), list):
            raise ValueError(f'As-Is HTML: missing nodes/edges at {level}')
        ids = [n['id'] for n in view['nodes']]
        if len(set(ids)) != len(ids):
            raise ValueError(f'As-Is HTML: duplicate IDs at {level}')
        for edge in view['edges']:
            if len(edge) < 3 or edge[0] not in ids or edge[1] not in ids:
                raise ValueError(f'As-Is HTML: dangling/malformed edge at {level}: {edge[:2]}')
    return data


def correspondence(data, asis):
    """Source row AND task label first; ID+label only when source rows are absent."""
    a6 = asis['A6']; result = {}; unmatched = []
    for node in data['lv6']['nodes']:
        key = node['id']
        label = node.get('task') or node.get('label', '')
        candidates = [k for k, row in a6.items()
                      if row.get('row') in node.get('sourceRows', []) and row.get('n') == label]
        if not node.get('sourceRows') and key in a6 and a6[key].get('n') == label:
            candidates = [key]
        if len(candidates) == 1:
            result[key] = candidates[0]
        elif len(candidates) > 1:
            raise ValueError(f'As-Is HTML: ambiguous Excel correspondence for {key}')
        else:
            unmatched.append(key)
    if len(set(result.values())) != len(result):
        raise ValueError('As-Is HTML: multiple source nodes map to one Excel task; resolve explicitly')
    return result, {'html_unmapped': unmatched, 'excel_unmapped': sorted(set(a6) - set(result.values()))}


def capture(path, asis):
    raw = Path(path).read_bytes(); text = raw.decode('utf-8-sig')
    data = snapshot(text); mapping, difference = correspondence(data, asis)
    if not mapping:
        raise ValueError('As-Is HTML and Excel have no exact ID/row+label correspondence')
    geometry = capture_geometry(text, data)
    pb = projection_basis(asis)
    return dict(schema='source-asis/v2', filename=Path(path).name,
                sha256=hashlib.sha256(raw).hexdigest(), bytes_base64=base64.b64encode(raw).decode(),
                data_sha256=digest(data), snapshot=data, mapping=mapping,
                scope_difference=difference, excel_basis=basis(asis), geometry=geometry,
                geometry_sha256=digest(geometry), projection_basis=pb, projection_basis_sha256=digest(pb))


def validate(payload, asis=None):
    if payload.get('schema') not in ('source-asis/v1', 'source-asis/v2'):
        raise ValueError('As-Is source schema missing or unsupported')
    raw = base64.b64decode(payload['bytes_base64'], validate=True)
    if hashlib.sha256(raw).hexdigest() != payload['sha256']:
        raise ValueError('As-Is HTML source hash mismatch')
    data = snapshot(raw.decode('utf-8-sig'))
    if digest(data) != payload['data_sha256'] or data != payload['snapshot']:
        raise ValueError('As-Is snapshot differs from embedded original HTML')
    if payload.get('schema') == 'source-asis/v2':
        if digest(payload.get('geometry')) != payload.get('geometry_sha256'):
            raise ValueError('As-Is source geometry hash mismatch')
        if payload.get('geometry') is not None: validate_geometry(payload['geometry'], data)
        pb=payload.get('projection_basis')
        if pb is not None and digest(pb)!=payload.get('projection_basis_sha256'):raise ValueError('As-Is projection basis hash mismatch')
        if pb is not None and correspondence(data,pb)!=(payload['mapping'],payload['scope_difference']):raise ValueError('Source projection correspondence differs')
    if asis is not None:
        if basis(asis) != payload['excel_basis']:
            raise ValueError('Excel changed since As-Is source capture; recapture and review differences')
        mapping, difference = correspondence(data, asis)
        if mapping != payload['mapping'] or difference != payload['scope_difference']:
            raise ValueError('As-Is correspondence or scope difference was altered')
    return payload


def attach(asis, path):
    result = copy.deepcopy(asis)
    result['source_html'] = capture(path, asis)
    return result


def mapped_edges(payload):
    """Only genuinely matched endpoints enter Excel analytical topology."""
    validate(payload)
    mapping = payload['mapping']; kinds = EDGE_KINDS
    out = []
    for edge in payload['snapshot']['lv6']['edges']:
        if edge[0] in mapping and edge[1] in mapping:
            if edge[2] not in kinds:
                raise ValueError('Unsupported As-Is analytical edge type: ' + str(edge[2]))
            out.append([mapping[edge[0]], mapping[edge[1]], kinds[edge[2]], edge[3] if len(edge) > 3 else ''])
    return out


EDGE_KINDS = {'std':'s', 'normal':'s', 'manual':'s', 'conditional':'b', 'cond':'b',
              'rework':'r', 'parallel':'p', 'fork':'p', 'join':'s'}


def path_points(value):
    """Import source polyline commands, never regenerate a route."""
    tokens = re.findall(r'[A-Za-z]|[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?', value or '')
    points=[]; i=0; command=None
    while i<len(tokens):
        if tokens[i].isalpha(): command=tokens[i]; i+=1
        if command not in ('M','L','H','V'):
            raise ValueError('Unsupported source path command: '+str(command))
        count=1 if command in ('H','V') else 2
        if i+count>len(tokens): raise ValueError('Truncated source path')
        values=[float(x) for x in tokens[i:i+count]];i+=count
        if command in ('H','V'):
            if not points:raise ValueError('Source path H/V before M')
            point=[values[0],points[-1][1]] if command=='H' else [points[-1][0],values[0]]
        else:point=values
        if not points or point!=points[-1]:points.append(point)
        if command=='M':command='L'
    if len(points)<2:raise ValueError('Source edge needs at least two points')
    return points


def capture_geometry(text, data):
    """Capture a supported source renderer once in an isolated no-network browser.

    Its DOM is discarded. Only data and geometry enter the shared output UI.
    Data-only sources can be audited, but build fails without reference geometry.
    """
    if '__PROCESS_MAP_QA' not in text:return None
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        executable=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('chromium-browser')
        opts={'headless':True,'args':['--no-sandbox']}
        if executable:opts['executable_path']=executable
        browser=pw.chromium.launch(**opts)
        try:
            context=browser.new_context(viewport={'width':1440,'height':1000},service_workers='block',accept_downloads=False)
            context.route('**/*', lambda route: route.abort())
            page=context.new_page();errors=[]
            page.on('pageerror',lambda error:errors.append(str(error)))
            anchor=re.search(r'window\.__PROCESS_MAP_QA\s*=\s*\{',text)
            if not anchor:raise ValueError('Unsupported source QA capture profile; explicit adapter required')
            hook="captureProjection:()=>{let g=window.__PROCESS_MAP_QA.graphData();if(typeof v4DisplayGraph==='function')g=v4DisplayGraph(g);if(typeof crm72DisplayGraph==='function')g=crm72DisplayGraph(g);return g.ns?g:{ns:g.nodes,es:g.edges};},captureHubs:g=>typeof crm73HubGroups==='function'?crm73HubGroups(g.ns,g.es).filter(h=>['fan2','fan3','fan4'].includes(h.kind)).map(h=>({id:h.id,sources:h.sources,targets:h.targets,pairs:[...h.pairs]})):[],"
            capture_text=text[:anchor.end()]+hook+text[anchor.end():]
            # Known source profile: annotate existing label elements without changing rendering.
            capture_text=capture_text.replace('svg.appendChild(txel)',
                "txel.dataset.a=a;txel.dataset.b=b;svg.appendChild(txel)")
            page.set_content(capture_text,wait_until='load',timeout=30000)
            page.wait_for_function('!!(window.__PROCESS_MAP_QA && window.__PROCESS_MAP_QA.chooseLevel)',timeout=10000)
            levels={}
            for level in (4,5,6):
                page.evaluate('(l)=>{window.__PROCESS_MAP_QA.chooseLevel(l);window.__PROCESS_MAP_QA.chooseStage("all");}',level)
                captured=page.evaluate(r'''() => {
                  const qa=window.__PROCESS_MAP_QA;
                  if(typeof qa.captureProjection!=='function') throw Error('Unsupported source projection renderer');
                  const projected=qa.captureProjection();
                  const capturePath=p=>({a:p.dataset.a||'',b:p.dataset.b||'',hub:p.dataset.hub||'',
                    visualKind:p.dataset.style||'base',d:p.getAttribute('d'),dash:p.getAttribute('stroke-dasharray')||'',
                    marker:p.getAttribute('marker-end')||'',strokeWidth:Number(p.getAttribute('stroke-width')||2)});
                  return {nodes:projected.ns,edges:projected.es,
                    boxes:[...document.querySelectorAll('#canvas .node[data-id]')].map(n=>({id:n.dataset.id,x:parseFloat(n.style.left),y:parseFloat(n.style.top),w:parseFloat(n.style.width),h:parseFloat(n.style.height)})),
                    paths:[...document.querySelectorAll('#canvas svg path[data-a][data-b]')].map(capturePath),
                    hubs:[...document.querySelectorAll('#canvas svg path[data-hub]')].map(capturePath),
                    junctions:[...document.querySelectorAll('#canvas svg circle[data-hub-point]')].map(c=>({id:c.dataset.hubPoint,x:Number(c.getAttribute('cx')),y:Number(c.getAttribute('cy')),r:Number(c.getAttribute('r')),fill:c.getAttribute('fill')||'',stroke:c.getAttribute('stroke')||'',strokeWidth:Number(c.getAttribute('stroke-width')||1)})),
                    labels:[...document.querySelectorAll('#canvas svg text')].filter(t=>getComputedStyle(t).display!=='none'&&getComputedStyle(t).visibility!=='hidden'&&t.textContent.trim()).map(t=>({source:t.dataset.a||'',target:t.dataset.b||'',text:t.textContent,x:Number(t.getAttribute('x')),y:Number(t.getAttribute('y')),anchor:t.getAttribute('text-anchor')||getComputedStyle(t).textAnchor||'start',fontSize:parseFloat(getComputedStyle(t).fontSize)})),
                    hubGroups:qa.captureHubs(projected),
                    lanes:qa.manageLanes.list().map(l=>{const el=[...document.querySelectorAll('#canvas .lane-strip')].find(e=>e.dataset.lane===l.id);return {...l,y:el?parseFloat(el.style.top):null,h:el?parseFloat(el.style.height)+1:null};})};
                }''')
                boxes={n['id']:n for n in captured['boxes']}
                pairs=[(p['a'],p['b']) for p in captured['paths']]
                graph_pairs=[tuple(e[:2]) for e in captured['edges']]
                if len(pairs)!=len(set(pairs)) or len(graph_pairs)!=len(set(graph_pairs)):
                    raise ValueError(f'Ambiguous multiple source routes share endpoints at Lv.{level}; explicit multiedge adapter required')
                by_pair={(p['a'],p['b']):p for p in captured['paths']}
                for p in captured['paths']+captured['hubs']:p['points']=path_points(p.pop('d'))
                routes=[]
                for edge in captured['edges']:
                    a,b,kind=edge[:3];label=edge[3] if len(edge)>3 else ''
                    if (a,b) in by_pair:segments=[by_pair[a,b]]
                    else:
                        hub=next((h for h in captured['hubGroups'] if a+'\0'+b in h['pairs']),None)
                        if hub is None:raise ValueError(f'Source visible route missing at Lv.{level}: {a} -> {b}')
                        strokes=[p for p in captured['hubs'] if p['hub']==hub['id']]
                        A=boxes[a];B=boxes[b]
                        start=[A['x']+A['w'],A['y']+A['h']/2];end=[B['x'],B['y']+B['h']/2]
                        near=lambda x,y:all(abs(u-v)<.11 for u,v in zip(x,y))
                        incoming=next((p for p in strokes if near(p['points'][0],start)),None)
                        outgoing=next((p for p in strokes if near(p['points'][-1],end)),None)
                        if not incoming or not outgoing or not near(incoming['points'][-1],outgoing['points'][0]):
                            raise ValueError(f'Source junction route is incomplete at Lv.{level}: {a} -> {b}')
                        segments=[incoming,outgoing]
                    points=[]
                    for seg in segments:points.extend(seg['points'] if not points else seg['points'][1:])
                    routes.append(dict(source=a,target=b,kind=kind,label=label,points=points,displayLabel=any(t['source']==a and t['target']==b for t in captured['labels']),
                                       visualKind=segments[-1]['visualKind'],dash=segments[-1]['dash'],
                                       marker=segments[-1]['marker'],strokeWidth=segments[-1]['strokeWidth'],segments=copy.deepcopy(segments)))
                levels[str(level)]={'nodes':captured['nodes'],'edges':captured['edges'],'boxes':boxes,
                                    'routes':routes,'lanes':captured['lanes'],'hubGroups':captured['hubGroups'],'junctions':captured['junctions'],'labels':captured['labels']}
            if errors:raise ValueError('Source renderer failed while capturing geometry: '+'; '.join(errors[:3]))
        finally:browser.close()
    out={'schema':'source-geometry/v1','renderer':'process-map-qa','levels':levels}
    validate_geometry(out,data)
    return out


def validate_geometry(geometry, data):
    if geometry.get('schema')!='source-geometry/v1':raise ValueError('Unsupported As-Is geometry schema')
    for level in ('4','5','6'):
        g=geometry['levels'][level]; ids=[n['id'] for n in g['nodes']]
        if len(ids)!=len(set(ids)) or set(ids)!=set(g['boxes']):raise ValueError('Source geometry node coverage mismatch at Lv.'+level)
        originals={n['id'] for n in data['lv'+level]['nodes']}
        if not originals.issubset(ids):raise ValueError('Source geometry omits original tasks at Lv.'+level)
        for n in g['nodes']:
            if n['id'] not in originals and (not n.get('_v4Mirror') or n.get('_v4BaseId') not in originals):
                raise ValueError('Undocumented source display proxy: '+n['id'])
        for box in g['boxes'].values():
            if not all(isinstance(box.get(k),(int,float)) and math.isfinite(box[k]) for k in ('x','y','w','h')) or min(box['w'],box['h'])<=0:
                raise ValueError('Source node geometry is non-finite or empty')
        if len(g['edges'])!=len(g['routes']):raise ValueError('Source geometry route coverage mismatch')
        edge_key=lambda e:tuple(e[:3]+[e[3] if len(e)>3 else ''])
        semantic=Counter(edge_key(e) for e in data['lv'+level]['edges'])
        projected=Counter(edge_key(e) for e in g['edges'])
        if semantic-projected:raise ValueError('Source projection changed semantic edge multiplicity: '+str(dict(semantic-projected)))
        for j in g.get('junctions',[]):
            if not all(isinstance(j.get(k),(int,float)) and math.isfinite(j[k]) for k in ('x','y','r')) or j['r']<=0:
                raise ValueError('Invalid source junction geometry')
            if j['id'] not in {h['id'] for h in g['hubGroups']}:raise ValueError('Undocumented source junction')
        for label in g.get('labels',[]):
            if (label.get('source'),label.get('target')) not in {tuple(e[:2]) for e in g['edges']}:
                raise ValueError('Visible source SVG label has no unambiguous edge association; explicit adapter required')
            if not isinstance(label.get('text'),str) or not label['text'].strip() or label.get('anchor') not in ('start','middle','end'):
                raise ValueError('Unsupported source edge label text/anchor')
            if not all(isinstance(label.get(k),(int,float)) and math.isfinite(label[k]) for k in ('x','y','fontSize')):
                raise ValueError('Invalid source edge label geometry')
        for e,r in zip(g['edges'],g['routes']):
            if edge_key(e)!=(r['source'],r['target'],r['kind'],r['label']):raise ValueError('Source route metadata differs from projection')
            if e[0] not in ids or e[1] not in ids or e[2] not in EDGE_KINDS:raise ValueError('Unsupported source route endpoint/type')
            for point in r['points']:
                if len(point)!=2 or not all(isinstance(x,(int,float)) and math.isfinite(x) for x in point):raise ValueError('Non-finite source route')
    return geometry


def projection_basis(asis):
    return {level:{key:{f:copy.deepcopy(v[f]) for f in fields if f in v} for key,v in asis[level].items()}
            for level,fields in [('A4',('n','kids')),('A5',('n','l4id','kids')),('A6',('n','row','l5'))]}


def apply_to_pmd(pmd, asis):
    """Replace As-Is views with captured source graph, rendered in the common UI."""
    source=validate(asis['source_html'],asis)
    if source.get('projection_basis')!=projection_basis(asis):raise ValueError('Source projection basis is stale; recapture original HTML')
    return _apply_to_pmd(pmd,source,source['projection_basis'])


def _apply_to_pmd(pmd, source, asis):
    geometry=source.get('geometry')
    if source.get('schema')!='source-asis/v2' or not geometry:
        raise ValueError('As-Is layout capture is missing/legacy. Run source_asis.py capture ORIGINAL.html asis.json; preserve design.json and rebuild.')
    data=source['snapshot'];mapping6=source['mapping']
    if any(source['scope_difference'].values()):raise ValueError('As-Is HTML/Excel scope differs; resolve before shared rendering: '+str(source['scope_difference']))
    stage_by_l5={k:next((s['n'] for s in pmd['stages'] if s['id']==v['l4id']),None) for k,v in asis['A5'].items()}
    node6={n['id']:n for n in data['lv6']['nodes']}; mapping5={};stage5={}
    for n in data['lv5']['nodes']:
        children=[mapping6[x['id']] for x in node6.values() if x.get('parent')==n['id']]
        rows=set(n.get('sourceRows',[]))
        if not children:children=[k for k,v in asis['A6'].items() if v.get('row') in rows]
        candidates={asis['A6'][k]['l5'].split(' ')[0] for k in children}
        if not candidates and n['id'] in asis['A5']:candidates={n['id']}
        if len(candidates)!=1:raise ValueError('Ambiguous source Lv.5 ancestry: '+n['id'])
        key=next(iter(candidates))
        if asis['A5'][key]['n']!=(n.get('task') or n.get('label')):raise ValueError('Source Lv.5 label differs from Excel: '+n['id'])
        mapping5[n['id']]=key;stage5[n['id']]=stage_by_l5[key]
    if set(mapping5.values())!=set(asis['A5']):raise ValueError('As-Is source Lv.5 does not cover Excel groups exactly')
    stage4={}
    for n in data['lv4']['nodes']:
        children=[x for x in data['lv5']['nodes'] if x.get('parent')==n['id']]
        stages={stage5[x['id']] for x in children}
        if len(stages)!=1 or None in stages:raise ValueError('Ambiguous source Lv.4 stage ancestry: '+n['id'])
        stage4[n['id']]=next(iter(stages))
        lane_id=n.get('manualLane') or n.get('track')
        lane=next((l for l in geometry['levels']['4']['lanes'] if l['id']==lane_id),{})
        pmd['A4'][n['id']]={'n':n.get('task') or n['label'],'kids':[mapping5[x['id']] for x in children],
                           'ln':lane.get('name',''),'place':lane.get('name','')+' '+str(len(children))+'개',
                           'team':' / '.join(n.get('orgs',[])),'sourceOnly':True}
    maps={'4':{n['id']:n['id'] for n in data['lv4']['nodes']},'5':mapping5,'6':mapping6}
    layout={'schema':'source-layout/v1','source_sha256':source['sha256'],'geometry_sha256':source['geometry_sha256'],'levels':{}}
    lane_map={};seen={l['k'] for l in pmd['lanes']}
    for level in ('4','5','6'):
        g=geometry['levels'][level];mapping=dict(maps[level]);by_id={n['id']:n for n in g['nodes']}
        for n in g['nodes']:
            if n.get('_v4Mirror'):mapping[n['id']]='SRC'+level+'-'+n['id']
        lane_meta=[]
        for lane in g['lanes']:
            key='SRC-'+lane['id'];lane_map[lane['id']]=key
            if key not in seen:
                pmd['lanes'].append({'k':key,'name':lane['name'],'sub':' / '.join(lane.get('orgs',[])),
                                     'who':lane['name'],'onlyIn':'asis','sourceLane':lane['id']});seen.add(key)
            lane_meta.append({'k':key,'name':lane['name'],'sub':' / '.join(lane.get('orgs',[])),'y':lane['y'],'h':lane['h']})
        nodes=[];boxes={};stage_bounds={}
        for n in g['nodes']:
            sid=n['id'];base=n.get('_v4BaseId') or sid;key=mapping[sid];ref=maps[level][base]
            if level=='6':stage=stage_by_l5[asis['A6'][ref]['l5'].split(' ')[0]]
            elif level=='5':stage=stage5[base]
            else:stage=stage4[base]
            ln=lane_map[n.get('manualLane') or n.get('track')];box=copy.deepcopy(g['boxes'][sid])
            box.update(sourceId=sid,sourceRef=ref,sourceProxy=bool(n.get('_v4Mirror')),lane=ln,stage=stage)
            boxes[key]=box
            out={'id':key,'st':stage,'c':box['x'],'r':box['y'],'ln':ln,'k':'h',
                 'lb':n.get('task') or n.get('label',''),'sourceId':sid,'sourceRef':ref,'sourceProxy':bool(n.get('_v4Mirror'))}
            if level=='6':out['pid']=mapping5[node6[base]['parent']]
            elif level=='5':out['pid']=by_id[base].get('parent','')
            if n.get('role'):out['ty']=n['role']
            nodes.append(out)
            bounds=stage_bounds.setdefault(str(stage),{'x':box['x'],'w':box['w']})
            right=max(bounds['x']+bounds['w'],box['x']+box['w']);bounds['x']=min(bounds['x'],box['x']);bounds['w']=right-bounds['x']
        edges=[];routes=[]
        for e,route in zip(g['edges'],g['routes']):
            edges.append([mapping[e[0]],mapping[e[1]],EDGE_KINDS[e[2]],e[3] if len(e)>3 else ''])
            r=copy.deepcopy(route);r.update(source=mapping[e[0]],target=mapping[e[1]],sourceFrom=e[0],sourceTo=e[1]);routes.append(r)
        pmd['views'][level]['asis']={'nodes':nodes,'edges':edges,'ncols':{str(s['n']):1 for s in pmd['stages']}}
        junctions=[]
        for junction in g.get('junctions',[]):
            j=copy.deepcopy(junction);hub=next(h for h in g['hubGroups'] if h['id']==j['id'])
            j['members']=[mapping[x] for x in hub['sources']+hub['targets']];junctions.append(j)
        labels=[]
        for label in g.get('labels',[]):
            label=copy.deepcopy(label);label['source']=mapping[label['source']];label['target']=mapping[label['target']];labels.append(label)
        layout['levels'][level]={'nodes':boxes,'edges':routes,'lanes':lane_meta,'stageBounds':stage_bounds,'junctions':junctions,'labels':labels,
                                 'semanticCount':len(data['lv'+level]['nodes']),'displayCount':len(nodes)}
    pmd['sourceAsis']=source;pmd['sourceLayout']=layout
    return pmd
def validate_projection(pmd):
    """Independently recompute normalized views from the captured source evidence."""
    source=validate(pmd.get('sourceAsis') or {})
    if source.get('schema')!='source-asis/v2' or not source.get('projection_basis'):
        raise ValueError('As-Is projection basis missing; recapture original HTML')
    expected=copy.deepcopy(pmd)
    _apply_to_pmd(expected,source,source['projection_basis'])
    if expected['sourceLayout']!=pmd.get('sourceLayout'):
        raise ValueError('As-Is normalized layout differs from captured source geometry')
    for level in ('4','5','6'):
        if expected['views'][level]['asis']!=pmd['views'][level]['asis']:
            raise ValueError('As-Is normalized nodes/edges differ from captured source at Lv.'+level)
    return pmd['sourceLayout']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    cap = sub.add_parser('capture'); cap.add_argument('html'); cap.add_argument('asis'); cap.add_argument('--out')
    ver = sub.add_parser('verify'); ver.add_argument('asis')
    args = parser.parse_args(); a = json.loads(Path(args.asis).read_text())
    if args.command == 'capture':
        a = attach(a, args.html)
        Path(args.out or args.asis).write_text(json.dumps(a, ensure_ascii=False, indent=1))
    source = validate(a['source_html'], a)
    print(json.dumps({'sha256':source['sha256'], 'mapped_tasks':len(source['mapping']),
                      'scope_difference':source['scope_difference']}, ensure_ascii=False))
