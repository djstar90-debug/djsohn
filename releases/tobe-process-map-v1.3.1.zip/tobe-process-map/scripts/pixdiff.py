"""두 캡처 폴더를 픽셀 비교 (글자 안티에일리어싱 잡음은 허용치로 거름)"""
import sys, os
from PIL import Image, ImageChops
def changed(x, y, thr=64):
    d = ImageChops.difference(x, y).convert('L').point(lambda v: 255 if v > thr else 0)
    return d.histogram()[255], d.getbbox()
# 사용: pixdiff.py 새캡처 기준1 [기준2 ...]  — 기준 중 하나와 같으면 통과
new, bases = sys.argv[1], sys.argv[2:]; tol = 150; bad = 0; a = new
for f in sorted(os.listdir(a)):
    y = Image.open(f'{new}/{f}').convert('RGB'); best = None
    for b in bases:
        x = Image.open(f'{b}/{f}').convert('RGB')
        r = (10**9, 'size') if x.size != y.size else changed(x, y)
        if best is None or r[0] < best[0]: best = r
    n, bb = best
    if n > tol: print('DIFF', f, n, bb); bad += 1
    elif n: print('  noise', f, n)
print(f'{len(os.listdir(a)) - bad}/{len(os.listdir(a))} same (tolerance {tol}px)')
