"""To-be 재설계 (Lv.4 유지, Lv.5·Lv.6는 Agent 운영 구조로 새로 설계) — 데이터 형식은 S01 v4(261106)와 같음. 설계 사고 과정은 references/redesign.md
To-be 업무를 새 ID로 다시 짜고, 업무마다 이어받은 As-Is 업무(ref)·인풋·아웃풋·시스템·형식·실행 방식(mode)을 둔다.
As-Is 화면은 엑셀 그대로, To-be 화면은 재구성한 To-be Lv.5(tb5)·Lv.6(tb)로 그린다.

사용:
  restructure.py check  asis.json design.json            — 점검 (원본 연결·흡수·실행 방식·Lv.5·Lv.4 유지·역할·산출물·결정 근거). As-Is 대비 비교 수치는 계산하지 않음
  restructure.py synth  asis.json design.json 폴더/      — To-be 전용 asis_tobe.json·design_tobe.json (autofill·check_design·style_check은 이 파일로)
  restructure.py absorb design.json 폴더/design_tobe.json — autofill fill 결과(세부 Agent 데이터·시스템, 흐름 따라가기 뼈대 등)를 ② 설계 파일로 옮김
  restructure.py build  asis.json design.json pmd.json   — As-Is(엑셀)·To-be(재구성)를 각각 compile해 한 화면 데이터로 합침

design.json (②) 형식:
  mode: "restructure"
  tb5:  {"T5-01": {"n": "To-be Lv.5 이름", "st": 1, "from": ["As-Is Lv.5 ID", ...], "note": ""}, ...}   — 순서 = 화면 순서
  tb:   To-be 업무 {"T6-01-01": {"t": "A|N|H|O", "lb": 업무명, "sub"(A) | "lane"(N·H·O), "l5": "T5-01",
                     "ref": [이어받은 As-Is Lv.6 ID...], "io": {"inp","out","sys","fmt"}, "mode": "파일 기반 시범" 등, "tg": 태그}}
        Orchestrator {"TB-G1": {"t": "M", "sub": "S0a", "lb": …, "anchor": "T6-…"}} (연결은 new_edges)
        흡수 As-Is 업무 {"As-Is ID": {"t": "X", "to": "T6-…", "why": 사유}}
  tobe_flow: [[a, b, 종류, 이름표], ...]   — To-be 업무 사이 연결 (종류 s 순차·b 분기·p 병행·r 반려). 없으면 단계 안 tb 순서대로 순차, 단계 끝 → 다음 단계 첫 업무
  나머지(lanes·bands·subs·story·tour·desc·memo·ax·ui·meta·structure·inputs·review)는 ①과 같음. desc.A6 = As-Is ID, desc.T6 = To-be ID
"""
import sys, os, json, copy, re
from collections import OrderedDict, Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import compile as CP
import design_contract
import render_preflight

def load(p): return json.load(open(p, encoding='utf-8'), object_pairs_hook=OrderedDict)
def tasks(dz): return OrderedDict((k, t) for k, t in dz['tb'].items() if t.get('t') in ('A', 'N', 'H', 'O') and t.get('l5'))
def lv4key(a5): return a5.get('g4id') or a5.get('g4') or a5.get('l4id')        # Lv.4 = F2는 g4 묶음, F1은 단계(l4id)
def lv4_of(asis, v):
    """To-be Lv.5의 소속 Lv.4 키: tb5.l4가 있으면 그것, 없으면 from 첫 Lv.5의 Lv.4, 그것도 없으면 단계(st)"""
    if v.get('l4'): return v['l4']
    src = [asis['A5'][f] for f in v.get('from') or [] if f in asis['A5']]
    if src: return lv4key(src[0])
    return list(asis['A4'])[int(v.get('st') or 1) - 1]
# ---- 역할 분류 (classification.md '역할 분류 코드') — 업무마다 Claude가 업무 내용을 이해해 role·role_why를 직접 정하고, 스크립트는 배치·표기가 그 역할과 맞는지 검증한다 ----
ROLES = {'A-검수': 'A', 'A-리서치': 'A', 'A-관리': 'A', 'A-취합': 'A', 'A-작성': 'A', 'A-처리': 'A',
         'H-연락': 'H', 'H-논의': 'H', 'H-현장': 'H', 'H-준법': 'N', 'H-최종': 'N', 'O-타부문': 'O'}
# 교차 확인용 사전 (참고 경고 — 역할 판단의 근거가 아니라, role과 업무명이 크게 어긋날 때 Claude가 다시 보게 하는 장치)
KW_H = {
 'H-연락': r'연락|컨택|콘택|섭외|통화|전화|문의|회신|답신|송부|발송|전달|공유|요청|접촉|응대|안내|통보|제출|접수 대응|피드백 수령|수령|회수',
 'H-논의': r'회의|미팅|협의|논의|협상|네고|조율|설득|발표|프레젠테이션|PT|킥오프|워크숍|브리핑|인터뷰|리뷰 미팅|보고회|시사회|면담|간담',
 'H-준법': r'준법|법무|법률|법적|컴플라이언스|심의|표시\s*광고|표시광고|개인정보|약관|저작권|초상권|상표|규제|인허가|윤리|공정위|광고법',
 'H-최종': r'최종|승인|결재|확정|결정|컨펌|재가|서명|체결|선정|셀렉|판정|채택|낙점|OK/NG|Go/No-Go',
 'H-현장': r'촬영 진행|현장|행사 운영|설치|리허설|녹음|오프라인 운영',
}
KW_A = {
 'A-검수': r'1차\s*(검수|점검|검토)|사전\s*(점검|검수)|오탈자|규격\s*(점검|확인)|가이드\s*대조|금지\s*표현|필수\s*표기|누락\s*(확인|점검)',
 'A-리서치': r'리서치|조사|수집|모니터링|크롤링|벤치마킹|사례\s*탐색|트렌드\s*분석|시장\s*분석|경쟁\s*분석',
 'A-관리': r'현황\s*(관리|업데이트|갱신)|파일\s*(관리|정리|보관)|버전\s*관리|이력\s*관리|아카이빙|백업|일정\s*관리|진행\s*관리|자산\s*관리|폴더',
 'A-취합': r'취합|수합|통합\s*정리|집계|데이터\s*정리|리포트\s*(작성|생성)|정리',
 'A-작성': r'초안|작성|수정안|대안|요약|번역|변환|리사이즈|베리에이션|구성',
 'A-처리': r'대조|비교|산정|계산|기록|등록|업로드|입력|매칭|분류',
}
DRAFT = r'초안|준비|자료|작성|정리|목록|요건표|체크리스트'   # 연락·논의 '준비'는 Agent 일
HUMAN_SUBJ = r'(AE|CD|PM|AP|AD|담당자|책임자|팀장|본부장|실무자)(이|가|는|께서|와|과)\s'
LEVER_TAG = re.compile(r'^(Tool|[①-⑨].*|앞당김|상시|상시\s*검수|재진입)$')
def role_checks(asis, dz, T):
    """[역할] role 코드와 박스 유형·배치(레인)·태그·담당 표기가 서로 맞는지 검증 (오류) + 업무명 교차 확인 (경고)"""
    out = []; lanes = {l['k']: l for l in dz.get('lanes', [])}; subs = dz.get('subs', {}) or {}
    for k, t in T.items():
        lb = t.get('lb', ''); role = str(t.get('role', '')).strip(); ty = t['t']
        if not role: out.append(('오류', '[역할]', f'{k} 「{lb[:30]}」 — role 빈칸 (classification.md 역할 분류 코드로 업무 내용을 판단해 지정)')); continue
        if role not in ROLES: out.append(('오류', '[역할]', f'{k} — role "{role}"는 정해진 코드가 아님 ({", ".join(ROLES)})')); continue
        if not str(t.get('role_why', '')).strip(): out.append(('오류', '[역할]', f'{k} 「{lb[:30]}」 — role_why 빈칸 (업무 내용 기준의 판단 이유 한 줄)'))
        if ROLES[role] != ty: out.append(('오류', '[역할]', f'{k} 「{lb[:30]}」 — role {role}인데 박스 유형이 {ty} ({role}은 {ROLES[role]})'))
        # 배치: 사람 업무는 담당 조직 레인, Agent 업무는 담당 세부 Agent 레인
        if ty == 'A':
            if t.get('lane'): out.append(('오류', '[배치]', f'{k} — Agent 업무인데 조직 레인(lane) 지정이 있음 (sub만 둔다)'))
            if subs and t.get('sub') not in subs: out.append(('오류', '[배치]', f'{k} — 담당 세부 Agent(sub) {t.get("sub")}가 subs에 없음'))
        elif ty in ('N', 'H', 'O'):
            if t.get('sub'): out.append(('오류', '[배치]', f'{k} — 사람 업무인데 Agent 레인(sub) 지정이 있음 (lane만 둔다)'))
            if t.get('lane') not in lanes: out.append(('오류', '[배치]', f'{k} — 담당 조직 레인(lane) {t.get("lane")}가 lanes에 없음'))
        # 태그: Agent 박스에는 사람 행위 태그를 붙이지 않는다 — 사람의 확인·발송·판단은 별도 Lv.6 박스로
        tg = str(t.get('tg', '')).strip()
        if ty == 'A' and tg and not LEVER_TAG.match(tg): out.append(('오류', '[역할]', f'{k} 「{lb[:30]}」 — Agent 박스에 사람 행위 태그 "{tg}" — 사람의 확인·판단·연락이 필요하면 뒤에 별도 Lv.6 박스(N 또는 H)로 둔다'))
        # 교차 확인 (경고): role과 업무명이 크게 어긋나 보이면 다시 판단
        if ty == 'A':
            for rc, rx in KW_H.items():
                if re.search(rx, lb) and not (rc in ('H-연락', 'H-논의') and re.search(DRAFT, lb)) and not (rc == 'H-최종' and re.search(r'후보|자동|1차', lb)):
                    out.append(('경고', '[역할]', f'{k} 「{lb[:30]}」 — role {role}이지만 업무명이 {rc} 성격으로 보임. 업무 내용을 다시 판단하고, 사람 일이 섞여 있으면 Lv.6 박스를 나눈다')); break
        elif ty in ('N', 'H'):
            hit = next((rc for rc, rx in KW_A.items() if re.search(rx, lb)), None)
            if hit and not any(re.search(rx, lb) for rx in KW_H.values()): out.append(('경고', '[역할]', f'{k} 「{lb[:30]}」 — role {role}이지만 업무명이 {hit}(Agent) 성격으로 보임. 업무 내용을 다시 판단한다'))
    out += subject_checks(dz, T)
    return out
def subject_checks(dz, T):
    """[담당표기] 상세 설명(desc.T6)과 흐름 따라가기 문장의 담당 주체가 박스의 실제 담당(레인)과 맞는지 — 설명·흐름이 작성된 뒤에만 검사"""
    out = []; lanes = {l['k']: l for l in dz.get('lanes', [])}; subs = dz.get('subs', {}) or {}
    def org_names(l): return [x for x in dict.fromkeys([l.get('who', ''), l.get('name', ''), l.get('short', '')] + [p.strip() for p in re.split(r'>|/', l.get('name', ''))]) if x and len(x) > 1]
    org_all = [n for l in lanes.values() for n in org_names(l)]
    hum_rx = re.compile(HUMAN_SUBJ + ('|(' + '|'.join(re.escape(n) for n in sorted(org_all, key=len, reverse=True)) + r')(이|가|는|께서)\s' if org_all else ''))
    D = (dz.get('desc') or {}).get('T6') or {}
    for k, t in T.items():
        s = str(D.get(k, '') or '').replace('**', '')
        if not s: continue
        if t['t'] == 'A':
            nm = (subs.get(t.get('sub')) or {}).get('name', '')
            if nm and nm not in s: out.append(('오류', '[담당표기]', f'{k} 상세 설명에 담당 Agent 「{nm}」가 주체로 나오지 않음'))
            if hum_rx.search(s): out.append(('오류', '[담당표기]', f'{k} Agent 박스 설명에 사람이 하는 일이 섞여 있음 — 사람 일은 별도 Lv.6 박스로 나누고, 이 설명은 Agent가 하는 일만 쓴다'))
        elif t['t'] in ('N', 'H') and t.get('lane') in lanes and dz.get('people') != 'role':
            if not any(n in s for n in org_names(lanes[t['lane']])): out.append(('오류', '[담당표기]', f'{k} 사람 박스 설명에 담당 조직 「{lanes[t["lane"]].get("who") or lanes[t["lane"]]["name"]}」이 주체로 나오지 않음'))
    for st, v in (dz.get('tour') or {}).items():
        for b in v.get('beats', []):
            for sp in b.get('steps', []):
                ids = [i for i in sp.get('ids', []) if i in T or i.startswith('TB-')]
                kinds = {('A' if (T.get(i, {}).get('t', 'M') in ('A', 'M')) else 'P') for i in ids}
                txt = str(sp.get('d', '')).replace('**', '')
                if len(kinds) > 1: out.append(('오류', '[담당표기]', f'{st}단계 "{b.get("t", "")}": 한 문장에 Agent 박스와 사람 박스가 함께 있음 ({", ".join(ids)}) — 박스마다 문장을 나눈다')); continue
                if kinds == {'A'}:
                    if str(sp.get('a', '')).strip(): out.append(('오류', '[담당표기]', f'{st}단계 "{b.get("t", "")}": Agent 박스({ids[0] if ids else ""}) 문장에 사람 주체 "{sp["a"]}"가 표시됨'))
                    if txt and hum_rx.search(txt): out.append(('오류', '[담당표기]', f'{st}단계 "{b.get("t", "")}": Agent 박스({ids[0] if ids else ""}) 문장에 사람이 하는 일이 섞여 있음 — 별도 Lv.6 박스로 나눈다'))
                elif kinds == {'P'}:
                    a = str(sp.get('a', '')).strip()
                    if not a: out.append(('오류', '[담당표기]', f'{st}단계 "{b.get("t", "")}": 사람 박스({ids[0] if ids else ""}) 문장에 담당 주체(a)가 없음'))
                    elif dz.get('people') != 'role':
                        ok = any(a in org_names(lanes[T[i]['lane']]) for i in ids if i in T and T[i].get('lane') in lanes)
                        if not ok: out.append(('오류', '[담당표기]', f'{st}단계 "{b.get("t", "")}": 사람 박스({ids[0] if ids else ""})의 담당 주체 "{a}"가 그 박스의 담당 조직 레인과 다름'))
    return out

def check(asis, dz):
    schema_errors = render_preflight.validate_design(dz, asis)
    if schema_errors: return render_preflight.as_issues(schema_errors)
    A6, A5 = asis['A6'], asis['A5']; T = tasks(dz); T5 = dz.get('tb5', {}); out = []
    used = {r for t in T.values() for r in (t.get('ref') or [])}
    X = {k: t for k, t in dz['tb'].items() if t.get('t') == 'X'}
    for k in A6:
        if k not in used and k not in X: out.append(('오류', '[원본 연결]', f'{k} 「{A6[k]["n"][:30]}」 — 어떤 To-be 업무의 ref에도, 흡수(X)에도 없음'))
    for k, t in X.items():
        if k not in A6: out.append(('오류', '[흡수]', f'{k} — As-Is에 없는 ID'))
        if not t.get('to') or t['to'] not in T: out.append(('오류', '[흡수]', f'{k} — 흡수처(to)가 To-be 업무가 아님'))
        if not str(t.get('why', '')).strip(): out.append(('오류', '[흡수]', f'{k} — 흡수 사유(why) 빈칸'))
    for k, t in T.items():
        if t['l5'] not in T5: out.append(('오류', '[Lv.5]', f'{k} — l5 {t["l5"]}가 tb5에 없음'))
        for r in t.get('ref') or []:
            if r not in A6: out.append(('오류', '[원본 연결]', f'{k} — ref {r}가 As-Is에 없음'))
        if not t.get('ref') and not t.get('why'): out.append(('경고', '[원본 연결]', f'{k} 「{t.get("lb", "")[:24]}」 — ref 없음 (신규 업무면 why에 이유)'))
        if t['t'] in ('A', 'N') and not str(t.get('mode', '')).strip(): out.append(('경고', '[실행 방식]', f'{k} — mode(실행 방식) 빈칸'))
        if t['t'] == 'A' and not t.get('sub'): out.append(('오류', '[판정]', f'{k} — Agent 업무에 sub 없음'))
        if t['t'] != 'A' and not t.get('lane'): out.append(('오류', '[판정]', f'{k} — 사람·확인 업무에 lane 없음'))
    nst = len(asis['A4'])
    out += role_checks(asis, dz, T)   # 역할·배치·태그·담당 표기 (classification.md 역할 분류 코드)
    for k, t in T.items():
        io = t.get('io') or {}
        if t['t'] == 'A' and not str(io.get('out', '')).strip(): out.append(('오류', '[산출물]', f'{k} 「{t.get("lb", "")[:24]}」 — Agent 업무의 io.out(만드는 것) 빈칸'))
        if t['t'] == 'A' and not str(io.get('to', '')).strip(): out.append(('경고', '[산출물]', f'{k} — io.to(받는 곳: 다음 업무·Agent·사람) 빈칸'))
    SO = sub_outputs(dz); subs = dz.get('subs') or {}
    for sid, sv in subs.items():   # 세부 Agent마다 산출물이 있어야 한다 (Agent 상세 페이지의 '산출물'이 비지 않게)
        if not SO.get(sid): out.append(('오류', '[산출물]', f'세부 Agent {sid} 「{sv.get("name", "")}」 산출물 없음 — 투입 데이터(d)와 기능을 바탕으로 업무별 io.out 또는 subs[].of를 작성'))
    for a, b, ty, _ in (flow(dz) if isinstance(dz.get('tobe_flow'), list) else []):   # 산출물 이어받기: Agent 산출물을 사람이나 다른 세부 Agent가 이어받는 지점
        ta, tb_ = T.get(a), T.get(b)
        if not ta or not tb_ or ta['t'] != 'A' or ty == 'r': continue
        if not (tb_['t'] in ('N', 'H') or (tb_['t'] == 'A' and tb_.get('sub') != ta.get('sub'))): continue
        outs = split_outs((ta.get('io') or {}).get('out'))
        whom = '사람' if tb_['t'] != 'A' else '다른 세부 Agent'
        if not outs: out.append(('오류', '[산출물연계]', f'{a} → {b}: {whom}가 이어받는데 {a}의 산출물(io.out) 빈칸')); continue
        if not str((ta.get('io') or {}).get('to', '')).strip(): out.append(('오류', '[산출물연계]', f'{a} → {b}: 산출물을 받는 곳(io.to) 빈칸'))
        inp = str((tb_.get('io') or {}).get('inp', '')) + ' ' + ' '.join(str(x[0]) for x in (subs.get(tb_.get('sub'), {}).get('d') or []) if x)
        if not any(o[:12] in inp for o in outs):
            where = '사람 업무의 판단 근거(io.inp)' if tb_['t'] != 'A' else f'세부 Agent {tb_.get("sub")}의 투입 데이터(d 또는 io.inp)'
            out.append(('경고', '[산출물연계]', f'{a} → {b}: {where}에 앞 Agent 산출물 「{outs[0][:24]}」가 없음 — 이어받는 자료를 적는다'))
    for k, t in T.items():
        if t['t'] == 'N' and not str((t.get('io') or {}).get('inp', '')).strip(): out.append(('오류', '[결정]', f'{k} — 사람 결정 업무의 io.inp(근거 산출물) 빈칸'))
    for k, v in T5.items():
        if not 1 <= int(v.get('st') or 1) <= nst: out.append(('오류', '[단계]', f'{k} — st {v.get("st")}가 단계 범위(1~{nst}) 밖'))
    for sk, v in (dz.get('stages_tobe') or {}).items():   # Lv.4(와 그 위 단계)는 이름·순서 유지 — 통합·이름 변경 불가
        if sk not in asis['A4']: out.append(('오류', '[Lv.4 유지]', f'stages_tobe {sk} — As-Is 단계 키가 아님'))
        elif v.get('into'): out.append(('오류', '[Lv.4 유지]', f'stages_tobe {sk} — 단계 통합(into)은 쓰지 않는다 (Lv.4·단계는 유지, 업무만 Lv.4 사이 이동)'))
        elif v.get('n') and v['n'] != asis['A4'][sk]['n']: out.append(('오류', '[Lv.4 유지]', f'stages_tobe {sk} — 단계 이름을 바꾸지 않는다 (엑셀 원문 유지)'))
    keys4 = list(dict.fromkeys(lv4key(a) for a in A5.values()))   # 모든 As-Is Lv.4에 To-be Lv.5가 있어야 함
    got4 = {lv4_of(asis, v) for v in T5.values()}
    for k4 in keys4:
        if k4 not in got4: out.append(('오류', '[Lv.4 유지]', f'As-Is Lv.4 「{k4}」에 To-be Lv.5가 없음 — Lv.4는 유지하고 그 안의 Lv.5·Lv.6를 새로 설계'))
    for k, v in T5.items():
        if v.get('l4') and v['l4'] not in keys4: out.append(('오류', '[Lv.4 유지]', f'{k} — l4 {v["l4"]}가 As-Is Lv.4가 아님'))
    names = dz.get('asis_names') or {}   # 설계 시점의 As-Is 업무명 — 엑셀이 바뀌면 그 행이 걸린 To-be를 다시 설계
    for k, n in names.items():
        if k in A6 and A6[k]['n'] != n: out.append(('오류', '[변경행]', f'{k} 업무명이 설계 때와 다름 — 관련 To-be 업무를 다시 설계: \'{n[:30]}\' → \'{A6[k]["n"][:30]}\''))
    for k, v in T5.items():
        for f in v.get('from') or []:
            if f not in A5: out.append(('오류', '[Lv.5]', f'{k} — from {f}가 As-Is Lv.5에 없음'))
        if not any(t['l5'] == k for t in T.values()): out.append(('경고', '[Lv.5]', f'{k} 「{v.get("n", "")}」 — To-be 업무 없음'))
        if not str(v.get('desc', '')).strip(): out.append(('경고', '[Lv.5]', f'{k} — desc(To-be Lv.5 설명) 빈칸'))
    out += design_contract.validate(asis, dz)
    return out

ORC_DEFAULT = {'S0a': [['다음 Agent·담당자 호출 신호', ['워크플로 이벤트']], ['호출·게이트 통과 기록', ['DB 기록 (다음 Agent가 조회)']]],
               'S0b': [['진행 현황 카드 (승인 대기·회차·일정·비용)', ['카드·현황 화면']], ['상태 변경 알림', ['메일·메신저 알림']]]}
def split_outs(s): return [o.strip(' -·') for o in re.split(r'\s*[;\n]\s*', str(s or '')) if o.strip(' -·')]
def sub_outputs(dz):
    """세부 Agent별 산출물 = 설계의 subs[].of + 그 Agent 업무들의 io.out (빠진 것 보충) + Orchestrator 기본 산출물 — [[이름, [형식]]]"""
    TB = dz.get('tb', {}); R = OrderedDict()
    for sid, sv in (dz.get('subs') or {}).items():
        res = OrderedDict((o[0], list(o[1]) if isinstance(o[1], list) else [o[1]]) for o in (sv.get('of') or []) if o and o[0])
        for k, x in TB.items():
            if x.get('sub') != sid or x.get('t') not in ('A', 'M'): continue
            io = x.get('io') or {}; fm = split_outs(io.get('fmt'))[:1]
            for o in split_outs(io.get('out')):
                if o not in res: res[o] = fm
        if not res and sid in ORC_DEFAULT: res = OrderedDict((o, f) for o, f in ORC_DEFAULT[sid])
        R[sid] = [[o, f] for o, f in res.items()]
    return R

def flow(dz):
    """Only explicitly designed edges; never manufacture a sequential workflow."""
    if not isinstance(dz.get('tobe_flow'), list):
        raise ValueError('tobe_flow is required; implicit sequential fallback is disabled')
    return [list(e) for e in dz['tobe_flow'] if isinstance(e, list) and len(e) == 4]

def repair(asis, dz):
    """HTML이 깨지지 않도록 하는 최소 보정 (원인은 Claude가 설계 파일에서 고친다) — 보정 내역을 돌려준다"""
    A6, A5 = asis['A6'], asis['A5']; msg = []; T5 = dz.setdefault('tb5', OrderedDict()); TB = dz.setdefault('tb', OrderedDict())
    lanes = [l['k'] for l in dz.get('lanes', [])]; subs = list((dz.get('subs') or {}).keys())
    for k, t in list(TB.items()):
        if t.get('t') in ('A', 'N', 'H', 'O') and t.get('l5') and t['l5'] not in T5:
            src = next((A6[r] for r in t.get('ref') or [] if r in A6), None)
            st = (list(asis['A4']).index(A5[src['l5'].split(' ')[0]]['l4id']) + 1) if src and src['l5'].split(' ')[0] in A5 else 1
            T5[t['l5']] = OrderedDict([('n', 'Lv.5 미지정'), ('st', st), ('from', []), ('desc', '')]); msg.append(f'{k}: To-be Lv.5 {t["l5"]}가 없어 임시 Lv.5 생성')
        if t.get('ref'):
            bad = [r for r in t['ref'] if r not in A6]
            if bad: t['ref'] = [r for r in t['ref'] if r in A6]; msg.append(f'{k}: As-Is에 없는 ref {", ".join(bad)} 제외')
        if t.get('t') == 'A' and not t.get('sub') and subs: t['sub'] = subs[0]; msg.append(f'{k}: Agent 업무에 담당 세부 Agent가 없어 {subs[0]}에 임시 배치')
        if t.get('t') in ('N', 'H', 'O') and t.get('lane') not in lanes and lanes: t['lane'] = lanes[0]; msg.append(f'{k}: 사람 업무에 담당 조직 레인이 없어 {lanes[0]}에 임시 배치')
        if t.get('t') == 'X' and t.get('to') and t['to'] not in TB: t.pop('to'); t['kind'] = '삭제'; msg.append(f'{k}: 흡수한 업무가 없어 삭제로 표시')
    used5 = {x.get('l5') for x in TB.values() if x.get('t') in ('A', 'N', 'H', 'O')}
    for k5 in [k5 for k5 in T5 if k5 not in used5]: T5.pop(k5); msg.append(f'To-be Lv.5 {k5}: 속한 업무가 없어 화면에서 제외')
    LN = {b: l['k'] for l in dz.get('lanes', []) for b in (l.get('bon') or [])}
    for i, sk in enumerate(asis['A4'], 1):   # To-be Lv.5가 하나도 없는 단계는 화면이 깨지므로 '설계 보완 필요' 자리 표시를 둔다
        if any(int(v.get('st') or 1) == i for v in T5.values()): continue
        rows = [x for k5 in asis['A4'][sk]['kids'] if k5 in A5 for x in A5[k5]['kids'] if x in A6]
        ln = Counter(LN.get(A6[x].get('bon'), lanes[0] if lanes else '') for x in rows).most_common(1)
        k5n, k6n = f'T5-AUTO-{i}', f'T6-AUTO-{i}'
        T5[k5n] = OrderedDict([('n', 'To-be 설계 보완 필요'), ('st', i), ('from', []), ('desc', '')])
        TB[k6n] = dict(t='H', lane=(ln[0][0] if ln else (lanes[0] if lanes else '')), lb='To-be 설계 보완 필요', l5=k5n, ref=[], why='자동 보정', mode='', role='H-최종', role_why='자동 보정')
        msg.append(f'{i}단계: To-be Lv.5가 없어 \'To-be 설계 보완 필요\' 자리 표시를 둠')
    SO = sub_outputs(dz)
    for s, v in (dz.get('subs') or {}).items():   # 산출물이 하나도 없는 세부 Agent는 담당 업무명으로 임시 산출물 (Claude가 투입 데이터·기능 기준으로 고친다)
        if not SO.get(s):
            lbs = [x.get('lb', '') for x in TB.values() if x.get('sub') == s and x.get('lb')]
            if lbs: v['of'] = [[f'{lb} 결과', ['']] for lb in lbs[:4]]; msg.append(f'세부 Agent {s}: 산출물이 없어 담당 업무명으로 임시 산출물 작성')
    for s, v in (dz.get('subs') or {}).items():   # 화면 생성에 필요한 기본 칸 (비어 있으면 빈 값)
        for f, dv in (('desc', ''), ('name', s), ('band', (dz.get('bands') or [{'id': 'B0'}])[0]['id']), ('d', []), ('s', [])): v.setdefault(f, dv)
    for b in dz.get('bands') or []:
        for f, dv in (('desc', ''), ('name', b.get('id', '')), ('subs', [])): b.setdefault(f, dv)
    for f, dv in (('story', {}), ('sysinfo', {}), ('dfmt', {}), ('outs', {}), ('when', {}), ('whenHave', {}), ('outnew', {}), ('form', {}), ('tour', {}), ('desc', {}), ('new_edges', [])): dz.setdefault(f, dv)
    for sk, v in list((dz.get('stages_tobe') or {}).items()):
        if v.get('into') or v.get('n'): dz['stages_tobe'].pop(sk); msg.append(f'단계 {sk}: 통합·이름 변경 설정 무시 (Lv.4·단계 유지)')
    return msg

def synth(asis, dz):
    """To-be 전용 원본: 단계 = 같은 단계, Lv.5 = tb5, Lv.6 = To-be 업무 (pre/post = To-be 연결)"""
    A6, A5, A4 = asis['A6'], asis['A5'], asis['A4']; T = tasks(dz); T5 = dz['tb5']; lanes = dz['lanes']
    stk = list(A4); bon_of = {l['k']: (l.get('bon') or l.get('team') or [l['name']])[0] for l in lanes}
    E = flow(dz); pre, post = {}, {}
    for a, b, ty, lab in E:
        if a in T and b in T: post.setdefault(a, []).append(b); pre.setdefault(b, []).append(a)
    a4 = OrderedDict((k, dict(copy.deepcopy(v), kids=[])) for k, v in A4.items())
    a5 = OrderedDict()
    for k5, v in T5.items():
        if v.get('l4') in A4: v = dict(v, st=stk.index(v['l4']) + 1)          # F1: Lv.4 = 단계
        st = v.get('st') or 1; sk = stk[st - 1]; src = [A5[f] for f in v.get('from') or [] if f in A5]
        g4src = next((x for x in A5.values() if v.get('l4') and lv4key(x) == v['l4'] and x.get('g4')), None) or (src[0] if src and src[0].get('g4') else None)   # F2: Lv.4 = g4 묶음 (tb5.l4 우선)
        if g4src: sk = g4src['l4id']
        a5[k5] = dict(n=v['n'], l4=a4[sk]['n'], l4id=sk, team='', ty='업무', br='', rejr='', rej='', pre='', post='', kids=[], pain=[], note=[v.get('note', '')] if v.get('note') else [], r=[0],
                      **({'g4': g4src.get('g4'), **({'g4id': g4src['g4id']} if g4src.get('g4id') else {})} if g4src else {}))
        a4[sk]['kids'].append(k5)
    a6 = OrderedDict()
    for k, t in T.items():
        refs = [A6[r] for r in t.get('ref') or [] if r in A6]; io = t.get('io') or {}
        j = lambda f: io.get(f) if io.get(f) is not None else '\n'.join(dict.fromkeys(x.get(f, '') for x in refs if x.get(f)))
        bon = bon_of.get(t.get('lane')) if t['t'] != 'A' else (refs[0]['bon'] if refs else bon_of[lanes[0]['k']])
        a6[k] = dict(n=t['lb'], l5=f"{t['l5']} {T5[t['l5']]['n']}", l4=a5[t['l5']]['l4'], team=bon, bon=bon, ai='', sys=j('sys'), inp=j('inp'), fmt=j('fmt'), out=j('out'),
                     pain=j('pain'), pre=', '.join(pre.get(k, [])), post=', '.join(post.get(k, [])), ty='세부작업', wt='', note=t.get('mode', ''), br='', rejr='', rej='', row=0, hl=[])
        a5[t['l5']]['kids'].append(k)
    for k5 in a5: a5[k5]['pain'] = list(dict.fromkeys(a6[x]['pain'] for x in a5[k5]['kids'] if a6[x]['pain']))
    asis_t = OrderedDict(meta=dict(asis['meta'], tobe=True), A6=a6, A5=a5, A4=a4)
    dzt = copy.deepcopy(dz); tb = OrderedDict()
    order = {k: i for i, k in enumerate(a6)}
    for k, t in dz['tb'].items():
        if t.get('t') == 'X': continue
        if k in a6: tb[k] = {f: v for f, v in t.items() if f not in ('l5', 'st', 'o', 'ref', 'io', 'mode', 'lane')}; continue
        x = dict(t); anc = x.get('anchor')
        if anc in a6 and not x.get('st'): x.update(st=stk.index(a5[T[anc]['l5']]['l4id']) + 1, l5=T[anc]['l5'], o=order[anc] + 0.05)
        x['_wired'] = True; tb[k] = x
    dzt['tb'] = tb
    SO = sub_outputs(dz)                                    # 세부 Agent 산출물 = 설계의 of + 업무별 io.out(빠진 것 보충) — 화면의 '산출물'이 비지 않게
    for sid, sv in dzt.get('subs', {}).items():
        if SO.get(sid): sv['of'] = [[o, f or ['']] for o, f in SO[sid][:12]]
    dzt['outs'] = OrderedDict((sid, [[o[0], (o[1] or [''])[0]] for o in sv['of']]) for sid, sv in dzt.get('subs', {}).items() if sv.get('of'))
    ds = dzt.setdefault('desc', {}); [ds.setdefault(x, {}) for x in ('A6', 'A5', 'T6', 'T4', 'A4', 'M6')]
    for k in T: ds['A6'].setdefault(k, ds['T6'].get(k, ''))           # To-be 전용 원본의 '원본 설명' 칸 = To-be 설명 (화면의 As-Is 설명은 엑셀 행 desc.A6)
    for k5, v in T5.items(): ds['A5'].setdefault(k5, v.get('desc') or (dz.get('desc', {}).get('T5', {}) or {}).get(k5, ''))
    br = [dict(st=a5[T[a]['l5']]['l4id'], frm=a, to={lab or '갈래': b}) for a, b, ty, lab in E if ty == 'b']
    st0 = dz.get('structure') or {}
    dzt['structure'] = dict(st0, source='To-be 재구성', source_edges=E, confirmed=True, extra=[e for e in E if e[2] in ('r', 'l')],
                            branch=[dict(**{'from': a}, to={lab or f'갈래{i}': b}) for i, (a, b, ty, lab) in enumerate(E) if ty == 'b'], join=[], rework=[dict(**{'from': a}, to=b) for a, b, ty, lab in E if ty in ('r', 'l')], parallel=[])
    return asis_t, dzt

def redesign_summary(asis, dz):
    """Count the original source and the redesigned work separately.
    Many-to-one refs are not deletions and a new ID is not a new activity.
    Bars classify only active To-be tasks, so every total has one denominator.
    """
    T = tasks(dz)
    c6 = Counter(t['t'] for t in T.values())
    c5 = Counter()
    for group in dz['tb5']:
        kinds = {t['t'] for t in T.values() if t['l5'] == group}
        if not kinds: continue
        c5['A' if kinds == {'A'} else 'N' if 'A' in kinds else 'H'] += 1
    n5, n6 = len(asis['A5']), len(asis['A6'])
    t5, t6 = len(dz['tb5']), len(T)
    parts5 = [['Agent 전담', c5['A'], 'A'], ['Agent·사람 협업', c5['N'], 'N'], ['사람 전담', c5['H'], 'H']]
    parts6 = [['Agent 수행', c6['A'], 'A'], ['사람 확인·판단', c6['N'], 'N'], ['사람 수행', c6['H'], 'H'], ['타 부문 수행', c6['O'], 'O']]
    fresh = sum(not t.get('ref') for t in T.values())
    merged = sum(len(t.get('ref') or []) > 1 for t in T.values())
    return [dict(lv=5, asis_count=n5, tobe_count=t5,
                 text=f"Lv.5 (As-Is {n5}개 → To-be {t5}개): " + ', '.join(f'{name} ({count})' for name, count, _ in parts5),
                 tip='As-Is는 입력 원본 Lv.5 수, To-be는 재설계한 Lv.5 수. 분류는 To-be 하위 Lv.6의 수행 주체 기준.', parts=parts5),
            dict(lv=6, asis_count=n6, tobe_count=t6,
                 text=f"Lv.6 (As-Is {n6}개 → To-be {t6}개): " + ', '.join(f'{name} ({count})' for name, count, _ in parts6),
                 tip=f'As-Is는 입력 원본 Lv.6 수, To-be는 활성 업무 수. Orchestrator 표시는 제외. 여러 원본 업무를 통합한 To-be {merged}개, 원본 ref 없는 신규 업무 {fresh}개. 단순 차감식으로 계산하지 않음.', parts=parts6)]

def build(asis, dz):
    errors = [x for x in check(asis, dz) if x[0] == '오류']
    if errors:
        raise ValueError('Release blocked: ' + '\n'.join(' '.join(x) for x in errors))
    return _build_validated(asis, dz)

def _build_validated(asis, dz, *, synthesized=None):
    """Internal release path: reuse the same in-memory, already-validated inputs.
    Public build() remains fail-closed; no CLI bypass or persisted pass token.
    Compiled renderer data is always checked independently below.
    """
    asis_t, dzt = copy.deepcopy(synthesized) if synthesized is not None else synth(asis, dz)
    dz1 = copy.deepcopy(dz); dz1['tb'] = OrderedDict((k, {'t': 'H'}) for k in asis['A6']); dz1['new_edges'] = []; dz1['structure'] = dict(dz.get('structure') or {}, confirmed=True)
    r1 = CP.compile_(asis, dz1); P1 = CP.assemble(asis, dz1, r1)
    r2 = CP.compile_(asis_t, dzt); P = CP.apply_scenario(CP.assemble(asis_t, dzt, r2), asis_t, dzt)
    for lv in P['views']: P['views'][lv]['asis'] = P1['views'][lv]['asis']
    for k in ('A6', 'A5'):
        m = OrderedDict(P1[k]); m.update(P[k]); P[k] = m
    for s1, s2 in zip(P1['stages'], P['stages']): s2['asis'] = s1.get('asis', s2.get('asis'))
    T = tasks(dz)
    for k, t in dz['tb'].items():
        if t.get('t') == 'X':
            to = T.get(t.get('to'), {}); P['TB'][k] = dict(t='X', sub=None, note=f"흡수 → 「{to.get('lb', t.get('to'))}」 {t.get('why', '')}".strip(), lb=asis['A6'][k]['n'], tg='', ref=[k], st=P['TB'].get(t.get('to'), {}).get('st', 1), l5=to.get('l5', ''))
        elif k in T: P['TB'][k]['ref'] = t.get('ref') or []
    P['optIO'] = OrderedDict((k, dict(inp=asis_t['A6'][k]['inp'], out=asis_t['A6'][k]['out'], sys=asis_t['A6'][k]['sys'], fmt=asis_t['A6'][k]['fmt'], mode=t.get('mode', ''),
                                      owner=t.get('sub') or t.get('lane'), source_l5=list(dict.fromkeys(asis['A6'][r]['l5'].split(' ')[0] for r in t.get('ref') or [] if r in asis['A6'])))) for k, t in T.items())
    P['optMap'] = OrderedDict((k, dict(original_l5=v.get('from') or [], original_l6=[r for x in T.values() if x['l5'] == k for r in x.get('ref') or []], note=v.get('note', ''))) for k, v in dz['tb5'].items())
    stb = dz.get('stages_tobe') or {}; keys = list(asis['A4'])
    for i, st in enumerate(P['stages']):
        v = stb.get(keys[i]) if i < len(keys) else None
        if not v: continue
        if v.get('n'): st['nameNs'] = v['n']
        if v.get('into'): st['into'] = int(v['into']); st['intoWhy'] = v.get('why', '')
    # Use the designed graph verbatim (the old pre/post roundtrip lost p/b labels).
    for node in P['views']['6']['ns']['nodes']:
        task = T.get(node['id'])
        if task: node['ln'] = task['sub'] if task['t'] == 'A' else task['lane']
    ns_ids = {n['id'] for n in P['views']['6']['ns']['nodes']}
    explicit = flow(dz)
    extra = [list(e) for e in dz.get('new_edges', []) if len(e) == 4 and e[0] in ns_ids and e[1] in ns_ids and (e[0] not in T or e[1] not in T)]
    P['views']['6']['ns']['edges'] = explicit + [e for e in extra if e not in explicit]
    # Project the same explicit business graph to Lv.5, without serial fallbacks.
    e5 = []
    for a, b, ty, label in explicit:
        pair = [T[a]['l5'], T[b]['l5'], ty, label]
        if pair[0] != pair[1] and pair not in e5: e5.append(pair)
    P['views']['5']['ns']['edges'] = e5
    if asis.get('source_html'):
        import source_asis
        source_asis.apply_to_pmd(P, asis)
    P['summary'] = redesign_summary(asis, dz)
    P['qualityGate'] = {'version': 1, 'passed': True, 'metrics': design_contract.metrics(asis, dz)}
    P['trace'] = CP.trace(asis, dz); P['design_mode'] = 'restructure'
    render_errors = render_preflight.validate_pmd(P)
    if render_errors:
        raise ValueError('Renderer preflight blocked: ' + '\n'.join(e['path']+' — '+e['message'] for e in render_errors))
    return P

ABSORB = ('subs', 'bands', 'tour', 'story', 'when', 'whenHave', 'sysinfo', 'ds_memo', 'dfmt', 'outs', 'new_edges')
if __name__ == '__main__':
    cmd = sys.argv[1]
    if cmd == 'absorb':
        dz = load(sys.argv[2]); dt = load(sys.argv[3])
        for k in ABSORB:
            if k in dt: dz[k] = dt[k]
        for k, t in dt['tb'].items():                       # fill이 정한 Orchestrator 연결·태그 등
            if k in dz['tb'] and dz['tb'][k].get('t') == 'M': dz['tb'][k].update({f: v for f, v in t.items() if f in ('st', 'l5', 'o', 'sub')})
        json.dump(dz, open(sys.argv[2], 'w'), ensure_ascii=False, indent=1); print('②', sys.argv[2], '←', ', '.join(k for k in ABSORB if k in dt)); sys.exit()
    asis = load(sys.argv[2]); dz = load(sys.argv[3])
    if cmd == 'check':
        v = check(asis, dz); v.sort(key=lambda x: x[0] != '오류'); [print(*x) for x in v[:60]]; ne = sum(1 for x in v if x[0] == '오류')
        print(f'점검: 오류 {ne} · 경고 {len(v) - ne}' + (' — 오류 수정 전 최종 산출 금지' if ne else '')); sys.exit(2 if ne else 0)
    if cmd == 'synth':
        a, d = synth(asis, dz); os.makedirs(sys.argv[4], exist_ok=True)
        json.dump(a, open(os.path.join(sys.argv[4], 'asis_tobe.json'), 'w'), ensure_ascii=False, indent=1); json.dump(d, open(os.path.join(sys.argv[4], 'design_tobe.json'), 'w'), ensure_ascii=False, indent=1)
        print('→', sys.argv[4], 'asis_tobe.json · design_tobe.json'); sys.exit()
    if cmd == 'build':
        problems = check(asis, dz)
        for issue in problems: print(*issue)
        if any(x[0] == '오류' for x in problems):
            print('최종 산출 중단: 설계 오류를 수정한 뒤 다시 build'); sys.exit(2)
        P = build(asis, dz); json.dump(P, open(sys.argv[4], 'w'), ensure_ascii=False); print('→', sys.argv[4], 'To-be 업무', len(tasks(dz)), '· To-be Lv.5', len(dz['tb5']))
