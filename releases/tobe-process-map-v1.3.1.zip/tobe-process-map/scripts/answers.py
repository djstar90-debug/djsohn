"""(선택) 추가로 받은 사용자 결정 기록 — 필수 단계 아님 (compile은 이 기록을 요구하지 않음)

  python scripts/answers.py work/design.json --answer "사용자 답 원문"
"""
import json, sys, datetime
if __name__ == '__main__':
    av = sys.argv[1:]; ans = ''
    if '--answer' in av: k = av.index('--answer'); ans = (av[k + 1] if k + 1 < len(av) else '').strip(); av = av[:k] + av[k + 2:]
    if not av or not ans: print('오류 [판정표] 사용법: answers.py work/design.json --answer "사용자 답 원문" — 사용자에게 받은 답을 그대로'); sys.exit(1)
    d = json.load(open(av[0], encoding='utf-8')); d['review'] = dict(answer=ans, at=datetime.date.today().isoformat())
    json.dump(d, open(av[0], 'w', encoding='utf-8'), ensure_ascii=False, indent=1); print('사용자 결정 기록:', ans[:60])
