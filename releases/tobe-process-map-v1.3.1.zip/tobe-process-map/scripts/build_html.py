"""Build a validated single-file HTML; source data and geometry use the shared map UI.
Usage: build_html.py shell.html engine.js pmd.json out.html [design.json]
"""
import sys, json, gzip, base64, html as H, re


def build(shell, engine, pmd, design=None):
    if not pmd.get('qualityGate', {}).get('passed'):
        raise ValueError('QA gate missing or failed; run validated restructure/release before HTML build')
    for token in ('/*__TITLE__*/', '/*__PMD__*/', '/*__ENGINE__*/'):
        if shell.count(token) != 1:
            raise ValueError('Invalid shell token count: ' + token)
    if pmd.get('sourceAsis'):
        from source_asis import validate_projection
        validate_projection(pmd)
        if 'sourceLayout' not in engine or 'sourceAsisFrame' in engine:
            raise ValueError('Source As-Is requires the shared renderer; original-HTML iframe is forbidden')
    # Escape all <, not only lowercase </script, including data supplied by users.
    data = json.dumps(pmd, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    out = shell.replace('/*__TITLE__*/', H.escape(pmd['text']['title']), 1)
    out = out.replace('/*__PMD__*/', data + ';', 1)
    out = out.replace('/*__ENGINE__*/', engine, 1)
    if design is not None:
        z = base64.b64encode(gzip.compress(json.dumps(design, ensure_ascii=False, sort_keys=True).encode('utf-8'), mtime=0)).decode()
        out = out.replace('</body>', '<script type="application/gzip+base64" id="pm-design">' + z + '</script>\n</body>', 1)
    return out


if __name__ == '__main__':
    shell = open(sys.argv[1], encoding='utf-8').read(); engine = open(sys.argv[2], encoding='utf-8').read()
    pmd = json.load(open(sys.argv[3])); design = json.load(open(sys.argv[5])) if len(sys.argv) > 5 else None
    open(sys.argv[4], 'w', encoding='utf-8').write(build(shell, engine, pmd, design))
