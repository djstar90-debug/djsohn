"""Agent 수정 — 요청 하나로 설계 전체를 함께 고친다 (a 지도 · b Agent 상세 페이지 · c 흐름 따라가기)

  python scripts/agent_edit.py work/design.json rename S4a "새 Agent 이름"
  python scripts/agent_edit.py work/design.json role S4a "새 역할 설명"
  python scripts/agent_edit.py work/design.json merge S1a,S1b --into S1a [--name "합친 이름"]
  python scripts/agent_edit.py work/design.json add B2 S2c "새 Agent 이름" "역할 설명"
  python scripts/agent_edit.py work/design.json remove S2c --to S2a

- 이름이 바뀌면 설계 안의 모든 문장(흐름 문장·이름표·단계 요약·상세 설명·Agent 페이지·게이트 이름·소멸 설명)에서 예전 이름을 새 이름으로 바꾸고 조사(이/가·을/를·은/는·와/과·으로/로)를 맞춘다
- 통합·삭제: 업무(tb.sub)를 옮기고, Agent 페이지 내용(기능·Pain point·기대 변화)을 합치고, 문장의 주어도 옮긴 Agent로
- 바뀐 이름은 design.agent_log에 '예전 → 새'로 남는다 — check_design [싱크]는 이 기록에 있는 예전 이름만 본다 (바꾸지 않았으면 볼 것이 없음)
- 지도의 레인·윤곽선·흐름 따라가기 창 위쪽 이름은 데이터(subs·bands)에서 읽으므로 자동으로 따라온다
"""
import json, re, sys, datetime

def _final(ch):   # 받침 유무 (한글이 아니면 영문 끝소리로 대강: Agent·Orchestrator 등은 받침 없음으로 읽음)
    if '가' <= ch <= '힣': return (ord(ch) - 0xAC00) % 28
    return 0
JOSA = [('이', '가'), ('을', '를'), ('은', '는'), ('과', '와'), ('으로', '로')]
def _josa(nv, tail):
    """새 이름 끝소리에 맞춘 조사: (지금 조사, 맞는 조사) 또는 None"""
    f = _final(nv.strip()[-1]) if nv.strip() else 0
    for a, b in JOSA:
        cur = a if tail.startswith(a) else (b if tail.startswith(b) else None)
        if cur: return cur, (b if (a == '으로' and f == 8) else (a if f else b))
    return None

def replace_name(text, old, nv):
    if not isinstance(text, str) or old not in text: return text
    out, i = '', 0
    for m in re.finditer(re.escape(old), text):
        out += text[i:m.start()] + nv; i = m.end()
        j = _josa(nv, text[i:i + 2])
        if j and j[0] != j[1]: out += j[1]; i += len(j[0])
    return out + text[i:]

SKIP_TOP = ('structure', 'inputs', 'agent_log', 'pruned', 'review')
def walk_replace(d, old, nv):
    n = [0]
    def go(o):
        if isinstance(o, dict):
            for k, v in list(o.items()):
                if isinstance(v, str):
                    w = replace_name(v, old, nv)
                    if w != v: o[k] = w; n[0] += 1
                else: go(v)
        elif isinstance(o, list):
            for i, v in enumerate(o):
                if isinstance(v, str):
                    w = replace_name(v, old, nv)
                    if w != v: o[i] = w; n[0] += 1
                else: go(v)
    for top in [k for k in d if k not in SKIP_TOP]: go(d[top])
    return n[0]

def _obj(d, aid):
    if aid in d.get('subs', {}): return d['subs'][aid]
    return next((b for b in d.get('bands', []) if b.get('id') == aid), None)

def log(d, **kw): d.setdefault('agent_log', []).append(dict(kw, at=datetime.date.today().isoformat()))

def rename(d, aid, nv):
    o = _obj(d, aid)
    if not o: raise SystemExit(f'오류 Agent {aid} 없음')
    old = o['name']
    if old == nv: return 0   # 같은 이름이면 아무것도 하지 않음 (기록도 남기지 않음)
    n = walk_replace(d, old, nv); o['name'] = nv
    log(d, op='rename', id=aid, old=old, new=nv); return n

def role(d, aid, desc):
    o = _obj(d, aid)
    if not o: raise SystemExit(f'오류 Agent {aid} 없음')
    o['desc'] = desc; log(d, op='role', id=aid)

def merge(d, srcs, into, name=None):
    if into not in d['subs']: raise SystemExit(f'오류 세부 Agent {into} 없음')
    srcs = [s for s in srcs if s != into]
    for s in srcs:
        if s not in d['subs']: raise SystemExit(f'오류 세부 Agent {s} 없음')
    tgt = d['subs'][into]
    for s in srcs:
        so = d['subs'][s]
        for k, t in d['tb'].items():   # 업무 옮기기
            if t.get('sub') == s: t['sub'] = into
        for key in ('d', 's'):   # 데이터·시스템 합치기 (겹치면 하나만)
            have = {json.dumps(x, ensure_ascii=False) for x in tgt.get(key, [])}
            tgt[key] = tgt.get(key, []) + [x for x in so.get(key, []) if json.dumps(x, ensure_ascii=False) not in have]
        for b in d.get('story', {}).values():   # Agent 페이지 내용 합치기
            ss = b.get('subs', {})
            if s in ss:
                ti = ss.setdefault(into, {'f': [], 'pn': [], 'e': ''})
                ti['f'] = ti.get('f', []) + ss[s].get('f', []); ti['pn'] = ti.get('pn', []) + ss[s].get('pn', [])
                if ss[s].get('e') and ss[s]['e'] not in (ti.get('e') or ''): ti['e'] = ((ti.get('e') or '') + ' ' + ss[s]['e']).strip()
                del ss[s]
        for bd in d.get('bands', []):
            if s in bd.get('subs', []): bd['subs'] = [x for x in bd['subs'] if x != s]
        walk_replace(d, so['name'], tgt['name'])   # 문장 주어도 합친 Agent로
        log(d, op='merge', id=s, old=so['name'], new=tgt['name'], into=into)
        del d['subs'][s]
    if name: rename(d, into, name)

def add(d, band, sid, name, desc):
    if sid in d['subs']: raise SystemExit(f'오류 {sid}가 이미 있음')
    bd = next((b for b in d.get('bands', []) if b.get('id') == band), None)
    if not bd: raise SystemExit(f'오류 큰 기능 {band} 없음')
    d['subs'][sid] = dict(name=name, desc=desc, d=[], s=[]); bd.setdefault('subs', []).append(sid)
    d.setdefault('story', {}).setdefault(band, {}).setdefault('subs', {})[sid] = {'f': [], 'pn': [], 'e': ''}
    log(d, op='add', id=sid, new=name, band=band)

def remove(d, sid, to):
    merge(d, [sid], to)

if __name__ == '__main__':
    a = sys.argv[1:]
    if len(a) < 3: print(__doc__); sys.exit(1)
    p, op = a[0], a[1]; d = json.load(open(p, encoding='utf-8')); opt = lambda k: a[a.index(k) + 1] if k in a else None
    if op == 'rename': n = rename(d, a[2], a[3]); print(f'이름 변경: 문장 {n}곳 함께 바꿈' if n else '같은 이름 — 바꿀 것 없음')
    elif op == 'role': role(d, a[2], a[3]); print('역할 설명 변경')
    elif op == 'merge': merge(d, a[2].split(','), opt('--into'), opt('--name')); print('통합 완료')
    elif op == 'add': add(d, a[2], a[3], a[4], a[5] if len(a) > 5 else ''); print('추가 완료 — 업무(tb.sub)를 배정하고 Agent 페이지 내용을 채운 뒤 compile')
    elif op == 'remove': remove(d, a[2], opt('--to')); print('삭제 완료 (업무는 --to Agent로 옮김)')
    else: print(__doc__); sys.exit(1)
    json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print('→ 다음: check_design (싱크 점검) · compile · 화면에서 a) 지도 b) 상세 페이지 c) 흐름 따라가기 확인')
