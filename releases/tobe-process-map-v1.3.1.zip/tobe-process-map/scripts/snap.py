"""회귀 비교용 화면 캡처: 같은 상태 목록을 캡처해 폴더에 저장"""
import asyncio, sys, os
from playwright.async_api import async_playwright
STATES = [(scr, lv, st, vw) for scr in ('asis', 'ns') for lv in (4, 5, 6) for st in ('all', '1', '4') for vw in ('compact',)] + \
         [('ns', 6, '1', 'flow'), ('ns', 5, '3', 'flow'), ('asis', 6, '6', 'flow')]
async def main(path, out):
    os.makedirs(out, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={'width': 1600, 'height': 1200})
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.add_init_script("document.addEventListener('DOMContentLoaded',()=>{const s=document.createElement('style');s.textContent='*,*::before,*::after{transition:none!important;animation:none!important;caret-color:transparent!important}#toast{display:none!important}';document.head.appendChild(s);});")
        await pg.goto('file://' + os.path.abspath(path)); await pg.wait_for_timeout(1500)
        for scr, lv, st, vw in STATES:
            await pg.click(f'[data-scr="{scr}"]'); await pg.click(f'[data-lv="{lv}"]')
            await pg.click(f'#stSeg [data-st="{st}"]'); await pg.click(f'[data-vw="{vw}"]')
            await pg.wait_for_timeout(900)
            await pg.evaluate('window.scrollTo(0,0)'); await pg.wait_for_timeout(100)
            await pg.screenshot(path=f'{out}/{scr}{lv}_{st}_{vw}.png', full_page=True)
        await pg.click('[data-vw="compact"]')
        await pg.click('#btnMap'); await pg.wait_for_timeout(600); await pg.screenshot(path=f'{out}/map.png', full_page=True)
        await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300)
        await pg.click('#btnPage'); await pg.wait_for_timeout(600); await pg.screenshot(path=f'{out}/page.png', full_page=True)
        await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300)
        if await pg.evaluate("(() => { const b = document.querySelector('#btnAx'); return !!(b && !b.hidden && b.offsetParent); })()"):
            await pg.click('#btnAx'); await pg.wait_for_timeout(700); await pg.screenshot(path=f'{out}/ax.png', full_page=True)
        await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300)
        await pg.click('[data-scr="ns"]'); await pg.click('[data-lv="6"]'); await pg.click('#stSeg [data-st="1"]'); await pg.wait_for_timeout(400)
        await pg.evaluate("window.__PM3__.showNode((window.__PMD__.views[6].ns.nodes[0] || {}).id)"); await pg.wait_for_timeout(500)
        await pg.screenshot(path=f'{out}/panel.png')
        await pg.keyboard.press('Escape')
        await pg.click('#btnTour'); await pg.wait_for_timeout(1800); await pg.screenshot(path=f'{out}/tour1.png')
        await pg.keyboard.press('ArrowRight'); await pg.wait_for_timeout(1800); await pg.screenshot(path=f'{out}/tour2.png')
        print('errors', errs)
        await b.close()
asyncio.run(main(sys.argv[1], sys.argv[2]))
