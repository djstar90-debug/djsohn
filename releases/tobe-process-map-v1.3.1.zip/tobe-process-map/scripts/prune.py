"""업데이트: 새 엑셀에서 없어진 행 정리 (업무명 대조로 행마다 정한 결과대로)

  python scripts/prune.py work/asis.json work/design.json                       → 없어진 행 목록만 (정리 안 함)
  python scripts/prune.py work/asis.json work/design.json --decide decide.json  → 정리
     decide.json = {"1-1-1-3-2-4": "gone", "2-1-1-2-4-6": "->2-1-1-2-4-5", …}
     gone      = 정말 없어진 업무: 판정·흐름 문장·상세 설명·Agent 업무·연결선에서 뺌
     ->행번호  = 그 행으로 옮겨 간(합쳐진) 업무: 판정을 그 행으로 넘기고(그 행에 판정이 없을 때), 문장·연결을 그 행으로 바꿈
"""
import json, re, sys, datetime
ROWID = re.compile(r'^\d+(?:-\d+){5}$')

def prune(asis, d, decide):
    A6, TB = asis['A6'], d['tb']; DEL = [k for k in TB if k not in A6 and ROWID.match(k)]; log = []
    miss = [k for k in DEL if k not in decide]
    if miss: raise ValueError('삭제/이동 결정 누락: ' + ', '.join(miss))
    for k in DEL:
        how = str(decide[k]).strip()
        if how != 'gone' and not (how.startswith('->') and how[2:].strip() in A6):
            raise ValueError(f'잘못된 삭제/이동 결정: {k}: {how}')
    for k in DEL:
        how = str(decide[k]).strip(); to = how[2:].strip() if how.startswith('->') else None
        if to and to not in A6: raise ValueError(f'이동 대상 없음: {to}')
        old = TB.pop(k)
        if to and not (TB.get(to) or {}).get('t'):   # 옮겨 간 행에 판정이 없으면 이전 판정을 넘김
            TB[to] = dict({f: v for f, v in old.items() if f in ('t', 'sub', 'lb', 'tg', 'note')}, src_n=A6[to]['n']); moved_tb = True
        else: moved_tb = False
        # 흐름 따라가기: 단계의 ids에서 빼거나 바꿈, ids가 비면 그 걸음을 뺌
        for st, tv in (d.get('tour') or {}).items():
            for bt in tv.get('beats', []):
                keep = []
                for sp in bt.get('steps', []):
                    ids = [(to if x == k else x) for x in sp.get('ids', [])] if to else [x for x in sp.get('ids', []) if x != k]
                    ids = list(dict.fromkeys(i for i in ids if i))
                    if ids: sp['ids'] = ids; keep.append(sp)
                bt['steps'] = keep
        for key, m in (d.get('desc') or {}).items():   # 상세 설명
            if isinstance(m, dict) and k in m:
                v = m.pop(k)
                if to and to not in m: m[to] = v
        for b in (d.get('story') or {}).values():      # Agent 기능에 묶인 업무
            for ss in (b.get('subs') or {}).values():
                for f in ss.get('f', []):
                    if isinstance(f, list) and len(f) > 1 and isinstance(f[1], list): f[1][:] = list(dict.fromkeys([(to if x == k else x) for x in f[1] if to or x != k]))
        ne = []
        for e in d.get('new_edges', []):              # 설계가 만든 연결
            if k in e[:2]:
                if not to: continue
                e = [to if x == k else x for x in e[:2]] + list(e[2:])
            ne.append(e)
        if 'new_edges' in d: d['new_edges'] = ne
        fix = []
        def sweep(o, path):   # 남은 참조 모두: 목록 안의 행 번호는 빼거나 바꾸고, 하나짜리 값(앵커 등)은 옮겼으면 바꾸고 아니면 '다시 정할 곳'으로 보고
            if isinstance(o, dict):
                for kk, v in list(o.items()):
                    if v == k:
                        if to: o[kk] = to
                        else: fix.append(path + '.' + kk)
                    else: sweep(v, path + '.' + kk)
            elif isinstance(o, list):
                if any(x == k for x in o):
                    o[:] = list(dict.fromkeys([(to if x == k else x) for x in o if to or x != k])) if all(isinstance(x, str) for x in o) else [(to if x == k else x) for x in o if to or x != k]
                for i, v in enumerate(o): sweep(v, f'{path}[{i}]')
        for top in [x for x in d if x not in ('pruned', 'tb')]: sweep(d[top], top)
        for n, t in TB.items(): sweep(t, 'tb.' + n)
        log.append(dict(id=k, how='moved' if to else 'gone', to=to or '', tb_moved=moved_tb, anchors_to_fix=fix, name=old.get('src_n', '')))
    d['pruned'] = (d.get('pruned') or []) + [dict(x, at=datetime.date.today().isoformat()) for x in log]
    return log

if __name__ == '__main__':
    av = sys.argv[1:]; dec = None
    if '--decide' in av: i = av.index('--decide'); dec = json.load(open(av[i + 1], encoding='utf-8')); av = av[:i] + av[i + 2:]
    asis = json.load(open(av[0], encoding='utf-8')); d = json.load(open(av[1], encoding='utf-8'))
    DEL = [k for k in d.get('tb', {}) if k not in asis['A6'] and ROWID.match(k)]
    if dec is None:
        print(f'새 엑셀에서 없어진 행 {len(DEL)}개 (업무명 대조로 행마다 [정말 없어짐]/[다른 행으로 옮겨 감] 결정):')
        for k in DEL: print(f"- {k} {d['tb'][k].get('src_n', '')} (이전 판정 {d['tb'][k].get('t', '')})")
        sys.exit(0 if not DEL else 2)
    log = prune(asis, d, dec); json.dump(d, open(av[1], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    for x in log: print(f"{x['id']} {x['name'][:30]}: " + (f"→ {x['to']}로 옮김" + (' (판정도 넘김)' if x['tb_moved'] else ' (그 행 판정 유지)') if x['how'] == 'moved' else '없어짐 — 뺌') + (f" · 다시 정할 곳: {', '.join(x['anchors_to_fix'])}" if x['anchors_to_fix'] else ''))
