"""엔진·화면 틀 고정 문구 점검 (v34) — HTML에 박혀 나가는 안내·제목·버튼 문구가 산출물 문체인지

  python scripts/ui_text_check.py assets/engine.js      (또는 만든 HTML)   → 걸린 문구 목록, 있으면 종료 코드 1

잡는 것: 질문꼴 제목(무엇을 …나 · 어떤 …가 · 어디서 왔나), 화살표로 이어 붙인 설명(무엇이 필요한가 → 그 형식), 구어 서술(보여 줍니다 · 맡는 · 고치세요 · 이어받습니다 · 만듭니다 · 들어갑니다 · 진하게 · …면 됩니다)
빼는 것: 사용자에게 묻는 대화 질문(…할까요?), 범례 화살표(사람 → Agent 등), 게이트 '→ … 호출', 키 안내(←/→, As-Is ↔ To-be)
"""
import re, sys, json

BAD = [
    ('질문꼴 제목', re.compile(r'(무엇|어떤|어디서|어디로|누가|누구를?|언제)[^.?!\n]{0,24}(나|가|나요|는가|인가|되나|하나|오나|가나)(\s|$|\)|<|\'|")')),
    ('화살표 설명', re.compile(r'[가-힣]\)?\s*→\s*[가-힣(]')),   # 한글 사이 화살표 전부 (범례·게이트·키 안내는 ALLOW)
    ('구어 서술', re.compile(r'나오는 (산출물|결과)|들어(오|가)는 (데이터|Data)')),
    ('구어 서술', re.compile(r'보여 ?줍니다|보여 ?준다|맡는 (일|업무)|고치세요|고칩니다|이어받습니다|만듭니다|들어갑니다|진하게|누르면 됩니다|읽으면 됩니다|하려고|일합니다|덮는|줄여 쓴|봅니다(?!\w)')),
]
ALLOW = re.compile(r'(할까요|시작할까요|따라갈까요)\?|사람 → (Agent|사람)|Agent → (사람|Agent)|→ .{0,40}호출|←\s*/?\s*→|↔|확정 → 다음 업무 시작|흡수 → |^[①-⑳]')

def strings(src):
    out = set()
    src = re.sub(r'/\*.*?\*/', ' ', src, flags=re.S)
    for m in re.finditer(r"'([^'\n]{3,400})'|\"([^\"\n]{3,400})\"|`([^`]{3,600})`|>([^<>]{3,400})<", src):
        x = next(g for g in m.groups() if g)
        if re.search(r'[가-힣]{2}', x): out.add(re.sub(r'\s+', ' ', x))
    return out

def lint(src):
    hits = []
    for x in strings(src):
        if '//' in x[:3]: continue
        for code, rx in BAD:
            m = rx.search(x)
            if m and not ALLOW.search(x[max(0, m.start() - 20): m.end() + 30]): hits.append((code, x[max(0, m.start() - 25): m.end() + 25].strip()))
    return sorted(set(hits))

if __name__ == '__main__':
    src = open(sys.argv[1], encoding='utf-8').read()
    if src.lstrip().startswith('<'):   # HTML이면 엔진 스크립트와 화면 틀만
        src = '\n'.join(re.findall(r'<script[^>]*>(.*?)</script>', src, re.S)) + re.sub(r'<script[^>]*>.*?</script>', ' ', src, flags=re.S)
    else:
        L = src.split('\n'); sh = [l for l in L if l.startswith('const SHELL = ')]
        if sh:
            v = json.loads(sh[0][len('const SHELL = '):-1]); src = '\n'.join(l for l in L if not l.startswith('const SHELL = ')) + '\n' + (v if isinstance(v, str) else json.dumps(v, ensure_ascii=False))
    h = lint(src)
    for code, x in h: print(f'[고정 문구] {code} | {x}')
    print(f'고정 문구 점검: {len(h)}건'); sys.exit(1 if h else 0)
