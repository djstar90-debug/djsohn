"""판단 층 보조 (결정적)
  skeleton asis.json out.json   : 설계 파일 초안 — 레인 자동, tb는 비움(As-Is 행별 판정 칸을 만들지 않음) + 같은 폴더에 lv4_sheet.md(Lv.4별 재설계 재료)
  fill asis.json design.json out.json : Claude가 쓴 설계에서 기계적으로 정할 수 있는 칸을 채움
     · 신규 노드: anchor + conn(splice/in/out) → 단계·순번·연결선, Orchestrator(M)는 자동 신호선
     · 세부 Agent 데이터·시스템 '기존 보유'(대체하는 As-Is 행의 인풋·시스템 원문, 문서 도구 제외) + new_data/new_sys
     · Agent 페이지 기능(f)·Pain point(pn) 초안, 흐름 따라가기 박스별 문장(beats), 산출물(outnew), 형식 사전
  Claude가 직접 쓰는 칸(판정, To-be 업무명, Agent 구조, 소개·효과 문단, 단계 요약)은 건드리지 않는다.
"""
import sys, json, re
from collections import OrderedDict, Counter

FORM = {"문서 (PPT·PDF·Word)": "파일 (PPT·PDF·Word)", "메일·메신저·회의록": "텍스트 (메일·메신저·회의록)", "DB·이력": "DB 레코드 (API 조회)",
        "표·수치 (Excel·ERP)": "표 데이터 (Excel·ERP)", "일정": "일정 데이터 (캘린더·PMS)", "이미지·영상 파일": "미디어 파일 (이미지·영상)",
        "규격 표": "표 데이터 (규격)", "규정·계약 문서": "파일 (규정·계약)", "프롬프트·생성 로그": "텍스트 (프롬프트·로그)",
        "카드·현황 화면": "화면 (카드·현황)", "확인·검토 결과": "기록 (확인·검토 결과)"}
OFFICE = re.compile(r'^(Excel|PowerPoint|PPT|Word|PDF|Keynote|Photoshop|Illustrator|Figma|한글|HWP|Premiere|After Effects)', re.I)
EXT = re.compile(r'외부|외주|협력사|에이전시|프로덕션|스튜디오')

def lines(s): return [re.sub(r'^[-•·]\s*', '', x).strip() for x in re.split(r'\n|\s+/\s+', s or '') if x.strip()]   # v35: 줄바꿈뿐 아니라 ' / '로 나눈 항목도 (붙은 '/'는 글자)
def fmt_of(name):
    rules = [(r'메일|메신저|회의록|녹취|카카오', '메일·메신저·회의록'), (r'이력|DB|기록|로그|Fact Base|아카이브', 'DB·이력'),
             (r'예산|Fee|금액|실적|원가|정산|계산서|견적|손익|매출|청구|비용|KPI|수치', '표·수치 (Excel·ERP)'),
             (r'일정|스케줄', '일정'), (r'이미지|영상|소재|시안|캡처|컷', '이미지·영상 파일'), (r'규격|스펙', '규격 표'),
             (r'계약|규정|약관|법무|권리|조항', '규정·계약 문서'), (r'프롬프트|생성 로그', '프롬프트·생성 로그'), (r'화면|카드|대시보드', '카드·현황 화면')]
    for p, f in rules:
        if re.search(p, name): return f
    return '문서 (PPT·PDF·Word)'
def josa(w, a, b):
    c = (w or ' ')[-1]
    if '가' <= c <= '힣': return a if (ord(c) - 0xAC00) % 28 else b
    return a if c in 'LMNRlmnr0136780' else b
core = lambda s: re.sub(r'\s*\([^)]*\)\s*$', '', s or '').strip()

# ---------------- 판정 신호 (참고용 — 판정은 Claude가 references/classification.md 순서로 정함) ----------------
X_SIG = ('개인 폴더', '북마크', '자체 기록', '사후 공유', '장표 작성', '통합 편집', '첨부', '규칙 설정', '팀 공유')
H_SIG = ('미팅', '리허설', '프레젠테이션', '발표', '협의', '협상', '조율', '논의', '재정의', '서명', '체결', '접수 및 결과 수령', 'OK/NG', '셀렉', '시사')
N_SIG = ('확정', '결정', '승인', '선별', '압축', '판정', '네고', '게이트키핑', '반려 시', '수정 지시', '판단')
def hint(name, team):
    s = re.sub(r'\[[^\]]+\]|\([^)]*\)', '', name)
    if any(k in s for k in X_SIG): return 'X?'
    if EXT.search(team or ''): return 'H(외부)'
    tail = ' '.join(s.split()[-2:])
    if any(k in tail for k in N_SIG): return 'N?'
    if any(k in s for k in H_SIG): return 'H?'
    return 'A?'

# ---- AE v15 형식 어휘 (S01 v15에서 가져옴) ----
DG_RULES = [('요청·Brief 자료', r'RFP|OT|Brief|브리프|제안 요청|과제'), ('계약·비용 조건', r'계약|Scope|Fee|견적|예산|비용|단가|청구|조건'),
            ('시안·소재·자산', r'시안|소재|콘티|스토리보드|키비주얼|편집|이미지|영상|자산|원고|배너'), ('실적·정산 수치', r'실적|매출|원가|가결산|정산|계산서|ERP|손익|전망'),
            ('성과·집행 데이터', r'성과|KPI|집행|게재|노출|매체|리포트|큐시트'), ('요청·커뮤니케이션', r'요청|피드백|의견|승인|문의|회의|녹취|메일|메신저|질의'),
            ('과거 이력·기준', r'이력|과거|기준|가이드|규정|DB|아카이브|사례|템플릿')]
FMT_RULES = [('회의 녹취·회의록', r'회의|녹취|미팅'), ('계약서 (PDF·전자계약)', r'계약'), ('ERP·계산서 데이터', r'ERP|세금계산서|계산서'),
             ('Excel 표', r'예산|견적|실적|매출|Fee|원가|단가|수치|물량|표|리스트|큐시트|정산'), ('이미지·영상 파일', r'시안|소재|이미지|영상|콘티|키비주얼|편집본|원고|배너|캡처'),
             ('웹·뉴스·SNS (공개 자료)', r'뉴스|SNS|포털|공개|트렌드'), ('DB 기록', r'DB|이력|기록|아카이브|목록')]
SP_RULES = [('요청·알림 주고받기', r'메일|메신저|Knox|카카오|알림|협업'), ('실적·정산 조회', r'ERP|정산|계산서|재무|실적'), ('자료 보관·검색', r'드라이브|아카이브|Cook|쿡|DAM|저장|클라우드|공유 폴더|PC'),
            ('외부 정보 수집', r'뉴스|포털|입찰|검색|모니터링|SNS|렙사|매체사'), ('요약·초안 생성', r'AI|GPT|Claude|Gemini|요약|노트|생성'), ('업무 처리', r'PM 시스템|프로젝트 관리|결재|전자계약|캘린더|일정')]
OF_RULES = [('현황 화면 (대시보드)', r'현황|대시보드|진행'), ('확인 기록 (체크리스트)', r'점검|검수|대조|체크|확인'), ('Excel 표', r'비교표|산정|집계|표|예산|견적|실적|전망'),
            ('Knox 메일·메신저 발송', r'발송|질의서|요청서|공유'), ('Word·PPT 문서', r'보고서|제안서|초안|자료|Deck|카드')]
def _pick(rules, name, default):
    return next((g for g, rx in rules if re.search(rx, name or '')), default)
def v15_fill(d, rep):
    for sid, v in d['subs'].items():
        for x in v.get('d', []):
            if len(x) == 5: x.append([_pick(FMT_RULES, x[0], 'PPT·PDF·Word 문서') if x[1] else 'Agent가 만드는 DB 기록'])
        if 'dg' not in v and v.get('d'):
            g = OrderedDict()
            for x in v['d']: g.setdefault(_pick(DG_RULES, x[0], '그 밖의 자료'), []).append(x[0])
            v['dg'] = [[k, xs] for k, xs in g.items()]; rep['v15 형식 — 투입 데이터 묶음(dg) 초안'] += 1
        if 'sp' not in v and v.get('s'):
            g = OrderedDict()
            for x in v['s']: g.setdefault(_pick(SP_RULES, x[0], '자동 처리·연동 (신규)' if not x[1] else '업무 처리'), []).append(x[0])
            v['sp'] = [[k, xs] for k, xs in g.items()]; rep['v15 형식 — 활용 시스템 용도(sp) 초안'] += 1
        outs = d.get('outs', {}).get(sid, [])
        if 'of' not in v and outs:
            v['of'] = [[o[0], [_pick(OF_RULES, o[0], 'DB 기록 (다음 Agent가 조회)')]] for o in outs]
            v['og'] = [[re.sub(r'\s*\([^)]*\)$', '', o[0]), [o[0]]] for o in outs]; rep['v15 형식 — 산출물(of·og) 초안'] += 1
MEMO_RX = re.compile(r'\s*\(([^()]*(?:확인\s*필요|가설|미정|추정|TBD|tbd)[^()]*)\)')
def memo_off(name):
    """엑셀 조직명에 붙은 작성자 메모(괄호 안 '확인 필요'·'가설' 등)를 떼어 냄 → (이름, 메모). 메모가 아닌 괄호(예: '(외부)')는 그대로"""
    memo = '; '.join(m.group(1).strip() for m in MEMO_RX.finditer(name or ''))
    return MEMO_RX.sub('', name or '').strip(), memo
def skeleton(asis):
    A6 = asis['A6']; bk = lambda a: a.get('bon') or a['team']   # 레인 = 담당본부 원문 그대로 (축약·생략·별칭 없음)
    bons = list(dict.fromkeys(bk(a) for a in A6.values()))
    lanes = [dict(k=f'l{i}', name=memo_off(b)[0], sub='', bon=[b], team=sorted({a['team'] for a in A6.values() if bk(a) == b}), short=memo_off(b)[0], who=memo_off(b)[0], memo=memo_off(b)[1])
             for i, b in enumerate(sorted(bons, key=lambda t: (bool(EXT.search(t)), bons.index(t))))]
    tb = OrderedDict()   # v1.1.2: As-Is 행마다 판정 칸을 만들지 않는다 — To-be는 Lv.4별로 새로 설계 (redesign.md)
    return dict(meta=dict(text=dict(title='', eyebrow='', ver='As-Is 원본 · To-be 가설 · 팀 검토용', crumb='', foot=''), start=dict(scr='asis', lv=5)),
                mode='restructure', tb5=OrderedDict(), asis_names=OrderedDict((k, a['n']) for k, a in A6.items()),
                lanes=lanes, tb=tb, new_edges=[], bands=[], subs={}, story={}, stage_gate={k: '' for k in asis['A4']},
                outs={}, outnew={}, when={}, whenHave={}, sysinfo={}, dfmt={}, form=FORM, tour={}, summary_mode='all', ui={})

AG_RX = re.compile(r'1차\s*검수|1차\s*점검|검토|리서치|조사|취합|정리|현황|관리|기록|작성|대조|점검|확인|수집|업데이트|공유|전달')
HU_RX = re.compile(r'준법|법무|심의|컴플라이언스|연락|협의|논의|협상|미팅|회의|커뮤니케이션|최종|승인|결정|확정|체결|발표|PT|촬영')
def lv4_sheet(asis):
    """Lv.4별 재설계 재료 — 행별 판정용이 아니라, Lv.4가 만들어야 할 결과와 사람 개입 현황을 한눈에 보는 시트"""
    A6, A5, A4 = asis['A6'], asis['A5'], asis['A4']
    key = lambda a5: a5.get('g4id') or a5.get('g4') or a5.get('l4id')
    G = OrderedDict()
    for k5, a5 in A5.items(): G.setdefault(key(a5), dict(name=a5.get('g4') or a5.get('l4', ''), st=a5.get('l4', ''), l5=[]))['l5'].append(k5)
    L = ['# Lv.4별 재설계 재료 (redesign.md 1절 — As-Is 순서를 따르지 말고 이 재료로 To-be Lv.5·Lv.6를 새로 설계)', '']
    for i, (k4, g) in enumerate(G.items(), 1):
        rows = [k for k5 in g['l5'] for k in A5[k5]['kids'] if k in A6]
        uq = lambda f: list(dict.fromkeys(x.strip(' -') for k in rows for x in str(A6[k].get(f, '')).split('\n') if x.strip(' -')))
        hu = [k for k in rows if HU_RX.search(A6[k]['n'])]; ag = [k for k in rows if k not in hu and AG_RX.search(A6[k]['n'])]
        L += [f'## Lv.4 {i}. {g["name"]}  (Lv.4 키: {k4} · 상위 단계: {g["st"]})', '',
              f'- As-Is Lv.5 {len(g["l5"])}개 · Lv.6 {len(rows)}개 · 담당: ' + ', '.join(dict.fromkeys(A6[k].get('bon') or A6[k]['team'] for k in rows)),
              '- As-Is Lv.5: ' + ' → '.join(A5[k5]['n'] for k5 in g['l5']),
              '- 산출물(엑셀 아웃풋): ' + ('; '.join(uq('out')[:8]) or '(빈칸)'),
              '- 투입 데이터: ' + ('; '.join(uq('inp')[:8]) or '(빈칸)'),
              '- 활용 시스템: ' + ('; '.join(uq('sys')[:8]) or '(빈칸)'),
              f'- 사람 역할 성격의 As-Is 업무 {len(hu)}개 (준법·연락·논의·최종 판단 등): ' + ('; '.join(f'{k} {A6[k]["n"]}' for k in hu[:10]) or '없음'),
              f'- Agent 역할 성격의 As-Is 업무 {len(ag)}개 (1차 검수·리서치·관리·취합·작성 등): ' + ('; '.join(f'{k} {A6[k]["n"]}' for k in ag[:10]) or '없음'),
              '- Pain point:'] + [f'  - {p}' for p in uq('pain')[:10]] + ['']
    return '\n'.join(L)

def fill(asis, d):
    A6, A5, A4 = asis['A6'], asis['A5'], asis['A4']
    TB = d['tb']; rep = Counter()
    st_of = {k: list(A4).index(A5[a['l5'].split(' ')[0]]['l4id']) + 1 for k, a in A6.items()}
    o6 = {k: i for i, k in enumerate(A6)}
    succ = {k: [p for p in a['post'].split(', ') if p in A6] for k, a in A6.items()}
    # ---- 신규 노드 (anchor + conn) ----
    cnt = Counter(); auto = [e for e in d.get('new_edges', [])]
    for k, t in TB.items():
        if k in A6 or 'anchor' not in t: continue
        anc = t['anchor']; cnt[anc] += 1
        t.setdefault('st', st_of[anc]); t.setdefault('l5', A6[anc]['l5'].split(' ')[0]); t.setdefault('o', o6[anc] + 0.01 * cnt[anc])
        if t.get('_wired') or any(k in e[:2] for e in auto): continue   # 이미 연결됨 (fill을 다시 돌려도 중복 없음)
        c = t.get('conn', {})
        if t['t'] == 'M':
            sig = re.sub(r'^[①②③]\s*', '', t['lb'].split('→')[0]).strip()   # v22: 글자 수로 자르지 않음
            if t.get('sub', '').endswith('0b'): auto.append([anc, k, 'o', c.get('label', '현황 반영')])
            else:
                auto.append([anc, k, 'o', c.get('label', sig)])
                for b in c.get('out', succ[anc]): auto.append([k, b, 'o', '호출'])
        else:
            if 'splice' in c:
                sp = c['splice']; auto.append([sp, k, 's', '']); auto += [[k, b, 's', ''] for b in succ[sp]]
            auto += [[a, k, 's', ''] for a in c.get('in', [])] + [[k, b, 's', ''] for b in c.get('out', [])]
        t['_wired'] = True; rep['신규 노드 연결'] += 1
    d['new_edges'] = auto
    # ---- 세부 Agent 데이터·시스템 ----
    d.setdefault('dfmt', {})
    for s, v in d['subs'].items():
        tasks = [k for k in A6 if TB[k].get('sub') == s and TB[k]['t'] == 'A']
        if 'd' not in v:
            hd, hs = [], []
            for k in tasks:
                hd += [x for x in lines(A6[k]['inp']) if x not in hd]
                hs += [x for x in lines(A6[k]['sys']) if x not in hs and not OFFICE.match(x)]
            hd = (hd or v.get('have_data', []))[:6]; hs = (hs or v.get('have_sys', []))[:5]
            # 5칸: [이름, 보유(1/0), 상태 E 기존 · P 준비중 · N 신규, 근거 메모, 준비중 괄호(어느 팀이 무엇을)]
            memo = d.get('ds_memo', {})
            nd = [x for x in v.get('new_data', [])]; ns = [x if isinstance(x, list) else [x] for x in v.get('new_sys', [])]
            pend = {x[0]: x for x in v.get('pend', [])}          # [이름, 근거 메모, 괄호] — 사내 준비 현황 자료로 판단
            def item(name, have, extra=''):
                if name in pend: return [name, 0, 'P', pend[name][1] if len(pend[name]) > 1 else '', pend[name][2] if len(pend[name]) > 2 else '']
                if re.search(r'[(（]\s*가설\s*[)）]', name): return [name, 0, 'N', memo.get(name, '엑셀에 가설로 표기 — 도입 검토 중'), '']   # v35: '(가설)' 표기 시스템은 신규 설치 필요
                return [name, have, 'E' if have else 'N', memo.get(name, extra), '']
            v['d'] = [item(x, 1) for x in hd] + [item(x[0], 0, x[2] if len(x) > 2 else '') for x in nd if x[0] not in hd]
            v['s'] = [item(x, 1) for x in hs] + [item(x[0], 0, x[1] if len(x) > 1 else '') for x in ns if x[0] not in hs]
            for x in v.get('new_data', []): d['dfmt'][x[0]] = x[1]
            rep['세부 Agent 데이터·시스템 (상태 E/P/N)'] += 0
            rep['세부 Agent 데이터·시스템'] += 1
        for x in v['d']: d['dfmt'].setdefault(x[0], fmt_of(x[0]))
    # 이전 형식(2칸 [이름, 보유])을 5칸으로 — 상태는 보유 여부로 E/N, 준비중은 pend로 다시 판단
    for v in list(d['subs'].values()) + d['bands']:
        for f in ('d', 's'):
            if f in v: v[f] = [x if len(x) >= 5 else (list(x) + ['E' if x[1] else 'N', '', ''])[:5] for x in v[f]]
    for b in d['bands']:
        if 'd' not in b:
            b['d'], b['s'] = [], []
            for s in b['subs']:
                b['d'] += [x for x in d['subs'][s]['d'] if x[0] not in [y[0] for y in b['d']]]  # 5칸 그대로
                b['s'] += [x for x in d['subs'][s]['s'] if x[0] not in [y[0] for y in b['s']]]
    # ---- Agent 페이지 기능·Pain 초안 ----
    def pains(tasks, n=3):
        out, seen = [], set()
        for k in tasks:
            first = next((re.sub(r'^[-•·]\s*', '', x).strip() for x in A6[k]['pain'].split('\n') if x.strip()), '')
            first = re.sub(r'\s+', ' ', first).rstrip('.')
            if first and first not in seen:
                seen.add(first); out.append([first, [k]])   # v22: 글자 수로 자르지 않음 (원문 첫 줄 전체)
            if len(out) >= n: break
        return out
    for b in d['bands']:
        st = d['story'].setdefault(b['id'], {}); ss = st.setdefault('subs', {})
        for s in b['subs']:
            x = ss.setdefault(s, {})
            tasks = [k for k in TB if TB[k].get('sub') == s and TB[k]['t'] in ('A', 'M')]
            if 'f' not in x: x['f'] = [[core(TB[k]['lb']), [k]] for k in tasks[:3]]; x['_auto_f'] = True; rep['기능 초안 (업무명 복사 — 기능 문장으로 다시 써야 함)'] += 1
            if 'pn' not in x: x['pn'] = pains([k for k in tasks if k in A6]) or [['As-Is에 대응하는 Pain point 기록 없음', []]]
            if not x.get('e'): rep['기대 변화(e) 빈칸 — Claude가 써야 함'] += 1
    # ---- 흐름 따라가기 박스별 문장 ----
    BYBON = any(l.get('bon') for l in d['lanes']); lane = {t: l for l in d['lanes'] for t in (l.get('bon') or l['team'])}
    lkey = (lambda a: a.get('bon') or a['team']) if BYBON else (lambda a: a['team'])
    lwho = lambda l: l.get('who') or l['name']   # 문장 속 주체: 레인 who (기본 = 조직명 원문, 직무명은 사용자가 허락했을 때만)
    order = {k: o6[k] for k in A6}; order.update({k: t['o'] for k, t in TB.items() if k not in A6 and 'o' in t})
    def step(k):
        t = TB[k]; c = core(t.get('lb') or A6[k]['n'])
        # 뼈대만: 문장(d)은 비워 두고 이름표(v)는 업무명으로 채운다(v33) — Claude가 박스마다 원문·판정·입출력·앞뒤를 읽고 직접 쓴다 (SKILL.md 3.5단계, check_design [서술] 오류)
        _nm = (TB.get(k) or {}).get('lb') or (A6[k]['n'] if k in A6 else '')
        st = dict(v=re.sub(r'\s*\([^()]*\)\s*$', '', _nm).strip() if _nm else '', d='', ids=[k])   # v33: 흐름 이름표 기본값 = 그 박스의 업무명 (줄이면 업무명의 말만·같은 순서·같은 동작)
        if d.get('people') == 'role' and t['t'] in ('N', 'H') and k in A6 and A6[k].get('team') and (len({x.get('team') for x in A6.values() if lkey(x) == lkey(A6[k])}) > 1 or lwho(lane[lkey(A6[k])]) == lane[lkey(A6[k])]['name']):   # 직무가 여럿인 레인, 또는 레인에 따로 정한 직무명이 없을 때
            m_ = re.search(r'\(([^()]+)\)\s*$', A6[k]['team']); st['a'] = m_.group(1) if m_ else A6[k]['team']   # 괄호가 없으면 담당 칸 원문   # v35: 직무명 표기 — 담당 칸 괄호 속 직무명(한 레인에 직무가 여럿일 때)
        elif d.get('people') != 'role' and (t['t'] == 'N' or (t['t'] == 'H' and k in A6)): st['a'] = lwho(lane[lkey(A6[k])]) if k in A6 else next(lwho(l) for l in d['lanes'] if l['k'] == t.get('lane'))
        return st
    for si, (sk, s4) in enumerate(A4.items(), 1):
        tv = d['tour'].setdefault(str(si), {})
        if 'beats' in tv: continue
        beats = []
        for k5 in s4['kids']:
            mem = [k for k in A5[k5]['kids'] if TB[k]['t'] != 'X'] + [k for k, t in TB.items() if k not in A6 and t.get('st') == si and t.get('l5') == k5]
            mem.sort(key=lambda k: order.get(k, 1e9))
            if mem: beats.append(dict(t=re.sub(r'^\[[^\]]+\]\s*', '', A5[k5]['n']), steps=[step(k) for k in mem]))
        tv['beats'] = beats; tv['_auto'] = True; rep['흐름 따라가기 뼈대 (문장·이름표는 빈칸 — Claude가 박스마다 직접 씀)'] += 1
        for f in ('now', 'chg', 'next'):
            if not tv.get(f): rep[f'단계 요약 빈칸({f}) — Claude가 써야 함'] += 1
    # 공통 문구 사전 (assets/phrasebook.json): 같은 이름의 데이터·시스템이면 빈칸만 채움
    import os
    pbp = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'assets', 'phrasebook.json')
    if os.path.exists(pbp) and d.get('use_phrasebook', False):   # v21: 기본 끔 — 켜면 같은 이름 항목의 빈칸만 채우고, 상태(준비중 등)는 최신 자료로 확인
        PB = json.load(open(pbp, encoding='utf-8'))
        names_d = {x[0] for v in d['subs'].values() for x in v.get('d', [])}; names_s = {x[0] for v in d['subs'].values() for x in v.get('s', [])}
        for nm in names_d | names_s:
            w = d.setdefault('when', {}); wh = d.setdefault('whenHave', {})
            if nm not in w and nm not in wh and nm in PB['when']: w[nm] = PB['when'][nm]; rep['공통 문구 사전 — 언제 쓰나'] += 1
            if nm in names_s and nm not in d.setdefault('sysinfo', {}) and nm in PB['sysinfo']: d['sysinfo'][nm] = PB['sysinfo'][nm]; rep['공통 문구 사전 — 주고받는 정보'] += 1
            if nm in names_d and nm in PB['dfmt'] and d['dfmt'].get(nm) == fmt_of(nm): d['dfmt'][nm] = PB['dfmt'][nm]
        for nm in names_s:                  # 이름이 달라도 사내 공통 시스템 키워드가 맞으면 (시스템만 — 데이터 이름의 '메일' 등에는 쓰지 않음)
            c = next((c for c in PB.get('canon', []) if re.search(c['pat'], nm)), None)
            if not c: continue
            if nm not in d['when'] and nm not in d['whenHave'] and c['when']: d['when'][nm] = c['when']; rep['공통 문구 사전(키워드) — 언제 쓰나'] += 1
            if nm in names_s and nm not in d['sysinfo'] and c['sysinfo']: d['sysinfo'][nm] = c['sysinfo']; rep['공통 문구 사전(키워드) — 주고받는 정보'] += 1
            for v in list(d['subs'].values()) + d['bands']:
                for x in v.get('s', []):
                    if x[0] == nm and len(x) >= 5 and not x[3] and c['memo'] and x[2] == c['status']: x[3] = c['memo']; rep['공통 문구 사전(키워드) — 근거 메모'] += 1
        for v in list(d['subs'].values()) + d['bands']:
            for x in v.get('d', []) + v.get('s', []):
                m = PB['memo'].get(x[0])
                if not m or len(x) < 5 or x[3]: continue
                if m[0] == 'P' and x[2] == 'N': x[1:5] = [0, 'P', m[1], m[2]]; rep['공통 문구 사전 — 준비중으로 (S04 시점 사내 현황, 최신 자료로 확인)'] += 1
                elif m[0] == x[2]: x[3] = m[1]; rep['공통 문구 사전 — 근거 메모'] += 1
    for k, t in TB.items():
        if k not in A6 and t['t'] == 'A': d.setdefault('outnew', {}).setdefault(k, core(t['lb']))
    # 박스별 설명: 같은 업무가 경로만 달리 반복되면(대괄호 태그를 뺀 업무명이 같고 판정도 같음) 한쪽 문장을 다른 쪽에 맞춰 채움
    ds = d.get('desc') or {}
    base = lambda n: re.sub(r'\s+', ' ', re.sub(r'\[[^\]]*\]', '', n or '')).strip()
    for key in ('A6', 'T6'):
        m = ds.get(key)
        if not m: continue
        grp = {}
        for k, a in A6.items(): grp.setdefault((base(a['n']), TB[k]['t'], TB[k].get('sub')), []).append(k)
        for ks in grp.values():
            src = next((m[k] for k in ks if m.get(k)), None)
            if not src: continue
            for k in ks:
                if not m.get(k): m[k] = src; rep[f'desc.{key} 같은 업무 경로 반복 — 문장 맞춰 채움'] += 1
    if d.get('v15_format', True): v15_fill(d, rep)
    d.setdefault('form', FORM)
    for k, t in TB.items(): t.pop('_wired', None); t.pop('hint', None)
    for k in [k for k in d.get('when', {}) if re.search(r'」 업무에서$', d['when'][k] or '')]: rep['when 틀 문장 (상황으로 다시 써야 함)'] += 1
    return d, rep

if __name__ == '__main__':
    cmd = sys.argv[1]; asis = json.load(open(sys.argv[2]))
    if cmd == 'skeleton':
        d = skeleton(asis); json.dump(d, open(sys.argv[3], 'w'), ensure_ascii=False, indent=1)
        import os; sp = os.path.join(os.path.dirname(os.path.abspath(sys.argv[3])), 'lv4_sheet.md'); open(sp, 'w', encoding='utf-8').write(lv4_sheet(asis)); print('Lv.4별 재설계 재료 →', sp)
        sys.path.insert(0, __file__.rsplit('/', 1)[0]); from compile import scenario_tags
        t5, lines, subl, scen, _ = scenario_tags(asis)
        if lines: print(f'시나리오 태그 {len(lines)}종 {lines[:8]} · 단계별 {dict((k, len(v)) for k, v in scen.items())}' + (' → 병렬박스 적용 (기본값)' if len(lines) >= 3 else ''))
        print('레인', len(d['lanes']), '· As-Is 행', len(asis['A6']), '(행별 판정 칸 없음 — Lv.4별로 To-be를 새로 설계)')
    else:
        d, rep = fill(asis, json.load(open(sys.argv[3])))
        json.dump(d, open(sys.argv[4], 'w'), ensure_ascii=False, indent=1)
        for k, v in rep.items(): print(f'{k}: {v}')
