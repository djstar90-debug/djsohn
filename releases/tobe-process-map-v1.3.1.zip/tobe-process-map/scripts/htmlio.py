"""Read the generated HTML's JSON and engine without executing input scripts."""
import json
import re
from html.parser import HTMLParser


class _ScriptParser(HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=False)
        self.source = source
        self.offsets = [0] + [match.end() for match in re.finditer('\n', source)]
        self.scripts = []
        self.active = None

    def source_offset(self):
        line, column = self.getpos()
        return self.offsets[line - 1] + column

    def handle_starttag(self, tag, attrs):
        if tag.lower() != 'script': return
        ids = [value for key, value in attrs if key.lower() == 'id']
        if len(ids) > 1: raise ValueError('Duplicate id attributes on script')
        self.active = {'id': ids[0] if ids else None, 'start': self.source_offset() + len(self.get_starttag_text()), 'end': None}
        self.scripts.append(self.active)

    def handle_endtag(self, tag):
        if tag.lower() == 'script' and self.active is not None:
            self.active['end'] = self.source_offset()
            self.active = None


def _script(source, script_id):
    parser = _ScriptParser(source); parser.feed(source); parser.close()
    matches = [item for item in parser.scripts if item['id'] == script_id]
    if len(matches) != 1:
        raise ValueError(f'Expected one script #{script_id}; found {len(matches)}')
    item = matches[0]
    if item['end'] is None:
        raise ValueError(f'Missing closing script tag for #{script_id}')
    return item['start'], item['end']


def split(html):
    """Return (PMD, engine, prefix, middle, suffix), preserving shell slices.

    Reject absent/duplicate markers and trailing executable content. A malformed
    source must never be interpreted using ``str.find``'s -1 offset.
    """
    ds, de = _script(html, 'pm-data')
    assignment = re.match(r'\s*window\.__PMD__\s*=\s*', html[ds:de])
    if assignment is None:
        raise ValueError('Missing window.__PMD__ assignment in #pm-data')
    start = ds + assignment.end()
    raw = html[start:de]
    try:
        data, end = json.JSONDecoder().raw_decode(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f'Invalid #pm-data JSON: {exc.msg}') from exc
    if raw[end:].strip() not in ('', ';'):
        raise ValueError('Unexpected content after #pm-data JSON')
    if not isinstance(data, dict):
        raise ValueError('#pm-data must contain a JSON object')
    es, ee = _script(html, 'pm-engine')
    if es <= de:
        raise ValueError('#pm-engine must follow #pm-data')
    return data, html[es:ee], html[:start], html[de:es], html[ee:]
