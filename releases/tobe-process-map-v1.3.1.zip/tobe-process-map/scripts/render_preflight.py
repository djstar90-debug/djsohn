"""Deterministic renderer schema checks before compilation/browser startup (v1.3).

No defaults or content repairs are applied. Errors identify the exact JSON path.
Optional grouping/format fields may be absent; if present they must be well typed.
CLI: render_preflight.py design design.json [--asis asis.json]
     render_preflight.py pmd pmd.json
"""
import argparse
import json
import math
from collections import Counter


class Audit:
    def __init__(self): self.errors = []
    def fail(self, path, message, code='RENDER_SCHEMA'):
        self.errors.append({'severity':'error','code':code,'path':path,'message':message})
    def obj(self, value, path):
        if not isinstance(value, dict): self.fail(path,'객체가 필요합니다.'); return None
        return value
    def arr(self, value, path, nonempty=False):
        if not isinstance(value, list): self.fail(path,'배열이 필요합니다.'); return None
        if nonempty and not value: self.fail(path,'내용이 있는 배열이 필요합니다.')
        return value
    def text(self, value, path, nonempty=True):
        if not isinstance(value, str) or (nonempty and not value.strip()):
            self.fail(path,'비어 있지 않은 문자열이 필요합니다.' if nonempty else '문자열이 필요합니다.'); return False
        return True
    def strings(self, value, path, nonempty=False, refs=None, allow_empty=False):
        rows = self.arr(value,path,nonempty)
        if rows is None: return
        for i,v in enumerate(rows):
            if self.text(v,f'{path}[{i}]',not allow_empty) and refs is not None and v not in refs:
                self.fail(f'{path}[{i}]',f'참조 ID가 없습니다: {v}','RENDER_REFERENCE')
    def number(self, value, path):
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value):
            self.fail(path,'유한한 숫자가 필요합니다.'); return False
        return True
    def groups(self, value, path, refs=None, allow_empty=False):
        rows=self.arr(value,path)
        if rows is None:return
        for i,row in enumerate(rows):
            p=f'{path}[{i}]'
            if not isinstance(row,list) or len(row)!=2: self.fail(p,'[설명, 문자열 배열] 쌍이 필요합니다.'); continue
            self.text(row[0],p+'[0]'); self.strings(row[1],p+'[1]',refs=refs,allow_empty=allow_empty)
    def resources(self, value, path):
        rows=self.arr(value,path)
        if rows is None:return
        for i,row in enumerate(rows):
            p=f'{path}[{i}]'
            if not isinstance(row,list) or not 2<=len(row)<=6: self.fail(p,'[이름, 보유 여부, 상태?, 비고?, 담당?, 형식 배열?]이 필요합니다.'); continue
            self.text(row[0],p+'[0]')
            if type(row[1]) not in (int,bool) or row[1] not in (0,1): self.fail(p+'[1]','보유 여부는 0 또는 1이어야 합니다.')
            if len(row)>2 and row[2] not in ('E','P','N'): self.fail(p+'[2]','상태는 E/P/N이어야 합니다.')
            for n in (3,4):
                if len(row)>n:self.text(row[n],p+f'[{n}]',False)
            if len(row)>5:self.strings(row[5],p+'[5]')


def _common(a, data, tasks, source_ids, stage_numbers, compiled):
    subs=a.obj(data.get('subs'),'subs'); bands=a.arr(data.get('bands'),'bands',True)
    story=a.obj(data.get('story'),'story'); tour=a.obj(data.get('tour'),'tour')
    if subs is None or bands is None or story is None or tour is None:return
    refs=set(tasks)|set(source_ids)
    owners=Counter(); band_ids=set()
    for i,band in enumerate(bands):
        p=f'bands[{i}]'; band=a.obj(band,p)
        if band is None:continue
        bid=band.get('id')
        if not a.text(bid,p+'.id'):continue
        if bid in band_ids:a.fail(p+'.id',f'큰 기능 Agent ID 중복: {bid}','RENDER_REFERENCE')
        band_ids.add(bid)
        for f in ('name','desc'):a.text(band.get(f),p+'.'+f)
        a.strings(band.get('subs'),p+'.subs',True,subs)
        for sid in band.get('subs',[]) if isinstance(band.get('subs'),list) else []:
            if isinstance(sid,str):owners[sid]+=1
        for f in ('d','s'):
            if f in band:a.resources(band[f],p+'.'+f)
        st=a.obj(story.get(bid),'story.'+bid)
        if st is None:continue
        for f in ('p','intro','hum'):a.text(st.get(f),'story.'+bid+'.'+f)
        for f in ('pb','pre'):
            if f in st:a.strings(st[f],'story.'+bid+'.'+f)
        rows=a.arr(st.get('imp'),'story.'+bid+'.imp',True)
        for n,row in enumerate(rows or []):
            rp=f'story.{bid}.imp[{n}]'
            # Existing valid CRM uses an optional third source-reference array.
            if not isinstance(row,list) or len(row) not in (2,3):a.fail(rp,'[제목, 설명, 참조 ID 배열?]이 필요합니다.');continue
            a.text(row[0],rp+'[0]');a.text(row[1],rp+'[1]')
            if len(row)==3:a.strings(row[2],rp+'[2]',refs=refs)
        details=a.obj(st.get('subs'),'story.'+bid+'.subs')
        if details is None:continue
        for sid in band.get('subs',[]) if isinstance(band.get('subs'),list) else []:
            if not isinstance(sid,str):continue
            dp=f'story.{bid}.subs.{sid}'; detail=a.obj(details.get(sid),dp)
            if detail is None:continue
            for f in ('f','pn'):
                a.groups(detail.get(f),dp+'.'+f,refs=refs)
                if detail.get(f)==[]:a.fail(dp+'.'+f,'기능/해결 Pain point 내용을 작성해야 합니다.')
            a.text(detail.get('e'),dp+'.e')
    for sid,sub in subs.items():
        p='subs.'+sid;sub=a.obj(sub,p)
        if sub is None:continue
        for f in ('name','desc','band'):a.text(sub.get(f),p+'.'+f)
        if not isinstance(sub.get('band'),str) or sub['band'] not in band_ids:a.fail(p+'.band','존재하는 큰 기능 Agent ID를 지정해야 합니다.','RENDER_REFERENCE')
        if owners[sid]!=1:a.fail(p,f'큰 기능 Agent 소속은 정확히 하나여야 합니다 (현재 {owners[sid]}개).','RENDER_REFERENCE')
        for band in bands:
            if isinstance(band,dict) and isinstance(band.get('subs'),list) and sid in band['subs'] and band.get('id')!=sub.get('band'):
                a.fail(p+'.band','bands[].subs와 subs[].band의 소속이 다릅니다.','RENDER_REFERENCE')
        for f in ('d','s'):a.resources(sub.get(f),p+'.'+f)
        for f in ('dg','sp','of','og'):
            if f in sub:a.groups(sub[f],p+'.'+f,allow_empty=(f=='of'))
        for f in ('wh','xw','xi','xf'):
            if f in sub:
                obj=a.obj(sub[f],p+'.'+f)
                if obj is not None:
                    for k,v in obj.items():a.text(v,p+'.'+f+'.'+str(k),False)
        if compiled:
            a.strings(sub.get('tasks'),p+'.tasks',refs=tasks)
            nums=a.arr(sub.get('stages'),p+'.stages')
            for n,v in enumerate(nums or []):
                if a.number(v,f'{p}.stages[{n}]') and v not in stage_numbers:a.fail(f'{p}.stages[{n}]','존재하지 않는 단계 번호입니다.','RENDER_REFERENCE')
    for st in stage_numbers:
        if str(st) not in tour:a.fail('tour.'+str(st),'해당 단계의 흐름 설명이 없습니다.')
    for key,stage in tour.items():
        p='tour.'+str(key);stage=a.obj(stage,p)
        if stage is None:continue
        if stage_numbers and str(key) not in {str(n) for n in stage_numbers}:a.fail(p,'존재하지 않는 단계의 흐름 설명입니다.','RENDER_REFERENCE')
        for f in ('now','chg','next'):a.text(stage.get(f),p+'.'+f)
        beats=a.arr(stage.get('beats'),p+'.beats',True)
        for i,beat in enumerate(beats or []):
            bp=f'{p}.beats[{i}]';beat=a.obj(beat,bp)
            if beat is None:continue
            a.text(beat.get('t'),bp+'.t')
            if 'p' in beat:a.text(beat['p'],bp+'.p',False)
            steps=a.arr(beat.get('steps'),bp+'.steps',True)
            for j,step in enumerate(steps or []):
                sp=f'{bp}.steps[{j}]';step=a.obj(step,sp)
                if step is None:continue
                a.strings(step.get('ids'),sp+'.ids',True,tasks)
                for f in ('v','d'):a.text(step.get(f),sp+'.'+f)
                for f in ('a','p'):
                    if f in step:a.text(step[f],sp+'.'+f,False)
    for f in ('outs','outnew','sysinfo','dfmt','when','whenHave','form','desc','ui'):
        if f not in data:continue
        obj=a.obj(data[f],f)
        if obj is None:continue
        if f=='outs':
            for sid,rows in obj.items():
                for n,row in enumerate(a.arr(rows,'outs.'+sid) or []):
                    p=f'outs.{sid}[{n}]'
                    if not isinstance(row,list) or len(row)!=2:a.fail(p,'[산출물, 형식 문자열] 쌍이 필요합니다.');continue
                    a.text(row[0],p+'[0]');a.text(row[1],p+'[1]',False)
        elif f=='desc':
            for level,entries in obj.items():
                rows=a.obj(entries,'desc.'+str(level))
                if rows is not None:
                    for ident,value in rows.items():a.text(value,'desc.'+str(level)+'.'+str(ident),False)
        elif f in ('outnew','sysinfo','dfmt','when','whenHave','form'):

            for k,v in obj.items():a.text(v,f+'.'+str(k),False)
    ax=data.get('ax')
    if ax is not None:_ax(a,ax,subs,stage_numbers)


def _ax(a, ax, subs, stages):
    ax=a.obj(ax,'ax')
    if ax is None:return
    rows=a.arr(ax.get('tasks'),'ax.tasks');a.obj(ax.get('cat'),'ax.cat')
    for i,t in enumerate(rows or []):
        p=f'ax.tasks[{i}]';t=a.obj(t,p)
        if t is None:continue
        for f in ('ag','st','dup','slides'):
            v=a.arr(t.get(f),p+'.'+f)
            if f=='ag' and v is not None:a.strings(v,p+'.'+f,refs=subs)
            if f=='st':
                for j,n in enumerate(v or []):
                    if a.number(n,f'{p}.st[{j}]') and stages and n not in stages:a.fail(f'{p}.st[{j}]','존재하지 않는 단계입니다.','RENDER_REFERENCE')
        for f in ('name','top','org','how'):a.text(t.get(f),p+'.'+f)
    if 'cols' in ax:
        for i,c in enumerate(a.arr(ax['cols'],'ax.cols') or []):
            p=f'ax.cols[{i}]';c=a.obj(c,p)
            if c is None:continue
            a.text(c.get('k'),p+'.k')
            if not c.get('st'):a.strings(c.get('cats'),p+'.cats')


def validate_design(data, asis=None):
    a=Audit();data=a.obj(data,'design')
    if data is None:return a.errors
    tb=a.obj(data.get('tb'),'tb')
    if tb is None:return a.errors
    tasks={}
    for k,t in tb.items():
        t=a.obj(t,'tb.'+k)
        if t is None:continue
        if t.get('t')!='X':tasks[k]=t
    if data.get('mode')=='restructure' and not (asis or {}).get('meta',{}).get('tobe'):
        groups=a.obj(data.get('tb5'),'tb5')
        if groups is not None:
            for key,group in groups.items():
                p='tb5.'+key;group=a.obj(group,p)
                if group is None:continue
                a.text(group.get('n'),p+'.n')
                if 'from' in group:a.strings(group['from'],p+'.from',refs=(asis or {}).get('A5') if asis else None)
                if 'st' in group:a.number(group['st'],p+'.st')
        for key,t in tasks.items():
            a.text(t.get('lb'),'tb.'+key+'.lb')
            if t.get('t')!='M':a.text(t.get('l5'),'tb.'+key+'.l5')
            if 'ref' in t:a.strings(t['ref'],'tb.'+key+'.ref')
    meta=a.obj(data.get('meta'),'meta')
    if meta is not None:
        mt=a.obj(meta.get('text'),'meta.text');a.obj(meta.get('start'),'meta.start')
        if mt is not None:a.text(mt.get('title'),'meta.text.title')
    lanes=a.arr(data.get('lanes'),'lanes')
    for i,l in enumerate(lanes or []):
        l=a.obj(l,f'lanes[{i}]')
        if l is None:continue
        for f in ('k','name'):a.text(l.get(f),f'lanes[{i}].'+f)
        for f in ('team','bon'):
            if f in l:a.strings(l[f],f'lanes[{i}].'+f)
    nums=list(range(1,len((asis or {}).get('A4',{}))+1))
    sources=set((asis or {}).get('A6',{}))|set(data.get('asis_names',{}) if isinstance(data.get('asis_names'),dict) else {})
    _common(a,data,tasks,sources,nums,False)
    return a.errors


def validate_pmd(data):
    a=Audit();data=a.obj(data,'pmd')
    if data is None:return a.errors
    text=a.obj(data.get('text'),'text');start=a.obj(data.get('start'),'start')
    if text is not None:
        for f in ('title','eyebrow','ver','crumb','foot'):a.text(text.get(f),'text.'+f,f=='title')
    if start is not None:
        if start.get('scr') not in ('asis','ns'):a.fail('start.scr','asis 또는 ns여야 합니다.')
        if start.get('lv') not in (4,5,6):a.fail('start.lv','4/5/6 중 하나여야 합니다.')
    summary=a.arr(data.get('summary'),'summary',True)
    for i,item in enumerate(summary or []):
        sp=f'summary[{i}]';item=a.obj(item,sp)
        if item is None:continue
        a.text(item.get('text'),sp+'.text');a.text(item.get('tip'),sp+'.tip',False)
        if 'parts' in item:
            for j,part in enumerate(a.arr(item['parts'],sp+'.parts') or []):
                pp=f'{sp}.parts[{j}]'
                if not isinstance(part,list) or len(part)!=3:a.fail(pp,'[분류명, 개수, 표시 코드] 배열이 필요합니다.');continue
                a.text(part[0],pp+'[0]');a.number(part[1],pp+'[1]');a.text(part[2],pp+'[2]')
    lanes=a.arr(data.get('lanes'),'lanes',True)
    for i,lane in enumerate(lanes or []):
        lp=f'lanes[{i}]';lane=a.obj(lane,lp)
        if lane is not None:
            for f in ('k','name'):a.text(lane.get(f),lp+'.'+f)
    layout=a.obj(data.get('layout'),'layout')
    if layout is not None:
        for level in ('4','5','6'):
            config=a.obj(layout.get(level),'layout.'+level)
            if config is not None:
                for f in ('colW','nodeW','rowH','nodeH','pad','gap','bandH'):a.number(config.get(f),'layout.'+level+'.'+f)
    tb=a.obj(data.get('TB'),'TB');a6=a.obj(data.get('A6'),'A6');a5=a.obj(data.get('A5'),'A5');a4=a.obj(data.get('A4'),'A4')
    if any(v is None for v in (tb,a6,a5,a4)):return a.errors
    sub_ids=set(data.get('subs',{})) if isinstance(data.get('subs'),dict) else set()
    lane_ids={v.get('k') for v in (lanes or []) if isinstance(v,dict) and isinstance(v.get('k'),str)}|sub_ids
    for k,t in tb.items():
        tp='TB.'+k;t=a.obj(t,tp)
        if t is not None:
            for f in ('t','lb','l5'):a.text(t.get(f),tp+'.'+f)
            a.strings(t.get('ref'),tp+'.ref',refs=a6)
            if t.get('sub') and (not isinstance(t['sub'],str) or t['sub'] not in sub_ids):a.fail(tp+'.sub','존재하지 않는 세부 Agent ID입니다.','RENDER_REFERENCE')
            if not isinstance(t.get('l5'),str) or t['l5'] not in a5:a.fail(tp+'.l5','존재하지 않는 Lv.5 ID입니다.','RENDER_REFERENCE')
    stages=a.arr(data.get('stages'),'stages',True);nums=[]
    for i,st in enumerate(stages or []):
        p=f'stages[{i}]';st=a.obj(st,p)
        if st is None:continue
        if a.number(st.get('n'),p+'.n'):nums.append(st['n'])
        a.text(st.get('name'),p+'.name')
        if not isinstance(st.get('id'),str) or st['id'] not in a4:a.fail(p+'.id','A4에 없는 단계 ID입니다.','RENDER_REFERENCE')
    for label,obj,refs in [('A4',a4,a5),('A5',a5,a6)]:
        for k,v in obj.items():
            v=a.obj(v,label+'.'+k)
            if v is not None:a.strings(v.get('kids'),label+'.'+k+'.kids',refs=refs)
    _common(a,data,tb,a6,nums,True)
    views=a.obj(data.get('views'),'views')
    if views is not None:
        for level in ('4','5','6'):
            lev=a.obj(views.get(level),f'views.{level}')
            if lev is None:continue
            for screen in ('asis','ns'):
                p=f'views.{level}.{screen}';g=a.obj(lev.get(screen),p)
                if g is None:continue
                a.obj(g.get('ncols'),p+'.ncols')
                nodes=a.arr(g.get('nodes'),p+'.nodes');edges=a.arr(g.get('edges'),p+'.edges');ids=set()
                for i,n in enumerate(nodes or []):
                    np=f'{p}.nodes[{i}]';n=a.obj(n,np)
                    if n is None:continue
                    if a.text(n.get('id'),np+'.id'):
                        if n['id'] in ids:a.fail(np+'.id','중복 노드 ID입니다.','RENDER_REFERENCE')
                        ids.add(n['id'])
                    for f in ('ln','k','lb'):a.text(n.get(f),np+'.'+f)
                    if not isinstance(n.get('ln'),str) or n['ln'] not in lane_ids:a.fail(np+'.ln','존재하지 않는 조직/Agent 레인입니다.','RENDER_REFERENCE')
                    for f in ('st','c','r'):a.number(n.get(f),np+'.'+f)
                    for f in ('subs','mem'):
                        if f in n:a.strings(n[f],np+'.'+f)
                for i,e in enumerate(edges or []):
                    ep=f'{p}.edges[{i}]'
                    if not isinstance(e,list) or len(e)!=4 or not all(isinstance(v,str) for v in e):a.fail(ep,'[시작 ID, 끝 ID, 종류, 조건] 문자열 배열이 필요합니다.');continue
                    if e[0] not in ids or e[1] not in ids:a.fail(ep,'연결 끝점이 화면 노드에 없습니다.','RENDER_REFERENCE')
    return a.errors


def as_issues(errors):
    return [('오류','[Agent 상세]' if e['path'].startswith('story.') else '[렌더 스키마]',e['path']+' — '+e['message']) for e in errors]

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('kind',choices=['design','pmd']);p.add_argument('input');p.add_argument('--asis');args=p.parse_args()
    with open(args.input,encoding='utf-8') as f:data=json.load(f)
    asis=None
    if args.asis:
        with open(args.asis,encoding='utf-8') as f:asis=json.load(f)
    errors=validate_design(data,asis) if args.kind=='design' else validate_pmd(data)
    print(json.dumps({'passed':not errors,'errors':errors},ensure_ascii=False,indent=2))
    raise SystemExit(2 if errors else 0)
