"""B 확인 화면(위젯) 도구 — input-request.md 3절
  b_widget.py skeleton asis.json structure.json out.json   : Lv.4별 DATA 초안 (Lv.1 위치·Lv.5 목록·구조 종류 자동, 순차 진행만인 Lv.4는 show=false)
  b_widget.py render data.json out.html                     : 템플릿(assets/b_review_widget.html)에 DATA를 넣은 위젯 코드 생성 — show 섹션이 없으면 그 사실만 출력
Claude는 초안의 show=true 섹션에 nodes·edges·notes(·ask)를 채우고, 순차 진행이지만 확인이 필요한 Lv.4는 ask를 넣고 show=true로 바꾼다.
"""
import json, os, re, sys
from collections import OrderedDict, Counter

def lv4key(a5): return a5.get('g4id') or a5.get('g4') or a5.get('l4id')

def skeleton(asis, st):
    A6, A5, A4 = asis['A6'], asis['A5'], asis['A4']
    G = OrderedDict()
    for k5, a5 in A5.items(): G.setdefault(lv4key(a5), dict(name=a5.get('g4') or a5.get('l4', ''), l5=[]))['l5'].append(k5)
    meta_l1 = (asis.get('meta') or {}).get('l1', '')
    def l1_of(k4, g):   # 엑셀 Process Map 시트의 Lv.1 열 — 행마다 저장된 값 중 가장 많은 것, 없으면 단계(A4)의 lv1, 없으면 meta
        c = Counter(A6[x].get('l1') for k5 in g['l5'] for x in A5[k5]['kids'] if x in A6 and A6[x].get('l1'))
        if c: return c.most_common(1)[0][0]
        sk = A5[g['l5'][0]].get('l4id')
        return (A4.get(sk) or {}).get('lv1') or meta_l1.split(' · ')[0]
    l5_of6 = {x: k5 for k5, a5 in A5.items() for x in a5['kids']}
    k4_of5 = {k5: k4 for k4, g in G.items() for k5 in g['l5']}
    kinds = {k4: Counter() for k4 in G}
    def mark(k6, kind):
        k5 = l5_of6.get(k6)
        if k5: kinds[k4_of5[k5]][kind] += 1
    for x in st.get('parallel', []): mark(x['frm'], 'par')
    for x in st.get('branch', []): mark(x['frm'], 'br')
    for x in st.get('rework', []): mark(x['frm'], 'rw')
    for x in st.get('conditional', []): mark(x['id'], 'cond')
    L1 = OrderedDict()
    for k4, g in G.items(): g['l1'] = l1_of(k4, g); L1.setdefault(g['l1'], []).append(k4)
    secs = []
    for k4, g in G.items():
        ks = [[k, n] for k, n in kinds[k4].items()]
        secs.append(OrderedDict(id=k4, name=re.sub(r'^\d+(?:-\d+)*\s*', '', g['name']), l1=g['l1'], l1_n=len(L1[g['l1']]), l1_pos=L1[g['l1']].index(k4) + 1,
                                count=len(g['l5']), kinds=ks, show=bool(ks),
                                lv5=[[k5, A5[k5]['n']] for k5 in g['l5']], nodes=[], edges=[], notes=[], ask=''))
    return dict(sections=secs)

def render(data, tpl):
    S = [s for s in data.get('sections', []) if s.get('show') or s.get('kinds') or s.get('ask')]
    slim = dict(sections=[{k: v for k, v in s.items() if k not in ('lv5', 'show')} for s in S])
    code = re.sub(r'/\*DATA\*/.*?/\*END\*/', lambda m: '/*DATA*/' + json.dumps(slim, ensure_ascii=False) + '/*END*/', tpl, flags=re.S)
    return code, len(S)

if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else ''
    if cmd == 'skeleton':
        asis = json.load(open(sys.argv[2], encoding='utf-8')); st = json.load(open(sys.argv[3], encoding='utf-8'))
        d = skeleton(asis, st); json.dump(d, open(sys.argv[4], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        n = sum(1 for s in d['sections'] if s['show'])
        print(f"Lv.4 {len(d['sections'])}개 중 확인 화면에 넣을 섹션(분기·병행·조건부·환류) {n}개 →", sys.argv[4])
    elif cmd == 'render':
        here = os.path.dirname(os.path.abspath(__file__)); tpl = open(os.path.join(here, '..', 'assets', 'b_review_widget.html'), encoding='utf-8').read()
        code, n = render(json.load(open(sys.argv[2], encoding='utf-8')), tpl)
        if not n: print('확인 화면에 넣을 섹션 없음 — 모든 Lv.4가 순차 진행이고 확인 필요 지점도 없음 (위젯 생략)')
        else: open(sys.argv[3], 'w', encoding='utf-8').write(code); print(f'섹션 {n}개 위젯 코드 →', sys.argv[3])
    else: print(__doc__)
