"""원본 층: Process Map 시트 → asis.json (결정적)
사용:
  parse_excel.py 엑셀 report            — 양식 점검표 (읽은 열·모르는 열·빈 열·규모·담당·태그)
  parse_excel.py 엑셀 list out          — 섹션 목록 (F1 양식)
  parse_excel.py 엑셀 2 out.json        — 2번 섹션만 (F1)
  parse_excel.py 엑셀 1,2 out.json      — 1·2번 섹션을 한 HTML로 합침 (같은 이름 단계는 합침)
  parse_excel.py 엑셀 3 out.json        — F2 양식(30열): 숫자 = 단계로 쓸 레벨 (보통 3)
  parse_excel.py 엑셀 1 out.json --stage lv3 — v38: F1 양식에서 단계 = Lv.3 (Lv.4는 Lv.4 화면의 묶음)
"""
import sys, json, re, hashlib
from pathlib import Path
from collections import OrderedDict
from openpyxl import load_workbook
class InputError(ValueError):
    """Source cannot be parsed losslessly; never silently omit source work."""

def open_sheet(path, sheet='Process Map'):
    wb = load_workbook(path, data_only=False)
    if sheet not in wb.sheetnames:
        raise InputError(f'필수 시트 {sheet!r} 없음; 시트: {wb.sheetnames}')
    ws = wb[sheet]
    cached = None
    for row in ws:
        for cell in row:
            if cell.data_type == 'f':
                if cached is None: cached = load_workbook(path, data_only=True)[sheet]
                value = cached[cell.coordinate].value
                if value is None or cached[cell.coordinate].data_type == 'e':
                    raise InputError(f'{sheet}!{cell.coordinate}: 계산값이 없는 수식. Excel에서 재계산·저장한 파일 필요')
                cell.value = value
            elif cell.data_type == 'e':
                raise InputError(f'{sheet}!{cell.coordinate}: Excel 오류값 {cell.value}')
    return wb, ws

def normalized(v): return re.sub(r'\s+', ' ', str(v or '')).strip()

def source_nodes(path):
    if not path: return []
    from source_asis import snapshot
    data = snapshot(Path(path).read_text(encoding='utf-8'))
    return data.get('lv6', {}).get('nodes', [])

C0 = dict(l1=3,l2=4,l3=5,l4=6,l5=7,l6=8,
  l4team=17,l4id=18,l4ty=19,l4pre=20,l4post=21,l4br=22,l4rej=23,l4rejr=24,
  l5team=25,l5id=26,l5ty=27,l5pre=28,l5post=29,l5br=30,l5rej=31,l5rejr=32,
  team=33,bon=34,id=35,ty=36,pre=37,post=38,br=39,rej=40,rejr=41,
  sys=42,inp=43,fmt=44,wt=45,ai=46,out=47,pain=48,note=49)   # 표준 F1 위치 — 머리글로 못 찾을 때만 씀
C0['l3id'] = 999
C = dict(C0)
FLD = [('담당팀','team'),('담당본부','bon'),('노드 ID','id'),('노드 유형','ty'),('선행','pre'),('후행','post'),('분기','br'),('반려 시','rej'),('반려 사유','rejr')]
def f1_columns(ws):
    """v38: F1 열 위치를 머리글로 찾음 ('Lv.6 노드 ID' 행) — 열이 앞뒤로 밀리거나 없는 양식(예: BX S08·S09: 한 칸 앞당김·아웃풋 열 없음)도 읽음"""
    for r in range(1, 15):
        hs = [s(ws.cell(r, c).value).replace('\n', ' ') for c in range(1, ws.max_column + 1)]
        if 'Lv.6 노드 ID' not in hs: continue
        col = {}
        for i, h in enumerate(hs, 1):
            m = re.match(r'^Lv\.([1-6])$', h)
            if m: col['l' + m.group(1)] = i; continue
            m = re.match(r'^Lv\.([3-6])\s+(.+)$', h)
            if m:
                lv, rest = m.groups(); pre = '' if lv == '6' else ('l' + lv)
                for kw, f in FLD:
                    if rest.startswith(kw) and not (kw == '반려 시' and '사유' in rest):
                        if lv in '456' or f == 'id': col.setdefault(pre + f, i)   # Lv.3는 노드 ID만 (단계 = Lv.3 선택 시)
                        break
                continue
            for kw, f in (('활용 시스템','sys'),('인풋 데이터 형식','fmt'),('인풋 데이터 작업','wt'),('인풋 데이터','inp'),('아웃풋','out'),('AI 자동화','ai'),('Pain','pain'),('비고','note')):
                if kw in h: col.setdefault(f, i); break
        col.setdefault('l3id', 999)
        miss = [k for k in C0 if k not in col]
        for k in miss: col[k] = 999          # 없는 열 → 빈 값 (보고에 '없는 열'로 표시)
        return r, col, miss
    raise InputError('F1 머리글을 찾지 못함: Lv.6 노드 ID와 계층 열 필요')
AI = {'인간 주도(AI보조)':'AI 보조','AI 주도(인간 검수)':'AI 주도'}
def s(v):
    if v is None: return ''
    if hasattr(v, 'text'): v = v.text          # v38: 배열 수식으로 저장된 칸 ('- …'로 시작해 수식이 된 칸 — 엑셀에선 #NAME?)
    v = str(v).strip()
    return v[1:].strip() if v.startswith('=-') else v
def read(path, section=1, sheet='Process Map'):
    wb, ws = open_sheet(path, sheet)
    val = {}
    for rng in ws.merged_cells.ranges:
        v = ws.cell(rng.min_row, rng.min_col).value
        for r in range(rng.min_row, rng.max_row+1):
            for c in range(rng.min_col, rng.max_col+1):
                val[(r,c)] = v
    g = lambda r,c: '' if c >= 999 else s(val.get((r,c), ws.cell(r,c).value))
    hr, col, missing = f1_columns(ws); C.clear(); C.update(col)
    required = {'l1','l4','l5','l6','l4id','l5id','id'}
    if required.intersection(missing): raise InputError('F1 필수 열 없음: ' + ', '.join(sorted(required.intersection(missing))))
    tcol = max(1, C['l1'] - 1)              # v38: 섹션 제목 열 = Lv.1 바로 왼쪽
    secs = [r for r in range(1, ws.max_row+1) if re.match(r'^\d+\.', g(r,tcol)) and not g(r,C['id'])]
    if not secs:   # v38: 섹션 제목 행 없는 양식 → 시트 통째 (제목 = A1)
        rows = []
        for r in range((hr or 0) + 1, ws.max_row+1):
            i6 = g(r, C['id'])
            if not i6 and g(r, C['l6']): raise InputError(f'행 {r}: Lv.6 업무명은 있지만 ID 누락')
            if not i6 or i6.startswith('Lv.'): continue
            d = {k: g(r,c) for k,c in C.items()}; d['row'] = r; rows.append(d)
        return g(1,1).replace('■','').strip(), rows
    if not 1 <= section <= len(secs): raise InputError(f'섹션 {section} 범위 오류 (1~{len(secs)})')
    start = secs[section-1]; end = secs[section] if section < len(secs) else ws.max_row+1
    rows = []
    for r in range(start+1, end):
        i6 = g(r, C['id'])
        if not i6 and g(r, C['l6']): raise InputError(f'행 {r}: Lv.6 업무명은 있지만 ID 누락')
        if not i6 or i6.startswith('Lv.'): continue
        d = {k: g(r,c) for k,c in C.items()}; d['row'] = r
        rows.append(d)
    return g(start,tcol), rows
def stage_lv3(out):
    """v38: F1에서 단계 축을 Lv.3로 — 단계(A4) = Lv.3, Lv.4는 Lv.4 화면의 묶음(g4·g4id)으로 남김 (S01처럼 Lv.3 기준 단계)"""
    A6, A5, A4 = out['A6'], out['A5'], out['A4']; N = {}
    for k4, a4 in A4.items():
        l3 = a4.get('l3') or ''; key = a4.get('l3id') or l3
        if key not in N: N[key] = dict(n=re.sub(r'\s+', ' ', l3).strip(), l3=l3, ty='', team=a4.get('team', ''), kids=[], br='', pre='', post='', rej='', rejr='')
        for k5 in a4['kids']:
            A5[k5].update(g4=a4['n'], g4id=k4, l4id=key, l4=N[key]['n']); N[key]['kids'].append(k5)
            for k6 in A5[k5]['kids']: A6[k6]['l4'] = N[key]['n']
    sid = {k: f'S{i + 1}' for i, k in enumerate(N)}
    out['A4'] = OrderedDict((sid[k] if not re.match(r'^[A-Z]+-L3', str(k)) else k, v) for k, v in N.items())
    m = {k: (sid[k] if not re.match(r'^[A-Z]+-L3', str(k)) else k) for k in N}
    for a5 in A5.values(): a5['l4id'] = m.get(a5['l4id'], a5['l4id'])
    out['meta']['stage'] = 'Lv.3'
    return out
def build(path, section=1):
    title, rows = read(path, section)
    if not rows: raise InputError('선택한 섹션에 Lv.6 업무가 없음')
    A6, A5, A4 = {}, {}, {}
    for d in rows:
        for key in ('id','l6','l5id','l5','l4id','l4'):
            if not d[key]: raise InputError(f'행 {d["row"]}: 필수값 {key} 누락')
        if d['id'] in A6: raise InputError(f'행 {d["row"]}: Lv.6 ID 중복 {d["id"]}')
        if d['l5id'] in A5 and (A5[d['l5id']]['n'], A5[d['l5id']]['l4id']) != (d['l5'], d['l4id']): raise InputError(f'행 {d["row"]}: Lv.5 ID {d["l5id"]}의 이름/부모 충돌')
        if d['l4id'] in A4 and A4[d['l4id']]['n'] != d['l4']: raise InputError(f'행 {d["row"]}: Lv.4 ID {d["l4id"]}의 이름 충돌')
        A6[d['id']] = dict(n=d['l6'], l5=f"{d['l5id']} {d['l5']}", l4=d['l4'], team=d['team'], bon=d['bon'],
            ai=AI.get(d['ai'], d['ai']), sys=d['sys'], inp=d['inp'], fmt=d['fmt'], out=d['out'], pain=d['pain'],
            pre=d['pre'], post=d['post'], ty=d['ty'], wt=d['wt'], note=d['note'], br=d['br'], rejr=d['rejr'], rej=d['rej'],
            row=d['row'], hl=[], l3=d['l3'], l1=d.get('l1', ''))
        A5.setdefault(d['l5id'], dict(n=d['l5'], l4=d['l4'], team=d['l5team'], l4id=d['l4id'], ty=d['l5ty'], br=d['l5br'],
            rejr=d['l5rejr'], rej=d['l5rej'], pre=d['l5pre'], post=d['l5post'], kids=[], pain=[], note=[], r=[]))
        a5 = A5[d['l5id']]; a5['kids'].append(d['id']); a5['r'].append(d['row'])
        if d['pain'] and d['pain'] not in a5['pain']: a5['pain'].append(d['pain'])
        A4.setdefault(d['l4id'], dict(n=d['l4'], l3=d['l3'], l3id=d.get('l3id', ''), ty=d['l4ty'], team=d['l4team'], kids=[], br=d['l4br'], pre=d['l4pre'], post=d['l4post'], rej='', rejr=''))
        for f in ('rej', 'rejr'):
            if not A4[d['l4id']][f] and d['l4' + f]: A4[d['l4id']][f] = d['l4' + f]
        if d['l5id'] not in A4[d['l4id']]['kids']: A4[d['l4id']]['kids'].append(d['l5id'])
    meta = dict(title=title, rows=[rows[0]['row'], rows[-1]['row']], l1=rows[0]['l1'], l2=rows[0]['l2'], l3=rows[0]['l3'])
    return dict(meta=meta, A6=A6, A5=A5, A4=A4)
# ---------------- 섹션 목록·합치기 ----------------
def list_sections(path, sheet='Process Map'):
    """F1 양식의 섹션(B열 "1. …" 제목 행) 목록 — [(번호, 제목, Lv.6 행 수)]"""
    wb, ws = open_sheet(path, sheet)
    hr, col, _ = f1_columns(ws); ic, tc = col['id'] - 1, max(0, col['l1'] - 2)
    out, cur = [], None
    for r in ws.iter_rows(min_row=1, values_only=True):
        b = s(r[tc]) if len(r) > tc else ''; i6 = s(r[ic]) if len(r) > ic else ''
        if re.match(r'^\d+\.', b) and not i6: cur = [len(out) + 1, b, 0]; out.append(cur); continue
        if i6 and not i6.startswith('Lv.'):
            if cur is None: cur = [1, s(ws.cell(1, 1).value).replace('■', '').strip() or '시트 전체', 0]; out.append(cur)   # 섹션 제목 행 없는 양식
            cur[2] += 1
    return [tuple(x) for x in out]
def merge(parts):
    """Merge distinct source IDs without renaming, overwriting, or collapsing named stages."""
    if not parts: raise InputError('합칠 섹션 없음')
    A6, A5, A4 = OrderedDict(), OrderedDict(), OrderedDict(); key_of = {}
    for si, sec in enumerate(parts, 1):
        for level, target in (('A6', A6), ('A5', A5), ('A4', A4)):
            dup = set(sec[level]).intersection(target)
            if dup: raise InputError(f'섹션 {si} {level} ID 충돌: {", ".join(sorted(dup))}; 원본 ID를 수정하거나 섹션별로 생성')
        for k4, a in sec['A4'].items():
            A4[k4] = dict(a, kids=list(a['kids'])); key_of[k4] = k4
        for k5, a in sec['A5'].items(): A5[k5] = dict(a, l4id=key_of[a['l4id']])
        A6.update(sec['A6'])
    meta = dict(parts[0]['meta'], title=' + '.join(p['meta']['title'] for p in parts), sections=[p['meta']['title'] for p in parts],
                rows=[parts[0]['meta']['rows'][0], parts[-1]['meta']['rows'][1]])
    return dict(meta=meta, A6=A6, A5=A5, A4=A4)

# ---------------- 형식 2: 단일 연결 열(노드 ID·선행·후행) + 계층 번호 ID (예: S01 30열 양식) ----------------
F2 = {'lv1': 'Lv.1', 'lv2': 'Lv.2', 'lv3': 'Lv.3', 'lv4': 'Lv.4', 'lv5': 'Lv.5', 'lv6': 'Lv.6', 'id': '노드 ID', 'ty': '노드 유형',
      'pre': '선행', 'post': '후행', 'br': '분기 조건', 'rej': '반려 시', 'rejr': '반려 사유', 'team': '담당팀', 'bon': '담당본부', 'part': '담당부분',
      'sys': '활용 시스템', 'inp': '인풋 데이터', 'fmt': '인풋 데이터 형식', 'wt': '인풋 데이터 작업 팀', 'ai': '자동화 여부',
      'status': '구분', 'pain': 'Pain point', 'note': '비고', 'out': '아웃풋', 'l5id': '_L5_ID'}
AI2 = {'수작업': '인간 전담', '인간 주도 (AI 보조)': 'AI 보조', '인간 주도(AI보조)': 'AI 보조', 'AI 주도 (인간 검수)': 'AI 주도', 'AI 주도(인간 검수)': 'AI 주도'}
# 머리글 동의어 (띄어쓰기·줄바꿈 무시, 앞부분 일치). 긴 이름부터 맞춰 '인풋 데이터'와 '인풋 데이터 형식'을 구분
SYN = {'lv1': ['Lv.1', 'Lv1', 'L1'], 'lv2': ['Lv.2', 'Lv2', 'L2'], 'lv3': ['Lv.3', 'Lv3', 'L3'], 'lv4': ['Lv.4', 'Lv4', 'L4'],
       'lv5': ['Lv.5', 'Lv5', 'L5'], 'lv6': ['Lv.6', 'Lv6', 'L6'], 'id': ['노드 ID', 'Node ID', '노드ID'], 'ty': ['노드 유형', '유형'],
       'pre': ['선행'], 'post': ['후행'], 'br': ['분기 조건', '분기'], 'rej': ['반려 시', '반려시', '반려 복귀'], 'rejr': ['반려 사유'],
       'team': ['담당팀', '담당 팀', '담당파트', '담당 파트', '수행 주체', '담당 조직'], 'bon': ['담당본부', '담당 본부'], 'part': ['담당부분', '담당 부분', '담당부문', '담당 부문'],
       'sys': ['활용 시스템', '사용 시스템', '시스템'], 'inp': ['인풋 데이터', '입력 데이터', 'Input'], 'fmt': ['인풋 데이터 형식', '입력 데이터 형식'],
       'wt': ['인풋 데이터 작업 팀', '인풋 데이터 작업팀'], 'ai': ['자동화 여부', 'AI 활용', '자동화'], 'status': ['구분'],
       'pain': ['Pain point', 'Pain', '페인'], 'note': ['비고'], 'out': ['아웃풋', '산출물', 'Output'], 'track': ['트랙', '경로'],
       'cowork': ['협업'], 'l5id': ['_L5_ID'], 'comment': ['Comment', '코멘트'], 'question': ['현업 실무진 대상', '확인 필요 질문']}
NORM = lambda x: re.sub(r'[\s\n]+', '', x or '')
def map_columns(hs):
    cand = sorted(((NORM(sy), k) for k, ss in SYN.items() for sy in ss), key=lambda t: -len(t[0]))
    col = {}
    for i, h in enumerate(hs, 1):
        nh = NORM(h)
        if not nh: continue
        for sy, k in cand:
            if nh.startswith(sy):
                if k not in col: col[k] = i
                break
    if 'team' in col and 'bon' in col and NORM(hs[col['team'] - 1]).startswith('담당파트'):
        pass
    return col
def report(path, sheet='Process Map', source_html=None):
    """양식 점검표: 어느 열을 무엇으로 읽었는지 · 모르는 열 · 빈 열 · Lv.5 단위로 병합된 열 · 섹션 · 규모"""
    wb, ws = open_sheet(path, sheet)
    fm, hr, hs = detect(ws)
    print(f'양식 {fm} · 시트 {sheet} · 머리글 {hr}행 · 열 {len([h for h in hs if h])}개')
    if fm == 'F1':
        _, col, miss = f1_columns(ws)
        print('  읽은 열: ' + ' · '.join(f'{k}←{i}' for k, i in sorted(col.items(), key=lambda x: x[1]) if i < 999))
        if miss: print('  없는 열(빈 값으로 읽음): ' + ', '.join(miss))
        for n, t, c in list_sections(path, sheet): print(f'  섹션 {n}: {t} (Lv.6 {c}행)')
        return
    col = map_columns(hs); inv = {v: k for k, v in col.items()}
    out = build_f2(path, 3, sheet, source_html=source_html); A6 = out['A6']
    print('  읽은 열: ' + ' · '.join(f'{k}←"{hs[i - 1][:14]}"' for k, i in sorted(col.items(), key=lambda x: x[1])))
    unk = [h for i, h in enumerate(hs, 1) if h and i not in inv]
    if unk: print('  모르는 열(화면에 쓰지 않음): ' + ', '.join(f'"{u[:20]}"' for u in unk))
    for f in ('team', 'sys', 'inp', 'out', 'pain', 'ai', 'track'):
        if f not in col: print(f'  없는 열: {f}' + (' → 담당팀 대신 다른 열 필요' if f == 'team' else ''))
        elif not any(a.get(f) for a in A6.values() if f in a): print(f'  빈 열: {f}')
    lv = {n: len({a.get(n) for a in A6.values()}) for n in ()}
    c = {k: len(v) for k, v in (('Lv.5', out['A5']), ('Lv.6', A6))}
    l1 = out['meta']['l1']; l4 = len({a['g4'] for a in out['A5'].values()})
    print(f"  규모: Lv.3 단계 {len(out['A4'])} · Lv.4 {l4} · Lv.5 {c['Lv.5']} · Lv.6 {c['Lv.6']} · Lv.1 {l1}")
    print('  담당: ' + ', '.join(f'{t}({n})' for t, n in __import__('collections').Counter(a['team'] for a in A6.values()).most_common()))
    tags = __import__('collections').Counter(re.match(r'^\[([^\]]+)\]', a['n']).group(1) for a in out['A5'].values() if re.match(r'^\[', a['n']))
    if tags: print('  Lv.5 대괄호 태그: ' + ', '.join(f'{t}({n})' for t, n in tags.most_common(10)))
    if 'track' in col: print('  트랙: ' + ', '.join(f'{t}({n})' for t, n in __import__('collections').Counter(a.get('track', '') for a in A6.values()).most_common()))
def detect(ws):
    for r in range(1, 15):
        hs = [s(ws.cell(r, c).value) for c in range(1, ws.max_column + 1)]
        if 'Lv.6 노드 ID' in hs: return 'F1', r, hs
        if '노드 ID' in hs and any(h.startswith('Lv.6') for h in hs): return 'F2', r, hs
    raise InputError('지원 양식 머리글을 찾지 못함 (Lv.6 · 노드 ID 열 필요)')
def idlist(v): return ', '.join(x for x in re.split(r'[,;\s]+', s(v)) if x)
def build_f2(path, stage_lv=3, sheet='Process Map', source_html=None):
    if stage_lv not in (3, 4): raise InputError('F2 단계 레벨은 3 또는 4만 지원')
    wb, ws = open_sheet(path, sheet)
    _, hr, hs = detect(ws)
    col = map_columns(hs)
    val = {}
    for rng in ws.merged_cells.ranges:
        v = ws.cell(rng.min_row, rng.min_col).value
        for r in range(rng.min_row, rng.max_row + 1):
            for c in range(rng.min_col, rng.max_col + 1): val[(r, c)] = v
    required = {'id', 'lv1', 'lv2', 'lv3', 'lv4', 'lv5', 'lv6'}
    if required - set(col): raise InputError('F2 필수 열 없음: ' + ', '.join(sorted(required - set(col))))
    if 'team' not in col and 'bon' in col: col['team'] = col['bon']
    g = lambda r, k: s(val.get((r, col[k]), ws.cell(r, col[k]).value)) if col.get(k) else ''
    rows = []; ids = {}; source_matches = {}; recovered = []
    srcnodes = source_nodes(source_html)
    for r in range(hr + 1, ws.max_row + 1):
        ident, name = g(r, 'id'), g(r, 'lv6')
        if not ident and not name: continue
        if not name: raise InputError(f'행 {r}: 노드 ID {ident}의 Lv.6 업무명 없음')
        if source_html:
            candidates = [n for n in srcnodes if r in (n.get('sourceRows') or []) and normalized(n.get('task') or n.get('label')) == normalized(name)
                          and all(normalized(n.get('hierarchy', {}).get('l'+str(lv))) == normalized(g(r, 'lv'+str(lv))) for lv in range(1, 6))]
            if len(candidates) != 1:
                raise InputError(f'행 {r}: As-Is HTML에서 행·업무명·계층이 유일하게 일치하지 않음')
            source_matches[r] = candidates[0]
        if not ident:
            if r not in source_matches:
                raise InputError(f'행 {r}: Lv.6 업무 「{name}」의 ID 누락. --source-html 원본에서 행·업무명·계층이 유일하게 일치해야 복원 가능')
            ident = str(source_matches[r].get('id') or '')
            if not ident: raise InputError(f'행 {r}: As-Is HTML 노드도 ID 없음')
            recovered.append({'row': r, 'id': ident, 'source': Path(source_html).name, 'method': 'sourceRows+exact_name+hierarchy'})
        if ident in ids.values(): raise InputError(f'행 {r}: Lv.6 ID 중복 {ident}')
        if re.search(r'[,;\s]', ident): raise InputError(f'행 {r}: ID에 공백/구분자 사용 불가: {ident}')
        ids[r] = ident; rows.append(r)
    if not rows: raise InputError('Lv.6 업무가 없음; 빈/지원하지 않는 시트')
    group = lambda r, upto: tuple(normalized(g(r, 'lv'+str(i))) for i in range(1, upto+1))
    st_ids, l5_ids = {}, {}
    # Explicit names/parent IDs take precedence over stale numeric prefixes when source HTML is supplied.
    for r in rows:
        ident = ids[r]
        if source_html:
            st_ids.setdefault(group(r, stage_lv), 'STAGE-' + str(len(st_ids) + 1))
            source_parent = str(source_matches[r].get('parent') or '')
            if not source_parent: raise InputError(f'행 {r}: 원본 HTML Lv.5 parent 없음')
            prior = l5_ids.get(group(r, 5))
            if prior and prior != source_parent: raise InputError(f'행 {r}: 원본 HTML 계층/parent 충돌')
            l5_ids[group(r, 5)] = source_parent
        elif re.fullmatch(r'\d+(?:-\d+){5}', ident):
            st_ids.setdefault(group(r, stage_lv), '-'.join(ident.split('-')[:stage_lv]))
            l5_ids.setdefault(group(r, 5), '-'.join(ident.split('-')[:5]))
        if g(r, 'l5id'):
            prior = l5_ids.get(group(r, 5))
            if prior and prior != g(r, 'l5id'): raise InputError(f'행 {r}: _L5_ID와 계층 ID 충돌')
            l5_ids[group(r, 5)] = g(r, 'l5id')
    for r in rows:
        st_ids.setdefault(group(r, stage_lv), 'STAGE-' + str(r))
        l5_ids.setdefault(group(r, 5), 'L5-' + str(r))
    A6, A5, A4 = OrderedDict(), OrderedDict(), OrderedDict()
    for r in rows:
        i6 = ids[r]; i5 = l5_ids[group(r, 5)]; st = st_ids[group(r, stage_lv)]
        if not g(r, 'lv5') or not g(r, 'lv'+str(stage_lv)): raise InputError(f'행 {r}: Lv.5/단계 업무명 누락')
        if st in A4 and normalized(re.sub(r'^\d+\.\s*', '', A4[st]['n'])) != normalized(g(r, 'lv'+str(stage_lv))): raise InputError(f'행 {r}: 단계 ID {st}의 이름 충돌; --source-html 원본 계층과 대조 필요')
        if i5 in A5 and (A5[i5]['n'], A5[i5]['l4id'], A5[i5]['g4']) != (g(r, 'lv5'), st, g(r, 'lv4')): raise InputError(f'행 {r}: Lv.5 ID {i5}의 부모/이름 충돌')
        if st not in A4: A4[st] = dict(n=f"{len(A4) + 1}. {g(r, 'lv' + str(stage_lv))}", ty='단계', team='', kids=[], br='', pre='', post='', rej='', rejr='',
                                       lv1=g(r, 'lv1'), lv2=g(r, 'lv2'), lv3=g(r, 'lv3'))
        if i5 not in A5:
            A5[i5] = dict(n=g(r, 'lv5'), l4=A4[st]['n'], g4=g(r, 'lv4'), team=g(r, 'team'), l4id=st, ty='업무', br='', rejr='', rej='', pre='', post='',
                          kids=[], pain=[], note=[], r=[])
            A4[st]['kids'].append(i5)
        a5 = A5[i5]; a5['kids'].append(i6); a5['r'].append(r)
        if g(r, 'pain') and g(r, 'pain') not in a5['pain']: a5['pain'].append(g(r, 'pain'))
        A6[i6] = dict(n=g(r, 'lv6'), l5=f"{i5} {g(r, 'lv5')}", l4=A4[st]['n'], team=g(r, 'team'), bon=g(r, 'bon'), **({'part': g(r, 'part')} if 'part' in col and g(r, 'part') else {}),
                      ai=AI2.get(g(r, 'ai'), g(r, 'ai')), sys=g(r, 'sys'), inp=g(r, 'inp'), fmt=g(r, 'fmt'), out=g(r, 'out'), pain=g(r, 'pain'),
                      pre=idlist(g(r, 'pre')), post=idlist(g(r, 'post')), ty=g(r, 'ty'), wt=g(r, 'wt'), note=g(r, 'note'),
                      br=g(r, 'br'), rejr=g(r, 'rejr'), rej=idlist(g(r, 'rej')), row=r, hl=[], status=g(r, 'status'), l1=g(r, 'lv1'))
        if 'track' in col: A6[i6]['track'] = g(r, 'track')
        if 'cowork' in col: A6[i6]['cowork'] = g(r, 'cowork')
    # Lv.5·단계 연결은 Lv.6 연결에서 끌어냄
    up5 = {k: a['l5'].split(' ')[0] for k, a in A6.items()}
    for k, a in A6.items():
        for p in a['post'].split(', '):
            if p in A6 and up5[p] != up5[k]:
                A, B = A5[up5[k]], A5[up5[p]]
                if up5[p] not in A['post'].split(', '): A['post'] = ', '.join(x for x in A['post'].split(', ') + [up5[p]] if x)
                if up5[k] not in B['pre'].split(', '): B['pre'] = ', '.join(x for x in B['pre'].split(', ') + [up5[k]] if x)
        for p in a['rej'].split(', '):
            if p in A6 and up5[p] != up5[k] and up5[p] not in A5[up5[k]]['rej'].split(', '):
                A5[up5[k]]['rej'] = ', '.join(x for x in A5[up5[k]]['rej'].split(', ') + [up5[p]] if x); A5[up5[k]]['rejr'] = a['rejr']
    ks = list(A4)
    for i, k in enumerate(ks):
        if i == 0: A4[k]['ty'] = '시작'
        if i == len(ks) - 1: A4[k]['ty'] = '종료'
    r0 = rows[0]
    meta = dict(fmt='F2', stage_lv=stage_lv, rows=[rows[0], rows[-1]], l1=' · '.join(dict.fromkeys(a['lv1'] for a in A4.values())),
                l2=g(r0, 'lv2'), hierarchy_basis='source_html_exact' if source_html else 'explicit_labels_and_ids', recovered_ids=recovered, source_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(), teams=sorted({a['team'] for a in A6.values()} | {a['team'] for a in A5.values()}))
    return dict(meta=meta, A6=A6, A5=A5, A4=A4)

def main():
    import argparse
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('excel'); ap.add_argument('spec', nargs='?', default='1'); ap.add_argument('output', nargs='?')
    ap.add_argument('--stage', choices=('lv3', '3', 'lv.3')); ap.add_argument('--source-html', help='동일 Excel의 As-Is HTML; 누락 ID를 엄격 일치로 복원')
    args = ap.parse_args()
    try:
        if args.spec == 'report': report(args.excel, source_html=args.source_html); return 0
        fm = detect(open_sheet(args.excel)[1])[0]
        if args.spec == 'list':
            if fm == 'F1':
                for n, t, c in list_sections(args.excel): print(f'{n}\t{t}\tLv.6 {c}행')
            else: print('F2 양식: 섹션 없음 (통째로)')
            return 0
        if not args.output: ap.error('출력 JSON 경로 필요')
        if fm == 'F2': out = build_f2(args.excel, int(args.spec), source_html=args.source_html)
        else:
            nums = [int(x) for x in re.split(r'[,+]', args.spec)]
            out = build(args.excel, nums[0]) if len(nums) == 1 else merge([build(args.excel, n) for n in nums])
        if args.stage and fm == 'F1': out = stage_lv3(out)
        from verify_input import validate
        findings = validate(out)
        errors = [x for x in findings if x['severity'] == 'error']
        out['meta']['input_warnings'] = [x for x in findings if x['severity'] == 'warning']
        if errors: raise InputError('; '.join(x['message'] for x in errors[:20]))
        Path(args.output).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
        print(out['meta'], len(out['A6']), len(out['A5']), len(out['A4']))
        return 0
    except (InputError, ValueError, KeyError) as exc:
        print('입력 오류: ' + str(exc), file=sys.stderr); return 2

if __name__ == '__main__': sys.exit(main())
