"""자료 진단 — 1단계(추가 자료 요청)의 근거를 만든다.

  python scripts/inputs.py work/asis.json <받은 파일 …> work/inputs     → work/inputs.json + work/inputs.md
  python scripts/inputs.py message work/inputs.json                     → 1단계 요청 메시지 (Claude가 requests·questions를 쓴 뒤)
  python scripts/inputs.py save work/inputs.json work/design.json --answer "사용자 답 원문"   → 요청·답·가정·반영·차이를 설계 파일 inputs에 기록 (답 없으면 저장 안 함)
  python scripts/inputs.py conflicts work/inputs.json [0.5|기타]      → 자료끼리 다른 점 (0.5 = 구조 확인 때 질문, 기타 = 기준에 따라 결정)
  업데이트: python scripts/inputs.py --prev work/design.json work/asis.json <파일 …> work/inputs   (이전 설계의 자료 기록 이어받음)

이 스크립트는 '무엇이 비었는지'의 근거(숫자·행 번호)만 만든다. 무엇을 요청할지는 Claude가
references/input-request.md의 기본 목록 + 판단 질문으로 정한다 (기본 목록 밖도 찾는다).
"""
import json, os, re, sys
from collections import Counter, OrderedDict

EMPTY = {'', '-', '–', '없음', 'N/A', 'n/a', 'NA', '해당 없음', '해당없음', 'x', 'X'}
MEMO = re.compile(r'확인\s*필요|가설|미정|추정|TBD|tbd')
DECIDE = re.compile(r'결정|확정|승인|선정|판단|합의|Go/No-Go|채택')
EXT = re.compile(r'외부|외주|에이전시|협력사|프로덕션|렙사|매체사')
COND = re.compile(r'필요\s*시|필요한 경우|경우에|(?<![가-힣])시 |한정')
VOLUME = re.compile(r'건수|빈도|소요\s*시간|소요시간|횟수|물량|공수|FTE|시간\(')

def ok(v): return str(v or '').strip() not in EMPTY

KIND_KEYS = OrderedDict([   # 내용 키워드 (서로 다른 키워드가 2개 이상 맞으면 그 종류)
    ('AX 과제 목록', r'AX|과제명|과제 ID|과제ID|과제 유형|추진 과제|PoC|과제 번호'),
    ('시스템·데이터 준비 현황', r'시스템명|연동|API|접근 권한|조회 권한|구축 예정|도입 예정|데이터 소스|준비 현황|IT 현황|DB명'),
    ('조직도·R&R', r'조직도|R&R|직무|직책|팀장|본부장|소속|역할 정의|담당 업무'),
    ('승인·결재 규정', r'전결|결재|위임|승인권자|금액 기준|규정|결재 라인'),
    ('산출물 양식·템플릿', r'양식|템플릿|목차|작성 방법|Template|작성 예시'),
    ('현업 인터뷰·회의록', r'인터뷰|회의록|녹취|참석자|일시|질문|답변|Q\.|A\.|발언'),
    ('업무량·소요 시간 자료', r'건수|소요 시간|소요시간|공수|FTE|빈도|횟수|연간'),
])
def sniff(path):
    """파일 앞부분 글 (엑셀: 시트 이름 + 시트마다 앞 3줄, 문서: 앞 4,000자)"""
    ext = os.path.splitext(path.lower())[1]
    try:
        if ext in ('.xlsx', '.xlsm'):
            import openpyxl
            wb = openpyxl.load_workbook(path, read_only=True, data_only=True); out = []
            for ws in wb.worksheets[:8]:
                out.append('[시트] ' + ws.title)
                for row in ws.iter_rows(max_row=3, values_only=True): out.append(' '.join(str(v) for v in row if v is not None))
            return '\n'.join(out)[:6000]
        if ext == '.docx':
            import docx
            return '\n'.join(p.text for p in docx.Document(path).paragraphs)[:4000]
        if ext == '.pdf':
            import subprocess
            return subprocess.run(['pdftotext', '-l', '2', path, '-'], capture_output=True, text=True, timeout=30).stdout[:4000]
        if ext in ('.txt', '.md', '.csv'):
            return open(path, encoding='utf-8', errors='ignore').read(4000)
    except Exception:
        return ''
    return ''

def kind_of(path, how=False):
    """받은 파일 종류 — 내용(시트 이름·머리글·앞부분)을 먼저 보고, 단서가 없을 때만 이름으로"""
    n = os.path.basename(path); low = n.lower(); ext = os.path.splitext(low)[1]
    res = lambda k, h: (k, h) if how else k
    if ext in ('.skill', '.zip'): return res(None, '')
    if ext in ('.png', '.jpg', '.jpeg', '.gif', '.webp'): return res('참고 이미지', '확장자')
    if ext == '.html':
        head = open(path, encoding='utf-8', errors='ignore').read(400000)
        if 'pm-design' in head: return res('이전 To-be HTML (업데이트·편집본)', '내용')
        if re.search(r'to-?be', low): return res('이전 To-be HTML (업데이트·편집본)', '이름')
        return res('As-Is HTML', '내용')
    t = sniff(path)
    if t:
        if re.search(r'\[시트\]\s*Process\s*Map', t, re.I) or (re.search(r'Lv\.?\s*6', t) and re.search(r'선행|후행|노드 ID', t)): return res('As-Is 엑셀', '내용')
        sc = {k: len(set(m.group(0) for m in re.finditer(rx, t))) for k, rx in KIND_KEYS.items()}
        k, v = max(sc.items(), key=lambda x: x[1])
        if v >= 2: return res(k, '내용')
    if ext in ('.xlsx', '.xlsm', '.xls', '.csv') and re.search(r'process|프로세스|as-?is', low): return res('As-Is 엑셀', '이름')
    for k, rx in (('현업 인터뷰·회의록', r'인터뷰|회의록|녹취|interview|미팅'), ('AX 과제 목록', r'ax|과제'), ('시스템·데이터 준비 현황', r'시스템|준비\s*현황|it\s*현황|데이터\s*현황|api'),
                  ('조직도·R&R', r'조직도|r&r|직무|역할'), ('승인·결재 규정', r'규정|결재|전결|위임'), ('산출물 양식·템플릿', r'양식|템플릿|template|샘플')):
        if re.search(rx, low): return res(k, '이름')
    return res('기타 자료 (' + (ext[1:] or '파일') + ')', '판별 안 됨 — Claude가 열어 확인')

CATALOG = OrderedDict([   # 기본 목록 — 바닥일 뿐, Claude가 분석으로 덧붙인다 (input-request.md)
    ('asis_html', ('As-Is HTML', 'As-Is HTML')),
    ('interview', ('현업 인터뷰·회의록', '현업 인터뷰·회의록')),
    ('ax', ('AX 과제 목록', 'AX 과제 목록')),
    ('sys', ('시스템·데이터 준비 현황', '시스템·데이터 준비 현황')),
    ('org', ('조직 정식 명칭·조직도·R&R', '조직도·R&R')),
    ('prev', ('이전 To-be HTML·편집본', '이전 To-be HTML (업데이트·편집본)')),
    ('rules', ('승인·결재 규정', '승인·결재 규정')),
    ('tmpl', ('산출물 양식·템플릿', '산출물 양식·템플릿')),
    ('volume', ('업무량·소요 시간 자료', '업무량·소요 시간 자료')),
])

def split_items(t):
    """쉼표·줄바꿈으로 나누되 괄호 안은 나누지 않음, 줄머리 '- ' 등은 뗌"""
    out, cur, dep = [], '', 0
    for ch in t + '\n':
        if ch in '([': dep += 1
        elif ch in ')]': dep = max(0, dep - 1)
        if ch in ',;\n' and dep == 0:
            x = re.sub(r'^[\s\-•·*]+', '', cur).strip()
            if ok(x) and len(x) > 1: out.append(x)
            cur = ''
        else: cur += ch
    return out
def diagnose(asis, files):
    A6, A5, A4 = asis['A6'], asis.get('A5', {}), asis.get('A4', {})
    st_of = {}
    for k, a in A6.items():
        l5 = a['l5'].split(' ')[0]; l4 = (A5.get(l5) or {}).get('l4id')
        st_of[k] = (list(A4).index(l4) + 1) if l4 in A4 else 0
    stages = sorted(set(st_of.values()))
    received = [dict(file=os.path.basename(f), kind=k, how=h) for f in files for k, h in [kind_of(f, True)] if k]
    kinds = Counter(r['kind'] for r in received)
    fields = OrderedDict([('pain', 'Pain point'), ('inp', '인풋 데이터'), ('fmt', '인풋 데이터 형식'), ('sys', '활용 시스템'), ('out', '아웃풋'), ('note', '비고')])
    fill = OrderedDict()
    for f, lab in fields.items():
        per = {s: [sum(1 for k in A6 if st_of[k] == s and ok(A6[k].get(f))), sum(1 for k in A6 if st_of[k] == s)] for s in stages}
        tot = sum(v[0] for v in per.values())
        fill[f] = dict(label=lab, filled=tot, total=len(A6), rate=round(tot / max(1, len(A6)) * 100), by_stage={str(s): v for s, v in per.items()})
    memo_org = sorted({v for a in A6.values() for v in (a.get('bon'), a.get('team'), a.get('part')) if v and MEMO.search(v)})
    memo_rows = [k for k, a in A6.items() if any(v and MEMO.search(v) for v in (a.get('bon'), a.get('team'), a.get('part')))]
    decide = [k for k, a in A6.items() if DECIDE.search(a['n'])]
    ext = [k for k, a in A6.items() if EXT.search((a.get('team') or '') + ' ' + (a.get('bon') or ''))]
    cond = [k for k, a in A6.items() if COND.search(a['n'])]
    systems = Counter(x for a in A6.values() for x in split_items(a.get('sys') or ''))
    sys_memo = sorted(x for x in systems if MEMO.search(x))
    tags = Counter(t.strip() for a in list(A5.values()) for t in re.findall(r'\[([^\]]+)\]', a.get('n', '')))
    tag_rows = Counter(t.strip() for a in A6.values() for t in re.findall(r'\[([^\]]+)\]', a.get('l5', '')))
    pain_txt = ' '.join(a.get('pain', '') for a in A6.values())
    vol = bool(VOLUME.search(pain_txt)) and len(VOLUME.findall(pain_txt))
    br = sum(1 for a in A6.values() if ok(a.get('br'))); rj = sum(1 for a in A6.values() if ok(a.get('rejr')))
    teams = Counter((a.get('bon') or '') + ' > ' + (a.get('team') or '') for a in A6.values())
    cat = OrderedDict()
    for key, (lab, kd) in CATALOG.items():
        got = [r['file'] for r in received if kd and r['kind'] == kd]
        st = 'received' if got else 'missing'
        if key == 'interview' and not got and any(re.search(r'인터뷰|interview', r['file']) for r in received): st = 'partial'   # 엑셀·HTML 이름에 '인터뷰 반영'만 있음
        if key == 'volume' and not got: st = 'partial' if vol else 'missing'
        cat[key] = dict(label=lab, status=st, files=got)
    return dict(received=received, kinds=dict(kinds), stages=len(stages), rows=len(A6), fill=fill,
                memo_org=memo_org, memo_rows=memo_rows[:20], decide=dict(n=len(decide), ex=decide[:8]), external=dict(n=len(ext), ex=ext[:8]),
                conditional=dict(n=len(cond), ex=cond[:8]), systems=dict(n=len(systems), top=systems.most_common(12), memo=sys_memo),
                scenario_tags=tags.most_common(), scenario_rows=tag_rows.most_common(), volume_mentions=vol or 0,
                branch_rows=br, rework_rows=rj, teams=teams.most_common(), catalog=cat)

def to_md(r):
    L = ['# 자료 진단 (1단계 추가 자료 요청의 근거)', '', '## 받은 자료']
    L += [f"- {x['file']} — {x['kind']}" + (f" ({ {'내용': '내용으로', '이름': '이름으로', '확장자': '확장자로'}.get(x.get('how'), x.get('how'))} 판별)" if x.get('how') and x.get('how') in ('내용', '이름', '확장자') else (f" ({x.get('how')})" if x.get('how') else '')) for x in r['received']] or ['- (없음)']
    if r.get('carried'):
        L += ['', '## 이전 자료 기록 (업데이트 — 이어받음)'] + [f"- {c['item']}: {dict(received='받음', none='없음', pending='아직')[c.get('status') or 'pending']}" for c in r['carried']]
    if r.get('changed_rows') is not None:
        L.append(f"- 이전 설계 대비 새로 생기거나 업무명이 바뀐 행: {len(r['changed_rows'])}개 " + ', '.join(r['changed_rows'][:8]))
    if r.get('deleted_rows') is not None:
        L.append(f"- 새 엑셀에서 없어진 행: {len(r['deleted_rows'])}개 " + ', '.join(r['deleted_rows'][:8]) + (' — 업무명 대조로 이동/삭제를 정해 prune.py로 정리' if r['deleted_rows'] else ''))
    L += ['', f"## 엑셀 규모: 단계 {r['stages']} · Lv.6 {r['rows']}행", '', '## 엑셀 칸 채움 (단계별 채움/전체)']
    for f, v in r['fill'].items():
        L.append(f"- {v['label']}: {v['filled']}/{v['total']} ({v['rate']}%) — " + ' · '.join(f"{s}단계 {a}/{b}" for s, (a, b) in v['by_stage'].items()))
    L += ['', '## 확인이 필요한 근거']
    L.append(f"- 메모가 붙은 조직명 {len(r['memo_org'])}개: " + (' / '.join(r['memo_org']) or '없음') + (f" (행 예: {', '.join(r['memo_rows'][:5])})" if r['memo_rows'] else ''))
    L.append(f"- 결정·승인 업무 {r['decide']['n']}행 (기준이 엑셀에 없음 → 승인 규정·기준 필요 여부): {', '.join(r['decide']['ex'])}")
    L.append(f"- 외부·협력사 담당 행 {r['external']['n']}행: {', '.join(r['external']['ex'])}")
    L.append(f"- '필요 시'·'경우' 같은 조건부 업무 {r['conditional']['n']}행 (조건·빈도 불명): {', '.join(r['conditional']['ex'])}")
    L.append(f"- 활용 시스템 {r['systems']['n']}종 (준비 상태·연동 가능 여부 근거 없음): " + ', '.join(f'{s}({c})' for s, c in r['systems']['top']))
    if r['systems'].get('memo'): L.append(f"- 이름에 '확인 필요' 등 메모가 붙은 시스템 {len(r['systems']['memo'])}개: " + ' / '.join(r['systems']['memo'][:6]))
    L.append(f"- 시나리오 태그(경로) {len(r['scenario_tags'])}종 (경로별 건수 비중 근거 없음): " + ', '.join(f'{t}' for t, _ in r['scenario_tags'][:12]))
    L.append(f"- 업무량·소요 시간 언급: Pain point 안 {r['volume_mentions']}곳 (별도 자료 없음)" if r['volume_mentions'] else '- 업무량·소요 시간 자료: 없음')
    L.append(f"- 분기 조건 {r['branch_rows']}행 · 반려 사유 {r['rework_rows']}행")
    L += ['', '## 기본 목록 대비 (바닥 — 분석으로 덧붙일 것은 input-request.md 판단 질문으로)']
    L += [f"- {v['label']}: {dict(received='받음', partial='일부', missing='없음')[v['status']]}" + (f" ({', '.join(v['files'])})" if v['files'] else '') for v in r['catalog'].values()]
    return '\n'.join(L) + '\n'

def message(I):
    """1단계 요청 메시지 (input-request.md 4절 형식)"""
    L = ['**받은 자료**'] + [f"- {x['file']} — {x['kind']}" for x in I.get('received', [])] + ['']
    done = {c['item']: c.get('status') for c in I.get('carried', []) if c.get('status') in ('received', 'none')}
    if done:
        L += ['**지난번 자료 기록 (다시 묻지 않음)**'] + [f"- {k}: {'받음' if v == 'received' else '없음으로 진행'}" for k, v in done.items()] + ['']
    R = [r for r in I.get('requests', []) if (r.get('item') not in done or r.get('reask')) and r.get('status') != 'received']; Q = I.get('questions', [])   # 이번에 받은 것도 다시 요청하지 않음
    if not R and not Q:
        return '\n'.join(L + ['부족한 자료가 없습니다 — 이대로 진행할까요?'])
    L.append('**A. 자료 요청**')
    for pri in ('필수', '권장', '있으면 좋음'):
        rs = [r for r in R if r.get('pri') == pri]
        if not rs: continue
        L.append(f'[{pri}]')
        for r in rs:
            L.append(f"- **{r['item']}**" + (f": {r['what']}" if r.get('what') else ''))
            L.append(f"  · 근거: {r['why']}"); L.append(f"  · 없을 때: {r['if_none']}")
    if Q:
        L += ['', '**B. 확인하고 싶은 내용** (파일 없이 답해 주셔도 됩니다)']
        L += [f"- {q['q']} — 근거: {q['why']} / 없을 때: {q['if_none']}" for q in Q]
    L += ['', '주실 수 있는 것만 주셔도 됩니다. 없는 항목은 "없음"이라고 답하시면 위 방식으로 진행하고, 나중에 주시면 그때 반영합니다.']
    return '\n'.join(L)

def conflicts(I, where=None):
    """자료끼리 다른 점 — 0.5(흐름 구조, 구조 확인 때 질문) 또는 그 밖(묻지 않고 input-request.md 8절 기준으로 결정)"""
    C = [c for c in I.get('conflicts', []) if not c.get('resolved') and (where is None or c.get('ask_in') == where)]
    return '\n'.join(f"- {c['what']} ({c.get('where', '')}): 엑셀 「{c['excel']}」 / {c.get('src', '추가 자료')} 「{c['other']}」 — 어느 쪽이 맞나요?" for c in C) or '(자료끼리 다른 점 없음)'

if __name__ == '__main__':
    if len(sys.argv) >= 3 and sys.argv[1] == 'conflicts':
        print(conflicts(json.load(open(sys.argv[2], encoding='utf-8')), sys.argv[3] if len(sys.argv) > 3 else None)); sys.exit(0)
    if len(sys.argv) >= 3 and sys.argv[1] == 'message':
        print(message(json.load(open(sys.argv[2], encoding='utf-8')))); sys.exit(0)
    if len(sys.argv) >= 4 and sys.argv[1] == 'save':
        av = sys.argv[1:]; ANS = ''
        if '--answer' in av: k = av.index('--answer'); ANS = (av[k + 1] if k + 1 < len(av) else '').strip(); av = av[:k] + av[k + 2:]; sys.argv = [sys.argv[0]] + av
        if not ANS: ANS = '(사용자 답변 기록 없음 — 받은 자료 기준으로 진행)'; print('주의 [자료] --answer가 없어 받은 자료 기준으로 저장 — 사용자 답을 받으면 다시 저장')
        I = json.load(open(sys.argv[2], encoding='utf-8')); d = json.load(open(sys.argv[3], encoding='utf-8')); I['answer'] = ANS
        d['inputs'] = {k: I[k] for k in ('received', 'requests', 'questions', 'answers', 'assumptions', 'none_needed', 'applied', 'conflicts', 'carried', 'prev_received', 'answer') if k in I}
        json.dump(d, open(sys.argv[3], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print('설계 파일에 자료 기록 저장:', sys.argv[3], '· 요청', len(I.get('requests', [])), '· 질문', len(I.get('questions', []))); sys.exit(0)
    if len(sys.argv) < 4: print(__doc__); sys.exit(1)
    args = sys.argv[1:]; prev = None
    if '--prev' in args: i = args.index('--prev'); prev = json.load(open(args[i + 1], encoding='utf-8')); args = args[:i] + args[i + 2:]
    asis = json.load(open(args[0], encoding='utf-8')); out = args[-1]; files = args[1:-1]
    r = diagnose(asis, files)
    if prev:   # 업데이트: 이전 설계의 자료 기록을 이어받아, 받음·없음은 다시 묻지 않음
        pi = prev.get('inputs') or {}
        r['carried'] = [dict(item=x.get('item'), pri=x.get('pri'), status=x.get('status'), if_none=x.get('if_none'), why=x.get('why'), what=x.get('what')) for x in pi.get('requests', [])]
        r['prev_received'] = pi.get('received', []); r['prev_answers'] = pi.get('answers', {}); r['prev_assumptions'] = pi.get('assumptions', [])
        TBp = prev.get('tb', {})
        NMp = prev.get('asis_names') or {}
        r['changed_rows'] = [k for k, a in asis['A6'].items() if (k not in NMp and k not in TBp) or (NMp.get(k) and NMp[k] != a['n']) or (k not in NMp and TBp.get(k, {}).get('src_n') and TBp[k]['src_n'] != a['n'])]
        r['deleted_rows'] = list(dict.fromkeys([k for k in NMp if k not in asis['A6']] + [k for k in TBp if re.match(r'^\d+(?:-\d+){5}$', k) and k not in asis['A6']]))   # 새 엑셀에서 없어진 행 → 업무명 대조로 이동/삭제를 정한 뒤 prune.py
    old = json.load(open(out + '.json', encoding='utf-8')) if os.path.exists(out + '.json') else {}
    for k in ('requests', 'questions', 'answers', 'assumptions', 'none_needed', 'applied', 'conflicts'):   # 자료가 추가로 오면 다시 돌려도 Claude가 쓴 요청·답·반영·차이 기록은 유지
        if k in old: r[k] = old[k]
    json.dump(r, open(out + '.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    open(out + '.md', 'w', encoding='utf-8').write(to_md(r)); print(to_md(r))
