"""v1.2 quality gates: structural redesign and visible human decisions.
Text explains design intent; executable graph evidence is the acceptance criterion.
Uses only the standard library. Does not invent redesign or infer consent.
"""
import json
import re
import sys
from collections import defaultdict

ACTIVE = {'A', 'N', 'H', 'O'}
TYPES = {'s', 'b', 'p', 'r', 'l'}
HUMAN_ACTION = re.compile(r'(?:사람|인간|담당자|책임자|광고주|팀장|법무|준법담당)(?:가|이|는|의)?\s*(?:최종\s*)?(?:확인|검토|승인|컨펌|판단|결정|확정)|(?:최종\s*(?:승인|확정|결정|판단)|컨펌|의사결정)')
DECISION_END = re.compile(r'(?:^|\s)(?:확정|승인|결재|판단|결정|선정)(?=\s*(?:및|·|/|$))')
PREPARATION = re.compile(r'(?:승인|확정|결정|판단|컨펌)(?:용|을\s*위한)?\s*(?:요청서|요청|자료|근거|초안|후보|지원|보조)|(?:승인|확정)\s*(?:결과|이력|상태|기록|여부|대기)')

def tasks(d):
    return {k: t for k, t in d.get('tb', {}).items() if t.get('t') in ACTIVE}

def lv4(a):
    return a.get('g4id') or a.get('g4') or a.get('l4id')

def source_scope(a, k):
    return lv4(a['A5'].get(a['A6'][k].get('l5', '').split(' ')[0], {}))

def source_edges(a):
    edges = set()
    for k, v in a.get('A6', {}).items():
        for f, ty in [('post', 's'), ('rej', 'r')]:
            for target in re.split(r'[,;\s]+', str(v.get(f) or '')):
                if target in a['A6']: edges.add((k, target, ty))
    if a.get('source_html'):
        from source_asis import mapped_edges
        source = mapped_edges(a['source_html'])
        pairs = {tuple(e[:2]) for e in source}
        edges = {e for e in edges if e[:2] not in pairs}
        edges.update(tuple(e[:3]) for e in source)
    return edges

def is_human_action(text):
    clean = PREPARATION.sub('', text)
    return bool(HUMAN_ACTION.search(clean) or DECISION_END.search(clean))

def edge_list(d):
    return [tuple(e[:3]) for e in d.get('tobe_flow', []) if isinstance(e, list) and len(e) >= 3]

def reachable(edges, start, target, blocked=None):
    todo, seen = [start], set()
    adjacency = defaultdict(set)
    for a, b, ty in edges:
        if ty not in ('r', 'l'): adjacency[a].add(b)
    while todo:
        here = todo.pop()
        if here == blocked or here in seen: continue
        if here == target: return True
        seen.add(here); todo.extend(adjacency[here] - seen)
    return False

def metrics(a, d):
    T = tasks(d)
    one = {k: t['ref'][0] for k, t in T.items() if len(t.get('ref') or []) == 1}
    return {'as_is_tasks': len(a['A6']), 'to_be_tasks': len(T),
            'one_source_tasks': len(one), 'merged_tasks': sum(len(t.get('ref') or []) > 1 for t in T.values()),
            'source_edges': len(source_edges(a)), 'to_be_edges': len(edge_list(d)),
            'human_tasks': sum(t['t'] in ('N', 'H', 'O') for t in T.values())}

def validate(a, d):
    out = []
    def error(tag, message): out.append(('오류', tag, message))
    T, A6 = tasks(d), a['A6']
    if d.get('mode') != 'restructure':
        error('[재설계]', 'mode=restructure 필수: As-Is 담당·워딩 치환 경로는 최종 산출에 사용할 수 없음')
    contract = d.get('design_contract')
    if not isinstance(contract, dict) or contract.get('version') != 1:
        error('[설계계약]', 'design_contract.version=1 및 Lv.4별 redesign 근거를 작성해야 함')
        contract = {}
    raw_flow = d.get('tobe_flow')
    if not isinstance(raw_flow, list):
        error('[흐름]', 'tobe_flow를 명시해야 함; 입력 순서의 자동 순차 연결은 금지')
        raw_flow = []
    edges = []
    for i, e in enumerate(raw_flow):
        if not isinstance(e, list) or len(e) != 4 or not all(isinstance(x, str) for x in e):
            error('[흐름]', f'tobe_flow[{i}]는 [시작 ID, 끝 ID, 종류, 조건 문자열] 형식이어야 함'); continue
        start, end, kind, label = e
        if start not in T or end not in T: error('[흐름]', f'{start} → {end}: 활성 Lv.6 업무가 아닌 끝점')
        if kind not in TYPES: error('[흐름]', f'{start} → {end}: 지원하지 않는 종류 {kind}')
        if kind in ('b', 'r', 'l') and not label.strip(): error('[흐름]', f'{start} → {end}: 조건·반려 사유 없음')
        edges.append(tuple(e[:3]))
    if len(edges) != len(set(edges)): error('[흐름]', '중복 연결이 있음')
    linked = {v for e in edges for v in e[:2]}
    if len(T) > 1:
        for k in T:
            if k not in linked and not T[k].get('standalone_reason'):
                error('[흐름]', f'{k}: 연결되지 않은 업무 (독립 업무면 standalone_reason 필수)')
    reach_edges = list(edges)
    for edge in d.get('new_edges', []):
        if not isinstance(edge, list) or len(edge) != 4:
            error('[흐름]', 'new_edges 형식 오류'); continue
        if edge[0] not in d.get('tb', {}) or edge[1] not in d.get('tb', {}):
            error('[흐름]', f'신규 연결 끝점 없음: {edge[:2]}'); continue
        reach_edges.append(tuple(edge[:3]))
    src_edges = source_edges(a)
    scopes = {source_scope(a, k) for k in A6}
    records = contract.get('redesign')
    if not isinstance(records, list): records = []; error('[재설계]', 'design_contract.redesign 배열 없음')
    covered, meaningful = set(), 0
    for i, op in enumerate(records):
        if not isinstance(op, dict): error('[재설계]', f'redesign[{i}] 객체 아님'); continue
        scope, kind = op.get('scope'), op.get('kind')
        if scope not in scopes: error('[재설계]', f'redesign[{i}]: 실제 Lv.4 scope가 아님: {scope}'); continue
        covered.add(scope)
        before, after = op.get('source_ids') or [], op.get('tobe_ids') or []
        if not isinstance(before, list) or not isinstance(after, list):
            error('[재설계]', f'{scope}: source_ids/tobe_ids는 배열이어야 함'); continue
        if not before or any(k not in A6 for k in before) or any(k not in T for k in after):
            error('[재설계]', f'{scope}: source_ids/tobe_ids가 비어 있거나 잘못된 ID'); continue
        if not any(source_scope(a, k) == scope for k in before): error('[재설계]', f'{scope}: 해당 Lv.4의 원본 업무가 근거에 없음')
        if not str(op.get('reason') or '').strip() or not str(op.get('evidence') or '').strip():
            error('[재설계]', f'{scope}: 병목 근거(reason)와 검토 가능한 변화 설명(evidence) 필수')
        refs = {k: set(T[k].get('ref') or []) for k in after}
        ok = False
        if kind == 'retain':
            if not op.get('constraint'): error('[재설계]', f'{scope}: 구조 유지의 실제 제약(constraint) 필수')
            continue
        if kind == 'merge':
            ok = any(len(refs[k] & set(before)) >= 2 and not any(
                other != k and t.get('t') == T[k].get('t') and set(t.get('ref') or []) & refs[k] & set(before)
                for other,t in T.items()) for k in after)
        elif kind == 'regroup':
            # Grouping must change relationships between at least two source tasks.
            for u in after:
                for v in after:
                    for x in refs[u] & set(before):
                        for y in refs[v] & set(before):
                            if x != y and ((A6[x]['l5'].split(' ')[0] == A6[y]['l5'].split(' ')[0]) != (T[u].get('l5') == T[v].get('l5'))): ok = True
        elif kind == 'reorder':
            ok = any((x, y, 's') in src_edges and reachable(edges, v, u) and not reachable(edges, u, v)
                     for u in after for v in after for x in refs[u] & set(before) for y in refs[v] & set(before))
        elif kind == 'parallelize':
            # A real fan-out plus removal of the previous serial dependency.
            pred = defaultdict(set)
            for u, v, ty in edges:
                if ty == 'p': pred[u].add(v)
            ok = any(u in targets and v in targets and any((x,y,'s') in src_edges or (y,x,'s') in src_edges for x in refs[u] & set(before) for y in refs[v] & set(before))
                     and not reachable(edges,u,v) and not reachable(edges,v,u)
                     for targets in pred.values() for u in after for v in after if u != v)
        elif kind == 'relocate':
            for k in after:
                target = d.get('tb5', {}).get(T[k].get('l5'), {})
                target_scope = target.get('l4')
                if target_scope is None:
                    origins = target.get('from') or []
                    if origins: target_scope = lv4(a['A5'].get(origins[0], {}))
                ok |= bool(target_scope and any(source_scope(a,x) != target_scope for x in refs[k] & set(before)))
        elif kind == 'remove':
            ok = any(d.get('tb', {}).get(x, {}).get('t') == 'X' and d['tb'][x].get('to') in after and d['tb'][x].get('why') for x in before)
        else:
            error('[재설계]', f'{scope}: kind {kind}는 구조 변화가 아님 (담당/워딩/ID 변경·인간 분리만으로 통과 불가)'); continue
        if not ok: error('[재설계]', f'{scope}: {kind} 주장과 실제 ref·Lv.5 소속·흐름이 일치하지 않음')
        else: meaningful += 1
    for scope in sorted(scopes - covered, key=str): error('[재설계]', f'{scope}: 구조 변화 또는 유지 제약 검토 누락')
    if not meaningful: error('[재설계]', '검증된 구조 변화 0건: 담당·워딩·새 ID 및 사람 확인 노드 추가만으로는 재설계가 아님')
    # Additional direct rejection of complete 1:1 mapped graph/group clones.
    mapping = {k: t['ref'][0] for k,t in T.items() if len(t.get('ref') or []) == 1}
    if len(mapping) == len(T) == len(A6) and len(set(mapping.values())) == len(A6):
        mapped = {(mapping[u],mapping[v],ty) for u,v,ty in edges if u in mapping and v in mapping}
        same_groups = all((T[u].get('l5') == T[v].get('l5')) == (A6[mapping[u]]['l5'] == A6[mapping[v]]['l5']) for u in T for v in T)
        if mapped == src_edges and same_groups: error('[재설계]', '원본 1:1 대응·연결·Lv.5 묶음이 동일함: 명칭·담당만 바꾼 설계')
    lanes = {l.get('k') for l in d.get('lanes', [])}
    for k,t in T.items():
        if t['t'] in ('N','H','O'):
            if t.get('lane') not in lanes or t.get('sub'): error('[사람분리]', f'{k}: 사람 업무는 유효한 조직 lane에만 배치해야 함')
            continue
        review = t.get('human_review')
        if not isinstance(review, dict) or type(review.get('required')) is not bool or not str(review.get('reason') or '').strip():
            error('[사람분리]', f'{k}: human_review.required(bool) 및 업무별 reason 필수'); continue
        text = str(t.get('lb') or '') + ' ' + str(d.get('desc',{}).get('T6',{}).get(k) or '')
        # Remove approval preparation/status nouns, but retain an actual human action.
        scan = PREPARATION.sub('', text)
        if is_human_action(scan): error('[사람분리]', f'{k}: Agent 박스에 사람 확인·최종 판단 행위가 포함됨; 별도 Lv.6으로 분리')
        if not review['required']: continue
        decision = review.get('decision_node'); h = T.get(decision, {})
        if decision == k or h.get('t') not in ('N','H','O') or h.get('lane') not in lanes or h.get('sub'):
            error('[사람분리]', f'{k}: decision_node는 별도 사람 Lv.6·조직 레인이어야 함'); continue
        if not any(u == k and v == decision and ty not in ('r','l') for u,v,ty in edges):
            error('[사람분리]', f'{k} → {decision}: Agent 산출물을 사람에게 넘기는 연결 없음')
        if not str(t.get('io',{}).get('out') or '').strip() or not str(h.get('io',{}).get('inp') or '').strip():
            error('[사람분리]', f'{k} → {decision}: Agent 산출물(io.out)·사람 판단 근거(io.inp) 필수')
        continuation, rework = review.get('continue_to') or [], review.get('rework_to') or []
        if not isinstance(continuation,list) or not isinstance(rework,list):
            error('[사람분리]',f'{k}: continue_to/rework_to는 ID 배열이어야 함'); continue
        if not continuation and review.get('terminal') is not True: error('[사람분리]', f'{decision}: 승인 후 경로 또는 terminal=true 필수')
        if not rework: error('[사람분리]', f'{decision}: 반려·재작업 경로(rework_to) 필수')
        for target in continuation:
            if target not in T or not any(u == decision and v == target and ty == 'b' for u,v,ty in edges):
                error('[사람분리]', f'{decision} → {target}: 조건을 표시한 승인 분기(b) 없음')
            if reachable(reach_edges,k,target,blocked=decision): error('[사람분리]', f'{k} → {target}: 사람 판단을 우회하는 진행 경로')
        for target in rework:
            if target not in T or not any(u == decision and v == target and ty in ('r','l') for u,v,ty in edges):
                error('[사람분리]', f'{decision} → {target}: 조건을 표시한 반려·재작업 연결 없음')
    # An original final approval cannot disappear merely by declaring required=false.
    for src,row in A6.items():
        if not is_human_action(str(row.get('n') or '')): continue
        holders = [(k,t) for k,t in T.items() if src in (t.get('ref') or [])]
        if not any(t['t'] in ('N','H','O') for _,t in holders):
            linked_human = any((t.get('human_review') or {}).get('required') and T.get((t.get('human_review') or {}).get('decision_node'),{}).get('t') in ('N','H','O') for _,t in holders)
            if not linked_human: error('[사람분리]', f'{src}: 원본 최종 확인·판단 업무의 사람 Lv.6 대응이 없음')
    return out

if __name__ == '__main__':
    a,d = (json.load(open(p,encoding='utf-8')) for p in sys.argv[1:3])
    issues = validate(a,d)
    for issue in issues: print(*issue)
    print(json.dumps(metrics(a,d),ensure_ascii=False))
    sys.exit(2 if any(x[0] == '오류' for x in issues) else 0)
