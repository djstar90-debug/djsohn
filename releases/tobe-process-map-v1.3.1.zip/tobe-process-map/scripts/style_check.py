"""design.json에서 Claude가 쓴 문구를 베인식 규칙으로 점검 (엑셀 원문 발췌인 Pain point는 제외)
- 개조식 칸(업무명·태그·소멸 비고·Agent 이름·설명·기능 목록·게이트): 경어체·마침표 금지 + 공통 규칙
- 서술형 칸(Agent 소개 문단·효과·사람이 남는 지점·기대 변화·흐름 따라가기): 공통 규칙만
사용: style_check.py design.json [asis.json]   (위반이 있으면 종료 코드 1, asis.json을 주면 업무명 점검 [이름]도 — 엑셀 원문 어휘 기준)
"""
import re, sys, json
class ChainWa:
    """'A와 B C과 D'처럼 조사 없이 와/과가 두 번 이어지는 명사 나열 ('·' 자동 변환이 만들던 꼴). 성과·결과·효과처럼 '과'로 끝나는 명사는 제외"""
    NOUN = {'성과', '결과', '효과', '경과', '초과', '통과', '부과', '학과', '교과', '사과', '과과'}
    JOSA = re.compile(r'(의|을|를|에|로|은|는|이|가|고|며|서|도|만|해|하여|하며|하면|되어|보고|받아|맞춰|따라|통해|위해|대해)$')   # 조사·동사 활용형이 사이에 있으면 연쇄 아님
    def search(self, txt):
        w = re.findall(r'[가-힣A-Za-z0-9/]+', re.sub(r'「[^」]*」', ' ', txt or ''))   # 「」 안은 엑셀 원문 인용이라 빼고 봄
        idx = [i for i, x in enumerate(w) if re.search(r'[가-힣A-Za-z0-9](와|과)$', x) and x not in self.NOUN and not any(x.endswith(n) for n in self.NOUN)]
        for a, b in zip(idx, idx[1:]):
            mid = w[a + 1:b]
            if b - a <= 3 and not any(self.JOSA.search(x) for x in mid): return True
        return False
COMMON = [('당위', re.compile(r'해야\s?(함|한다|합니다|하며|할)|반드시|필수적으로')),
          ('과장', re.compile(r'압도|장악|독점|지배|완벽|획기적|혁명|완전히')),
          ('단정', re.compile(r'없앱|없앤|없애|사라집니다|사라진다|해소된다')),
          ('비난', re.compile(r'못한다|못함|미흡|비효율|낭비|깜깜이|허술|엉망|잘못')),
          ('부사', re.compile(r'매우|굉장히|정말|아주|너무')),
          ('용어', re.compile(r'기준선')),
          ('쉬운말', re.compile(r'게이트키핑|하네스|금칙|Always-on|Mandatory(?!\))|딜리버러블')),   # 풀어 쓰고 원어는 괄호로 (예: 필수 표기 요소(Mandatory))          # 추상어 '기준선' 대신 구체 명칭 (예: 제작 조건/범위, Scope·Fee 조건/범위)
          ('조사', re.compile(r'범위(\([^)]*\))?(을|이|과|은)(?![가-힣])')),
          ('반복', re.compile(r'업무\s*업무')),                                     # "업무명 업무" 반복
          ('틀 문장', re.compile(r'업무를 맡습니다|처리를 합니다|결정을 내립니다')),   # 이름만 끼워 넣은 틀 문장
          ('틀 문장', re.compile(r'^[^:]{2,80}: .+(이|가) (직접 )?처리합니다$|^[^:]{2,80}: .+Agent 결과를 확인하고 결정합니다$')),   # "업무: 주체가 처리합니다" 꼴
          ('조사', re.compile(r'(자동|수동|일괄|상시|사전)(을|를)(?![가-힣])')),        # "이해상충 자동을 점검"
          ('연쇄', ChainWa()),   # "RFP와 초청 자료 수신과 구조화" — 사이에 조사 없이 'A와 B C과 D'
          ('만든 말', re.compile(r'상시 감지|카드화|레버(?!리지)|시그널 포착|딥다이브|얼라인'))]   # 업계에서 쓰지 않는 비유·신조어
BULLET = [('경어체', re.compile(r'(습니다|[가-힣]니다)[.\s]*$')), ('마침표', re.compile(r'[가-힣)\]]\.\s*$'))]
def fields(D):
    for k, t in D['tb'].items():
        for f in ('lb', 'tg', 'note'):
            if t.get(f): yield f'tb.{k}.{f}', t[f], 'b'
    for s, v in D['subs'].items():
        yield f'subs.{s}.name', v['name'], 'b'; yield f'subs.{s}.desc', v['desc'], 'p'     # v17부터 Agent 설명은 서술형
    for b in D['bands']: yield f"bands.{b['id']}.desc", b['desc'], 'p'
    for k, v in D.get('stage_gate', {}).items(): yield f'stage_gate.{k}', v, 'b'
    for b, s in D['story'].items():
        yield f'story.{b}.intro', s.get('intro', ''), 'b'   # v35: 아직 안 쓴 칸이 있어도 점검이 멈추지 않게
        for j, x in enumerate(s.get('pb', [])): yield f'story.{b}.pb[{j}]', x, 'b'
        for k in ('p', 'hum'): yield f'story.{b}.{k}', s.get(k, ''), 'p'
        for j, x in enumerate(s.get('imp', [])): yield f'story.{b}.imp[{j}]', x[1], 'p'
        for sid, ss in s.get('subs', {}).items():
            for j, x in enumerate(ss.get('f', [])): yield f'story.{b}.{sid}.f[{j}]', x[0], 'b'
            yield f'story.{b}.{sid}.e', ss.get('e', ''), 'p'
    for key, m in (D.get('desc') or {}).items():
        for k, txt in m.items(): yield f'desc.{key}.{k}', txt, 'p'
    for st, v in D.get('tour', {}).items():
        for k in ('now', 'chg', 'next'): yield f'tour.{st}.{k}', v.get(k, ''), 'p'
        for bi, bt in enumerate(v.get('beats', [])):
            for si, sp in enumerate(bt['steps']): yield f'tour.{st}.{bi}.{si}', sp['d'], 'p'
def check(D):
    out = []
    for path, txt, kind in fields(D):
        rules = COMMON + (BULLET if kind == 'b' else [])
        t = (txt or '').replace('**', '')   # 굵은 글씨 표시는 빼고 봄 ("**이해상충 자동**을")
        for code, rx in rules:
            if t and rx.search(t): out.append((path, code, t[:70]))
    return out
# ===== v30 업무명 점검 [이름] — To-be 업무명(Lv.6·신규 노드)·게이트·흐름 따라가기 이름표·Agent 이름 =====
VERBS = set('확인 정리 검토 작성 공유 전달 요청 협의 조회 등록 발송 수령 접수 관리 보고 분석 비교 점검 준비 결정 확정 승인 선정 반영 수정 계산 대조 기록 보관 안내 제출 제안 조율 취합 수집 모니터링 배정 지정 발행 처리 회신 질의 응대 시사 발표 계획 수립 검수 산출 추정 분류 입력 갱신 업데이트 탐색 평가 진행 실행 설계 개발 구성 배포 출고 확보 접촉 협상 합의 체결 서명 통보 요약 파악 찾기 정하기 보내기 받기 맞추기 모으기 나누기 시작'.split())
NJOSA = re.compile(r'(을|를|에서|에게|에|과|와|의|로|으로|은|는|이|가|도|만|부터|까지|해|하여|하고|하며|고|며|서|보고|맞는지|있는지|없는지|인지|이나|거나|나|든|,|모아|찾아|나눠|묶어|맞춰|받아|따라|넣어|보며|통해|위해|대해)$|^(및|기반|기준|대비|대상|관련|간|중|내|시|별)$')   # v32: '및'·기반·기준·대비도 끊김   # 쉼표·이나도 끊김으로 봄
def name_rules(nm, kind, vocab):
    """kind: tb(업무명) · gate · label(흐름 이름표) · agent"""
    o = []; t = (nm or '').strip()
    if not t: return o
    if kind == 'gate':
        if not re.match(r'^[①-⑳]\s.+\s→\s.+\sAgent 호출$', t): o.append(('오류', '게이트 형식', "'[번호] [확정 지점] → [다음 Agent] 호출' 꼴이 아님"))
        return o
    if re.search(r'[()（）]', t): o.append(('오류', '괄호 설명', '근거·주체는 상세 창·태그·흐름 문장으로'))
    if re.search(r'[^·\s]+·[^·\s]+·[^·\s]+', t): o.append(('오류', "'·' 3개 이상 나열", '두 개까지만, 나머지는 묶어 부르기'))
    if re.search(r'(?<![A-Za-z])[^/\s]+/[^/\s]+/[^/\s]+', t) and not any(m in vocab['text'] for m in re.findall(r'[^\s]+/[^\s]+/[^\s]+', t)): o.append(('오류', "'/' 3개 이상 나열", '두 개까지만'))
    if re.search(r'[→↔⇒>+＋]', t): o.append(('오류', '기호', '기호 대신 말로'))
    last_w = t.split()[-1]
    if kind == 'tb' and (last_w in ('표', '안', '목록', '초안', '리스트', '양식', '후보', '항목') or re.search(r'(근거표|대조표|비교표|요건표|일정표|역할표|정리본|전달본|공유본|요청서|의견서|보고서|배정안|변경안|지정안)$', last_w)): o.append(('오류', '문서 이름으로 끝남', "'…작성'·'…정리'처럼 동작으로 끝내기"))
    run = mx = 0
    for w in t.split():
        run = 0 if NJOSA.search(w) else run + 1; mx = max(mx, run)
    if kind in ('tb', 'label') and mx >= 7: o.append(('오류', '조사 없이 명사 7개 이상', '조사(에서·과·을)를 살려 풀어 쓰기'))
    for e in set(re.findall(r'[A-Za-z][A-Za-z&\-]*', t)):
        if e not in vocab['en'] and e not in ('Agent', 'Orchestrator', 'AI', 'AE', 'CD', 'PM', 'AP'): o.append(('경고', '엑셀에 없는 영문', e))
    if kind == 'tb':
        last = re.sub(r'(하기|함)$', '', t.split()[-1])
        if last not in VERBS and last not in vocab['words']: o.append(('경고', '낯선 동작어', f"'{last}' — 엑셀 원문에도 공통 동사에도 없음"))
    for w in re.findall(r'[가-힣]+화(?![가-힣])', t):
        if w not in vocab['words'] and w not in ('변화', '강화', '대화', '전화', '문화', '자동화', '표준화', '체계화', '구체화', '최적화', '고도화', '디지털화'): o.append(('경고', '조어 의심', w))
    return o
# ===== v31 자연스러운 문장 점검 [표현] — 업무명·흐름 문장·상세 설명 공통 =====
NAT = [
  ('오류', '조사 짝', re.compile(r'에\s*(비교|대조)(?:[가-힣]*)'), "비교·대조는 '과/와'와 짝 — 'A를 B와 비교'"),
  ('오류', '조사 짝', re.compile(r'(맞는지|드는지|있는지|되는지)\s*(비교|대조)'), "'…맞는지'에는 '확인'·'검토'"),
  ('오류', '구어체', re.compile(r'(을|를) (보고|보며) '), "'…을 보고' → '…을 바탕으로'·'…에 따라'"),
  ('오류', '구어체', re.compile(r'다시 보고|(을|를) (잡아|묶어|나눠) |(이|가) 낸 |에 주는 '), "문서체로 — 잡아→정리해, 묶어→종합해, 나눠→분류해, 낸→제출한, 주는→미치는"),
  ('경고', '구어체', re.compile(r'[가-힣]+ 같은 [가-힣]'), "'A 같은 B' → 'A 등 B'"),
]
COLLOQ = re.compile(r'(?<![가-힣])(빠진|찾아|만들어|만듭니다|만들고|만든다|겹치는지|겹치는|모아서?|나눠서?|다시|뽑아|뽑은|뽑고|챙겨|살펴|봅니다|보여 ?줍니다|보여 ?줌|맡는|덮는|이어받습니다|고치세요)(?![가-힣])')   # v32 구어 어휘 → 누락된·확인해·작성해·중복되는지·취합해·분류해·재-
NAME_CONN = re.compile(r'(?<![가-힣])[가-힣]*(해|하고|하며|하여)\s|(?<![가-힣])(찾아|모아|나눠|묶어|맞춰|받아|잡아|넣어|보며)\s')   # v32 업무명 안 연결어미 → '및'으로
ACT_WA = re.compile(r'(정리|확인|확정|작성|검토|취합|수합|공유|전달)(와|과)\s')   # v32 동작을 '와/과'로 이음 → '및'
MIXED = re.compile(r'(?:^|\s)[^,\s]+(?:와|과)\s+[^,]{1,18},\s*[^,]+')   # 'A와 B, C' — 셋 이상 나열은 쉼표로 통일
def nat_rules(t, kind):
    o = []
    for lvl, code, rx, why in NAT:
        if rx.search(t): o.append((lvl, code, why))
    if COLLOQ.search(t): o.append(('오류', '구어 어휘', "빠진→누락된, 찾아→확인해, 만들어→작성해, 겹치는지→중복되는지, 모아→취합해, 나눠→분류해, 다시→재-"))
    if kind == 'name' and NAME_CONN.search(t + ' '): o.append(('오류', '업무명 연결어미', "업무명은 '…확인 및 …검토'처럼 '및'으로 잇고 명사로 끝냄"))
    if kind == 'name' and ACT_WA.search(t): o.append(('오류', '동작을 와/과로 이음', "'정리와 공유' → '정리 및 공유'"))
    mm = next((m for m in MIXED.finditer(t) if re.sub(r'(와|과)$', '', m.group(0).split()[0]) + m.group(0).split()[0][-1] not in ChainWa.NOUN), None)   # v35: 성과·결과·효과처럼 '과'로 끝나는 명사는 접속이 아님
    if mm and kind == 'name':
        mid = mm.group(0).split(',')[0].split()[1:]   # '와/과' 뒤부터 쉼표 앞까지 — 조사로 끝나는 말이 끼면 다른 구절
        if not any(re.search(r'(에서|에게|에|을|를|이|가|은|는|로|으로|의)$', w) for w in mid): o.append(('오류', '섞인 나열', "셋 이상은 'A, B, C'처럼 쉼표로 — '와/과'와 섞지 않기"))
    subj = re.match(r'^(.+?(?:Agent|Orchestrator|AE|PM|CD|AP|담당자|책임자))(?:와|과|가|이)?\s', t)   # 주어(Agent·담당자 이름)에 든 말은 반복으로 보지 않음
    body = t[subj.end():] if subj else t
    ws = [re.sub(r'(을|를|에서|에게|에|과|와|의|로|으로|은|는|이|가|도)$', '', w) for w in re.findall(r'[가-힣]{2,}', body)]
    rep = {w for w in ws if ws.count(w) > 1 and w in ('접수', '보고', '정리', '확인', '요청', '공유', '검토', '작성', '전달', '수합', '취합')}
    if rep: o.append(('경고', '같은 말 반복', '·'.join(sorted(rep))))
    return o
def nat_check(D):
    out = []
    for k, t in D.get('tb', {}).items():
        if t.get('lb') and not str(k).startswith('TB-G'):
            for lvl, code, why in nat_rules(t['lb'], 'name'): out.append((lvl, f'tb.{k}', code, t['lb'][:60], why))
    A6n = D.get('_a6names') or {}
    for st, tv in (D.get('tour') or {}).items():
        for bi, bt in enumerate(tv.get('beats', [])):
            for si, sp in enumerate(bt.get('steps', [])):
                for lvl, code, why in nat_rules((sp.get('d') or '').replace('**', ''), 'sent'): out.append((lvl, f'tour.{st}.{bi}.{si}.d', code, (sp.get('d') or '').replace('**', '')[:60], why))
                ids_ = sp.get('ids') or []; src = (D.get('tb', {}).get(ids_[0]) or {}).get('lb') if ids_ else None
                if ids_ and ((sp.get('v') == A6n.get(ids_[0]) and not src) or (str(ids_[0]).startswith('TB-G') and sp.get('v') == src)): continue   # 원문·게이트 이름 그대로
                for lvl, code, why in nat_rules(sp.get('v') or '', 'name'): out.append((lvl, f'tour.{st}.{bi}.{si}.v', code, sp.get('v', '')[:60], why))
    for st, tv in (D.get('tour') or {}).items():   # v33 단계 요약
        for f in ('now', 'chg', 'next'):
            for lvl, code, why in nat_rules(tv.get(f) or '', 'sent'): out.append((lvl, f'tour.{st}.{f}', code, (tv.get(f) or '')[:60], why))
    for k, t in D.get('tb', {}).items():   # v33 소멸 사유
        if t.get('t') == 'X':
            for lvl, code, why in nat_rules(t.get('why') or t.get('note') or '', 'sent'): out.append((lvl, f'tb.{k}.why', code, (t.get('why') or t.get('note') or '')[:60], why))
    for b, st_ in (D.get('story') or {}).items():   # v33 Agent 페이지 문장
        for f in ('intro', 'p', 'hum'):
            for lvl, code, why in nat_rules(st_.get(f) or '', 'sent'): out.append((lvl, f'story.{b}.{f}', code, (st_.get(f) or '')[:60], why))
        for i, x in enumerate(st_.get('pb') or []):
            for lvl, code, why in nat_rules(x if isinstance(x, str) else '', 'sent'): out.append((lvl, f'story.{b}.pb[{i}]', code, str(x)[:60], why))
        for i, x in enumerate(st_.get('imp') or []):
            for j, y in enumerate(x if isinstance(x, list) else []):
                if isinstance(y, str):
                    for lvl, code, why in nat_rules(y, 'sent'): out.append((lvl, f'story.{b}.imp[{i}][{j}]', code, y[:60], why))
        for sid, ss in (st_.get('subs') or {}).items():
            for lvl, code, why in nat_rules(ss.get('e') or '', 'sent'): out.append((lvl, f'story.{b}.subs.{sid}.e', code, (ss.get('e') or '')[:60], why))
            for i, x in enumerate(ss.get('f') or []):
                if isinstance(x, list) and x and isinstance(x[0], str):
                    for lvl, code, why in nat_rules(x[0], 'sent'): out.append((lvl, f'story.{b}.subs.{sid}.f[{i}]', code, x[0][:60], why))
    for k_, v_ in (D.get('ui') or {}).items():   # v34 설계의 화면 문구 칸
        if isinstance(v_, str):
            for lvl, code, why in nat_rules(v_, 'sent'): out.append((lvl, f'ui.{k_}', code, v_[:60], why))
    for sid, s_ in (D.get('subs') or {}).items():
        for lvl, code, why in nat_rules(s_.get('desc') or '', 'sent'): out.append((lvl, f'subs.{sid}.desc', code, (s_.get('desc') or '')[:60], why))
    for b in D.get('bands', []):
        for lvl, code, why in nat_rules(b.get('desc') or '', 'sent'): out.append((lvl, f"bands.{b.get('id')}.desc", code, (b.get('desc') or '')[:60], why))
    for key, m in (D.get('desc') or {}).items():
        if isinstance(m, dict):
            for k, v in m.items():
                for lvl, code, why in nat_rules(v or '', 'sent'): out.append((lvl, f'desc.{key}.{k}', code, (v or '')[:60], why))
    return out

def name_check(D, asis):
    A6 = asis['A6']; txt = ' '.join([a.get('n', '') + ' ' + a.get('inp', '') + ' ' + a.get('sys', '') + ' ' + a.get('out', '') + ' ' + a.get('pain', '') for a in A6.values()] + [a.get('n', '') for a in asis.get('A5', {}).values()])
    vocab = dict(text=txt, en=set(re.findall(r'[A-Za-z][A-Za-z&\-]*', txt)), words=set(re.findall(r'[가-힣]+', txt)))
    out = []
    for k, t in D.get('tb', {}).items():
        if not t.get('lb'): continue
        kind = 'gate' if t.get('t') == 'M' and str(k).startswith('TB-G') else 'tb'
        for lvl, code, why in name_rules(t['lb'], kind, vocab): out.append((lvl, f'tb.{k}', code, t['lb'][:60], why))
    for st, tv in (D.get('tour') or {}).items():
        for bi, bt in enumerate(tv.get('beats', [])):
            for si, sp in enumerate(bt.get('steps', [])):
                ids_ = sp.get('ids') or []; src = (D.get('tb', {}).get(ids_[0]) or {}).get('lb') if ids_ else None
                if ids_ and (sp.get('v') == (A6.get(ids_[0]) or {}).get('n') and not src or str(ids_[0]).startswith('TB-G') and sp.get('v') == src): continue   # v33: 엑셀 원문·게이트 이름 그대로인 이름표는 박스와 같은 글 (원문은 고치지 않음)
                for lvl, code, why in name_rules(sp.get('v', ''), 'label', vocab):
                    if code != '엑셀에 없는 영문': out.append((lvl, f'tour.{st}.{bi}.{si}.v', code, sp.get('v', '')[:60], why))
    for sid, s_ in (D.get('subs') or {}).items():
        for lvl, code, why in name_rules(s_.get('name', ''), 'agent', vocab): out.append((lvl, f'subs.{sid}.name', code, s_.get('name', ''), why))
    # v33 흐름 따라가기 이름표(동그라미 밑): 그 박스의 업무명이거나, 업무명의 말만·같은 순서로·같은 동작으로 끝나게 줄인 것
    TB = D.get('tb', {})
    for st, tv in (D.get('tour') or {}).items():
        for bi, bt in enumerate(tv.get('beats', [])):
            for si, sp in enumerate(bt.get('steps', [])):
                v = (sp.get('v') or '').strip(); ids = sp.get('ids') or []
                if not v or not ids: continue
                nm = (TB.get(ids[0]) or {}).get('lb') or (A6.get(ids[0]) or {}).get('n', '')
                if nm and not label_ok(v, nm): out.append(('오류', f'tour.{st}.{bi}.{si}.v', '이름표 규칙', v[:60], f"업무명 '{nm[:40]}'의 말만·같은 순서로·같은 동작으로 끝나게 (기본은 업무명 그대로)"))
    return out
def label_ok(v, nm):
    clean = lambda x: re.sub(r'\s*\([^()]*\)\s*$', '', re.sub(r'^\[[^\]]+\]\s*', '', x)).replace(',', ' ').split()
    a, b = clean(v), clean(nm)
    if not a or not b: return True
    if a == b: return True
    if a[-1] != b[-1]: return False   # 같은 동작으로 끝남
    i = 0
    for w in a:   # 업무명에 있는 말만, 같은 순서로 (말 일부를 줄인 '자료'←'자료와' 같은 조사 차이는 허용)
        while i < len(b) and not (b[i] == w or b[i].startswith(w)): i += 1
        if i == len(b): return False
        i += 1
    return True

if __name__ == '__main__':
    D = json.load(open(sys.argv[1])); v = check(D)
    if len(sys.argv) > 2:   # v30: 업무명 점검 (엑셀 원문 어휘 기준)
        nv = name_check(D, json.load(open(sys.argv[2], encoding='utf-8')))
        for x in nv: print(*x, sep=' | ')
        ne = sum(1 for x in nv if x[0] == '오류'); print(f'[이름] 오류 {ne}건 · 경고 {len(nv) - ne}건')
        if ne: v = v + [x for x in nv if x[0] == '오류']
        D['_a6names'] = {k: a['n'] for k, a in json.load(open(sys.argv[2], encoding='utf-8'))['A6'].items()}
        tv = nat_check(D)   # v31 [표현]
        for x in tv: print('[표현]', *x, sep=' | ')
        te = sum(1 for x in tv if x[0] == '오류'); print(f'[표현] 오류 {te}건 · 경고 {len(tv) - te}건')
        if te: v = v + [x for x in tv if x[0] == '오류']
    for x in v: print(*x, sep=' | ')
    print(f'위반 {len(v)}건'); sys.exit(2 if v else 0)
